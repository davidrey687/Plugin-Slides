<?php
/**
 * Log events for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$logs = array(
    array('name' => 'view', 'actions' => array('view'), 'legacy' => array('view')),
    array('name' => 'created', 'actions' => array('add'), 'legacy' => array('add')),
    array('name' => 'updated', 'actions' => array('update'), 'legacy' => array('update')),
    array('name' => 'deleted', 'actions' => array('delete'), 'legacy' => array('delete')),
);
