<?php
/**
 * Web services for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'mod_slides_get_deck' => [
        'classname'   => 'mod_slides\external',
        'methodname'  => 'get_deck',
        'description' => 'Load all slides for a presentation.',
        'type'        => 'read',
        'ajax'        => true,
        'login'       => true,
        'capabilities' => 'mod/slides:view',
    ],
    'mod_slides_save_deck' => [
        'classname'   => 'mod_slides\external',
        'methodname'  => 'save_deck',
        'description' => 'Save the full deck for a presentation.',
        'type'        => 'write',
        'ajax'        => true,
        'login'       => true,
        'capabilities' => 'mod/slides:edit',
    ],
];
