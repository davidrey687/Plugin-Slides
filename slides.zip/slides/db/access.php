<?php
/**
 * Capabilities for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$capabilities = array(

    'mod/slides:addinstance' => array(
        'riskbitmask' => RISK_XSS,
        'captype'     => 'write',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => array(
            'manager'    => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
        ),
    ),

    'mod/slides:view' => array(
        'riskbitmask'  => 0,
        'captype'      => 'read',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => array(
            'student'        => CAP_ALLOW,
            'teacher'        => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
        ),
    ),

    'mod/slides:edit' => array(
        'riskbitmask'  => RISK_XSS,
        'captype'      => 'write',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes' => array(
            'editingteacher' => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
        ),
    ),
);
