<?php
/**
 * Upgrade steps for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Schema upgrade steps.
 *
 * @param int $oldversion
 */
function xmldb_mod_slides_upgrade($oldversion) {
    global $CFG, $DB;

    require_once($CFG->libdir . '/ddllib.php');

    $dbman = $DB->get_manager();

    if ($oldversion < 2026093002) {
        // Define table slides_fonts to be created.
        $table = new xmldb_table('slides_fonts');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('slidesid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('fontfamily', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('files', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('css', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Define key slidesid to be added to slides_fonts.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('slidesid', XMLDB_KEY_FOREIGN, ['slidesid'], 'slides', ['id']);

        // Conditionally create table slides_fonts.
        if (!$dbman->table_exists('slides_fonts')) {
            $dbman->create_table($table);
        }

        // Slides savepoint reached.
        upgrade_mod_savepoint(true, 2026093002, 'slides');
    }

    if ($oldversion < 2026100101) {
        // The font bank replaces the import feature: drop its table.
        if ($dbman->table_exists('slides_fonts')) {
            $dbman->drop_table(new xmldb_table('slides_fonts'));
        }

        // Slides savepoint reached.
        upgrade_mod_savepoint(true, 2026100101, 'slides');
    }

    return true;
}

/**
 * Legacy alias - some Moodle versions expect this name.
 */
function xmldb_slides_upgrade($oldversion) {
    return xmldb_mod_slides_upgrade($oldversion);
}
