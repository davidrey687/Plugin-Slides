/**
 * Photo bank dialog — PowerPoint-style stock images, local upload and URL.
 *
 * Three tabs: local bank (pix/stock catalogue), upload file, and from URL.
 * Opens from the toolbar, from an empty image placeholder, or from the
 * slide background picker (mode: element / replace / background).
 *
 * @module     mod_slides/editorImageBank
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([
    'mod_slides/editorState',
    'mod_slides/editorImage',
], function(state, image) {
    'use strict';

    var backdrop = null;
    var dialog = null;
    var catalogPromise = null;
    var opts = {};

    function str(key) {
        return M.util.get_string(key, 'mod_slides');
    }

    function strSafe(key) {
        try { return str(key); } catch (e) { return key; }
    }

    function toastError(message) {
        try {
            var t = document.createElement('div');
            t.className = 'imagebank-toast';
            t.textContent = message;
            document.body.appendChild(t);
            setTimeout(function() {
                if (t.parentNode) { t.parentNode.removeChild(t); }
            }, 5000);
        } catch (ignore) { /* never break apply because of the toast */ }
    }

    function reportError(e) {
        console.error('mod_slides/imagebank:', e);
        toastError(strSafe('imagebankapplyerr') +
            (e && e.message ? ' — ' + e.message : ''));
    }

    /* ---- Catalogue ------------------------------------------------------ */

    function loadCatalog() {
        if (catalogPromise) { return catalogPromise; }
        catalogPromise = fetch(M.cfg.wwwroot + '/mod/slides/classes/local/image_bank_ajax.php', {
            credentials: 'same-origin',
        }).then(function(res) {
            if (!res.ok) { throw new Error('HTTP ' + res.status); }
            return res.json();
        }).then(function(data) {
            if (data.error) { throw new Error(data.error); }
            return data.categories || [];
        }).catch(function(err) {
            catalogPromise = null;
            throw err;
        });
        return catalogPromise;
    }

    /* ---- Insert / apply ------------------------------------------------- */

    function currentBackground() {
        var s = state.get();
        var slide = s.slides[s.current];
        return (slide && slide.background) ? slide.background : {};
    }

    function apply(src, alt) {
        // Selection mode: the caller (link_manager) receives the chosen
        // image and inserts its own element — the bank must not insert.
        if (opts && typeof opts.onSelect === 'function') {
            try { opts.onSelect(src, alt); } catch (e) { reportError(e); }
            close();
            return;
        }
        try {
            if (opts.mode === 'background') {
                var bg = currentBackground();
                var fit = 'cover';
                if (typeof opts.getFit === 'function') {
                    try { fit = opts.getFit() || 'cover'; } catch (e) { fit = 'cover'; }
                }
                state.setSlideBackground(state.get().current, {
                    type: 'image',
                    color: bg.color || '#ffffff',
                    image: src,
                    imageFit: fit,
                });
            } else if (opts.mode === 'replace') {
                state.updateElementAtomic(state.get().current, opts.elemIdx, {
                    src: src,
                    alt: alt || '',
                });
            } else {
                insertElement(src, alt || '');
            }
            close();
        } catch (e) {
            reportError(e);
        }
    }

    /**
     * Insert a new image element sized from its natural dimensions so the
     * aspect ratio is always preserved (max box 440x330 canvas units).
     */
    function insertElement(src, alt) {
        var maxW = 440;
        var maxH = 330;

        function place(w, h) {
            try {
                var s = state.get();
                state.addElement(s.current, Object.assign({}, image.DEFAULTS, {
                    src: src,
                    alt: alt,
                    w: w,
                    h: h,
                    x: Math.max(0, Math.round((960 - w) / 2)),
                    y: 100,
                }));
            } catch (e) {
                reportError(e);
            }
        }

        var probe = new Image();
        probe.onload = function() {
            var nw = probe.naturalWidth || 300;
            var nh = probe.naturalHeight || 200;
            var scale = (nw <= maxW && nh <= maxH) ? 1 : Math.min(maxW / nw, maxH / nh);
            place(Math.round(nw * scale), Math.round(nh * scale));
        };
        probe.onerror = function() {
            place(300, 200);
        };
        probe.src = src;
    }

    /* ---- Dialog --------------------------------------------------------- */

    function close() {
        if (dialog && dialog.parentNode) { dialog.parentNode.removeChild(dialog); }
        if (backdrop && backdrop.parentNode) { backdrop.parentNode.removeChild(backdrop); }
        document.removeEventListener('keydown', onKey, true);
        dialog = null;
        backdrop = null;
        opts = {};
    }

    function onKey(e) {
        if (e.key === 'Escape' && dialog) {
            e.stopPropagation();
            close();
        }
    }

    function open(options) {
        close();
        opts = options || {};

        backdrop = document.createElement('div');
        backdrop.className = 'imagebank-backdrop';
        backdrop.addEventListener('mousedown', close);

        dialog = document.createElement('div');
        dialog.className = 'imagebank-dialog';
        dialog.setAttribute('role', 'dialog');
        dialog.setAttribute('aria-modal', 'true');
        dialog.addEventListener('mousedown', function(e) { e.stopPropagation(); });

        // Header
        var header = document.createElement('div');
        header.className = 'imagebank-header';
        var title = document.createElement('div');
        title.className = 'imagebank-title';
        title.textContent = str('imagebank');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'imagebank-close';
        closeBtn.setAttribute('aria-label', strSafe('imagebankclose'));
        closeBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';
        closeBtn.addEventListener('click', close);
        header.appendChild(title);
        header.appendChild(closeBtn);
        dialog.appendChild(header);

        // Tabs
        var tabs = document.createElement('div');
        tabs.className = 'imagebank-tabs';
        var panes = {};
        var tabDefs = [
            { id: 'bank', label: str('imagebank') },
            { id: 'upload', label: str('imagebankupload') },
            { id: 'url', label: str('imagebankurl') },
        ];
        tabDefs.forEach(function(def, i) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'imagebank-tab' + (i === 0 ? ' is-active' : '');
            btn.textContent = def.label;
            btn.addEventListener('click', function() {
                tabs.querySelectorAll('.imagebank-tab').forEach(function(t) { t.classList.remove('is-active'); });
                btn.classList.add('is-active');
                Object.keys(panes).forEach(function(k) {
                    panes[k].style.display = (k === def.id) ? 'block' : 'none';
                });
                if (def.id === 'url' && panes.url && panes.url.input) {
                    panes.url.input.focus();
                }
            });
            tabs.appendChild(btn);
        });
        dialog.appendChild(tabs);

        // Body
        var body = document.createElement('div');
        body.className = 'imagebank-body';
        dialog.appendChild(body);

        buildBankPane(body, panes);
        buildUploadPane(body, panes);
        buildUrlPane(body, panes);

        // Footer
        var footer = document.createElement('div');
        footer.className = 'imagebank-footer';
        var hint = document.createElement('span');
        hint.textContent = str('imagebankhint');
        footer.appendChild(hint);
        dialog.appendChild(footer);

        document.body.appendChild(backdrop);
        backdrop.appendChild(dialog);
        document.addEventListener('keydown', onKey, true);
    }

    /* ---- Tab 1: local bank --------------------------------------------- */

    function buildBankPane(body, panes) {
        var pane = document.createElement('div');
        pane.style.display = 'block';

        var tools = document.createElement('div');
        tools.className = 'imagebank-tools';

        var search = document.createElement('input');
        search.type = 'search';
        search.className = 'imagebank-search';
        search.placeholder = str('imagebanksearch');
        search.setAttribute('aria-label', str('imagebanksearch'));
        tools.appendChild(search);

        var chips = document.createElement('div');
        chips.className = 'imagebank-chips';
        tools.appendChild(chips);
        pane.appendChild(tools);

        var grid = document.createElement('div');
        grid.className = 'imagebank-grid';
        pane.appendChild(grid);

        var status = document.createElement('div');
        status.className = 'imagebank-status';
        status.textContent = str('imagebankloading');
        pane.appendChild(status);

        body.appendChild(pane);
        panes.bank = pane;

        var all = [{ id: '', label: str('imagebankall') }];
        var activeCat = '';
        var flat = [];

        function renderChips() {
            chips.textContent = '';
            all.forEach(function(cat) {
                var chip = document.createElement('button');
                chip.type = 'button';
                chip.className = 'imagebank-chip' + (cat.id === activeCat ? ' is-active' : '');
                chip.textContent = cat.label;
                chip.addEventListener('click', function() {
                    activeCat = cat.id;
                    renderChips();
                    renderGrid();
                });
                chips.appendChild(chip);
            });
        }

        function renderGrid() {
            var q = (search.value || '').toLowerCase().trim();
            grid.textContent = '';
            var shown = 0;
            flat.forEach(function(img) {
                if (activeCat && img.cat !== activeCat) { return; }
                if (q && (img.name || '').toLowerCase().indexOf(q) === -1) { return; }
                shown++;
                var item = document.createElement('button');
                item.type = 'button';
                item.className = 'imagebank-item';
                item.title = img.name || '';
                var thumb = document.createElement('img');
                thumb.loading = 'lazy';
                thumb.alt = img.name || '';
                thumb.src = img.thumb;
                thumb.addEventListener('error', function() {
                    if (thumb.src !== img.url) { thumb.src = img.url; }
                });
                item.appendChild(thumb);
                item.addEventListener('click', function() {
                    apply(img.url, img.name || '');
                });
                grid.appendChild(item);
            });
            status.style.display = shown ? 'none' : 'block';
            if (!shown) { status.textContent = str('imagebankempty'); }
        }

        search.addEventListener('input', renderGrid);

        loadCatalog().then(function(categories) {
            all = [{ id: '', label: str('imagebankall') }];
            categories.forEach(function(cat) {
                all.push({ id: cat.id, label: cat.label });
                cat.images.forEach(function(im) {
                    flat.push({
                        cat: cat.id,
                        url: im.url,
                        thumb: im.thumb,
                        name: im.name,
                    });
                });
            });
            renderChips();
            renderGrid();
        }).catch(function() {
            status.textContent = str('errorloading');
        });
    }

    /* ---- Tab 2: upload -------------------------------------------------- */

    function buildUploadPane(body, panes) {
        var pane = document.createElement('div');
        pane.style.display = 'none';

        var drop = document.createElement('div');
        drop.className = 'imagebank-drop';
        drop.textContent = str('imagebankdrop');
        pane.appendChild(drop);

        var input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.style.display = 'none';
        pane.appendChild(input);

        function handleFile(file) {
            if (!file || file.type.indexOf('image/') !== 0) { return; }
            var root = document.getElementById('slides-editor');
            if (!root) { return; }
            var cmid = parseInt(root.dataset.cmid, 10);
            var sesskey = root.dataset.sesskey;
            if (!cmid || !sesskey) { return; }

            var fd = new FormData();
            fd.append('cmid', cmid);
            fd.append('sesskey', sesskey);
            fd.append('media', file, file.name || 'image.png');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', M.cfg.wwwroot + '/mod/slides/classes/local/media_upload_ajax.php', true);
            xhr.timeout = 60000;
            xhr.onload = function() {
                if (xhr.status === 200) {
                    try {
                        var res = JSON.parse(xhr.responseText);
                        if (res && res.url) {
                            apply(res.url, file.name);
                            return;
                        }
                    } catch (e) { /* ignore */ }
                }
            };
            xhr.send(fd);
        }

        drop.addEventListener('click', function() { input.click(); });
        input.addEventListener('change', function() { handleFile(input.files[0]); });
        ['dragover', 'dragenter'].forEach(function(ev) {
            drop.addEventListener(ev, function(e) {
                e.preventDefault();
                drop.classList.add('is-over');
            });
        });
        ['dragleave', 'drop'].forEach(function(ev) {
            drop.addEventListener(ev, function(e) {
                e.preventDefault();
                drop.classList.remove('is-over');
            });
        });
        drop.addEventListener('drop', function(e) {
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleFile(e.dataTransfer.files[0]);
            }
        });

        body.appendChild(pane);
        panes.upload = pane;
    }

    /* ---- Tab 3: from URL ------------------------------------------------ */

    function buildUrlPane(body, panes) {
        var pane = document.createElement('div');
        pane.style.display = 'none';

        var row = document.createElement('div');
        row.className = 'imagebank-urlrow';

        var input = document.createElement('input');
        input.type = 'url';
        input.placeholder = 'https://…';
        input.setAttribute('aria-label', str('imagebankurl'));

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-primary btn-sm';
        btn.textContent = str('imagebankurlbtn');

        row.appendChild(input);
        row.appendChild(btn);
        pane.appendChild(row);

        var msg = document.createElement('div');
        msg.className = 'imagebank-urlmsg';
        pane.appendChild(msg);

        function tryInsert() {
            var url = (input.value || '').trim();
            if (!url) { return; }
            msg.textContent = str('imagebankloading');
            msg.classList.remove('is-error');
            var probe = new Image();
            probe.onload = function() {
                apply(url, '');
            };
            probe.onerror = function() {
                msg.textContent = str('imagebankurlerr');
                msg.classList.add('is-error');
            };
            probe.src = url;
        }

        btn.addEventListener('click', tryInsert);
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); tryInsert(); }
        });

        body.appendChild(pane);
        panes.url = pane;
        panes.url.input = input;
    }

    return {
        open: open,
        close: close,
    };
});
