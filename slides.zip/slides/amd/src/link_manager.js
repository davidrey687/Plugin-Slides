/**
 * Interactive links on images, shapes and text buttons.
 *
 * Owns two pieces of UI:
 *  1. The enriched link modal (URL + target + origin source). In create mode
 *     three tabs pick what the link is attached to — a text button (existing
 *     `link` element type), an image chosen through the photo bank, or a
 *     shape chosen through the shape picker. In edit mode it re-configures
 *     the link already attached to the selected element.
 *  2. The floating toolbar rendered over the selected element in the editor
 *     (🔗 chip + "Edit link" / "Remove link"). The primary click still
 *     belongs to move/resize: the bar only handles its own buttons and
 *     stops propagation so pressing it never starts a drag or a deselect.
 *
 * Navigation itself lives in viewer.js: a linked element's whole container
 * opens the URL there; the editor never navigates (drag owns the click).
 *
 * @module     mod_slides/link_manager
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([
    'mod_slides/editorState',
    'mod_slides/editorImageBank',
    'mod_slides/editorImage',
    'mod_slides/editorShapes',
    'mod_slides/editorLink',
    'mod_slides/shapes_library',
], function(state, imagebank, image, shapes, link, shapesLib) {
    'use strict';

    /** Element types the floating toolbar and edit modal accept. */
    var LINKABLE = ['image', 'shape', 'text', 'link'];
    var CANVAS_W = 960;

    var ctx = null;       // { shapePicker } — injected by editorApp
    var backdrop = null;  // modal backdrop node currently open
    var modal = null;     // modal dialog node currently open

    function str(key) {
        try { return M.util.get_string(key, 'mod_slides'); } catch (e) { return key; }
    }

    /**
     * Inject cross-module openers (shape picker lives in editorApp so this
     * module keeps no circular dependency on it).
     *
     * @param {{shapePicker: Function}} opts
     */
    function init(opts) {
        ctx = {
            shapePicker: (opts && typeof opts.shapePicker === 'function') ? opts.shapePicker : null,
        };
    }

    /* =====================================================================
     *  URL validation — same rules the original link dialog applied
     * ===================================================================== */

    function validateUrl(raw) {
        var url = (raw || '').trim();
        if (!url) { return { error: true }; }
        if (!/^https?:\/\//i.test(url) && !/^\/\//.test(url)) {
            url = 'https://' + url;
        }
        var hostPart = url.replace(/^https?:\/\//i, '').split(/[\/?#]/)[0];
        if (hostPart.indexOf('.') === -1 && hostPart !== 'localhost' && hostPart.indexOf(':') === -1) {
            return { error: true };
        }
        return { url: url };
    }

    /* =====================================================================
     *  Enriched link modal
     * ===================================================================== */

    /**
     * @param {{mode?: 'create'|'edit', slideIdx?: number, elemIdx?: number}} options
     */
    function open(options) {
        close();
        var opts = options || {};
        var s = state.get();
        var slideIdx = (typeof opts.slideIdx === 'number') ? opts.slideIdx : s.current;
        var elemIdx = (typeof opts.elemIdx === 'number') ? opts.elemIdx : null;
        var mode = opts.mode === 'create' ? 'create' : 'edit';

        var el = null;
        if (mode === 'edit') {
            var slide = s.slides[slideIdx];
            el = slide && slide.elements[elemIdx];
            if (!el || LINKABLE.indexOf(el.type) === -1) { return; }
        }

        // Modal session state.
        var tab = 'text';                       // create mode: text | image | shape
        var pickedImage = null;                 // {src, alt}
        var pickedShape = '';

        backdrop = document.createElement('div');
        backdrop.className = 'link-dialog-backdrop';

        modal = document.createElement('div');
        modal.className = 'link-dialog link-dialog--rich';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');

        /* ---- Header ---- */
        var header = document.createElement('div');
        header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;' +
            'gap:10px;padding:14px 18px;border-bottom:1px solid #e9ecef;';

        var titleRow = document.createElement('div');
        titleRow.style.cssText = 'display:flex;align-items:center;gap:8px;min-width:0;';
        var title = document.createElement('div');
        title.textContent = str('linkmodaltitle');
        title.style.cssText = 'font-size:15px;font-weight:600;color:#212529;';
        titleRow.appendChild(title);

        if (mode === 'edit' && el) {
            var origin = document.createElement('span');
            origin.className = 'link-origin-chip';
            origin.textContent = str('type-' + (el.type || 'text'));
            titleRow.appendChild(origin);
        }
        header.appendChild(titleRow);

        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.setAttribute('aria-label', str('cancel'));
        closeBtn.style.cssText = 'border:none;background:none;font-size:20px;line-height:1;' +
            'cursor:pointer;color:#6c757d;padding:0 4px;';
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', function(e) { e.stopPropagation(); close(); });
        header.appendChild(closeBtn);
        modal.appendChild(header);

        /* ---- Body ---- */
        var body = document.createElement('div');
        body.style.cssText = 'padding:18px;display:flex;flex-direction:column;gap:14px;';

        function addField(labelText, inputType, placeholder, value) {
            var wrap = document.createElement('div');
            wrap.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
            var lbl = document.createElement('label');
            lbl.textContent = labelText;
            lbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
            var input = document.createElement('input');
            input.type = inputType;
            input.placeholder = placeholder || '';
            if (value !== undefined) { input.value = value; }
            input.style.cssText = 'padding:8px 10px;border:1px solid #ced4da;border-radius:6px;' +
                'font-size:14px;outline:none;transition:border-color 0.15s;';
            input.addEventListener('focus', function() { input.style.borderColor = '#0d6efd'; });
            input.addEventListener('blur', function() { input.style.borderColor = '#ced4da'; });
            wrap.appendChild(lbl);
            wrap.appendChild(input);
            body.appendChild(wrap);
            return input;
        }

        /* Origin tabs (create mode only) */
        var tabWrap = null;
        var tabBtns = {};
        var sectionText = null;
        var sectionImage = null;
        var sectionShape = null;

        if (mode === 'create') {
            tabWrap = document.createElement('div');
            tabWrap.className = 'link-modal-tabs';
            ['text', 'image', 'shape'].forEach(function(key) {
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'link-modal-tab' + (key === tab ? ' is-active' : '');
                b.textContent = str(key === 'text' ? 'linktabtext' : 'type-' + key);
                b.addEventListener('click', function(e) {
                    e.stopPropagation();
                    setTab(key);
                });
                tabBtns[key] = b;
                tabWrap.appendChild(b);
            });
            body.appendChild(tabWrap);
        }

        /* Visible name (text buttons, and edit mode for text/link elements) */
        var nameFieldWrap = null;
        var nameInput = null;
        var showName = (mode === 'edit' && el && (el.type === 'text' || el.type === 'link')) ||
            mode === 'create';
        if (showName) {
            nameInput = addField(str('linkname'), 'text', str('linkname'),
                mode === 'edit' && el ? (el.text || '') : '');
            nameFieldWrap = nameInput.parentNode;
        }

        /* Destination URL + target window */
        var urlInput = addField(str('linkurl'), 'text', 'https://www.ejemplo.com',
            mode === 'edit' && el ? (el.url || '') : '');

        var targetWrap = document.createElement('div');
        targetWrap.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
        var targetLbl = document.createElement('label');
        targetLbl.textContent = str('linktarget');
        targetLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        var targetSel = document.createElement('select');
        targetSel.style.cssText = 'padding:8px 10px;border:1px solid #ced4da;border-radius:6px;' +
            'font-size:14px;outline:none;background:#fff;transition:border-color 0.15s;';
        targetSel.addEventListener('focus', function() { targetSel.style.borderColor = '#0d6efd'; });
        targetSel.addEventListener('blur', function() { targetSel.style.borderColor = '#ced4da'; });
        [['_blank', 'linknewtab'], ['_self', 'linksametab']].forEach(function(pair) {
            var o = document.createElement('option');
            o.value = pair[0];
            o.textContent = str(pair[1]);
            targetSel.appendChild(o);
        });
        var initialTarget = (mode === 'edit' && el && el.target === '_self') ? '_self' : '_blank';
        targetSel.value = initialTarget;
        targetWrap.appendChild(targetLbl);
        targetWrap.appendChild(targetSel);
        body.appendChild(targetWrap);

        /* Source sections (create mode) */
        var imageSection = null;
        var imageChip = null;
        var shapeSection = null;
        var shapeChip = null;

        if (mode === 'create') {
            sectionText = nameFieldWrap;

            imageSection = document.createElement('div');
            imageSection.style.cssText = 'display:flex;flex-direction:column;gap:8px;';
            var pickImgBtn = document.createElement('button');
            pickImgBtn.type = 'button';
            pickImgBtn.className = 'btn btn-outline-primary btn-sm';
            pickImgBtn.textContent = str('linkpickimage');
            pickImgBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                imagebank.open({
                    mode: 'linkpick',
                    onSelect: function(src, alt) {
                        pickedImage = { src: src, alt: alt || '' };
                        renderImageChip();
                    },
                });
            });
            imageSection.appendChild(pickImgBtn);
            imageChip = document.createElement('div');
            imageChip.className = 'link-source-chip';
            imageChip.style.display = 'none';
            imageSection.appendChild(imageChip);
            body.appendChild(imageSection);
            sectionImage = imageSection;

            shapeSection = document.createElement('div');
            shapeSection.style.cssText = 'display:flex;flex-direction:column;gap:8px;';
            var pickShapeBtn = document.createElement('button');
            pickShapeBtn.type = 'button';
            pickShapeBtn.className = 'btn btn-outline-primary btn-sm';
            pickShapeBtn.textContent = str('linkpickshape');
            pickShapeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                if (!ctx || !ctx.shapePicker) { return; }
                ctx.shapePicker(pickShapeBtn, function(key) {
                    pickedShape = key;
                    renderShapeChip();
                });
            });
            shapeSection.appendChild(pickShapeBtn);
            shapeChip = document.createElement('div');
            shapeChip.className = 'link-source-chip';
            shapeChip.style.display = 'none';
            shapeSection.appendChild(shapeChip);
            body.appendChild(shapeSection);
            sectionShape = shapeSection;
        }

        function renderImageChip() {
            if (!pickedImage) { imageChip.style.display = 'none'; return; }
            imageChip.textContent = '';
            var img = document.createElement('img');
            img.src = pickedImage.src;
            img.alt = '';
            var name = document.createElement('span');
            name.className = 'link-source-name';
            name.textContent = pickedImage.alt || str('type-image');
            imageChip.appendChild(img);
            imageChip.appendChild(name);
            imageChip.style.display = '';
        }

        function renderShapeChip() {
            if (!pickedShape) { shapeChip.style.display = 'none'; return; }
            shapeChip.textContent = '';
            var thumb = document.createElement('div');
            thumb.className = 'link-source-thumb';
            thumb.style.cssText = shapesLib.thumbStyle(pickedShape, '#0d6efd');
            var name = document.createElement('span');
            name.className = 'link-source-name';
            try {
                name.textContent = M.util.get_string('shape-' + pickedShape, 'mod_slides');
            } catch (e) {
                name.textContent = pickedShape;
            }
            shapeChip.appendChild(thumb);
            shapeChip.appendChild(name);
            shapeChip.style.display = '';
        }

        function setTab(next) {
            tab = next;
            Object.keys(tabBtns).forEach(function(k) {
                tabBtns[k].classList.toggle('is-active', k === tab);
            });
            // In create mode the name only belongs to the text button; the
            // other tabs choose their visual source instead.
            if (nameFieldWrap) { nameFieldWrap.style.display = tab === 'text' ? '' : 'none'; }
            if (sectionImage) { sectionImage.style.display = tab === 'image' ? '' : 'none'; }
            if (sectionShape) { sectionShape.style.display = tab === 'shape' ? '' : 'none'; }
        }
        if (mode === 'create') { setTab('text'); }

        /* Error message */
        var errEl = document.createElement('div');
        errEl.style.cssText = 'font-size:12px;color:#dc3545;min-height:16px;display:none;';
        body.appendChild(errEl);

        modal.appendChild(body);

        /* ---- Footer ---- */
        var footer = document.createElement('div');
        footer.style.cssText = 'display:flex;justify-content:flex-end;gap:8px;' +
            'padding:12px 18px;background:#f8f9fa;border-top:1px solid #e9ecef;';

        var cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.textContent = str('cancel');
        cancelBtn.style.cssText = 'padding:7px 16px;font-size:13px;';
        cancelBtn.addEventListener('click', function(e) { e.stopPropagation(); close(); });

        var saveBtn = document.createElement('button');
        saveBtn.type = 'button';
        saveBtn.className = 'btn btn-primary';
        saveBtn.textContent = str('save');
        saveBtn.style.cssText = 'padding:7px 16px;font-size:13px;';
        saveBtn.addEventListener('click', function(e) { e.stopPropagation(); submit(); });

        footer.appendChild(cancelBtn);
        footer.appendChild(saveBtn);
        modal.appendChild(footer);

        backdrop.addEventListener('click', close);
        document.body.appendChild(backdrop);
        backdrop.appendChild(modal);
        modal.addEventListener('click', function(e) { e.stopPropagation(); });

        modal.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') { e.stopPropagation(); close(); }
            if (e.key === 'Enter') { e.preventDefault(); submit(); }
        });
        if (!window.matchMedia('(pointer: coarse)').matches) {
            urlInput.focus();
        }

        function showErr(msg) {
            errEl.textContent = msg;
            errEl.style.display = 'block';
        }

        function submit() {
            var res = validateUrl(urlInput.value);
            if (res.error) {
                showErr(str('linkinvalidurl'));
                urlInput.focus();
                return;
            }
            var url = res.url;
            var target = targetSel.value === '_self' ? '_self' : '_blank';

            if (mode === 'edit') {
                var props = { url: url, target: target };
                if (el.type === 'text' || el.type === 'link') {
                    props.text = nameInput.value.trim() || url;
                }
                state.updateElementAtomic(slideIdx, elemIdx, props);
                close();
                return;
            }

            if (tab === 'text') {
                state.addElement(slideIdx, Object.assign({}, link.DEFAULTS, {
                    text: nameInput.value.trim() || url,
                    url: url,
                    target: target,
                }));
                close();
                return;
            }

            if (tab === 'image') {
                if (!pickedImage) { showErr(str('linkimagerequired')); return; }
                var picked = pickedImage;
                close();
                placeLinkedImage(slideIdx, picked.src, picked.alt, url, target);
                return;
            }

            // tab === 'shape'
            if (!pickedShape) { showErr(str('linkshaperequired')); return; }
            var shapeOpts = Object.assign({}, shapes.DEFAULTS, {
                shape: pickedShape,
                url: url,
                target: target,
            });
            if (pickedShape === 'circle' || pickedShape === 'ellipse') {
                var size = Math.min(shapeOpts.w, shapeOpts.h);
                shapeOpts.w = size;
                shapeOpts.h = size;
            }
            state.addElement(slideIdx, shapeOpts);
            close();
        }
    }

    function close() {
        if (backdrop && backdrop.parentNode) { backdrop.parentNode.removeChild(backdrop); }
        backdrop = null;
        modal = null;
    }

    /**
     * Add an image element sized from its natural dimensions (same 440x330
     * max-box rule the photo bank uses) carrying the link URL/target.
     */
    function placeLinkedImage(slideIdx, src, alt, url, target) {
        var maxW = 440;
        var maxH = 330;

        function place(w, h) {
            state.addElement(slideIdx, Object.assign({}, image.DEFAULTS, {
                src: src,
                alt: alt || '',
                url: url,
                target: target,
                w: w,
                h: h,
                x: Math.max(0, Math.round((CANVAS_W - w) / 2)),
                y: 100,
            }));
        }

        var probe = new Image();
        probe.onload = function() {
            var nw = probe.naturalWidth || 300;
            var nh = probe.naturalHeight || 200;
            var scale = (nw <= maxW && nh <= maxH) ? 1 : Math.min(maxW / nw, maxH / nh);
            place(Math.round(nw * scale), Math.round(nh * scale));
        };
        probe.onerror = function() { place(300, 200); };
        probe.src = src;
    }

    /* =====================================================================
     *  Floating toolbar over the selected element (editor only)
     * ===================================================================== */

    function positionBar(bar, el) {
        bar.style.left = Math.max(0, Math.min(el.x, CANVAS_W - 210)) + 'px';
        bar.style.top = (el.y >= 40 ? el.y - 40 : el.y + el.h + 8) + 'px';
    }

    /**
     * Build the 🔗 toolbar for the selected element.
     *
     * @param {HTMLElement} canvasEl Editor canvas (bar is positioned in its
     *                               coordinate space, crop-toolbar pattern).
     * @param {Object} el            Selected element.
     * @param {number} slideIdx      Slide index.
     * @param {number} elemIdx       Element index.
     * @return {{node: HTMLElement, update: Function}|null}
     */
    function renderToolbar(canvasEl, el, slideIdx, elemIdx) {
        if (!el || LINKABLE.indexOf(el.type) === -1) { return null; }

        var bar = document.createElement('div');
        bar.className = 'element-link-toolbar';

        var chip = document.createElement('span');
        chip.className = 'element-link-chip';
        chip.textContent = '\uD83D\uDD17'; // 🔗
        chip.title = str('linkurl');
        chip.setAttribute('aria-hidden', 'true');
        bar.appendChild(chip);

        var editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'btn btn-sm btn-secondary element-link-btn';
        editBtn.textContent = str('editlink');
        editBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            open({ mode: 'edit', slideIdx: slideIdx, elemIdx: elemIdx });
        });
        bar.appendChild(editBtn);

        if (el.url) {
            var removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'btn btn-sm btn-outline-danger element-link-btn';
            removeBtn.textContent = str('removelink');
            removeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                state.updateElementAtomic(slideIdx, elemIdx, { url: '', target: '_blank' });
            });
            bar.appendChild(removeBtn);
        }

        // Pressing the bar never starts a drag, a resize or a deselect.
        bar.addEventListener('pointerdown', function(e) { e.stopPropagation(); });
        bar.addEventListener('click', function(e) { e.stopPropagation(); });

        positionBar(bar, el);
        canvasEl.appendChild(bar);

        return {
            node: bar,
            update: function(liveEl) { positionBar(bar, liveEl); },
        };
    }

    return {
        init: init,
        open: open,
        close: close,
        renderToolbar: renderToolbar,
        LINKABLE: LINKABLE,
    };
});
