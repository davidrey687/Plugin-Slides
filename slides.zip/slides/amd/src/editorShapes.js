/**
 * Shape element type — powered by shapes_library.
 * 2-layer render: outer (position/selection/handles) + inner (fill/clip-path).
 *
 * @module     mod_slides/editorShapes
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/shapes_library'], function(shapesLib) {
    'use strict';

    var TYPE = 'shape';

    var SHAPES = shapesLib.SHAPES;

    var DEFAULTS = {
        type: TYPE,
        shape: 'rect',
        x: 100,
        y: 100,
        w: 300,
        h: 200,
        fill: '#0d6efd',
        stroke: '#0b5ed7',
        strokeWidth: 2,
        angle: 0,
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
    }

    function innerStyle(el) {
        return shapesLib.innerStyle(el);
    }

    function getShapeOptions() {
        return shapesLib.getShapeOptions();
    }

    var PROPERTY_DEFS = [
        { key: 'shape',       label: 'shape',       control: 'select', options: [] },
        { key: 'fill',        label: 'fill',         control: 'color', clearable: true, clearLabel: 'fillnone' },
        { key: 'stroke',      label: 'stroke',       control: 'color' },
        { key: 'strokeWidth', label: 'strokewidth',  control: 'number', min: 0, max: 20, step: 1 },
        { key: 'angle',       label: 'angle',        control: 'number', min: 0, max: 360, step: 1 },
        { key: 'opacity',     label: 'opacity',      control: 'number', min: 0, max: 100, step: 5 },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor', label: 'shadow-color',  control: 'color' },
        { key: 'shadowBlur',  label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',     label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',     label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        SHAPES: SHAPES,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        getShapeOptions: getShapeOptions,
        PROPERTY_DEFS: PROPERTY_DEFS,
    };
});
