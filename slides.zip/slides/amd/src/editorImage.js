/**
 * Image element type — inserted via file picker or drag-drop.
 *
 * @module     mod_slides/editorImage
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var TYPE = 'image';

    var DEFAULTS = {
        type: TYPE,
        x: 100,
        y: 100,
        w: 300,
        h: 200,
        src: '',
        alt: '',
        opacity: 100,
        borderRadius: 0,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
    }

    function innerStyle(el) {
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var br = el.borderRadius || 0;
        var style = 'width:100%;height:100%;object-fit:contain;opacity:' + opacity +
            ';border-radius:' + br + 'px;pointer-events:none;display:block;';
        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return style;
    }

    function renderImage(el) {
        var img = document.createElement('img');
        img.src = el.src || '';
        img.alt = el.alt || '';
        img.style.cssText = innerStyle(el);
        img.draggable = false;
        return img;
    }

    /* ---- Crop helpers ----------------------------------------------------
     * el.crop = {x, y, w, h} as fractions of the source image. The frame
     * shows exactly the crop region: the <img> is scaled to frame/crop and
     * offset so the region lands on the frame (object-fit fills it).
     * -------------------------------------------------------------------- */

    function r4(v) {
        return Math.round(v * 10000) / 10000;
    }

    function hasCrop(el) {
        var c = el && el.crop;
        return !!(c && c.w > 0 && c.h > 0 && (c.x > 0 || c.y > 0 || c.w < 1 || c.h < 1));
    }

    /**
     * Full style for the <img> when the element carries a crop rect.
     * Returns '' when there is no crop (callers keep their legacy style).
     */
    function croppedImgStyle(el) {
        var c = el.crop;
        if (!c || !(c.w > 0) || !(c.h > 0)) { return ''; }
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        return 'position:absolute;max-width:none;' +
            'width:' + r4(100 / c.w) + '%;height:' + r4(100 / c.h) + '%;' +
            'left:' + r4(-(c.x / c.w) * 100) + '%;top:' + r4(-(c.y / c.h) * 100) + '%;' +
            'object-fit:fill;opacity:' + opacity + ';display:block;';
    }

    /**
     * Container extras needed when an image is cropped (clip + corner radius).
     */
    function croppedContainerStyle(el) {
        return 'overflow:hidden;border-radius:' + (el.borderRadius || 0) + 'px;';
    }

    var PROPERTY_DEFS = [
        { key: 'alt',           label: 'alt',           control: 'text' },
        { key: 'opacity',       label: 'opacity',       control: 'number', min: 0, max: 100, step: 5 },
        { key: 'borderRadius',  label: 'borderradius',  control: 'number', min: 0, max: 100, step: 1 },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color',  control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        renderImage: renderImage,
        PROPERTY_DEFS: PROPERTY_DEFS,
        hasCrop: hasCrop,
        croppedImgStyle: croppedImgStyle,
        croppedContainerStyle: croppedContainerStyle,
    };
});
