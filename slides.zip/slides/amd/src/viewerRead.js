/**
 * Viewer read-aloud — Web Speech API text-to-speech for the slides viewer.
 *
 * @module     mod_slides/viewerRead
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var STORAGE_KEY = 'mod_slides_read';
    var MAX_FRAG = 180;
    var Y_TOL = 8;

    var cfg = null;
    var btn = null, panel = null, labelEl = null;
    var rateInput = null, rateValueEl = null, voiceSelect = null, readAllInput = null;
    var supported = false;
    var state = 'idle';
    var generation = 0;
    var voices = [];
    var watchdog = null;
    var prefs = { rate: 1, voiceURI: '', readAll: false };

    /* ---- Preferences (localStorage) --------------------------------------- */
    function loadPrefs() {
        try {
            var raw = window.localStorage.getItem(STORAGE_KEY);
            if (!raw) { return; }
            var p = JSON.parse(raw);
            if (p && typeof p === 'object') {
                var r = parseFloat(p.rate);
                if (r >= 0.5 && r <= 2) { prefs.rate = r; }
                if (typeof p.voiceURI === 'string') { prefs.voiceURI = p.voiceURI; }
                prefs.readAll = !!p.readAll;
            }
        } catch (e) { /* localStorage unavailable */ }
    }

    function savePrefs() {
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
        } catch (e) { /* localStorage unavailable */ }
    }

    /* ---- Slide text extraction -------------------------------------------- */
    function elementSpeech(el) {
        if (!el || el._visible === false) { return null; }
        var type = el.type || 'text';
        if (type === 'text' || type === 'footer' || type === 'link') {
            return typeof el.text === 'string' ? el.text : '';
        }
        if (type === 'chart') {
            return typeof el.title === 'string' ? el.title : '';
        }
        return null;
    }

    function slideText(slide) {
        if (!slide) { return ''; }
        var items = [];
        (slide.elements || []).forEach(function(el) {
            var txt = elementSpeech(el);
            if (txt === null) { return; }
            txt = String(txt).replace(/\s+/g, ' ').trim();
            if (!txt) { return; }
            items.push({ y: Number(el.y) || 0, x: Number(el.x) || 0, text: txt });
        });
        if (!items.length) { return ''; }

        items.sort(function(a, b) { return a.y - b.y; });
        var rows = [], row = null;
        items.forEach(function(it) {
            if (row && it.y - row.y0 <= Y_TOL) { row.items.push(it); }
            else { row = { y0: it.y, items: [it] }; rows.push(row); }
        });

        var parts = [];
        rows.forEach(function(r) {
            r.items.sort(function(a, b) { return a.x - b.x; });
            r.items.forEach(function(it) { parts.push(it.text); });
        });

        var joined = '';
        parts.forEach(function(p, i) {
            if (i === 0) { joined = p; return; }
            joined += /[.!?…:,;]$/.test(joined) ? ' ' : '. ';
            joined += p;
        });
        return joined;
    }

    /* ---- Sentence fragmentation ------------------------------------------- */
    function toFragments(text) {
        var clean = String(text || '').replace(/\s+/g, ' ').trim();
        if (!clean) { return []; }
        var sentences = clean.match(/[^.!?…]+[.!?…]+|[^.!?…]+$/g) || [clean];
        var frags = [], buf = '';

        function flush() {
            if (buf) { frags.push(buf); buf = ''; }
        }

        sentences.forEach(function(s) {
            s = s.trim();
            if (!s) { return; }
            if (buf && buf.length + 1 + s.length <= MAX_FRAG) {
                buf += ' ' + s;
                return;
            }
            flush();
            if (s.length <= MAX_FRAG) { buf = s; return; }
            var words = s.split(' ');
            var part = '';
            words.forEach(function(w) {
                if (part && part.length + 1 + w.length > MAX_FRAG) {
                    frags.push(part);
                    part = w;
                } else {
                    part = part ? part + ' ' + w : w;
                }
            });
            buf = part;
        });
        flush();
        return frags;
    }

    /* ---- Voices ------------------------------------------------------------ */
    function pickDefaultVoice() {
        if (!voices.length) { return null; }
        var nav = (window.navigator.language || 'es').toLowerCase();
        var base = nav.split('-')[0];
        var i;
        for (i = 0; i < voices.length; i++) {
            if (voices[i].lang.toLowerCase() === nav) { return voices[i]; }
        }
        for (i = 0; i < voices.length; i++) {
            if (voices[i].lang.toLowerCase().split('-')[0] === base) { return voices[i]; }
        }
        for (i = 0; i < voices.length; i++) {
            if (voices[i].lang.toLowerCase().indexOf('es') === 0) { return voices[i]; }
        }
        return null;
    }

    function currentVoice() {
        if (!voices.length) { return null; }
        for (var i = 0; i < voices.length; i++) {
            if (voices[i].voiceURI === prefs.voiceURI) { return voices[i]; }
        }
        return pickDefaultVoice();
    }

    function fillVoices() {
        if (!voiceSelect || !supported) { return; }
        voices = window.speechSynthesis.getVoices() || [];
        var emptyLabel = voiceSelect.getAttribute('data-empty') || '';
        voiceSelect.innerHTML = '';

        if (!voices.length) {
            var opt = document.createElement('option');
            opt.value = '';
            opt.textContent = emptyLabel;
            opt.disabled = true;
            voiceSelect.appendChild(opt);
            return;
        }

        voices.forEach(function(v) {
            var o = document.createElement('option');
            o.value = v.voiceURI;
            o.textContent = v.name + ' (' + v.lang + ')';
            voiceSelect.appendChild(o);
        });

        var found = false;
        for (var i = 0; i < voices.length; i++) {
            if (voices[i].voiceURI === prefs.voiceURI) { found = true; break; }
        }
        if (!found) {
            var def = pickDefaultVoice();
            prefs.voiceURI = def ? def.voiceURI : '';
        }
        voiceSelect.value = prefs.voiceURI;
    }

    /* ---- Speech engine ----------------------------------------------------- */
    function speak(fragments, idx, gen, onDone) {
        if (state !== 'reading' || gen !== generation) { return; }
        if (idx >= fragments.length) { onDone(); return; }

        var fired = false;
        var utter = new SpeechSynthesisUtterance(fragments[idx]);
        var voice = currentVoice();
        if (voice) {
            utter.voice = voice;
            utter.lang = voice.lang;
        } else {
            utter.lang = window.navigator.language || 'es';
        }
        utter.rate = prefs.rate;

        function step() {
            if (fired) { return; }
            fired = true;
            if (state !== 'reading' || gen !== generation) { return; }
            speak(fragments, idx + 1, gen, onDone);
        }

        utter.onend = step;
        utter.onerror = step;
        window.speechSynthesis.speak(utter);
    }

    function updateButton() {
        if (!btn) { return; }
        var reading = state === 'reading';
        btn.classList.toggle('is-reading', reading);
        btn.setAttribute('aria-pressed', reading ? 'true' : 'false');
        var label = reading ?
            (btn.getAttribute('data-label-stop') || '') :
            (btn.getAttribute('data-label-read') || '');
        if (labelEl) { labelEl.textContent = label; }
        btn.setAttribute('title', label);
        btn.setAttribute('aria-label', label);
    }

    function stop(reason) {
        if (state !== 'reading') { return; }
        state = 'idle';
        generation++;
        if (watchdog) {
            window.clearInterval(watchdog);
            watchdog = null;
        }
        if (supported) {
            try { window.speechSynthesis.cancel(); } catch (e) { /* noop */ }
        }
        updateButton();
    }

    function readCurrent() {
        if (state !== 'reading' || !cfg) { return; }
        var slides = cfg.getSlides() || [];
        var idx = cfg.getCurrent();
        var text = slideText(slides[idx]);

        if (!text) {
            if (!prefs.readAll) { stop('nocontent'); return; }
            var target = -1;
            for (var i = idx + 1; i < slides.length; i++) {
                if (slideText(slides[i])) { target = i; break; }
            }
            if (target === -1) { stop('nocontent'); return; }
            cfg.goTo(target, 'reader');
            text = slideText(slides[target]);
        }

        var fragments = toFragments(text);
        if (!fragments.length) { stop('nocontent'); return; }
        var gen = generation;

        speak(fragments, 0, gen, function() {
            if (state !== 'reading' || gen !== generation) { return; }
            if (!prefs.readAll) { stop('done'); return; }
            var all = cfg.getSlides() || [];
            if (cfg.getCurrent() >= all.length - 1) { stop('done'); return; }
            cfg.goTo(cfg.getCurrent() + 1, 'reader');
            readCurrent();
        });
    }

    function start() {
        if (!supported || !cfg || state === 'reading') { return; }
        state = 'reading';
        generation++;
        updateButton();
        if (watchdog) { window.clearInterval(watchdog); }
        watchdog = window.setInterval(function() {
            if (state === 'reading') {
                try { window.speechSynthesis.resume(); } catch (e) { /* noop */ }
            }
        }, 10000);
        readCurrent();
    }

    /* ---- Wiring ------------------------------------------------------------- */
    function init(config) {
        cfg = config;
        if (!cfg || !cfg.root) { return; }

        btn = cfg.root.querySelector('.slides-btn-read');
        panel = cfg.root.querySelector('.slides-readpanel');
        if (!btn) { return; }
        labelEl = btn.querySelector('.slides-btn-read-label');
        if (panel) {
            rateInput = panel.querySelector('.slides-read-rate');
            rateValueEl = panel.querySelector('.slides-read-rate-value');
            voiceSelect = panel.querySelector('.slides-read-voice');
            readAllInput = panel.querySelector('.slides-read-all');
        }

        supported = !!(window.speechSynthesis && window.SpeechSynthesisUtterance);
        if (!supported) {
            btn.style.display = 'none';
            if (panel) { panel.style.display = 'none'; }
            return;
        }

        loadPrefs();

        if (rateInput) {
            rateInput.value = String(prefs.rate);
            if (rateValueEl) { rateValueEl.textContent = String(prefs.rate); }
        }
        if (readAllInput) { readAllInput.checked = prefs.readAll; }

        btn.addEventListener('click', function() {
            if (state === 'reading') { stop('user'); } else { start(); }
        });

        if (rateInput) {
            rateInput.addEventListener('input', function() {
                var r = parseFloat(rateInput.value);
                if (!(r >= 0.5 && r <= 2)) { r = 1; }
                prefs.rate = r;
                if (rateValueEl) { rateValueEl.textContent = String(r); }
                savePrefs();
            });
        }
        if (voiceSelect) {
            voiceSelect.addEventListener('change', function() {
                prefs.voiceURI = voiceSelect.value;
                savePrefs();
            });
        }
        if (readAllInput) {
            readAllInput.addEventListener('change', function() {
                prefs.readAll = !!readAllInput.checked;
                savePrefs();
            });
        }

        fillVoices();
        if (typeof window.speechSynthesis.addEventListener === 'function') {
            window.speechSynthesis.addEventListener('voiceschanged', fillVoices);
        } else {
            window.speechSynthesis.onvoiceschanged = fillVoices;
        }
        window.setTimeout(fillVoices, 800);

        updateButton();
    }

    return { init: init, stop: stop };
});
