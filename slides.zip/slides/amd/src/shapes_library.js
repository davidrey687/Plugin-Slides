/**
 * Comprehensive vector shapes library for mod_slides (PowerPoint-style categories).
 *
 * @module     mod_slides/shapes_library
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var CATEGORIES = [
        ['basic', 'shapecat-basic'],
        ['arrows', 'shapecat-arrows'],
        ['equations', 'shapecat-equations'],
        ['flowchart', 'shapecat-flowchart'],
        ['stars', 'shapecat-stars'],
    ];

    var SHAPES = {
        /* Basic shapes */
        rect:           { label: 'Rectangle',     cat: 'basic',     clip: '' },
        roundedrect:    { label: 'Rounded Rect',  cat: 'basic',     clip: 'border-radius:18px;' },
        circle:         { label: 'Circle',        cat: 'basic',     clip: 'border-radius:50%;' },
        ellipse:        { label: 'Ellipse',       cat: 'basic',     clip: 'border-radius:50%;' },
        line:           { label: 'Line',          cat: 'basic',     clip: '' },
        diamond:        { label: 'Diamond',       cat: 'basic',     clip: 'clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);' },
        triangle:       { label: 'Triangle',      cat: 'basic',     clip: 'clip-path:polygon(50% 0,100% 100%,0 100%);' },
        triangledown:   { label: 'Triangle ↓',    cat: 'basic',     clip: 'clip-path:polygon(50% 100%,100% 0,0 0);' },
        pentagon:       { label: 'Pentagon',      cat: 'basic',     clip: 'clip-path:polygon(50% 0,100% 38%,82% 100%,18% 100%,0 38%);' },
        hexagon:        { label: 'Hexagon',       cat: 'basic',     clip: 'clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);' },
        octagon:        { label: 'Octagon',       cat: 'basic',     clip: 'clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);' },
        cross:          { label: 'Cross',         cat: 'basic',     clip: 'clip-path:polygon(35% 0,65% 0,65% 35%,100% 35%,100% 65%,65% 65%,65% 100%,35% 100%,35% 65%,0 65%,0 35%,35% 35%);' },
        heart:          { label: 'Heart',         cat: 'basic',     clip: 'clip-path:polygon(50% 92%,42% 78%,25% 62%,12% 48%,6% 34%,8% 20%,20% 9%,33% 8%,44% 15%,50% 25%,56% 15%,67% 8%,80% 9%,92% 20%,94% 34%,88% 48%,75% 62%,58% 78%);' },
        cloud:          { label: 'Cloud',         cat: 'basic',     clip: 'clip-path:polygon(22% 78%,12% 74%,5% 62%,6% 48%,14% 37%,26% 31%,33% 20%,46% 14%,58% 18%,67% 13%,78% 19%,87% 29%,94% 42%,93% 56%,88% 68%,78% 76%,60% 78%,40% 78%);' },
        parallelogram:  { label: 'Parallelogram', cat: 'basic',     clip: 'clip-path:polygon(25% 0,100% 0,75% 100%,0 100%);' },
        trapezoid:      { label: 'Trapezoid',     cat: 'basic',     clip: 'clip-path:polygon(20% 0,80% 0,100% 100%,0 100%);' },
        speechbubble:   { label: 'Speech Bubble', cat: 'basic',     clip: 'clip-path:polygon(0 0,100% 0,100% 70%,70% 70%,50% 100%,50% 70%,0 70%);' },

        /* Block Arrows */
        arrowright:     { label: 'Arrow →',       cat: 'arrows',    clip: 'clip-path:polygon(0 30%,60% 30%,60% 0,100% 50%,60% 100%,60% 70%,0 70%);' },
        arrowleft:      { label: 'Arrow ←',       cat: 'arrows',    clip: 'clip-path:polygon(100% 30%,40% 30%,40% 0,0 50%,40% 100%,40% 70%,100% 70%);' },
        arrowup:        { label: 'Arrow ↑',       cat: 'arrows',    clip: 'clip-path:polygon(30% 100%,30% 40%,0 40%,50% 0,100% 40%,70% 40%,70% 100%);' },
        arrowdown:      { label: 'Arrow ↓',       cat: 'arrows',    clip: 'clip-path:polygon(30% 0,30% 60%,0 60%,50% 100%,100% 60%,70% 60%,70% 0);' },
        arrowrightwide: { label: 'Wide Arrow',    cat: 'arrows',    clip: 'clip-path:polygon(0 20%,60% 20%,60% 0,100% 50%,60% 100%,60% 80%,0 80%);' },

        /* Equation Shapes */
        eqplus:         { label: 'Plus (+)',      cat: 'equations', clip: 'clip-path:polygon(35% 0,65% 0,65% 35%,100% 35%,100% 65%,65% 65%,65% 100%,35% 100%,35% 65%,0 65%,0 35%,35% 35%);' },
        eqminus:        { label: 'Minus (-)',     cat: 'equations', clip: 'clip-path:polygon(0 35%,100% 35%,100% 65%,0 65%);' },
        eqmultiply:     { label: 'Multiply (×)',  cat: 'equations', clip: 'clip-path:polygon(20% 0,50% 30%,80% 0,100% 20%,70% 50%,100% 80%,80% 100%,50% 70%,20% 100%,0 80%,30% 50%,0 20%);' },
        eqdivide:       { label: 'Divide (÷)',    cat: 'equations', clip: 'clip-path:polygon(0 0,100% 0,100% 100%,0 100%);', dotted: true },
        eqequals:       { label: 'Equals (=)',    cat: 'equations', clip: 'clip-path:polygon(0 20%,100% 20%,100% 40%,0 40%,0 60%,100% 60%,100% 80%,0 80%);' },

        /* Flowchart */
        flowprocess:    { label: 'Process',       cat: 'flowchart', clip: '' },
        flowdecision:   { label: 'Decision',      cat: 'flowchart', clip: 'clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);' },
        flowterminator: { label: 'Terminator',    cat: 'flowchart', clip: 'border-radius:999px;' },

        /* Stars & Extras */
        star4:          { label: 'Star 4',        cat: 'stars',     clip: 'clip-path:polygon(50% 0,65% 35%,100% 35%,75% 57%,85% 91%,50% 72%,15% 91%,25% 57%,0 35%,35% 35%);' },
        star5:          { label: 'Star 5',        cat: 'stars',     clip: 'clip-path:polygon(50% 0,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%);' },
        star6:          { label: 'Star 6',        cat: 'stars',     clip: 'clip-path:polygon(50% 0,63% 25%,100% 25%,75% 50%,88% 81%,50% 63%,12% 81%,25% 50%,0 25%,37% 25%);' },
        star8:          { label: 'Star 8',        cat: 'stars',     clip: 'clip-path:polygon(50% 0,60% 20%,80% 5%,75% 28%,100% 25%,80% 42%,95% 60%,72% 58%,80% 80%,55% 65%,50% 90%,45% 65%,20% 80%,28% 58%,5% 60%,20% 42%,0% 25%,25% 28%,20% 5%,40% 20%);' },
        star12:         { label: 'Star 12',       cat: 'stars',     clip: 'clip-path:polygon(50% 0,61% 15%,78% 6%,79% 25%,98% 25%,88% 41%,100% 50%,88% 59%,98% 75%,79% 75%,78% 94%,61% 85%,50% 100%,39% 85%,22% 94%,21% 75%,2% 75%,12% 59%,0 50%,12% 41%,2% 25%,21% 25%,22% 6%,39% 15%);' },
        bolt:           { label: 'Bolt',          cat: 'stars',     clip: 'clip-path:polygon(55% 0,18% 55%,44% 55%,40% 100%,82% 40%,52% 40%);' },
        shield:         { label: 'Shield',        cat: 'stars',     clip: 'clip-path:polygon(50% 0,100% 16%,100% 55%,50% 100%,0 55%,0 16%);' },
        droplet:        { label: 'Droplet',       cat: 'stars',     clip: 'clip-path:polygon(50% 0,90% 42%,88% 70%,50% 100%,12% 70%,10% 42%);' },
        ribbon:         { label: 'Ribbon',        cat: 'stars',     clip: 'clip-path:polygon(0 0,100% 0,100% 100%,50% 72%,0 100%);' },
        pennant:        { label: 'Pennant',       cat: 'stars',     clip: 'clip-path:polygon(0 0,100% 0,72% 50%,100% 100%,0 100%);' },
        hourglass:      { label: 'Hourglass',     cat: 'stars',     clip: 'clip-path:polygon(0 0,100% 0,56% 50%,100% 100%,0 100%,44% 50%);' },
        flower:         { label: 'Flower',        cat: 'stars',     clip: 'clip-path:polygon(50% 0,65% 20%,90% 12%,80% 38%,100% 50%,80% 62%,90% 88%,65% 80%,50% 100%,35% 80%,10% 88%,20% 62%,0 50%,20% 38%,10% 12%,35% 20%);' },
    };

    /**
     * Background layers for dotted symbols (÷): bar + two dots in `fill`.
     *
     * @param {string} fill Fill colour (may be 'transparent').
     * @return {string} CSS declarations.
     */
    function dottedLayers(fill) {
        return 'background-color:transparent;' +
            'background-image:' +
            'radial-gradient(circle at 50% 14%,' + fill + ' 0 7%,transparent 7.5%),' +
            'radial-gradient(circle at 50% 86%,' + fill + ' 0 7%,transparent 7.5%),' +
            'linear-gradient(' + fill + ',' + fill + ');' +
            'background-size:100% 100%,100% 100%,100% 14%;' +
            'background-position:0 0,0 0,0 43%;' +
            'background-repeat:no-repeat;';
    }

    function innerStyle(el) {
        var sw = (el.strokeWidth !== undefined) ? el.strokeWidth : 2;
        var angle = el.angle || 0;
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var fill = (el.fill === '' || el.fill === 'transparent') ? 'transparent' : (el.fill || '#0d6efd');

        if (el.shape === 'line') {
            var barH = Math.max(2, sw);
            var style = 'width:100%;height:' + barH + 'px;position:absolute;top:calc(50% - ' + (barH / 2) + 'px);' +
                   'background:' + (el.stroke || '#1a1a2e') + ';border-radius:' + (barH / 2) + 'px;' +
                   'transform-origin:center center;opacity:' + opacity + ';';
            if (angle !== 0) {
                style += 'transform:rotate(' + angle + 'deg);';
            }
            if (el.shadowEnabled) {
                style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                    (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
            }
            return style;
        }

        var s = SHAPES[el.shape] || SHAPES.rect;
        var style = 'width:100%;height:100%;background:' + fill + ';box-sizing:border-box;' +
            'transform-origin:center center;opacity:' + opacity + ';';

        if (s.dotted) {
            // Symbols drawn from background layers (e.g. ÷ = bar + two dots):
            // the shorthand background above is overridden by these layers.
            style += dottedLayers(fill);
        } else if (s.clip.indexOf('clip-path') === -1 && sw > 0 && fill !== 'transparent') {
            style += 'border:' + sw + 'px solid ' + (el.stroke || '#1a1a2e') + ';';
        } else if (sw > 0 && fill === 'transparent') {
            // Transparent fill: keep the border so the shape stays visible.
            style += 'border:' + sw + 'px solid ' + (el.stroke || '#1a1a2e') + ';';
        }

        style += s.clip;

        if (angle !== 0) {
            style += 'transform:rotate(' + angle + 'deg);';
        }

        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }

        return style;
    }

    /**
     * Style for a catalogue thumbnail (picker grids, chips, previews).
     * Deliberately omits width/height so callers keep their own box size.
     *
     * @param {string} shapeKey Shape key.
     * @param {string} [color]  Fill colour (defaults to the brand blue).
     * @return {string} CSS declarations.
     */
    function thumbStyle(shapeKey, color) {
        var s = SHAPES[shapeKey] || SHAPES.rect;
        var fill = (color === '' || color === 'transparent') ? 'transparent' : (color || '#0d6efd');
        var style = 'background:' + fill + ';box-sizing:border-box;';
        if (s.dotted) {
            style += dottedLayers(fill);
        }
        style += s.clip;
        return style;
    }

    function getShapeOptions() {
        var opts = [];
        Object.keys(SHAPES).forEach(function(key) {
            var label;
            try {
                label = M.util.get_string('shape-' + key, 'mod_slides');
            } catch (e) {
                label = SHAPES[key].label;
            }
            opts.push({ value: key, label: label });
        });
        return opts;
    }

    return {
        CATEGORIES: CATEGORIES,
        SHAPES: SHAPES,
        innerStyle: innerStyle,
        thumbStyle: thumbStyle,
        getShapeOptions: getShapeOptions,
    };
});
