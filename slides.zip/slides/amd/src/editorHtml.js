/**
 * HTML / Embed element type — paste custom HTML (YouTube/Vimeo iframes,
 * external images, interactive widgets) straight into a slide.
 *
 * The raw markup lives in the standard `text` field so the web service and
 * the sanitiser schema need no new keys (same trick as editorEquation).
 *
 * @module     mod_slides/editorHtml
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState'], function(state) {
    'use strict';

    var TYPE = 'html';

    var DEFAULTS = {
        type: TYPE,
        x: 100,
        y: 100,
        w: 560,
        h: 315,
        text: '',
        opacity: 100,
        borderRadius: 0,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function str(key) {
        try { return M.util.get_string(key, 'mod_slides'); } catch (e) { return key; }
    }

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
    }

    function innerStyle(el) {
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var style = 'width:100%;height:100%;box-sizing:border-box;overflow:hidden;opacity:' + opacity + ';';
        var br = el.borderRadius || 0;
        if (br) { style += 'border-radius:' + br + 'px;'; }
        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return style;
    }

    var PROPERTY_DEFS = [
        { key: 'opacity',       label: 'opacity',        control: 'number', min: 0, max: 100, step: 5 },
        { key: 'borderRadius',  label: 'borderradius',   control: 'number', min: 0, max: 60, step: 1 },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color',   control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',    control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',       control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',       control: 'number', min: -20, max: 20, step: 1 },
    ];

    /* ======================================================================
     *  Modal
     * ====================================================================== */

    var modalCtx = null;

    function closeModal() {
        if (!modalCtx) { return; }
        if (modalCtx.onDocKey) {
            document.removeEventListener('keydown', modalCtx.onDocKey, true);
        }
        if (modalCtx.backdrop && modalCtx.backdrop.parentNode) {
            modalCtx.backdrop.remove();
        }
        modalCtx = null;
    }

    /**
     * Open the HTML / Embed editor.
     *
     * @param {Object} [opts]
     * @param {String} [opts.code]    Prefilled markup (edit mode when non-empty).
     * @param {Function} [opts.onApply] Called with the final markup string.
     */
    function openModal(opts) {
        opts = opts || {};
        closeModal();

        var initialCode = opts.code || '';
        var isEdit = !!initialCode;

        var backdrop = document.createElement('div');
        backdrop.className = 'html-dialog-backdrop';

        var modal = document.createElement('div');
        modal.className = 'html-dialog';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-label', str('htmlmodaltitle'));

        /* Header */
        var header = document.createElement('div');
        header.className = 'html-header';
        var title = document.createElement('div');
        title.className = 'html-title';
        title.textContent = str('htmlmodaltitle');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'html-close';
        closeBtn.setAttribute('aria-label', str('cancel'));
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', closeModal);
        header.appendChild(title);
        header.appendChild(closeBtn);
        modal.appendChild(header);

        /* Body */
        var body = document.createElement('div');
        body.className = 'html-body';

        var hint = document.createElement('p');
        hint.className = 'html-hint';
        hint.textContent = str('htmlhint');
        body.appendChild(hint);

        var inputLabel = document.createElement('label');
        inputLabel.className = 'html-label';
        inputLabel.setAttribute('for', 'html-code-input');
        inputLabel.textContent = str('htmlcodelabel');
        body.appendChild(inputLabel);

        var input = document.createElement('textarea');
        input.id = 'html-code-input';
        input.className = 'html-code-input';
        input.value = initialCode;
        input.spellcheck = false;
        input.rows = 8;
        input.placeholder = '<iframe src="https://www.youtube.com/embed/..." width="560" height="315"></iframe>';
        body.appendChild(input);

        var previewLabel = document.createElement('div');
        previewLabel.className = 'html-label';
        previewLabel.textContent = str('htmlpreviewlabel');
        body.appendChild(previewLabel);

        // Live preview: a sandboxed iframe keeps embedded scripts and page-wide
        // styles from ever touching the editor document.
        var preview = document.createElement('div');
        preview.className = 'html-preview';
        preview.setAttribute('data-empty', str('htmlpreviewempty'));
        preview.classList.add('is-empty');
        var previewFrame = document.createElement('iframe');
        previewFrame.className = 'html-preview-frame';
        previewFrame.setAttribute('sandbox', 'allow-scripts allow-popups allow-forms');
        previewFrame.setAttribute('title', str('htmlpreviewlabel'));
        previewFrame.setAttribute('loading', 'lazy');
        preview.appendChild(previewFrame);
        body.appendChild(preview);

        var errEl = document.createElement('div');
        errEl.className = 'html-error';
        body.appendChild(errEl);

        modal.appendChild(body);

        /* Footer */
        var footer = document.createElement('div');
        footer.className = 'html-footer';
        var cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.textContent = str('cancel');
        cancelBtn.addEventListener('click', closeModal);
        var applyBtn = document.createElement('button');
        applyBtn.type = 'button';
        applyBtn.className = 'btn btn-primary';
        applyBtn.textContent = str(isEdit ? 'htmlupdate' : 'htmlinsert');
        applyBtn.addEventListener('click', apply);
        footer.appendChild(cancelBtn);
        footer.appendChild(applyBtn);
        modal.appendChild(footer);

        /* Wiring */
        function renderPreview() {
            var code = input.value || '';
            if (!code.trim()) {
                previewFrame.removeAttribute('srcdoc');
                preview.classList.add('is-empty');
                return;
            }
            preview.classList.remove('is-empty');
            previewFrame.setAttribute('srcdoc', code);
        }

        function apply() {
            var code = input.value || '';
            if (!code.trim()) {
                errEl.textContent = str('htmlempty');
                input.focus();
                return;
            }
            var handler = opts.onApply || defaultApply;
            closeModal();
            handler(code);
        }

        input.addEventListener('input', renderPreview);
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                apply();
            }
        });

        modal.addEventListener('click', function(e) { e.stopPropagation(); });
        backdrop.addEventListener('click', closeModal);

        document.body.appendChild(backdrop);
        backdrop.appendChild(modal);

        // Escape / editor shortcuts must not leak through the modal.
        modalCtx = {
            backdrop: backdrop,
            onDocKey: function(e) {
                if (e.key === 'Escape') {
                    e.stopPropagation();
                    e.preventDefault();
                    closeModal();
                    return;
                }
                var tag = e.target && e.target.tagName;
                if (tag === 'TEXTAREA' || tag === 'INPUT') { return; }
                if (e.key === 'Delete' || e.key === 'Backspace' ||
                        e.key.indexOf('Arrow') === 0 || e.key === 'PageUp' || e.key === 'PageDown') {
                    e.stopPropagation();
                }
            },
        };
        document.addEventListener('keydown', modalCtx.onDocKey, true);

        renderPreview();
        // Focus the source so the teacher can paste right away (skip on touch
        // where the on-screen keyboard would cover the preview).
        if (!window.matchMedia('(pointer: coarse)').matches) {
            input.focus();
            input.setSelectionRange(input.value.length, input.value.length);
        }
    }

    /** Default action for a brand-new embed: centre it on the active slide. */
    function defaultApply(code) {
        var canvas = document.getElementById('editor-canvas');
        var canvasH = (canvas && parseInt(canvas.dataset.height, 10)) || 540;
        var w = DEFAULTS.w;
        var h = DEFAULTS.h;
        state.addElement(state.get().current, Object.assign({}, DEFAULTS, {
            text: code,
            x: Math.round((960 - w) / 2),
            y: Math.round((canvasH - h) / 2),
        }));
    }

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        PROPERTY_DEFS: PROPERTY_DEFS,

        // Modal.
        openModal: openModal,
        closeModal: closeModal,
    };
});
