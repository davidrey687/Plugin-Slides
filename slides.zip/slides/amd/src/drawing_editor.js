/**
 * Drawing / whiteboard modal — freehand annotation editor.
 *
 * Opens a light dialog with an HTML5 canvas: colour picker, 1-30 px width
 * slider, brush/eraser modes, undo/redo snapshots (getImageData stack, capped
 * at MAX_UNDO to bound memory) and a clear-all button. Mouse and touch input
 * are both supported. "Save drawing" exports the canvas as a PNG blob and
 * uploads it through drawing_upload_ajax.php into the slides_media file area;
 * "Insert" adds the stored pluginfile URL as a standard image element (the
 * image type already renders in the editor, viewer, print view and SCORM).
 *
 * The canvas is never painted white: the eraser uses the destination-out
 * composite mode so exported PNGs keep a transparent background.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/editorImage'], function(state, image) {

    var MAX_UNDO = 20;
    var CANVAS_W = 1280;
    var CANVAS_H = 720;

    var open = null;

    function str(key) {
        return M.util.get_string(key, 'mod_slides');
    }

    /* ---- canvas geometry ------------------------------------------------ */

    function getPos(canvas, clientX, clientY) {
        var rect = canvas.getBoundingClientRect();
        var sx = canvas.width / (rect.width || 1);
        var sy = canvas.height / (rect.height || 1);
        return {
            x: (clientX - rect.left) * sx,
            y: (clientY - rect.top) * sy,
        };
    }

    function canvasHasInk(canvas, ctx) {
        var data;
        try {
            data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
        } catch (e) {
            return true;
        }
        // Any non-zero alpha means content (every pixel: cheap on click).
        for (var i = 3; i < data.length; i += 4) {
            if (data[i] !== 0) { return true; }
        }
        return false;
    }

    /* ---- modal ---------------------------------------------------------- */

    function openModal(opts) {
        opts = opts || {};
        if (open) { return; }

        var undoStack = [];
        var redoStack = [];
        var drawing = false;
        var mode = 'brush';
        var color = '#212529';
        var width = 5;
        var uploadedUrl = null;
        var uploadedName = '';
        var saving = false;

        var backdrop = document.createElement('div');
        backdrop.className = 'media-dialog-backdrop';

        var modal = document.createElement('div');
        modal.className = 'media-dialog';

        var header = document.createElement('div');
        header.className = 'media-header';
        var title = document.createElement('div');
        title.className = 'media-title';
        title.textContent = str('drawingtitle');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'media-close';
        closeBtn.innerHTML = '&times;';
        closeBtn.setAttribute('aria-label', str('cancel'));
        header.appendChild(title);
        header.appendChild(closeBtn);
        modal.appendChild(header);

        var body = document.createElement('div');
        body.className = 'media-body';

        var hint = document.createElement('p');
        hint.className = 'media-hint';
        hint.textContent = str('drawinghint');
        body.appendChild(hint);

        /* toolbar */
        var toolbar = document.createElement('div');
        toolbar.className = 'drawing-toolbar';

        var colorInput = document.createElement('input');
        colorInput.type = 'color';
        colorInput.className = 'drawing-color';
        colorInput.value = color;
        colorInput.setAttribute('aria-label', str('drawingcolor'));

        var rangeInput = document.createElement('input');
        rangeInput.type = 'range';
        rangeInput.min = '1';
        rangeInput.max = '30';
        rangeInput.value = String(width);
        rangeInput.className = 'drawing-range';
        rangeInput.setAttribute('aria-label', str('drawingwidth'));

        var sizeOut = document.createElement('span');
        sizeOut.className = 'drawing-size';
        sizeOut.textContent = String(width);

        var brushBtn = document.createElement('button');
        brushBtn.type = 'button';
        brushBtn.className = 'drawing-tool btn btn-sm btn-outline-secondary is-active';
        brushBtn.textContent = str('drawingbrush');

        var eraserBtn = document.createElement('button');
        eraserBtn.type = 'button';
        eraserBtn.className = 'drawing-tool btn btn-sm btn-outline-secondary';
        eraserBtn.textContent = str('drawingeraser');

        var undoBtn = document.createElement('button');
        undoBtn.type = 'button';
        undoBtn.className = 'drawing-tool btn btn-sm btn-outline-secondary';
        undoBtn.textContent = '\u2190';
        undoBtn.title = str('drawingundo');
        undoBtn.disabled = true;

        var redoBtn = document.createElement('button');
        redoBtn.type = 'button';
        redoBtn.className = 'drawing-tool btn btn-sm btn-outline-secondary';
        redoBtn.textContent = '\u2192';
        redoBtn.title = str('drawingredo');
        redoBtn.disabled = true;

        var clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'drawing-tool btn btn-sm btn-outline-secondary';
        clearBtn.textContent = '\u2716';
        clearBtn.title = str('drawingclear');

        toolbar.appendChild(colorInput);
        toolbar.appendChild(rangeInput);
        toolbar.appendChild(sizeOut);
        toolbar.appendChild(brushBtn);
        toolbar.appendChild(eraserBtn);
        toolbar.appendChild(undoBtn);
        toolbar.appendChild(redoBtn);
        toolbar.appendChild(clearBtn);
        body.appendChild(toolbar);

        /* canvas */
        var wrap = document.createElement('div');
        wrap.className = 'drawing-canvas-wrap';
        var canvas = document.createElement('canvas');
        canvas.className = 'drawing-canvas';
        canvas.width = CANVAS_W;
        canvas.height = CANVAS_H;
        wrap.appendChild(canvas);
        body.appendChild(wrap);

        var status = document.createElement('div');
        status.className = 'media-status';
        body.appendChild(status);

        modal.appendChild(body);

        /* footer */
        var footer = document.createElement('div');
        footer.className = 'media-footer';
        var saveBtn = document.createElement('button');
        saveBtn.type = 'button';
        saveBtn.className = 'btn btn-primary';
        saveBtn.textContent = str('drawingsave');
        var insertBtn = document.createElement('button');
        insertBtn.type = 'button';
        insertBtn.className = 'btn btn-success';
        insertBtn.textContent = str('drawinginsert');
        insertBtn.disabled = true;
        footer.appendChild(saveBtn);
        footer.appendChild(insertBtn);
        modal.appendChild(footer);

        backdrop.appendChild(modal);
        document.body.appendChild(backdrop);

        var ctx = canvas.getContext('2d');
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        /* ---- tool state -------------------------------------------------- */

        function setStatus(text, isError) {
            status.textContent = text || '';
            status.classList.toggle('is-error', !!isError);
        }

        function refreshButtons() {
            undoBtn.disabled = undoStack.length === 0;
            redoBtn.disabled = redoStack.length === 0;
        }

        function invalidateUpload() {
            if (uploadedUrl) {
                uploadedUrl = null;
                uploadedName = '';
                insertBtn.disabled = true;
            }
        }

        function pushUndo() {
            try {
                undoStack.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
                if (undoStack.length > MAX_UNDO) {
                    undoStack.shift();
                }
                redoStack = [];
            } catch (e) { /* tainted or OOM: simply keep editing */ }
            refreshButtons();
        }

        function applyTool() {
            ctx.globalCompositeOperation = (mode === 'eraser') ? 'destination-out' : 'source-over';
            ctx.strokeStyle = color;
            ctx.fillStyle = color;
            ctx.lineWidth = width;
        }

        function setMode(next) {
            mode = next;
            brushBtn.classList.toggle('is-active', mode === 'brush');
            eraserBtn.classList.toggle('is-active', mode === 'eraser');
            applyTool();
        }

        /* ---- stroke handling --------------------------------------------- */

        function startStroke(x, y) {
            pushUndo();
            invalidateUpload();
            drawing = true;
            applyTool();
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + 0.01, y + 0.01); // lone click still leaves a dot
            ctx.stroke();
            setStatus('');
        }

        function moveStroke(x, y) {
            if (!drawing) { return; }
            ctx.lineTo(x, y);
            ctx.stroke();
        }

        function endStroke() {
            if (!drawing) { return; }
            drawing = false;
            ctx.closePath();
        }

        function mousePos(e) {
            return getPos(canvas, e.clientX, e.clientY);
        }

        function touchPos(t) {
            return getPos(canvas, t.clientX, t.clientY);
        }

        canvas.addEventListener('mousedown', function(e) {
            e.preventDefault();
            var p = mousePos(e);
            startStroke(p.x, p.y);
        });
        // mousemove is bound on window once (onGlobalMove below) so the
        // stroke follows the pointer outside the canvas and can be unbound.
        window.addEventListener('mouseup', endStroke);
        window.addEventListener('pointercancel', endStroke);

        canvas.addEventListener('touchstart', function(e) {
            if (!e.touches || !e.touches.length) { return; }
            e.preventDefault();
            var t = e.touches[0];
            var p = touchPos(t);
            startStroke(p.x, p.y);
        }, { passive: false });
        canvas.addEventListener('touchmove', function(e) {
            if (!e.touches || !e.touches.length) { return; }
            e.preventDefault();
            var t = e.touches[0];
            var p = touchPos(t);
            moveStroke(p.x, p.y);
        }, { passive: false });
        window.addEventListener('touchend', endStroke);
        window.addEventListener('touchcancel', endStroke);

        /* ---- toolbar actions --------------------------------------------- */

        colorInput.addEventListener('input', function() {
            color = colorInput.value;
            applyTool();
        });
        rangeInput.addEventListener('input', function() {
            width = parseInt(rangeInput.value, 10) || 1;
            sizeOut.textContent = String(width);
            applyTool();
        });
        brushBtn.addEventListener('click', function() { setMode('brush'); });
        eraserBtn.addEventListener('click', function() { setMode('eraser'); });

        undoBtn.addEventListener('click', function() {
            if (!undoStack.length) { return; }
            endStroke();
            try {
                redoStack.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
                if (redoStack.length > MAX_UNDO) { redoStack.shift(); }
                ctx.putImageData(undoStack.pop(), 0, 0);
            } catch (e) { /* keep stacks consistent on failure */ }
            invalidateUpload();
            refreshButtons();
        });

        redoBtn.addEventListener('click', function() {
            if (!redoStack.length) { return; }
            endStroke();
            try {
                undoStack.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
                if (undoStack.length > MAX_UNDO) { undoStack.shift(); }
                ctx.putImageData(redoStack.pop(), 0, 0);
            } catch (e) { /* ignore */ }
            invalidateUpload();
            refreshButtons();
        });

        clearBtn.addEventListener('click', function() {
            if (!canvasHasInk(canvas, ctx)) { return; }
            pushUndo();
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            invalidateUpload();
            setStatus('');
        });

        /* ---- upload ------------------------------------------------------- */

        function withBusy(busy) {
            saveBtn.disabled = busy;
            insertBtn.disabled = busy || !uploadedUrl;
            colorInput.disabled = busy;
            rangeInput.disabled = busy;
            brushBtn.disabled = busy;
            eraserBtn.disabled = busy;
            undoBtn.disabled = busy || undoStack.length === 0;
            redoBtn.disabled = busy || redoStack.length === 0;
            clearBtn.disabled = busy;
            closeBtn.disabled = busy;
        }

        function uploadDrawing() {
            if (saving) { return; }
            if (!canvasHasInk(canvas, ctx)) {
                setStatus(str('drawingempty'), true);
                return;
            }

            saving = true;
            withBusy(true);
            setStatus(str('drawingsaving'));

            var root = document.getElementById('slides-editor');
            var cmid = parseInt(root.dataset.cmid, 10);
            var sesskey = root.dataset.sesskey;
            var filename = 'dibujo_' + Date.now() + '.png';

            canvas.toBlob(function(blob) {
                if (!blob) {
                    saving = false;
                    withBusy(false);
                    setStatus(str('drawingerror'), true);
                    return;
                }

                var fd = new FormData();
                fd.append('cmid', cmid);
                fd.append('sesskey', sesskey);
                fd.append('drawing', blob, filename);

                var xhr = new XMLHttpRequest();
                try {
                    xhr.open('POST', M.cfg.wwwroot + '/mod/slides/classes/local/drawing_upload_ajax.php', true);
                } catch (ex) {
                    saving = false;
                    withBusy(false);
                    setStatus(str('drawingerror') + ' — ' + ex.message, true);
                    return;
                }
                xhr.timeout = 60000;

                function finish(ok, msg, isError) {
                    saving = false;
                    withBusy(false);
                    setStatus(msg, isError);
                }

                xhr.onload = function() {
                    var body = '';
                    try { body = xhr.responseText || ''; } catch (e) { /* ignore */ }
                    if (xhr.status === 200) {
                        try {
                            var resp = JSON.parse(body);
                            if (resp.url) {
                                uploadedUrl = resp.url;
                                uploadedName = resp.filename || filename;
                                insertBtn.disabled = false;
                                finish(true, str('drawingsaved'), false);
                                return;
                            }
                            finish(false, resp.error || str('drawingerror'), true);
                        } catch (ex) {
                            finish(false, str('drawingerror') + ' — ' + ex.message, true);
                        }
                    } else {
                        finish(false, str('drawingerror') + ' — HTTP ' + xhr.status, true);
                    }
                };
                xhr.onerror = function() {
                    finish(false, str('drawingerror') + ' — network', true);
                };
                xhr.ontimeout = function() {
                    finish(false, str('drawingerror') + ' — timeout', true);
                };

                try {
                    xhr.send(fd);
                } catch (ex) {
                    finish(false, str('drawingerror') + ' — ' + ex.message, true);
                }
            }, 'image/png');
        }

        function insertDrawing() {
            if (!uploadedUrl) { return; }

            var canvasEl = document.getElementById('editor-canvas');
            var canvasH = (canvasEl && parseInt(canvasEl.dataset.height, 10)) || 540;
            var w = 480;
            var h = 270; // source is 16:9 (1280x720)
            var el = Object.assign({}, image.DEFAULTS, {
                src: uploadedUrl,
                alt: uploadedName,
                w: w,
                h: h,
                x: Math.round((960 - w) / 2),
                y: Math.round((canvasH - h) / 2),
            });

            closeModal();
            state.addElement(state.get().current, el);
        }

        saveBtn.addEventListener('click', uploadDrawing);
        insertBtn.addEventListener('click', insertDrawing);

        /* ---- close / teardown -------------------------------------------- */

        function removeWindowListeners() {
            window.removeEventListener('mousemove', onGlobalMove);
            window.removeEventListener('mouseup', endStroke);
            window.removeEventListener('pointercancel', endStroke);
            window.removeEventListener('touchend', endStroke);
            window.removeEventListener('touchcancel', endStroke);
            document.removeEventListener('keydown', onDocKey, true);
        }

        // Window listeners are registered by name here so teardown can
        // unbind exactly the handlers the canvas attached.
        var onGlobalMove = function(e) {
            if (!drawing) { return; }
            var p = mousePos(e);
            moveStroke(p.x, p.y);
        };
        window.addEventListener('mousemove', onGlobalMove);

        function closeModal() {
            if (!open) { return; }
            removeWindowListeners();
            open.backdrop.remove();
            open = null;
        }

        function onDocKey(e) {
            if (e.key === 'Escape') {
                if (saving) { return; }
                e.stopPropagation();
                e.preventDefault();
                closeModal();
                return;
            }
            var tag = e.target && e.target.tagName;
            if (tag === 'TEXTAREA' || tag === 'INPUT') { return; }
            if (e.key === 'Delete' || e.key === 'Backspace' ||
                    e.key.indexOf('Arrow') === 0 || e.key === 'PageUp' || e.key === 'PageDown') {
                e.stopPropagation();
            }
        }
        document.addEventListener('keydown', onDocKey, true);

        closeBtn.addEventListener('click', function() {
            if (saving) { return; }
            closeModal();
        });
        backdrop.addEventListener('click', function() {
            if (saving) { return; }
            closeModal();
        });
        modal.addEventListener('click', function(e) { e.stopPropagation(); });

        open = { backdrop: backdrop };
        brushBtn.focus();
    }

    return {
        openModal: openModal,
    };
});
