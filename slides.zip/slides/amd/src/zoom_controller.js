/**
 * Canvas zoom controller (Canva-style) for the slides editor.
 *
 * Owns the zoom percentage of the editing canvas: the slider, the −/+ and
 * Fit buttons in the status bar, Ctrl+wheel over the canvas and the
 * Ctrl+0 / Ctrl+1 / Ctrl+= / Ctrl+- shortcuts.
 *
 * Semantics: 100% = scale 1.0 (the960×540 canvas at its natural size).
 * "Fit" computes the largest scale that keeps the whole frame inside the
 * workspace. The viewport element is sized explicitly (960·s × 540·s) so
 * the workspace (`.editor-canvas-wrap`, overflow:auto) shows scrollbars
 * when the zoomed canvas overflows.
 *
 * editorCanvas delegates its scaleCanvas() to applyScale() through
 * canvas.setScaler() — same setter-injection pattern used by the equation
 * and HTML editors, so there is no AMD cycle.
 *
 * @module     mod_slides/zoom_controller
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var MIN_ZOOM = 20;
    var MAX_ZOOM = 200;
    var STEP = 5;
    var WHEEL_STEP = 10;

    var zoomPct = 100;
    var canvasW = 960;
    var canvasH = 540;

    var viewportEl = null;
    var canvasEl = null;
    var sliderEl = null;
    var labelEl = null;

    function clamp(pct) {
        return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Math.round(pct)));
    }

    function str(key) {
        try { return M.util.get_string(key, 'mod_slides'); } catch (e) { return key; }
    }

    /**
     * Largest scale (in %) that fits the whole canvas frame inside the
     * workspace, honouring its padding. Width-driven like the original
     * auto-fit, with a height clamp so the frame never overflows vertically.
     *
     * @return {Number} percentage clamped to [MIN_ZOOM, MAX_ZOOM]
     */
    function computeFitPct() {
        if (!viewportEl) { return 100; }
        var wrap = viewportEl.parentNode;
        if (!wrap) { return 100; }
        var style = window.getComputedStyle(wrap);
        var padX = (parseFloat(style.paddingLeft) || 0) + (parseFloat(style.paddingRight) || 0);
        var padY = (parseFloat(style.paddingTop) || 0) + (parseFloat(style.paddingBottom) || 0);
        var availW = wrap.clientWidth - padX;
        var availH = wrap.clientHeight - padY;
        if (availW <= 0 || availH <= 0) { return MIN_ZOOM; }
        var scale = Math.min(availW / canvasW, availH / canvasH);
        return clamp(scale * 100);
    }

    /** Apply the current zoom to the viewport frame and the canvas transform. */
    function applyScale() {
        if (!viewportEl || !canvasEl) { return; }
        var s = zoomPct / 100;
        viewportEl.style.width = Math.round(canvasW * s) + 'px';
        viewportEl.style.height = Math.round(canvasH * s) + 'px';
        canvasEl.style.transform = 'scale(' + s + ')';
        // Consumed by styles.css to counter-scale embedded iframes/video
        // (they don't re-raster under an ancestor transform — PDF blur).
        canvasEl.style.setProperty('--slide-scale', String(s));
        if (sliderEl && parseInt(sliderEl.value, 10) !== zoomPct) {
            sliderEl.value = String(zoomPct);
        }
        if (labelEl) {
            labelEl.textContent = zoomPct + '%';
        }
    }

    /** Set the zoom (clamped) and repaint. */
    function setZoom(pct) {
        var next = clamp(pct);
        if (next === zoomPct) { applyScale(); return; }
        zoomPct = next;
        applyScale();
    }

    /** Jump to the fit scale (workspace size minus padding). */
    function fit() {
        setZoom(computeFitPct());
    }

    /** @return {Number} current zoom percentage. */
    function getZoom() {
        return zoomPct;
    }

    /* ---- Keyboard shortcuts ---------------------------------------------- */

    function onDocKey(e) {
        if (!e.ctrlKey && !e.metaKey) { return; }
        // Leave the shortcuts to focused form controls.
        var t = e.target;
        if (t && t.closest && t.closest('input, select, textarea, [contenteditable]:not([contenteditable="false"])')) {
            return;
        }
        if (e.key === '0') { e.preventDefault(); fit(); return; }
        if (e.key === '1') { e.preventDefault(); setZoom(100); return; }
        if (e.key === '=' || e.key === '+') { e.preventDefault(); setZoom(zoomPct + WHEEL_STEP); return; }
        if (e.key === '-' || e.key === '_') { e.preventDefault(); setZoom(zoomPct - WHEEL_STEP); return; }
    }

    /* ---- Init ------------------------------------------------------------- */

    /**
     * Wire the zoom controls.
     *
     * @param {Object} opts
     * @param {HTMLElement} opts.viewport #editor-viewport (the frame).
     * @param {HTMLElement} opts.canvas   #editor-canvas.
     * @param {HTMLElement} opts.slider   range input.
     * @param {HTMLElement} opts.label    percentage text.
     * @param {HTMLElement} [opts.outBtn] − button.
     * @param {HTMLElement} [opts.inBtn]  + button.
     * @param {HTMLElement} [opts.fitBtn] fit button.
     */
    function init(opts) {
        if (!opts || !opts.viewport || !opts.canvas) { return; }
        viewportEl = opts.viewport;
        canvasEl = opts.canvas;
        sliderEl = opts.slider || null;
        labelEl = opts.label || null;

        canvasW = parseInt(document.getElementById('slides-editor').dataset.canvaswidth, 10) || 960;
        canvasH = parseInt(canvasEl.dataset.height, 10) || 540;

        // Start fitted, like the original auto-fit behaviour; the slider
        // then shows the real percentage (e.g.56%).
        zoomPct = computeFitPct();
        applyScale();

        if (sliderEl) {
            sliderEl.addEventListener('input', function() {
                setZoom(parseInt(sliderEl.value, 10));
            });
        }
        if (opts.outBtn) {
            opts.outBtn.addEventListener('click', function() { setZoom(zoomPct - STEP); });
        }
        if (opts.inBtn) {
            opts.inBtn.addEventListener('click', function() { setZoom(zoomPct + STEP); });
        }
        if (opts.fitBtn) {
            opts.fitBtn.addEventListener('click', fit);
        }

        // Ctrl+wheel (and trackpad pinch, which fires ctrl+wheel) zooms the
        // canvas; plain wheel keeps its default page-scroll behaviour.
        viewportEl.addEventListener('wheel', function(e) {
            if (!e.ctrlKey) { return; }
            e.preventDefault();
            setZoom(zoomPct + (e.deltaY < 0 ? WHEEL_STEP : -WHEEL_STEP));
        }, { passive: false });

        document.addEventListener('keydown', onDocKey);
    }

    return {
        init: init,
        applyScale: applyScale,
        fit: fit,
        setZoom: setZoom,
        getZoom: getZoom,
        computeFitPct: computeFitPct,
    };
});
