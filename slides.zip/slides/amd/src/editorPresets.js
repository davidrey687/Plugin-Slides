/**
 * Preset slide layouts — predefined templates for快速 slide creation.
 *
 * @module     mod_slides/editorPresets
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var PRESETS = [
        {
            id: 'blank',
            label: 'Blank',
            slide: {
                title: 'Blank',
                elements: [],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'title',
            label: 'Title only',
            slide: {
                title: 'Title only',
                elements: [
                    {
                        type: 'text', x: 80, y: 160, w: 800, h: 80,
                        text: 'Título de la diapositiva',
                        fontfamily: '"Calibri", sans-serif', fontSize: 44,
                        color: '#1a1a2e', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'titlecontent',
            label: 'Title + content',
            slide: {
                title: 'Title + content',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Título de la diapositiva',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 60, y: 140, w: 840, h: 360,
                        text: 'Contenido principal de la diapositiva.\n\n• Punto uno\n• Punto dos\n• Punto tres',
                        fontfamily: 'sans-serif', fontSize: 22,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: {
                    type: 'linear-gradient',
                    gradient: {
                        angle: 180,
                        stops: [
                            { color: '#e8f0fe', position: 0 },
                            { color: '#ffffff', position: 100 },
                        ],
                    },
                },
                transition: 'none',
            },
        },
        {
            id: 'titleimage',
            label: 'Title + image',
            slide: {
                title: 'Title + image',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Título con imagen',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'image', x: 60, y: 140, w: 420, h: 360,
                        src: '', alt: '',
                        opacity: 100, borderRadius: 0,
                    },
                    {
                        type: 'text', x: 60, y: 520, w: 420, h: 40,
                        text: 'Click para agregar imagen',
                        fontfamily: 'sans-serif', fontSize: 14,
                        color: '#888888', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: {
                    type: 'linear-gradient',
                    gradient: {
                        angle: 135,
                        stops: [
                            { color: '#f0f4ff', position: 0 },
                            { color: '#ffffff', position: 100 },
                        ],
                    },
                },
                transition: 'none',
            },
        },
        {
            id: 'textonly',
            label: 'Text only',
            slide: {
                title: 'Text only',
                elements: [
                    {
                        type: 'text', x: 80, y: 80, w: 800, h: 400,
                        text: 'Escribe tu contenido aquí.\n\nPuedes agregar párrafos, listas y formato de texto.',
                        fontfamily: 'sans-serif', fontSize: 24,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'twocolumns',
            label: 'Two columns',
            slide: {
                title: 'Two columns',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Dos columnas',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 60, y: 140, w: 400, h: 360,
                        text: 'Columna izquierda\n\n• Elemento 1\n• Elemento 2\n• Elemento 3',
                        fontfamily: 'sans-serif', fontSize: 20,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 500, y: 140, w: 400, h: 360,
                        text: 'Columna derecha\n\n• Elemento A\n• Elemento B\n• Elemento C',
                        fontfamily: 'sans-serif', fontSize: 20,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'closing',
            label: 'Closing',
            slide: {
                title: 'Closing',
                elements: [
                    {
                        type: 'text', x: 80, y: 160, w: 800, h: 80,
                        text: '¡Gracias!',
                        fontfamily: '"Calibri", sans-serif', fontSize: 54,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 80, y: 280, w: 800, h: 50,
                        text: 'Preguntas y respuestas',
                        fontfamily: 'sans-serif', fontSize: 24,
                        color: '#cccccc', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: {
                    type: 'linear-gradient',
                    gradient: {
                        angle: 180,
                        stops: [
                            { color: '#1a1a2e', position: 0 },
                            { color: '#2d2d44', position: 100 },
                        ],
                    },
                },
                transition: 'none',
            },
        },
        /* ======== NEW PRESETS (Phase 4) ======== */
        {
            id: 'sectionheader',
            label: 'Section header',
            slide: {
                title: 'Section header',
                elements: [
                    {
                        type: 'shape', x: 0, y: 0, w: 960, h: 540,
                        shape: 'rect', fill: '#1a1a2e', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 80, y: 180, w: 800, h: 80,
                        text: 'Encabezado de Sección',
                        fontfamily: '"Calibri", sans-serif', fontSize: 48,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 80, y: 280, w: 800, h: 50,
                        text: 'Subtítulo descriptivo de la sección',
                        fontfamily: 'sans-serif', fontSize: 22,
                        color: '#aab4c8', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 380, y: 260, w: 200, h: 3,
                        shape: 'rect', fill: '#0d6efd', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                ],
                background: { type: 'solid', color: '#1a1a2e' },
                transition: 'none',
            },
        },
        {
            id: 'titlebullets',
            label: 'Title + bullets',
            slide: {
                title: 'Title + bullets',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Título con viñetas',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 60, y: 110, w: 840, h: 3,
                        shape: 'rect', fill: '#0d6efd', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 60, y: 130, w: 840, h: 370,
                        text: '• Primer punto importante del tema\n\n• Segundo punto con más detalle\n\n• Tercer punto de discusión\n\n• Cuarto punto de conclusión\n\n• Quinto punto adicional',
                        fontfamily: 'sans-serif', fontSize: 22,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'bigquote',
            label: 'Big quote',
            slide: {
                title: 'Big quote',
                elements: [
                    {
                        type: 'text', x: 100, y: 120, w: 80, h: 80,
                        text: '\u201C',
                        fontfamily: 'Georgia, serif', fontSize: 120,
                        color: '#0d6efd', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 120, y: 180, w: 720, h: 160,
                        text: 'La educación es el arma más poderosa que puedes usar para cambiar el mundo.',
                        fontfamily: 'Georgia, serif', fontSize: 28,
                        color: '#333333', align: 'left', bold: false,
                        italic: true, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 120, y: 370, w: 720, h: 40,
                        text: '— Nelson Mandela',
                        fontfamily: 'sans-serif', fontSize: 18,
                        color: '#666666', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#f8f9fa' },
                transition: 'none',
            },
        },
        {
            id: 'comparison',
            label: 'Comparison',
            slide: {
                title: 'Comparison',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Comparación',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 60, y: 130, w: 400, h: 45,
                        shape: 'roundedrect', fill: '#0d6efd', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 60, y: 135, w: 400, h: 40,
                        text: 'Opción A',
                        fontfamily: '"Calibri", sans-serif', fontSize: 20,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 500, y: 130, w: 400, h: 45,
                        shape: 'roundedrect', fill: '#198754', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 500, y: 135, w: 400, h: 40,
                        text: 'Opción B',
                        fontfamily: '"Calibri", sans-serif', fontSize: 20,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 60, y: 190, w: 400, h: 310,
                        text: '• Característica 1\n• Característica 2\n• Característica 3\n• Característica 4',
                        fontfamily: 'sans-serif', fontSize: 20,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 500, y: 190, w: 400, h: 310,
                        text: '• Característica 1\n• Característica 2\n• Característica 3\n• Característica 4',
                        fontfamily: 'sans-serif', fontSize: 20,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'imagefull',
            label: 'Full image',
            slide: {
                title: 'Full image',
                elements: [
                    {
                        type: 'image', x: 60, y: 60, w: 840, h: 420,
                        src: '', alt: '',
                        opacity: 100, borderRadius: 0,
                    },
                    {
                        type: 'text', x: 60, y: 500, w: 840, h: 40,
                        text: 'Click para agregar imagen',
                        fontfamily: 'sans-serif', fontSize: 14,
                        color: '#888888', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#f8f9fa' },
                transition: 'none',
            },
        },
        {
            id: 'title3columns',
            label: 'Title + 3 columns',
            slide: {
                title: 'Title + 3 columns',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Título con tres columnas',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 60, y: 130, w: 260, h: 180,
                        shape: 'roundedrect', fill: '#e8f0fe', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 70, y: 140, w: 240, h: 30,
                        text: 'Categoría 1',
                        fontfamily: '"Calibri", sans-serif', fontSize: 18,
                        color: '#0d6efd', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 70, y: 180, w: 240, h: 120,
                        text: 'Descripción breve del primer punto o categoría.',
                        fontfamily: 'sans-serif', fontSize: 16,
                        color: '#333333', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 350, y: 130, w: 260, h: 180,
                        shape: 'roundedrect', fill: '#e8f0fe', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 360, y: 140, w: 240, h: 30,
                        text: 'Categoría 2',
                        fontfamily: '"Calibri", sans-serif', fontSize: 18,
                        color: '#0d6efd', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 360, y: 180, w: 240, h: 120,
                        text: 'Descripción breve del segundo punto o categoría.',
                        fontfamily: 'sans-serif', fontSize: 16,
                        color: '#333333', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 640, y: 130, w: 260, h: 180,
                        shape: 'roundedrect', fill: '#e8f0fe', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 650, y: 140, w: 240, h: 30,
                        text: 'Categoría 3',
                        fontfamily: '"Calibri", sans-serif', fontSize: 18,
                        color: '#0d6efd', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 650, y: 180, w: 240, h: 120,
                        text: 'Descripción breve del tercer punto o categoría.',
                        fontfamily: 'sans-serif', fontSize: 16,
                        color: '#333333', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'twocolumnstitle',
            label: 'Two columns with titles',
            slide: {
                title: 'Two columns with titles',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Dos columnas con encabezados',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'left', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 60, y: 130, w: 400, h: 40,
                        shape: 'roundedrect', fill: '#0d6efd', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 70, y: 133, w: 380, h: 35,
                        text: 'Ventajas',
                        fontfamily: '"Calibri", sans-serif', fontSize: 18,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 500, y: 130, w: 400, h: 40,
                        shape: 'roundedrect', fill: '#dc3545', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 510, y: 133, w: 380, h: 35,
                        text: 'Desventajas',
                        fontfamily: '"Calibri", sans-serif', fontSize: 18,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 60, y: 185, w: 400, h: 315,
                        text: '• Beneficio 1\n• Beneficio 2\n• Beneficio 3\n• Beneficio 4\n• Beneficio 5',
                        fontfamily: 'sans-serif', fontSize: 20,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 500, y: 185, w: 400, h: 315,
                        text: '• Riesgo 1\n• Riesgo 2\n• Riesgo 3\n• Riesgo 4\n• Riesgo 5',
                        fontfamily: 'sans-serif', fontSize: 20,
                        color: '#333333', align: 'left', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
        {
            id: 'blankdark',
            label: 'Blank dark',
            slide: {
                title: 'Blank dark',
                elements: [],
                background: {
                    type: 'linear-gradient',
                    gradient: {
                        angle: 180,
                        stops: [
                            { color: '#1a1a2e', position: 0 },
                            { color: '#16213e', position: 100 },
                        ],
                    },
                },
                transition: 'none',
            },
        },
        {
            id: 'titlecenterdark',
            label: 'Title centered dark',
            slide: {
                title: 'Title centered dark',
                elements: [
                    {
                        type: 'text', x: 80, y: 200, w: 800, h: 80,
                        text: 'Título Centrado',
                        fontfamily: '"Calibri", sans-serif', fontSize: 48,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 80, y: 300, w: 800, h: 50,
                        text: 'Subtítulo o descripción adicional',
                        fontfamily: 'sans-serif', fontSize: 22,
                        color: '#aab4c8', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 430, y: 285, w: 100, h: 3,
                        shape: 'rect', fill: '#0d6efd', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                ],
                background: {
                    type: 'linear-gradient',
                    gradient: {
                        angle: 135,
                        stops: [
                            { color: '#0f2027', position: 0 },
                            { color: '#203a43', position: 50 },
                            { color: '#2c5364', position: 100 },
                        ],
                    },
                },
                transition: 'none',
            },
        },
        {
            id: 'iconlist',
            label: 'Icon list',
            slide: {
                title: 'Icon list',
                elements: [
                    {
                        type: 'text', x: 60, y: 40, w: 840, h: 70,
                        text: 'Lista con iconos',
                        fontfamily: '"Calibri", sans-serif', fontSize: 36,
                        color: '#1a1a2e', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 100, y: 150, w: 100, h: 100,
                        shape: 'circle', fill: '#0d6efd', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 100, y: 180, w: 100, h: 40,
                        text: '01',
                        fontfamily: '"Calibri", sans-serif', fontSize: 28,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 60, y: 270, w: 180, h: 80,
                        text: 'Primer paso\nDescripción breve',
                        fontfamily: 'sans-serif', fontSize: 16,
                        color: '#333333', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 310, y: 150, w: 100, h: 100,
                        shape: 'circle', fill: '#198754', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 310, y: 180, w: 100, h: 40,
                        text: '02',
                        fontfamily: '"Calibri", sans-serif', fontSize: 28,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 270, y: 270, w: 180, h: 80,
                        text: 'Segundo paso\nDescripción breve',
                        fontfamily: 'sans-serif', fontSize: 16,
                        color: '#333333', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 520, y: 150, w: 100, h: 100,
                        shape: 'circle', fill: '#ffc107', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 520, y: 180, w: 100, h: 40,
                        text: '03',
                        fontfamily: '"Calibri", sans-serif', fontSize: 28,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 480, y: 270, w: 180, h: 80,
                        text: 'Tercer paso\nDescripción breve',
                        fontfamily: 'sans-serif', fontSize: 16,
                        color: '#333333', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'shape', x: 730, y: 150, w: 100, h: 100,
                        shape: 'circle', fill: '#dc3545', stroke: '',
                        strokeWidth: 0, angle: 0,
                    },
                    {
                        type: 'text', x: 730, y: 180, w: 100, h: 40,
                        text: '04',
                        fontfamily: '"Calibri", sans-serif', fontSize: 28,
                        color: '#ffffff', align: 'center', bold: true,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                    {
                        type: 'text', x: 690, y: 270, w: 180, h: 80,
                        text: 'Cuarto paso\nDescripción breve',
                        fontfamily: 'sans-serif', fontSize: 16,
                        color: '#333333', align: 'center', bold: false,
                        italic: false, underline: false, strikethrough: false,
                        highlight: '', listType: 'none',
                    },
                ],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            },
        },
    ];

    function getPresets() {
        return PRESETS.map(function(preset) {
            var resolved = JSON.parse(JSON.stringify(preset));
            try {
                resolved.label = M.util.get_string('preset-' + preset.id, 'mod_slides');
            } catch (e) {
                // Keep hardcoded label as fallback.
            }
            return resolved;
        });
    }

    function getPreset(id) {
        for (var i = 0; i < PRESETS.length; i++) {
            if (PRESETS[i].id === id) { return PRESETS[i]; }
        }
        return null;
    }

    return {
        getPresets: getPresets,
        getPreset: getPreset,
    };
});
