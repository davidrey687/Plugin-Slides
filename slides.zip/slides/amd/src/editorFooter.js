/**
 * Footer element type — persistent footer bar across slides.
 *
 * @module     mod_slides/editorFooter
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var TYPE = 'footer';

    var DEFAULTS = {
        type: TYPE,
        x: 0,
        y: 500,
        w: 960,
        h: 40,
        text: '__FOOTER_DEFAULT__',
        fontfamily: 'sans-serif',
        fontSize: 14,
        color: '#888888',
        align: 'center',
        bold: false,
        italic: false,
        background: '#f8f9fa',
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;' +
            'position:absolute;overflow:hidden;';
    }

    function innerStyle(el) {
        var bg = el.background || '#f8f9fa';
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var style = 'width:100%;height:100%;background:' + bg +
            ';display:flex;align-items:center;justify-content:' + (el.align || 'center') + ';' +
            'font-size:' + (el.fontSize || 14) + 'px;color:' + (el.color || '#888888') + ';' +
            'font-family:' + (el.fontfamily || 'sans-serif') + ';' +
            'opacity:' + opacity + ';' +
            (el.bold ? 'font-weight:bold;' : '') +
            (el.italic ? 'font-style:italic;' : '') +
            'pointer-events:none;';
        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return style;
    }

    function inlineStyles(el) {
        return outerStyle(el) + innerStyle(el);
    }

    function renderText(el) {
        var text = el.text || '';
        if (text === '__FOOTER_DEFAULT__') {
            try { text = M.util.get_string('footertext', 'mod_slides'); }
            catch (e) { text = 'Footer text'; }
        }
        return escapeHtml(text);
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    var PROPERTY_DEFS = [
        { key: 'text',          label: 'footertext',    control: 'text' },
        { key: 'fontfamily',    label: 'font-family',   control: 'select', options: [] },
        { key: 'fontSize',      label: 'font-size',     control: 'number', min: 8, max: 48, step: 1 },
        { key: 'color',         label: 'color',         control: 'color' },
        { key: 'background',    label: 'fill',          control: 'color' },
        { key: 'align',         label: 'alignment',     control: 'iconselect', options: [
            { value: 'left',   icon: 'align-left',   labelKey: 'left',   fallback: 'Left' },
            { value: 'center', icon: 'align-center', labelKey: 'center', fallback: 'Center' },
            { value: 'right',  icon: 'align-right',  labelKey: 'right',  fallback: 'Right' },
        ]},
        { key: 'opacity',        label: 'opacity',        control: 'number', min: 0, max: 100, step: 5 },
        { key: 'bold',          label: 'bold',          control: 'checkbox' },
        { key: 'italic',        label: 'italic',        control: 'checkbox' },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color',  control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        inlineStyles: inlineStyles,
        renderText: renderText,
        PROPERTY_DEFS: PROPERTY_DEFS,
    };
});
