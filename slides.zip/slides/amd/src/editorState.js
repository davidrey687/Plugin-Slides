/**
 * State store for the slides editor with undo/redo.
 *
 * @module     mod_slides/editorState
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorBackground'], function(background) {
    'use strict';

    var MAX_UNDO = 50;

    var state = {
        slides: [],
        current: 0,
        selected: null,
        multiSelected: [],
        dirty: false,
        clipboard: null,
    };

    var undoStack = [];
    var redoStack = [];
    var listeners = [];
    // Content generation counter: bumped on every content mutation so
    // listeners (autosave) can detect real changes in O(1) without
    // serialising the whole deck on each notification.
    var gen = 0;

    function notify() {
        listeners.forEach(function(fn) { fn(state); });
    }

    function snapshot() {
        undoStack.push(JSON.parse(JSON.stringify(state.slides)));
        if (undoStack.length > MAX_UNDO) { undoStack.shift(); }
        redoStack = [];
        state.dirty = true;
        gen++;
        notify();
    }

    function undo() {
        if (undoStack.length === 0) { return; }
        redoStack.push(JSON.parse(JSON.stringify(state.slides)));
        state.slides = undoStack.pop();
        if (state.current >= state.slides.length) {
            state.current = Math.max(0, state.slides.length - 1);
        }
        state.selected = null;
        gen++;
        notify();
    }

    function redo() {
        if (redoStack.length === 0) { return; }
        undoStack.push(JSON.parse(JSON.stringify(state.slides)));
        state.slides = redoStack.pop();
        state.selected = null;
        gen++;
        notify();
    }

    return {
        get: function() { return state; },
        getGen: function() { return gen; },
        subscribe: function(fn) { listeners.push(fn); },
        notify: notify,

        /* ---- data --------------------------------------------------------- */
        load: function(slides) {
            state.slides = slides.map(function(s) {
                s.background = background.normalize(s.background);
                return s;
            });
            state.current = 0;
            state.selected = null;
            state.dirty = false;
            undoStack = [];
            redoStack = [];
            gen++;
            notify();
        },

        /* ---- navigation --------------------------------------------------- */
        setCurrent: function(idx) {
            if (idx < 0 || idx >= state.slides.length) { return; }
            state.current = idx;
            state.selected = null;
            notify();
        },

        selectElement: function(idx, multi) {
            if (multi) {
                var pos = state.multiSelected.indexOf(idx);
                if (pos >= 0) {
                    state.multiSelected.splice(pos, 1);
                } else {
                    state.multiSelected.push(idx);
                }
                state.selected = state.multiSelected.length > 0 ? state.multiSelected[state.multiSelected.length - 1] : null;
            } else {
                state.selected = idx;
                state.multiSelected = idx !== null ? [idx] : [];
            }
            notify();
        },

        deselectElement: function() {
            state.selected = null;
            state.multiSelected = [];
            notify();
        },

        /* ---- slide operations --------------------------------------------- */
        addSlide: function(preset) {
            snapshot();
            var slide = preset ? JSON.parse(JSON.stringify(preset.slide)) : {
                id: 0,
                title: 'Diapositiva ' + (state.slides.length + 1),
                sortorder: state.slides.length,
                elements: [],
                background: { type: 'solid', color: '#ffffff' },
                transition: 'none',
            };
            if (preset) {
                slide.title = preset.label;
            }
            if (!slide.transition) { slide.transition = 'none'; }
            state.slides.push(slide);
            state.current = state.slides.length - 1;
            state.selected = null;
            notify();
        },

        /**
         * Insert several slides in one undo step (PDF import). When
         * `opts.replace` is set the current deck is swapped for the new list.
         *
         * @param {Array} slides raw slide objects (title/elements/background)
         * @param {Object} [opts] {replace: Boolean}
         * @return {Number} index of the first inserted slide
         */
        addSlidesBulk: function(slides, opts) {
            if (!slides || !slides.length) { return state.current; }
            snapshot();
            if (opts && opts.replace) {
                state.slides = [];
            }
            var startIdx = state.slides.length;
            slides.forEach(function(slide) {
                if (!slide.transition) { slide.transition = 'none'; }
                state.slides.push(slide);
            });
            state.slides.forEach(function(s, i) { s.sortorder = i; });
            state.current = startIdx;
            state.selected = null;
            state.multiSelected = [];
            notify();
            return startIdx;
        },

        deleteSlide: function(idx) {
            if (state.slides.length <= 1) { return; }
            snapshot();
            state.slides.splice(idx, 1);
            if (state.current >= state.slides.length) {
                state.current = state.slides.length - 1;
            }
            state.selected = null;
            notify();
        },

        duplicateSlide: function(idx) {
            snapshot();
            var copy = JSON.parse(JSON.stringify(state.slides[idx]));
            copy.id = 0;
            copy.title = copy.title + ' (copia)';
            state.slides.splice(idx + 1, 0, copy);
            state.current = idx + 1;
            state.selected = null;
            notify();
        },

        moveSlide: function(from, to) {
            if (to < 0 || to >= state.slides.length) { return; }
            snapshot();
            var item = state.slides.splice(from, 1)[0];
            state.slides.splice(to, 0, item);
            state.current = to;
            state.selected = null;
            notify();
        },

        renameSlide: function(idx, newTitle) {
            if (idx < 0 || idx >= state.slides.length) { return; }
            snapshot();
            state.slides[idx].title = newTitle;
            notify();
        },

        setSlideTransition: function(idx, transition) {
            if (idx < 0 || idx >= state.slides.length) { return; }
            snapshot();
            state.slides[idx].transition = transition;
            notify();
        },

        setAllTransitions: function(transition) {
            snapshot();
            state.slides.forEach(function(s) { s.transition = transition; });
            notify();
        },

        /* ---- bulk font-family updates -------------------------------------- */
        /**
         * Text elements that would change if `family` were applied deck-wide.
         *
         * @param {string} family Target font-family value.
         * @param {Object} exclude {slide, element} selection to skip (may be null).
         * @return {{elements: number, slides: number}}
         */
        countTextElements: function(family, exclude) {
            var elements = 0;
            var slides = 0;
            state.slides.forEach(function(s, sIdx) {
                var hits = 0;
                (s.elements || []).forEach(function(el, eIdx) {
                    if (el.type !== 'text') { return; }
                    if (exclude && exclude.slide === sIdx && exclude.element === eIdx) { return; }
                    if ((el.fontfamily || 'sans-serif') === family) { return; }
                    hits++;
                });
                if (hits > 0) {
                    slides++;
                    elements += hits;
                }
            });
            return { elements: elements, slides: slides };
        },

        /**
         * Apply one font family to every text element of the deck.
         * One snapshot for the whole bulk change = one undo step.
         *
         * @param {string} family New font-family value.
         * @param {Object} exclude {slide, element} selection to skip (may be null).
         * @return {{elements: number, slides: number}}
         */
        applyFontToAllText: function(family, exclude) {
            if (!family) {
                return { elements: 0, slides: 0 };
            }

            // Count first so we can skip the undo snapshot when nothing matches.
            var pending = 0;
            state.slides.forEach(function(s, sIdx) {
                (s.elements || []).forEach(function(el, eIdx) {
                    if (el.type !== 'text') { return; }
                    if (exclude && exclude.slide === sIdx && exclude.element === eIdx) { return; }
                    if ((el.fontfamily || 'sans-serif') === family) { return; }
                    pending++;
                });
            });
            if (pending === 0) {
                return { elements: 0, slides: 0 };
            }

            snapshot();

            var changed = 0;
            var slidesHit = 0;
            state.slides.forEach(function(s, sIdx) {
                var hits = 0;
                (s.elements || []).forEach(function(el, eIdx) {
                    if (el.type !== 'text') { return; }
                    if (exclude && exclude.slide === sIdx && exclude.element === eIdx) { return; }
                    if ((el.fontfamily || 'sans-serif') === family) { return; }
                    el.fontfamily = family;
                    hits++;
                });
                if (hits > 0) {
                    slidesHit++;
                    changed += hits;
                }
            });

            notify();
            return { elements: changed, slides: slidesHit };
        },

        /* ---- templates / layouts ------------------------------------------ */
        addTemplateSlide: function(preset) {
            snapshot();
            var slide = JSON.parse(JSON.stringify(preset.slide));
            slide.title = preset.label;
            if (!slide.transition) { slide.transition = 'none'; }
            state.slides.push(slide);
            state.current = state.slides.length - 1;
            state.selected = null;
            notify();
        },

        applyTemplate: function(slideIdx, preset) {
            snapshot();
            var slide = JSON.parse(JSON.stringify(preset.slide));
            slide.title = preset.label;
            if (!slide.transition) { slide.transition = 'none'; }
            state.slides[slideIdx] = slide;
            state.selected = null;
            notify();
        },

        /* ---- element operations ------------------------------------------- */
        addElement: function(slideIdx, element) {
            var slide = state.slides[slideIdx];
            if (!slide) { return; }
            snapshot();
            if (!Array.isArray(slide.elements)) { slide.elements = []; }
            slide.elements.push(element);
            state.selected = slide.elements.length - 1;
            notify();
        },

        updateElementAtomic: function(slideIdx, elemIdx, props) {
            snapshot();
            var el = state.slides[slideIdx].elements[elemIdx];
            Object.keys(props).forEach(function(k) { el[k] = props[k]; });
            notify();
        },

        beginDragSnapshot: function() {
            snapshot();
        },

        updateElement: function(slideIdx, elemIdx, props) {
            var el = state.slides[slideIdx].elements[elemIdx];
            Object.keys(props).forEach(function(k) { el[k] = props[k]; });
            state.dirty = true;
            gen++;
            notify();
        },

        markDirty: function() {
            state.dirty = true;
            gen++;
            notify();
        },

        deleteElement: function(slideIdx, elemIdx) {
            snapshot();
            state.slides[slideIdx].elements.splice(elemIdx, 1);
            state.selected = null;
            notify();
        },

        /* ---- background --------------------------------------------------- */
        setSlideBackground: function(slideIdx, bg) {
            snapshot();
            state.slides[slideIdx].background = bg;
            notify();
        },

        /**
         * Apply one background to every slide as a single undo step.
         */
        setAllBackgrounds: function(bg) {
            snapshot();
            var copy = JSON.parse(JSON.stringify(bg));
            state.slides.forEach(function(s) {
                s.background = JSON.parse(JSON.stringify(copy));
            });
            notify();
        },

        /* ---- layer operations -------------------------------------------- */
        bringToFront: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx < 0 || elemIdx >= elements.length) { return; }
            snapshot();
            var el = elements.splice(elemIdx, 1)[0];
            elements.push(el);
            state.selected = elements.length - 1;
            notify();
        },

        sendToBack: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx < 0 || elemIdx >= elements.length) { return; }
            snapshot();
            var el = elements.splice(elemIdx, 1)[0];
            elements.unshift(el);
            state.selected = 0;
            notify();
        },

        bringForward: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx < 0 || elemIdx >= elements.length - 1) { return; }
            snapshot();
            var el = elements[elemIdx];
            elements[elemIdx] = elements[elemIdx + 1];
            elements[elemIdx + 1] = el;
            state.selected = elemIdx + 1;
            notify();
        },

        sendBackward: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx <= 0 || elemIdx >= elements.length) { return; }
            snapshot();
            var el = elements[elemIdx];
            elements[elemIdx] = elements[elemIdx - 1];
            elements[elemIdx - 1] = el;
            state.selected = elemIdx - 1;
            notify();
        },

        moveLayer: function(slideIdx, fromIdx, toIdx) {
            var elements = state.slides[slideIdx].elements;
            if (fromIdx < 0 || fromIdx >= elements.length) { return; }
            if (toIdx < 0 || toIdx >= elements.length) { return; }
            if (fromIdx === toIdx) { return; }
            snapshot();
            var el = elements.splice(fromIdx, 1)[0];
            elements.splice(toIdx, 0, el);
            state.selected = toIdx;
            notify();
        },

        toggleLayerVisibility: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx < 0 || elemIdx >= elements.length) { return; }
            snapshot();
            var el = elements[elemIdx];
            el._visible = el._visible === false ? true : false;
            notify();
        },

        toggleLayerLock: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx < 0 || elemIdx >= elements.length) { return; }
            snapshot();
            var el = elements[elemIdx];
            el._locked = !el._locked;
            notify();
        },

        /* ---- copy / cut / paste ------------------------------------------- */
        copyElement: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx < 0 || elemIdx >= elements.length) { return; }
            state.clipboard = JSON.parse(JSON.stringify(elements[elemIdx]));
        },

        cutElement: function(slideIdx, elemIdx) {
            var elements = state.slides[slideIdx].elements;
            if (elemIdx < 0 || elemIdx >= elements.length) { return; }
            state.clipboard = JSON.parse(JSON.stringify(elements[elemIdx]));
            snapshot();
            elements.splice(elemIdx, 1);
            state.selected = null;
            notify();
        },

        pasteElement: function(slideIdx) {
            if (!state.clipboard) { return; }
            snapshot();
            var el = JSON.parse(JSON.stringify(state.clipboard));
            el.x = (el.x || 0) + 20;
            el.y = (el.y || 0) + 20;
            state.slides[slideIdx].elements.push(el);
            state.selected = state.slides[slideIdx].elements.length - 1;
            notify();
        },

        /* ---- dirty -------------------------------------------------------- */
        isDirty: function() { return state.dirty; },
        setClean: function() { state.dirty = false; notify(); },
        // Mark dirty + leave an undo checkpoint (used by autosave recovery).
        snapshot: snapshot,

        /* ---- undo / redo -------------------------------------------------- */
        canUndo: function() { return undoStack.length > 0; },
        canRedo: function() { return redoStack.length > 0; },
        undo: undo,
        redo: redo,
    };
});
