/**
 * Pencil element type — freehand drawing via SVG polyline.
 *
 * @module     mod_slides/editorPencil
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var TYPE = 'pencil';

    var DEFAULTS = {
        type: TYPE,
        x: 100,
        y: 100,
        w: 300,
        h: 200,
        points: [],
        stroke: '#1a1a2e',
        strokeWidth: 3,
        pathfill: '',
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
    }

    function innerStyle(el) {
        var stroke = el.stroke || '#1a1a2e';
        var sw = el.strokeWidth || 3;
        return 'width:100%;height:100%;position:relative;overflow:visible;';
    }

    function buildSvgPath(points, w, h) {
        if (!points || points.length < 2) { return ''; }
        var pathData = 'M ' + points[0].x + ' ' + points[0].y;
        for (var i = 1; i < points.length; i++) {
            pathData += ' L ' + points[i].x + ' ' + points[i].y;
        }
        return pathData;
    }

    function renderSvg(el) {
        var w = el.w || 300;
        var h = el.h || 200;
        var stroke = el.stroke || '#1a1a2e';
        var sw = (el.strokeWidth !== undefined && el.strokeWidth !== null) ? el.strokeWidth : 3;
        // Optional fill (imported vector shapes); empty = open stroke only.
        var fill = (el.pathfill && el.pathfill !== 'transparent') ? el.pathfill : 'none';
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var pathData = buildSvgPath(el.points || [], w, h);

        var svgNS = 'http://www.w3.org/2000/svg';
        var svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
        svg.setAttribute('preserveAspectRatio', 'none');
        svg.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;opacity:' + opacity + ';';

        if (pathData) {
            var path = document.createElementNS(svgNS, 'path');
            path.setAttribute('d', pathData);
            path.setAttribute('stroke', stroke);
            path.setAttribute('stroke-width', sw);
            path.setAttribute('fill', fill);
            path.setAttribute('stroke-linecap', 'round');
            path.setAttribute('stroke-linejoin', 'round');
            if (el.shadowEnabled) {
                path.setAttribute('filter', 'url(#pencil-shadow-' + el.x + ')');
            }
            svg.appendChild(path);
        }

        return svg;
    }

    function computeBounds(points) {
        if (!points || points.length === 0) {
            return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
        }
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        points.forEach(function(p) {
            if (p.x < minX) { minX = p.x; }
            if (p.y < minY) { minY = p.y; }
            if (p.x > maxX) { maxX = p.x; }
            if (p.y > maxY) { maxY = p.y; }
        });
        return { minX: minX, minY: minY, maxX: maxX, maxY: maxY };
    }

    function normalizePoints(points) {
        if (!points || points.length === 0) { return []; }
        var bounds = computeBounds(points);
        var offsetX = bounds.minX;
        var offsetY = bounds.minY;
        return points.map(function(p) {
            return { x: Math.round(p.x - offsetX), y: Math.round(p.y - offsetY) };
        });
    }

    var PROPERTY_DEFS = [
        { key: 'stroke',        label: 'stroke',        control: 'color' },
        { key: 'strokeWidth',   label: 'strokewidth',   control: 'number', min: 1, max: 20, step: 1 },
        { key: 'pathfill',      label: 'fill',          control: 'color', clearable: true, clearLabel: 'fillnone' },
        { key: 'opacity',       label: 'opacity',       control: 'number', min: 0, max: 100, step: 5 },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color',  control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        renderSvg: renderSvg,
        computeBounds: computeBounds,
        normalizePoints: normalizePoints,
        PROPERTY_DEFS: PROPERTY_DEFS,
    };
});
