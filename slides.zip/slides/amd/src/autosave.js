/**
 * Auto-save for the slides editor — local drafts + debounced server saves.
 *
 * Three layers protect the teacher's work:
 *  1. localStorage draft (debounced 1s) written on every content change, so a
 *     crash or power cut can be recovered with a restore dialog on next load.
 *  2. Debounced server save (4s idle) through mod_slides_save_deck — the same
 *     external web service the manual Save button uses, in quiet mode (status
 *     indicator instead of error modals).
 *  3. A 30s fallback interval that retries whenever the deck is still dirty
 *     (covers a failed debounced save while the teacher keeps editing).
 *
 * The status indicator (#editor-status) walks through:
 *   "Unsaved changes" → "Saving…" → "Auto-saved HH:MM" / "Error saving".
 *
 * Change detection uses editorState's O(1) content generation counter, so
 * selection notifications and drag mouse-moves never serialise the deck.
 *
 * Concurrency: a single `inflight` promise (plus the content gen captured
 * when it was fired) is the only place a server request can be running. The
 * manual Save button and the debounced autosave can therefore never issue two
 * concurrent requests — Moodle serialises same-session requests behind its
 * session lock, and racing them used to double the Save button's latency.
 * The manual button goes through flush(), which piggybacks on an in-flight
 * save that already covers the current content, or fires exactly one request.
 *
 * @module     mod_slides/autosave
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/editorSave'], function(state, save) {
    'use strict';

    var LOCAL_DEBOUNCE_MS = 1000;   // localStorage write after 1s idle
    var SERVER_DEBOUNCE_MS = 4000;  // server save after 4s idle
    var FALLBACK_MS = 30000;        // retry interval while still dirty
    var MANUAL_SAFETY_MS = 60000;   // never leave autosave blocked forever
    var KEY_PREFIX = 'slides_autosave_';

    var ctx = null;        // {cmid, sesskey, statusEl}
    var serverTimer = null;
    var localTimer = null;
    var intervalId = null;
    var safetyTimer = null;   // manual-save watchdog (releases the inflight slot)
    var inflight = null;      // Promise of the one server request that may run
    var inflightGen = -1;     // editorState content gen captured at fire time
    var queued = false;       // content changed while a save was in flight
    var lastGen = -1;      // editorState content gen last seen as changed
    var localBroken = false; // localStorage quota/type failure → skip drafts

    function str(key, param) {
        try {
            return M.util.get_string(key, 'mod_slides', param);
        } catch (e) { return key; }
    }

    /* ---- status indicator ------------------------------------------------ */

    function setStatus(kind, text) {
        var el = ctx && ctx.statusEl;
        if (!el) { return; }
        el.classList.remove('is-dirty', 'is-saving', 'is-saved', 'is-error');
        el.classList.add('is-' + kind);
        el.dataset.state = kind;
        if (text) { el.textContent = text; }
    }

    function clockTime() {
        var d = new Date();
        var hh = ('0' + d.getHours()).slice(-2);
        var mm = ('0' + d.getMinutes()).slice(-2);
        return hh + ':' + mm;
    }

    /* ---- localStorage draft ---------------------------------------------- */

    function draftKey() {
        return KEY_PREFIX + ctx.cmid;
    }

    function savedKey() {
        return KEY_PREFIX + ctx.cmid + '.saved';
    }

    function readDraft() {
        if (localBroken || !ctx) { return null; }
        try {
            var raw = localStorage.getItem(draftKey());
            if (!raw) { return null; }
            var d = JSON.parse(raw);
            if (!d || d.v !== 1 || !Array.isArray(d.slides)) { return null; }
            return d;
        } catch (e) {
            return null;
        }
    }

    function writeDraft(slides) {
        if (localBroken || !ctx) { return; }
        try {
            localStorage.setItem(draftKey(), JSON.stringify({
                v: 1,
                slides: slides,
                updatedAt: Date.now(),
            }));
        } catch (e) {
            // QuotaExceededError (huge data-URI decks) or private mode:
            // fall back to server-only autosave rather than breaking editing.
            localBroken = true;
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('[mod_slides] localStorage draft disabled: ' + e.message);
            }
        }
    }

    /**
     * Tiny baseline key (timestamp only): recording "the server has this deck"
     * must cost ~0 ms — never re-serialise the slides here.
     */
    function writeSavedAt() {
        if (localBroken || !ctx) { return; }
        try {
            localStorage.setItem(savedKey(), String(Date.now()));
        } catch (e) {
            localBroken = true;
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('[mod_slides] localStorage baseline disabled: ' + e.message);
            }
        }
    }

    function readSavedAt() {
        if (localBroken || !ctx) { return 0; }
        try {
            return Number(localStorage.getItem(savedKey())) || 0;
        } catch (e) {
            return 0;
        }
    }

    function scheduleLocal(slides) {
        if (localTimer) { clearTimeout(localTimer); }
        localTimer = setTimeout(function() {
            localTimer = null;
            writeDraft(slides);
        }, LOCAL_DEBOUNCE_MS);
    }

    /* ---- server save ------------------------------------------------------ */

    /**
     * Fire the server save NOW (no debounce). Returns a promise that resolves
     * with true on success / false on failure and never rejects, so callers
     * that ignore the result (debounce timer, fallback interval) cannot leak
     * an unhandled rejection.
     *
     * At most one request runs at a time: `inflight` holds its promise and
     * `inflightGen` the content gen it captures, so flush() can tell whether
     * that request already covers the current content.
     */
    function runServerSave() {
        if (serverTimer) { clearTimeout(serverTimer); serverTimer = null; }
        if (!ctx) { return Promise.resolve(false); }
        if (inflight) { return inflight; }
        if (!state.isDirty()) { return Promise.resolve(true); }

        setStatus('saving', str('saving'));

        var genAtSend = state.getGen();
        inflightGen = genAtSend;
        var slides = state.get().slides;

        var p = save.save(ctx.cmid, slides, ctx.sesskey, { quiet: true }).then(function() {
            // Only release the slot if it is still ours: the watchdog may have
            // freed it already and a newer save may own it now.
            if (inflight === p) {
                inflight = null;
                if (safetyTimer) { clearTimeout(safetyTimer); safetyTimer = null; }
            }
            writeSavedAt();
            if (state.isDirty()) {
                if (state.getGen() === genAtSend) {
                    state.setClean(); // notify → onChange: dirty=false → no-op
                    setStatus('saved', str('autosaved', clockTime()));
                } else {
                    // Content changed while the save was in flight: stay dirty.
                    setStatus('dirty', str('unsaved'));
                }
            } else {
                setStatus('saved', str('autosaved', clockTime()));
            }
            if (queued) { runServerSave(); }
            return true;
        }).catch(function() {
            if (inflight === p) {
                inflight = null;
                if (safetyTimer) { clearTimeout(safetyTimer); safetyTimer = null; }
            }
            setStatus('error', str('errorsaving'));
            if (queued) { runServerSave(); }
            return false;
        });

        inflight = p;
        // Watchdog: a never-settling request must not block autosave (and the
        // Save button) forever. The slot is released; a late settlement then
        // just skips (inflight !== p) instead of clobbering a newer save.
        if (safetyTimer) { clearTimeout(safetyTimer); }
        safetyTimer = setTimeout(function() {
            safetyTimer = null;
            if (inflight === p) { inflight = null; }
        }, MANUAL_SAFETY_MS);
        return p;
    }

    function scheduleServer() {
        if (inflight) { queued = true; return; }
        if (serverTimer) { clearTimeout(serverTimer); }
        serverTimer = setTimeout(runServerSave, SERVER_DEBOUNCE_MS);
    }

    /**
     * Resolve once the CURRENT content is on the server. Used by the manual
     * Save button so it can never race the debounced autosave:
     *  - deck already clean        → resolves instantly, no request at all
     *  - an in-flight save covers the current gen → piggybacks on it
     *  - an in-flight save is stale (edits landed meanwhile) → waits, then
     *    saves the fresh content
     *  - nothing running           → saves right now
     * Rejects when the save actually failed, so the button can show the error.
     */
    function flush() {
        function failIfNot(ok) {
            if (ok === false) {
                throw new Error('mod_slides: save failed');
            }
        }

        if (!ctx) { return Promise.resolve(); }
        if (serverTimer) { clearTimeout(serverTimer); serverTimer = null; }
        queued = false;

        if (!state.isDirty()) { return Promise.resolve(); }

        if (inflight) {
            var covered = inflightGen === state.getGen();
            return inflight.then(function(ok) {
                if (covered) { failIfNot(ok); return; } // already saved this exact content
                if (!state.isDirty()) { return; }
                return runServerSave().then(failIfNot);
            });
        }

        return runServerSave().then(failIfNot);
    }

    /* ---- change detection -------------------------------------------------- */

    function onChange() {
        if (!ctx || !state.isDirty()) { return; }
        var gen = state.getGen();
        // Selection-only notifications carry no content change (gen unchanged):
        // keep the pending timers stable so clicks never reset the debounce.
        if (gen === lastGen) { return; }
        lastGen = gen;

        // Never clobber the "Saving…" text while a save is running; the
        // timers below still track the change and the save result refreshes
        // the status when it settles.
        if (!inflight) {
            setStatus('dirty', str('unsaved'));
        }
        scheduleLocal(state.get().slides);
        scheduleServer();
    }

    /* ---- recovery ---------------------------------------------------------- */

    /**
     * Offer the local draft when it has edits newer than the last server save
     * and differs from the deck that just loaded.
     */
    function checkRecovery() {
        if (!ctx) { return; }
        var draft = readDraft();
        if (!draft) { return; }
        if (!(draft.updatedAt > readSavedAt())) { return; }

        var serverJson = JSON.stringify(state.get().slides);
        var draftJson = JSON.stringify(draft.slides);
        if (serverJson === draftJson) {
            // Identical content: silently refresh the baseline.
            writeSavedAt();
            return;
        }

        openRecoveryDialog(draft);
    }

    function openRecoveryDialog(draft) {
        var backdrop = document.createElement('div');
        backdrop.className = 'media-dialog-backdrop';

        var modal = document.createElement('div');
        modal.className = 'media-dialog autosave-dialog';
        modal.setAttribute('role', 'alertdialog');
        modal.setAttribute('aria-modal', 'true');

        var header = document.createElement('div');
        header.className = 'media-header';
        var title = document.createElement('div');
        title.className = 'media-title';
        title.textContent = str('draftfound');
        header.appendChild(title);
        modal.appendChild(header);

        var footer = document.createElement('div');
        footer.className = 'media-footer';

        function choose(restore) {
            document.removeEventListener('keydown', onKey, true);
            backdrop.remove();
            if (restore) {
                state.load(draft.slides);
                // load() clears dirty: snapshot() re-marks the deck dirty and
                // leaves an undo entry, so the restore itself is reversible.
                // snapshot() also bumps the content gen, so onChange schedules
                // the local draft write and the debounced server save.
                state.snapshot();
            } else {
                try { localStorage.removeItem(draftKey()); } catch (e) { /* ignore */ }
            }
        }

        var discardBtn = document.createElement('button');
        discardBtn.type = 'button';
        discardBtn.className = 'btn btn-secondary';
        discardBtn.textContent = str('draftdiscard');
        discardBtn.addEventListener('click', function() { choose(false); });

        var restoreBtn = document.createElement('button');
        restoreBtn.type = 'button';
        restoreBtn.className = 'btn btn-primary';
        restoreBtn.textContent = str('draftrestore');
        restoreBtn.addEventListener('click', function() { choose(true); });

        footer.appendChild(discardBtn);
        footer.appendChild(restoreBtn);
        modal.appendChild(footer);

        function onKey(e) {
            if (e.key === 'Escape') { e.stopPropagation(); e.preventDefault(); }
            // The teacher must pick Restore or Discard explicitly.
        }
        document.addEventListener('keydown', onKey, true);

        backdrop.appendChild(modal);
        document.body.appendChild(backdrop);
        restoreBtn.focus();
    }

    /* ---- public API -------------------------------------------------------- */

    function init(opts) {
        if (ctx) { return; } // idempotent (page reload safety)
        ctx = {
            cmid: opts.cmid,
            sesskey: opts.sesskey,
            statusEl: opts.statusEl || null,
        };
        lastGen = state.getGen();
        state.subscribe(onChange);

        if (ctx.statusEl) {
            ctx.statusEl.classList.add('is-saved');
            ctx.statusEl.dataset.state = 'saved';
        }

        if (intervalId) { clearInterval(intervalId); }
        intervalId = setInterval(function() {
            if (state.isDirty() && !inflight && !serverTimer) {
                runServerSave();
            }
        }, FALLBACK_MS);
    }

    return {
        init: init,
        checkRecovery: checkRecovery,
        flush: flush,
    };
});
