/**
 * Chart element type — renders bar/line/pie charts as SVG.
 *
 * @module     mod_slides/editorChart
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var TYPE = 'chart';

    var COLORS = [
        '#0d6efd', '#dc3545', '#198754', '#ffc107',
        '#0dcaf0', '#6f42c1', '#fd7e14', '#20c997',
    ];

    var DEFAULTS = {
        type: TYPE,
        x: 100,
        y: 100,
        w: 400,
        h: 300,
        charttype: 'bar',
        title: '__CHART_DEFAULT__',
        labels: 'A\nB\nC\nD',
        values: '30\n50\n20\n40',
        titleColor: '#1a1a2e',
        valueColor: '#333333',
        bgColor: '#ffffff',
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
    }

    function innerStyle(el) {
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var style = 'width:100%;height:100%;overflow:hidden;pointer-events:none;opacity:' + opacity + ';';
        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return style;
    }

    function parseValues(el) {
        var labels = (el.labels || '').split('\n').filter(function(s) { return s.trim(); });
        var rawValues = (el.values || '').split('\n').filter(function(s) { return s.trim(); });
        var values = rawValues.map(function(v) { return parseFloat(v) || 0; });
        return { labels: labels, values: values };
    }

    function renderChart(el) {
        var data = parseValues(el);
        var svgNS = 'http://www.w3.org/2000/svg';
        var w = el.w || 400;
        var h = el.h || 300;
        var charttype = el.charttype || 'bar';
        var chartTitle = el.title || '';
        if (chartTitle === '__CHART_DEFAULT__') {
            try { chartTitle = M.util.get_string('addchart', 'mod_slides'); }
            catch (e) { chartTitle = 'Chart'; }
        }

        var svg = document.createElementNS(svgNS, 'svg');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
        svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
        svg.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;';

        var margin = { top: 30, right: 20, bottom: 30, left: 40 };
        var cw = w - margin.left - margin.right;
        var ch = h - margin.top - margin.bottom;

        // Title
        if (chartTitle) {
            var title = document.createElementNS(svgNS, 'text');
            title.setAttribute('x', w / 2);
            title.setAttribute('y', 18);
            title.setAttribute('text-anchor', 'middle');
            title.setAttribute('fill', el.titleColor || '#1a1a2e');
            title.setAttribute('font-size', '13');
            title.setAttribute('font-weight', 'bold');
            title.textContent = chartTitle;
            svg.appendChild(title);
        }

        var maxVal = Math.max.apply(null, data.values.length ? data.values : [1]);

        if (charttype === 'bar') {
            var barW = cw / Math.max(data.values.length, 1) * 0.6;
            var gap = cw / Math.max(data.values.length, 1) * 0.4;

            data.values.forEach(function(v, i) {
                var barH = (v / maxVal) * ch;
                var x = margin.left + i * (barW + gap) + gap / 2;
                var y = margin.top + ch - barH;
                var rect = document.createElementNS(svgNS, 'rect');
                rect.setAttribute('x', x);
                rect.setAttribute('y', y);
                rect.setAttribute('width', barW);
                rect.setAttribute('height', barH);
                rect.setAttribute('fill', COLORS[i % COLORS.length]);
                rect.setAttribute('rx', '2');
                svg.appendChild(rect);

                // Label
                var label = document.createElementNS(svgNS, 'text');
                label.setAttribute('x', x + barW / 2);
                label.setAttribute('y', h - 8);
                label.setAttribute('text-anchor', 'middle');
                label.setAttribute('fill', el.valueColor || '#333');
                label.setAttribute('font-size', '10');
                label.textContent = data.labels[i] || '';
                svg.appendChild(label);

                // Value
                var valText = document.createElementNS(svgNS, 'text');
                valText.setAttribute('x', x + barW / 2);
                valText.setAttribute('y', y - 4);
                valText.setAttribute('text-anchor', 'middle');
                valText.setAttribute('fill', el.valueColor || '#333');
                valText.setAttribute('font-size', '10');
                valText.textContent = v;
                svg.appendChild(valText);
            });

        } else if (charttype === 'line') {
            var pts = data.values.map(function(v, i) {
                var px = margin.left + (i / Math.max(data.values.length - 1, 1)) * cw;
                var py = margin.top + ch - (v / maxVal) * ch;
                return px + ',' + py;
            });

            if (pts.length > 1) {
                var polyline = document.createElementNS(svgNS, 'polyline');
                polyline.setAttribute('points', pts.join(' '));
                polyline.setAttribute('fill', 'none');
                polyline.setAttribute('stroke', COLORS[0]);
                polyline.setAttribute('stroke-width', '2');
                svg.appendChild(polyline);
            }

            data.values.forEach(function(v, i) {
                var px = margin.left + (i / Math.max(data.values.length - 1, 1)) * cw;
                var py = margin.top + ch - (v / maxVal) * ch;
                var circle = document.createElementNS(svgNS, 'circle');
                circle.setAttribute('cx', px);
                circle.setAttribute('cy', py);
                circle.setAttribute('r', '4');
                circle.setAttribute('fill', COLORS[0]);
                svg.appendChild(circle);

                var label = document.createElementNS(svgNS, 'text');
                label.setAttribute('x', px);
                label.setAttribute('y', h - 8);
                label.setAttribute('text-anchor', 'middle');
                label.setAttribute('fill', el.valueColor || '#333');
                label.setAttribute('font-size', '10');
                label.textContent = data.labels[i] || '';
                svg.appendChild(label);
            });

        } else if (charttype === 'pie') {
            var total = data.values.reduce(function(a, b) { return a + b; }, 0);
            if (total === 0) { total = 1; }
            var cx = margin.left + cw / 2;
            var cy = margin.top + ch / 2;
            var r = Math.min(cw, ch) / 2 - 10;
            var startAngle = -Math.PI / 2;

            data.values.forEach(function(v, i) {
                var slice = (v / total) * 2 * Math.PI;
                var x1 = cx + r * Math.cos(startAngle);
                var y1 = cy + r * Math.sin(startAngle);
                var x2 = cx + r * Math.cos(startAngle + slice);
                var y2 = cy + r * Math.sin(startAngle + slice);
                var large = slice > Math.PI ? 1 : 0;

                var path = document.createElementNS(svgNS, 'path');
                var d = 'M ' + cx + ' ' + cy + ' L ' + x1 + ' ' + y1 +
                    ' A ' + r + ' ' + r + ' 0 ' + large + ' 1 ' + x2 + ' ' + y2 + ' Z';
                path.setAttribute('d', d);
                path.setAttribute('fill', COLORS[i % COLORS.length]);
                svg.appendChild(path);
                startAngle += slice;
            });
        }

        return svg;
    }

    var PROPERTY_DEFS = [
        { key: 'charttype',    label: 'addchart',      control: 'select', options: [
            { value: 'bar',  labelKey: 'chartbar',  fallback: 'Bar' },
            { value: 'line', labelKey: 'chartline', fallback: 'Line' },
            { value: 'pie',  labelKey: 'chartpie',  fallback: 'Pie' },
        ]},
        { key: 'title',         label: 'name',          control: 'text' },
        { key: 'labels',        label: 'addchart',      control: 'text' },
        { key: 'values',        label: 'width',         control: 'text' },
        { key: 'titleColor',    label: 'color',         control: 'color' },
        { key: 'valueColor',    label: 'font-size',     control: 'color' },
        { key: 'bgColor',       label: 'fill',          control: 'color' },
        { key: 'opacity',       label: 'opacity',       control: 'number', min: 0, max: 100, step: 5 },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color',  control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        renderChart: renderChart,
        parseValues: parseValues,
        PROPERTY_DEFS: PROPERTY_DEFS,
    };
});
