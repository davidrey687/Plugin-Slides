/**
 * Properties panel — compact layout with 2-col grids + section labels.
 *
 * @module     mod_slides/editorProperties
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([
    'mod_slides/editorState',
    'mod_slides/editorTextelem',
    'mod_slides/editorPencil',
    'mod_slides/editorIcons',
], function(state, textelem, pencil, icons) {
    'use strict';

    var container = null;
    var typeConfigs = { text: textelem, pencil: pencil };
    var cropStarter = null;
    var equationStarter = null;
    var htmlStarter = null;

    /**
     * Register the handler used by the "Crop" button (wired to the canvas
     * by the app module, mirroring canvas.setEmptyImagePicker).
     *
     * @param {Function} fn function(elemIdx)
     */
    function setCropStarter(fn) {
        cropStarter = typeof fn === 'function' ? fn : null;
    }

    /**
     * Register the handler used by the "Edit equation" button.
     *
     * @param {Function} fn function(slideIdx, elemIdx)
     */
    function setEquationStarter(fn) {
        equationStarter = typeof fn === 'function' ? fn : null;
    }

    /**
     * Register the handler used by the "Edit HTML code" button.
     *
     * @param {Function} fn function(slideIdx, elemIdx)
     */
    function setHtmlStarter(fn) {
        htmlStarter = typeof fn === 'function' ? fn : null;
    }


    var TYPE_LABELS = {
        text:   'type-text',
        shape:  'type-shape',
        pencil: 'type-pencil',
        image:  'type-image',
        video:  'type-video',
        audio:  'type-audio',
        link:   'type-link',
        pdf:    'type-pdf',
        equation: 'type-equation',
        html:   'type-html',
    };

    var TRANSITION_OPTIONS = [
        { value: 'none',       labelKey: 'transition-none',       fallback: 'None',       icon: 'none' },
        { value: 'fade',       labelKey: 'transition-fade',       fallback: 'Fade',       icon: 'fade' },
        { value: 'push',       labelKey: 'transition-push',       fallback: 'Push',       icon: 'push' },
        { value: 'slide-left', labelKey: 'transition-slide-left', fallback: 'Slide Left', icon: 'slide-left' },
        { value: 'slide-up',   labelKey: 'transition-slide-up',   fallback: 'Slide Up',   icon: 'slide-up' },
        { value: 'slide-down', labelKey: 'transition-slide-down', fallback: 'Slide Down', icon: 'slide-down' },
        { value: 'zoom',       labelKey: 'transition-zoom',       fallback: 'Zoom',       icon: 'zoom' },
        { value: 'flip',       labelKey: 'transition-flip',       fallback: 'Flip',       icon: 'flip' },
        { value: 'reveal',     labelKey: 'transition-reveal',     fallback: 'Reveal',     icon: 'reveal' },
        { value: 'cube',       labelKey: 'transition-cube',       fallback: 'Cube',       icon: 'cube' },
        { value: 'cut',        labelKey: 'transition-cut',        fallback: 'Cut',        icon: 'cut' },
        { value: 'transform',  labelKey: 'transition-transform',  fallback: 'Transform',  icon: 'transform' },
    ];

    function str(key) {
        return M.util.get_string(key, 'mod_slides');
    }

    function init(c) {
        container = c;
        state.subscribe(render);
        render();
    }

    function render() {
        var s = state.get();
        container.innerHTML = '';

        if (s.selected === null) {
            // Show slide properties when no element selected
            renderSlideProps(s);
            return;
        }

        var slide = s.slides[s.current];
        if (!slide) { return; }
        var el = slide.elements[s.selected];
        if (!el) { return; }

        var config = typeConfigs[el.type];
        if (!config) { return; }

        // Header
        var header = document.createElement('div');
        header.className = 'properties-header';
        header.textContent = str('properties') + ' — ' + (str(TYPE_LABELS[el.type] || 'properties'));
        container.appendChild(header);

        // Section: Position
        addSectionLabel(container, str('width') + ' & ' + str('height'));
        var grid = document.createElement('div');
        grid.className = 'prop-grid-2';
        addMiniField(grid, 'x', 'X', el.x, function(v) {
            state.updateElementAtomic(s.current, s.selected, { x: v });
        });
        addMiniField(grid, 'y', 'Y', el.y, function(v) {
            state.updateElementAtomic(s.current, s.selected, { y: v });
        });
        addMiniField(grid, 'w', str('width'), el.w, function(v) {
            state.updateElementAtomic(s.current, s.selected, { w: v });
        });
        addMiniField(grid, 'h', str('height'), el.h, function(v) {
            state.updateElementAtomic(s.current, s.selected, { h: v });
        });
        container.appendChild(grid);

        addSeparator(container);

        // Type-specific properties
        var defs = config.PROPERTY_DEFS || [];
        var checkboxes = [];

        defs.forEach(function(def) {
            var val = el[def.key];
            var label = str(def.label);

            if (def.showFor) {
                if (!(def.showFor === 'line' && el.type === 'shape' && el.shape === 'line')) {
                    return;
                }
            }

            if (def.control === 'checkbox') {
                checkboxes.push({ def: def, label: label, val: val });
            } else {
                switch (def.control) {
                    case 'number':
                        addMiniField(container, def.key, label, val, function(v) {
                            var props = {};
                            props[def.key] = v;
                            state.updateElementAtomic(s.current, s.selected, props);
                        }, def);
                        break;
                    case 'color':
                        addMiniColorField(container, def.key, label, val, function(v) {
                            var props = {};
                            props[def.key] = v;
                            state.updateElementAtomic(s.current, s.selected, props);
                        }, def);
                        break;
                    case 'select':
                        if (def.key === 'fontfamily') {
                            addFontFamilyField(container, def, label, val, s.current, s.selected, el);
                        } else {
                            addMiniSelectField(container, def.key, label, val, def.options, function(v) {
                                var props = {};
                                props[def.key] = v;
                                state.updateElementAtomic(s.current, s.selected, props);
                            });
                        }
                        break;
                    case 'iconselect':
                        addMiniIconSelect(container, def.key, label, val, def.options, function(v) {
                            var props = {};
                            props[def.key] = v;
                            state.updateElementAtomic(s.current, s.selected, props);
                        });
                        break;
                    case 'fontsize':
                        addFontSizeDropdown(container, label, val, s.current, s.selected, def.key);
                        break;
                    case 'text':
                        addMiniTextField(container, def.key, label, val, function(v) {
                            var props = {};
                            props[def.key] = v;
                            state.updateElementAtomic(s.current, s.selected, props);
                        });
                        break;
                }
            }
        });

        // Checkboxes in 2-column grid
        if (checkboxes.length > 0) {
            addSeparator(container);
            var cgrid = document.createElement('div');
            cgrid.className = 'prop-grid-2';
            checkboxes.forEach(function(cb) {
                addMiniCheckbox(cgrid, cb.def.key, cb.label, cb.val, function(v) {
                    var props = {};
                    props[cb.def.key] = v;
                    state.updateElementAtomic(s.current, s.selected, props);
                });
            });
            container.appendChild(cgrid);
        }

        // Crop controls for images
        if (el.type === 'image' && el.src) {
            addSeparator(container);
            var cropRow = document.createElement('div');
            cropRow.className = 'prop-grid-2';
            var cropBtn = document.createElement('button');
            cropBtn.type = 'button';
            cropBtn.className = 'btn btn-outline-secondary btn-sm';
            cropBtn.style.width = '100%';
            cropBtn.textContent = str('crop');
            cropBtn.addEventListener('click', function() {
                if (cropStarter) { cropStarter(s.selected); }
            });
            cropRow.appendChild(cropBtn);

            var c = el.crop;
            var cropped = !!(c && c.w > 0 && c.h > 0 && (c.x > 0 || c.y > 0 || c.w < 1 || c.h < 1));
            if (cropped) {
                var cropResetBtn = document.createElement('button');
                cropResetBtn.type = 'button';
                cropResetBtn.className = 'btn btn-outline-secondary btn-sm';
                cropResetBtn.style.width = '100%';
                cropResetBtn.textContent = str('cropreset');
                cropResetBtn.addEventListener('click', function() {
                    state.updateElementAtomic(s.current, s.selected, { crop: null });
                });
                cropRow.appendChild(cropResetBtn);
            }
            container.appendChild(cropRow);
        }

        // Edit button for equations (reopens the modal with the TeX source).
        if (el.type === 'equation') {
            addSeparator(container);
            var eqRow = document.createElement('div');
            eqRow.className = 'prop-grid-2';
            var eqBtn = document.createElement('button');
            eqBtn.type = 'button';
            eqBtn.className = 'btn btn-outline-secondary btn-sm';
            eqBtn.style.width = '100%';
            eqBtn.textContent = str('editequation');
            eqBtn.addEventListener('click', function() {
                if (equationStarter) { equationStarter(s.current, s.selected); }
            });
            eqRow.appendChild(eqBtn);
            container.appendChild(eqRow);
        }

        // Edit button for HTML/Embed elements (reopens the modal with the code).
        if (el.type === 'html') {
            addSeparator(container);
            var htmlRow = document.createElement('div');
            htmlRow.className = 'prop-grid-2';
            var htmlBtn = document.createElement('button');
            htmlBtn.type = 'button';
            htmlBtn.className = 'btn btn-outline-secondary btn-sm';
            htmlBtn.style.width = '100%';
            htmlBtn.textContent = str('edithtml');
            htmlBtn.addEventListener('click', function() {
                if (htmlStarter) { htmlStarter(s.current, s.selected); }
            });
            htmlRow.appendChild(htmlBtn);
            container.appendChild(htmlRow);
        }

        // Delete button
        var del = document.createElement('button');
        del.className = 'btn btn-danger btn-sm properties-delete';
        del.textContent = str('deleteelement');
        del.addEventListener('click', function() { state.deleteElement(s.current, s.selected); });
        container.appendChild(del);
    }

    function renderSlideProps(s) {
        var slide = s.slides[s.current];
        if (!slide) { return; }

        var header = document.createElement('div');
        header.className = 'properties-header';
        header.textContent = str('properties') + ' — ' + str('slides');
        container.appendChild(header);

        // Transition selector — button that opens visual picker
        addSectionLabel(container, str('transition'));
        var currentTransition = slide.transition || 'none';
        var transitionBtn = document.createElement('button');
        transitionBtn.type = 'button';
        transitionBtn.className = 'btn btn-outline-secondary btn-sm transition-picker-btn';
        transitionBtn.style.cssText = 'width:100%;display:flex;align-items:center;gap:8px;padding:6px 10px;justify-content:space-between;';
        transitionBtn.innerHTML = '<span class="transition-btn-label">' + getTransitionLabel(currentTransition) + '</span>' +
            '<span class="transition-btn-icon" style="width:28px;height:28px;background:#f8f9fa;border-radius:4px;display:flex;align-items:center;justify-content:center;">' + getTransitionIcon(currentTransition) + '</span>';
        transitionBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            openTransitionPicker(transitionBtn, s.current, currentTransition);
        });
        container.appendChild(transitionBtn);

        // Apply to all button
        var applyAll = document.createElement('button');
        applyAll.className = 'btn btn-sm btn-secondary';
        applyAll.textContent = str('applytoall');
        applyAll.style.cssText = 'margin:8px 14px;width:calc(100% - 28px);';
        applyAll.addEventListener('click', function() {
            state.setAllTransitions(slide.transition || 'none');
        });
        container.appendChild(applyAll);

        addSeparator(container);

        // Slide count info
        var info = document.createElement('div');
        info.className = 'properties-empty';
        info.textContent = str('selectelement');
        container.appendChild(info);
    }

    /* ---- Section helpers -------------------------------------------------- */
    function addSectionLabel(parent, text) {
        var lbl = document.createElement('div');
        lbl.className = 'prop-section';
        lbl.textContent = text;
        parent.appendChild(lbl);
    }

    function addSeparator(parent) {
        var hr = document.createElement('div');
        hr.className = 'prop-separator';
        parent.appendChild(hr);
    }

    /* ---- Compact field helpers -------------------------------------------- */
    function addMiniField(parent, key, label, value, onChange, def) {
        var wrap = document.createElement('div');
        wrap.className = 'prop-field';
        var lbl = document.createElement('label');
        lbl.textContent = label;
        var input = document.createElement('input');
        input.type = 'number';
        input.value = value || 0;
        input.className = 'prop-input';
        if (def) {
            if (def.min !== undefined) { input.min = def.min; }
            if (def.max !== undefined) { input.max = def.max; }
            if (def.step !== undefined) { input.step = def.step; }
        }
        input.addEventListener('change', function() {
            onChange(parseInt(input.value, 10) || 0);
        });
        wrap.appendChild(lbl);
        wrap.appendChild(input);
        parent.appendChild(wrap);
    }

    function addMiniColorField(parent, key, label, value, onChange, def) {
        var wrap = document.createElement('div');
        wrap.className = 'prop-field';
        var lbl = document.createElement('label');
        lbl.textContent = label;

        var input = document.createElement('input');
        input.type = 'color';
        input.value = value || '#000000';
        input.className = 'prop-input';
        input.addEventListener('change', function() { onChange(input.value); });

        if (def && def.clearable) {
            var row = document.createElement('div');
            row.className = 'prop-color-row';
            row.appendChild(input);

            var clearBtn = document.createElement('button');
            clearBtn.type = 'button';
            clearBtn.className = 'btn btn-outline-secondary btn-sm prop-color-clear';
            clearBtn.textContent = str(def.clearLabel || 'highlight-none');
            if (def.clearLabel) { clearBtn.title = clearBtn.textContent; }
            var refresh = function() {
                if (!value) {
                    clearBtn.classList.add('is-active');
                } else {
                    clearBtn.classList.remove('is-active');
                }
            };
            clearBtn.addEventListener('click', function() {
                value = '';
                input.value = '#000000';
                refresh();
                onChange('');
            });
            input.addEventListener('change', function() { value = input.value; refresh(); });
            refresh();
            row.appendChild(clearBtn);
            wrap.appendChild(lbl);
            wrap.appendChild(row);
        } else {
            wrap.appendChild(lbl);
            wrap.appendChild(input);
        }
        parent.appendChild(wrap);
    }

    function optionLabel(opt) {
        if (opt.labelKey) {
            try { return M.util.get_string(opt.labelKey, 'mod_slides'); }
            catch (e) { return opt.fallback || opt.labelKey; }
        }
        return opt.label || opt.value;
    }

    function addMiniSelectField(parent, key, label, value, options, onChange) {
        var wrap = document.createElement('div');
        wrap.className = 'prop-field';
        var lbl = document.createElement('label');
        lbl.textContent = label;
        var select = document.createElement('select');
        select.className = 'prop-input';
        (options || []).forEach(function(opt) {
            var o = document.createElement('option');
            o.value = opt.value;
            o.textContent = optionLabel(opt);
            if (opt.value === value) { o.selected = true; }
            select.appendChild(o);
        });
        select.addEventListener('change', function() { onChange(select.value); });
        wrap.appendChild(lbl);
        wrap.appendChild(select);
        parent.appendChild(wrap);
    }

    /**
     * Font family control for text elements: Word-style popup where every entry
     * is rendered with its own typeface, plus the "apply to all slides" button
     * that pushes the current family onto every text element of the deck.
     */
    function addFontFamilyField(parent, def, label, value, slideIdx, elemIdx, el) {
        var options = (def.options || []).slice();

        // Keep the current value visible even if its option is not loaded yet.
        if (value && !options.some(function(opt) { return opt.value === value; })) {
            options.push({ value: value, label: value, cat: 'other' });
        }

        var wrap = document.createElement('div');
        wrap.className = 'prop-field';
        var lbl = document.createElement('label');
        lbl.textContent = label;

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'prop-input fontfamily-dropdown-btn';
        var current = options.filter(function(opt) { return opt.value === value; })[0];
        var btnText = document.createElement('span');
        btnText.className = 'fontfamily-dropdown-value';
        btnText.textContent = current ? optionLabel(current) : (value || 'sans-serif');
        btnText.style.fontFamily = value || 'sans-serif';
        btn.appendChild(btnText);
        btn.appendChild(Object.assign(document.createElement('span'), {
            className: 'fontfamily-dropdown-caret',
            innerHTML: icons.get('chevron-down', { size: 12 }),
        }));

        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (fontFamilyPicker) {
                closeFontFamilyPicker();
                return;
            }
            openFontFamilyPicker(btn, options, value, slideIdx, elemIdx, def);
        });

        wrap.appendChild(lbl);
        wrap.appendChild(btn);
        parent.appendChild(wrap);

        if (def.applyfontafter && el.type === 'text') {
            addApplyFontToAllButton(parent, slideIdx, elemIdx, el);
        }
    }

    /* ---- Font family picker (Word-style live previews) --------------------- */
    var fontFamilyPicker = null;

    function openFontFamilyPicker(anchorEl, options, current, slideIdx, elemIdx, def) {
        closeFontFamilyPicker();

        var popup = document.createElement('div');
        popup.className = 'fontfamily-picker-popup';
        popup.id = 'fontfamily-picker-popup';

        function applyFamily(newFamily) {
            var s = state.get();
            var currentEl = s.slides[slideIdx] && s.slides[slideIdx].elements[elemIdx];
            if (!currentEl || currentEl.fontfamily === newFamily) {
                closeFontFamilyPicker();
                return;
            }
            var props = {};
            props[def.key] = newFamily;
            state.updateElementAtomic(slideIdx, elemIdx, props);
            closeFontFamilyPicker();
        }

        var groups = [
            { cat: 'system-sans',       labelKey: 'fontgroup-sans',       fallback: 'Sans-serif' },
            { cat: 'system-serif',      labelKey: 'fontgroup-serif',      fallback: 'Serif' },
            { cat: 'system-mono',       labelKey: 'fontgroup-mono',       fallback: 'Monospaced' },
            { cat: 'system-decorative', labelKey: 'fontgroup-decorative', fallback: 'Decorative' },
            { cat: 'web',               labelKey: 'fontgroup-web',        fallback: 'Web fonts' },
            { cat: 'other',             labelKey: 'fontgroup-other',      fallback: 'Other' },
        ];

        groups.forEach(function(grp) {
            var list = options
                .filter(function(o) { return o.cat === grp.cat; })
                .sort(function(a, b) {
                    return optionLabel(a).localeCompare(optionLabel(b));
                });
            if (!list.length) {
                return;
            }
            var title;
            try {
                title = M.util.get_string(grp.labelKey, 'mod_slides');
            } catch (e) {
                title = grp.fallback;
            }
            appendGroup(popup, title, list, current, applyFamily);
        });

        document.body.appendChild(popup);
        positionPopupFixed(popup, anchorEl);
        trapWheelInPopup(popup);

        // Close the popup only when something BEHIND it scrolls; scrolling the
        // list itself (scroll events fire on the popup with capture listeners)
        // must keep it open.
        var onScroll = function(e) {
            if (e && e.target && (e.target === popup || popup.contains(e.target))) {
                return;
            }
            closeFontFamilyPicker();
        };
        window.addEventListener('scroll', onScroll, true);
        document.addEventListener('scroll', onScroll, true);

        function onOutsideClick(e) {
            if (popup.contains(e.target)) { return; }
            if (e.target.closest && e.target.closest('.fontfamily-dropdown-btn')) { return; }
            closeFontFamilyPicker();
        }
        function onEsc(e) {
            if (e.key === 'Escape') { closeFontFamilyPicker(); }
        }
        setTimeout(function() {
            document.addEventListener('click', onOutsideClick);
            document.addEventListener('keydown', onEsc);
        }, 0);

        fontFamilyPicker = popup;
        popup._onOutsideClick = onOutsideClick;
        popup._onEsc = onEsc;
        popup._onScroll = onScroll;
    }

    function closeFontFamilyPicker() {
        if (fontFamilyPicker) {
            if (fontFamilyPicker._onOutsideClick) {
                document.removeEventListener('click', fontFamilyPicker._onOutsideClick);
            }
            if (fontFamilyPicker._onEsc) {
                document.removeEventListener('keydown', fontFamilyPicker._onEsc);
            }
            if (fontFamilyPicker._onScroll) {
                window.removeEventListener('scroll', fontFamilyPicker._onScroll, true);
                document.removeEventListener('scroll', fontFamilyPicker._onScroll, true);
            }
            fontFamilyPicker.remove();
            fontFamilyPicker = null;
        }
    }

    function appendGroup(popup, title, list, current, applyFamily) {
        var head = document.createElement('div');
        head.className = 'fontfamily-picker-group';
        head.textContent = title;
        popup.appendChild(head);

        list.forEach(function(opt) {
            var item = document.createElement('button');
            item.type = 'button';
            item.className = 'fontfamily-picker-item';
            if (opt.cat === 'web') {
                item.classList.add('is-web');
            }
            if (opt.value === current) {
                item.classList.add('is-active');
            }
            // Live preview: each row is rendered with its own typeface.
            item.style.fontFamily = opt.value;
            item.textContent = optionLabel(opt);
            item.title = optionLabel(opt);
            item.addEventListener('click', function(e) {
                e.stopPropagation();
                applyFamily(opt.value);
            });
            popup.appendChild(item);
        });
    }

    /**
     * Always-on bulk action under the font dropdown: pushes the selected
     * element's family onto every other text element of the presentation.
     * The count reflects how many elements would actually change.
     */
    function addApplyFontToAllButton(parent, slideIdx, elemIdx, el) {
        var family = el.fontfamily || 'sans-serif';
        var exclude = { slide: slideIdx, element: elemIdx };
        var usage = state.countTextElements(family, exclude);

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-sm btn-secondary applyfonttoall-btn';
        btn.style.cssText = 'margin:8px 14px;width:calc(100% - 28px);';
        btn.title = strSafe('applyfonttoallhelp');
        btn.textContent = strSafe('applyfonttoall') + ' (' + usage.elements + ')';
        if (usage.elements < 1) {
            btn.disabled = true;
        }
        btn.addEventListener('click', function() {
            var pending = state.countTextElements(family, exclude);
            if (pending.elements < 1) {
                return;
            }
            if (pending.elements > 10) {
                var msg;
                try {
                    msg = M.util.get_string('applyfonttoallconfirm', 'mod_slides', pending.elements);
                } catch (e) {
                    msg = String(pending.elements);
                }
                if (!window.confirm(msg)) {
                    return;
                }
            }
            state.applyFontToAllText(family, exclude);
        });
        parent.appendChild(btn);
    }

    function strSafe(key) {
        try { return str(key); } catch (e) { return key; }
    }

    function addMiniIconSelect(parent, key, label, value, options, onChange) {
        var wrap = document.createElement('div');
        wrap.className = 'prop-field';
        var lbl = document.createElement('label');
        lbl.textContent = label;
        var group = document.createElement('div');
        group.className = 'prop-segmented';
        group.setAttribute('role', 'group');
        group.setAttribute('aria-label', label);

        (options || []).forEach(function(opt) {
            var btn = document.createElement('button');
            btn.type = 'button';
            var active = opt.value === value;
            btn.className = 'prop-segmented-btn' + (active ? ' is-active' : '');
            btn.title = optionLabel(opt);
            btn.setAttribute('aria-label', optionLabel(opt));
            btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            btn.innerHTML = icons.get(opt.icon, {size: 16});
            btn.addEventListener('click', function() {
                group.querySelectorAll('.prop-segmented-btn').forEach(function(b) {
                    b.classList.remove('is-active');
                    b.setAttribute('aria-pressed', 'false');
                });
                btn.classList.add('is-active');
                btn.setAttribute('aria-pressed', 'true');
                onChange(opt.value);
            });
            group.appendChild(btn);
        });

        wrap.appendChild(lbl);
        wrap.appendChild(group);
        parent.appendChild(wrap);
    }

    function addMiniTextField(parent, key, label, value, onChange) {
        var wrap = document.createElement('div');
        wrap.className = 'prop-field';
        var lbl = document.createElement('label');
        lbl.textContent = label;
        var input = document.createElement('input');
        input.type = 'text';
        input.value = value || '';
        input.className = 'prop-input';
        input.addEventListener('change', function() { onChange(input.value); });
        wrap.appendChild(lbl);
        wrap.appendChild(input);
        parent.appendChild(wrap);
    }

    /* ---- Font size dropdown (PowerPoint-style) ---------------------------- */
    var fontSizePicker = null;

    function positionPopupFixed(popup, anchorEl) {
        var rect = anchorEl.getBoundingClientRect();
        popup.style.position = 'fixed';
        popup.style.zIndex = '200';
        popup.style.overflowY = 'auto';
        popup.style.overflowX = 'hidden';
        popup.style.overscrollBehavior = 'contain';
        popup.style.left = Math.max(4, Math.min(rect.left, window.innerWidth - (popup.offsetWidth || 64) - 4)) + 'px';

        // Desired height: full content, capped to a comfortable dropdown size.
        var desired = Math.min(popup.scrollHeight || 320, 320);
        var spaceBelow = window.innerHeight - rect.bottom - 12;
        var spaceAbove = rect.top - 12;

        // Prefer below, but flip above when the content does not fit below
        // and the space above is bigger. This keeps the whole panel on screen
        // so its internal scrollbar actually reaches every entry.
        var useBelow = desired <= spaceBelow || spaceBelow >= spaceAbove;
        var height;
        var top;
        if (useBelow) {
            height = Math.min(desired, Math.max(120, spaceBelow));
            top = rect.bottom + 4;
            if (top + height > window.innerHeight - 4 && spaceAbove > spaceBelow) {
                height = Math.min(desired, Math.max(120, spaceAbove));
                top = Math.max(4, rect.top - 4 - height);
            }
        } else {
            height = Math.min(desired, Math.max(120, spaceAbove));
            top = Math.max(4, rect.top - 4 - height);
        }
        if (top + height > window.innerHeight - 4) {
            top = Math.max(4, window.innerHeight - height - 4);
        }

        popup.style.maxHeight = height + 'px';
        popup.style.top = top + 'px';
    }

    function trapWheelInPopup(popup) {
        popup.addEventListener('wheel', function(e) {
            e.stopPropagation();
            // Walk up (popup included): scroll the popup itself natively, but
            // never let the wheel move the page behind it.
            var el = e.target;
            while (el) {
                var oy = window.getComputedStyle(el).overflowY;
                if ((oy === 'auto' || oy === 'scroll') && el.scrollHeight > el.clientHeight + 1) {
                    if (!popup.contains(el)) {
                        e.preventDefault();
                        return;
                    }
                    var atTop = el.scrollTop <= 0 && e.deltaY < 0;
                    var atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 1 && e.deltaY > 0;
                    if (atTop || atBottom) {
                        // Edge reached: stop the wheel from chaining to the page.
                        e.preventDefault();
                    }
                    return;
                }
                el = el.parentElement;
            }
            e.preventDefault();
        }, { passive: false });
    }

    function getFontSizeList() {
        if (textelem && textelem.FONT_SIZES && textelem.FONT_SIZES.length) {
            return textelem.FONT_SIZES;
        }
        return [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 44, 48, 54, 60, 66, 72, 80, 88, 96];
    }

    function addFontSizeDropdown(parent, label, value, slideIdx, elemIdx, key) {
        var wrap = document.createElement('div');
        wrap.className = 'prop-field';
        var lbl = document.createElement('label');
        lbl.textContent = label;
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'prop-input fontsize-dropdown-btn';
        btn.innerHTML = '<span class="fontsize-dropdown-value"></span><span class="fontsize-dropdown-caret">' + icons.get('chevron-down', {size: 12}) + '</span>';
        btn.querySelector('.fontsize-dropdown-value').textContent = value || '';
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (fontSizePicker) {
                closeFontSizePicker();
                return;
            }
            openFontSizePicker(btn, value, slideIdx, elemIdx, key);
        });
        wrap.appendChild(lbl);
        wrap.appendChild(btn);
        parent.appendChild(wrap);
    }

    function openFontSizePicker(anchorEl, current, slideIdx, elemIdx, key) {
        closeFontSizePicker();

        var sizes = getFontSizeList();
        var snapshotTaken = false;

        var popup = document.createElement('div');
        popup.className = 'fontsize-picker-popup';
        popup.id = 'fontsize-picker-popup';

        var active = parseInt(current, 10);

        sizes.forEach(function(size) {
            var item = document.createElement('button');
            item.type = 'button';
            item.className = 'fontsize-picker-item';
            item.textContent = size;
            if (size === active) {
                item.classList.add('is-active');
            }
            item.addEventListener('click', function(e) {
                e.stopPropagation();
                var s = state.get();
                if (s.selected === null || !s.slides[s.current] || !s.slides[s.current].elements[s.selected]) {
                    closeFontSizePicker();
                    return;
                }
                if (!snapshotTaken) {
                    state.beginDragSnapshot();
                    snapshotTaken = true;
                }
                var props = {};
                props[key] = size;
                state.updateElement(s.current, s.selected, props);

                var items = popup.querySelectorAll('.fontsize-picker-item');
                for (var i = 0; i < items.length; i++) {
                    items[i].classList.toggle('is-active', items[i].textContent === String(size));
                }
            });
            popup.appendChild(item);
        });

        document.body.appendChild(popup);
        positionPopupFixed(popup, anchorEl);
        trapWheelInPopup(popup);

        function onOutsideClick(e) {
            if (popup.contains(e.target)) { return; }
            if (e.target.closest && e.target.closest('.fontsize-dropdown-btn')) { return; }
            closeFontSizePicker();
        }
        function onEsc(e) {
            if (e.key === 'Escape') { closeFontSizePicker(); }
        }
        setTimeout(function() {
            document.addEventListener('click', onOutsideClick);
            document.addEventListener('keydown', onEsc);
        }, 0);

        fontSizePicker = popup;
        popup._onOutsideClick = onOutsideClick;
        popup._onEsc = onEsc;
    }

    function closeFontSizePicker() {
        if (fontSizePicker) {
            if (fontSizePicker._onOutsideClick) {
                document.removeEventListener('click', fontSizePicker._onOutsideClick);
            }
            if (fontSizePicker._onEsc) {
                document.removeEventListener('keydown', fontSizePicker._onEsc);
            }
            fontSizePicker.remove();
            fontSizePicker = null;
        }
    }

    function addMiniCheckbox(parent, key, label, value, onChange) {
        var wrap = document.createElement('div');
        wrap.className = 'prop-field prop-field-check';
        var input = document.createElement('input');
        input.type = 'checkbox';
        input.checked = !!value;
        var lbl = document.createElement('label');
        lbl.textContent = label;
        input.addEventListener('change', function() { onChange(input.checked); });
        wrap.appendChild(input);
        wrap.appendChild(lbl);
        parent.appendChild(wrap);
    }

    function registerType(id, typeModule) {
        typeConfigs[id] = typeModule;
    }

    /* ─── Transition Picker (visual grid with SVG icons) ─────────────────────── */
    var transitionPicker = null;

    function getTransitionLabel(value) {
        var labels = {
            'none': 'None', 'fade': 'Fade', 'push': 'Push', 'slide-left': 'Slide Left',
            'slide-up': 'Slide Up', 'slide-down': 'Slide Down', 'zoom': 'Zoom',
            'flip': 'Flip', 'reveal': 'Reveal', 'cube': 'Cube', 'cut': 'Cut', 'transform': 'Transform'
        };
        try { return M.util.get_string('transition-' + value, 'mod_slides'); } catch (e) { return labels[value] || value; }
    }

    function getTransitionIcon(value, size) {
        return icons.get('transition-' + value, {size: size || 20}) || icons.get('transition-none', {size: size || 20});
    }

    function openTransitionPicker(anchorEl, slideIdx, currentTransition) {
        closeTransitionPicker();
        var s = state.get();
        var slide = s.slides[slideIdx];

        var popup = document.createElement('div');
        popup.className = 'transition-picker-popup';
        popup.id = 'transition-picker-popup';
        popup.style.cssText = 'position:fixed;z-index:200;background:#fff;border:1px solid #dee2e6;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,0.18);width:320px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;padding:8px;';

        var header = document.createElement('div');
        header.className = 'transition-picker-header';
        header.textContent = str('transition');
        header.style.cssText = 'padding:10px 14px 6px;font-size:13px;font-weight:600;color:#333;border-bottom:1px solid #eee;';
        popup.appendChild(header);

        var grid = document.createElement('div');
        grid.className = 'transition-picker-grid';
        grid.style.cssText = 'display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:10px;max-height:280px;overflow-y:auto;overscroll-behavior:contain;';

        var transitions = [
            { value: 'none',       icon: getTransitionIcon('none', 24),       labelKey: 'transition-none' },
            { value: 'fade',       icon: getTransitionIcon('fade', 24),       labelKey: 'transition-fade' },
            { value: 'push',       icon: getTransitionIcon('push', 24),       labelKey: 'transition-push' },
            { value: 'slide-left', icon: getTransitionIcon('slide-left', 24), labelKey: 'transition-slide-left' },
            { value: 'slide-up',   icon: getTransitionIcon('slide-up', 24),   labelKey: 'transition-slide-up' },
            { value: 'slide-down', icon: getTransitionIcon('slide-down', 24), labelKey: 'transition-slide-down' },
            { value: 'zoom',       icon: getTransitionIcon('zoom', 24),       labelKey: 'transition-zoom' },
            { value: 'flip',       icon: getTransitionIcon('flip', 24),       labelKey: 'transition-flip' },
            { value: 'reveal',     icon: getTransitionIcon('reveal', 24),     labelKey: 'transition-reveal' },
            { value: 'cube',       icon: getTransitionIcon('cube', 24),       labelKey: 'transition-cube' },
            { value: 'cut',        icon: getTransitionIcon('cut', 24),        labelKey: 'transition-cut' },
            { value: 'transform',  icon: getTransitionIcon('transform', 24),  labelKey: 'transition-transform' },
        ];

        transitions.forEach(function(t) {
            var item = document.createElement('div');
            item.className = 'transition-picker-item';
            item.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:4px;padding:8px;border-radius:6px;cursor:pointer;transition:background 0.12s;';
            if (t.value === currentTransition) {
                item.style.background = '#e7f1ff';
                item.style.border = '2px solid #0d6efd';
            }
            item.addEventListener('mouseenter', function() {
                if (t.value !== currentTransition) item.style.background = '#f0f4f8';
            });
            item.addEventListener('mouseleave', function() {
                if (t.value !== currentTransition) item.style.background = '';
            });

            var iconWrap = document.createElement('div');
            iconWrap.className = 'transition-picker-icon';
            iconWrap.style.cssText = 'width:48px;height:48px;display:flex;align-items:center;justify-content:center;background:#f8f9fa;border-radius:8px;overflow:hidden;';
            iconWrap.innerHTML = t.icon;
            item.appendChild(iconWrap);

            var label = document.createElement('div');
            label.className = 'transition-picker-label';
            try { label.textContent = M.util.get_string(t.labelKey, 'mod_slides'); }
            catch (e) { label.textContent = t.labelKey; }
            label.style.cssText = 'font-size:11px;color:#555;text-align:center;line-height:1.2;max-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
            item.appendChild(label);

            item.addEventListener('click', function() {
                state.setSlideTransition(slideIdx, t.value);
                closeTransitionPicker();
            });

            grid.appendChild(item);
        });

        popup.appendChild(grid);
        document.body.appendChild(popup);
        positionPopupFixed(popup, anchorEl);
        trapWheelInPopup(popup);

        function onOutsideClick(e) {
            if (!popup.contains(e.target) && e.target !== anchorEl && !anchorEl.contains(e.target)) {
                closeTransitionPicker();
            }
        }
        function onEsc(e) {
            if (e.key === 'Escape') { closeTransitionPicker(); }
        }
        setTimeout(function() {
            document.addEventListener('click', onOutsideClick);
            document.addEventListener('keydown', onEsc);
        }, 0);

        transitionPicker = popup;
        popup._onOutsideClick = onOutsideClick;
        popup._onEsc = onEsc;
    }

    function closeTransitionPicker() {
        if (transitionPicker) {
            if (transitionPicker._onOutsideClick) {
                document.removeEventListener('click', transitionPicker._onOutsideClick);
            }
            if (transitionPicker._onEsc) {
                document.removeEventListener('keydown', transitionPicker._onEsc);
            }
            transitionPicker.remove();
            transitionPicker = null;
        }
    }

    return { init: init, registerType: registerType, setCropStarter: setCropStarter, setEquationStarter: setEquationStarter, setHtmlStarter: setHtmlStarter };
});
