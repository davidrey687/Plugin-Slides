/**
 * Templates panel — shows preset grid, applies templates to slides.
 *
 * @module     mod_slides/editorTemplates
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorPresets', 'mod_slides/editorToolbar', 'mod_slides/shapes_library'], function(presets, toolbar, shapesLib) {
    'use strict';

    var panelEl = null;
    var isVisible = false;

    function init() {
        panelEl = document.getElementById('editor-templates');
        if (!panelEl) { return; }

        renderPanel();
    }

    function renderPanel() {
        var str = M.util.get_string;
        var allPresets = presets.getPresets();

        panelEl.innerHTML = '';

        // Header
        var header = document.createElement('div');
        header.className = 'templates-header';
        header.textContent = str('templates', 'mod_slides');
        panelEl.appendChild(header);

        // Grid
        var grid = document.createElement('div');
        grid.className = 'templates-grid';

        allPresets.forEach(function(preset) {
            var card = document.createElement('div');
            card.className = 'templates-card';
            card.dataset.id = preset.id;

            // Mini render of the preset
            var mini = document.createElement('div');
            mini.className = 'templates-card-mini';
            var bg = preset.slide.background;
            if (bg.type === 'linear-gradient' && bg.gradient) {
                var angle = bg.gradient.angle || 135;
                var stopsStr = (bg.gradient.stops || []).map(function(s) {
                    return s.color + ' ' + s.position + '%';
                }).join(', ');
                mini.style.background = 'linear-gradient(' + angle + 'deg, ' + stopsStr + ')';
            } else if (bg.type === 'radial-gradient' && bg.gradient) {
                var stopsStr2 = (bg.gradient.stops || []).map(function(s) {
                    return s.color + ' ' + s.position + '%';
                }).join(', ');
                mini.style.background = 'radial-gradient(circle, ' + stopsStr2 + ')';
            } else {
                mini.style.background = bg.color || '#ffffff';
            }

            // Scale factors for mini (120px wide)
            var sw = 120;
            var sh = 68; // 120 * 9/16
            var scale = sw / 960;

            (preset.slide.elements || []).forEach(function(el) {
                var div = document.createElement('div');
                div.style.cssText = 'position:absolute;overflow:hidden;' +
                    'left:' + (el.x * scale) + 'px;top:' + (el.y * scale) + 'px;' +
                    'width:' + (el.w * scale) + 'px;height:' + (el.h * scale) + 'px;' +
                    'font-size:' + Math.max(2, (el.fontSize || 24) * scale) + 'px;color:' + (el.color || '#000') + ';' +
                    'text-align:' + (el.align || 'left') + ';' +
                    (el.bold ? 'font-weight:bold;' : '') +
                    (el.type === 'shape' ? (function() {
                        if (el.shape === 'line') { return ''; }
                        return shapesLib.thumbStyle(el.shape, (el.fill === '' || el.fill === 'transparent') ? 'transparent' : (el.fill || '#0d6efd'));
                    })() : '') +
                    'line-height:1.2;white-space:pre-wrap;';
                if (el.type === 'text') { div.textContent = el.text; }
                mini.appendChild(div);
            });

            card.appendChild(mini);

            var label = document.createElement('div');
            label.className = 'templates-card-label';
            label.textContent = preset.label;
            card.appendChild(label);

            card.addEventListener('click', function() {
                if (typeof window.slidesApplyTemplate === 'function') {
                    window.slidesApplyTemplate(preset.id);
                }
                hide();
            });

            grid.appendChild(card);
        });

        panelEl.appendChild(grid);
    }

    function toggle() {
        if (isVisible) { hide(); } else { show(); }
    }

    function show() {
        if (!panelEl) { return; }
        isVisible = true;
        panelEl.style.display = 'block';
        // Reposition near the toolbar button
        var btn = document.querySelector('[data-action="templates"]');
        if (btn) {
            var rect = btn.getBoundingClientRect();
            var toolbarRect = btn.closest('.toolbar-group').getBoundingClientRect();
            panelEl.style.position = 'fixed';
            panelEl.style.zIndex = 100;
            if (window.innerWidth <= 768) {
                panelEl.style.left = Math.max(8, Math.round((window.innerWidth - panelEl.offsetWidth) / 2)) + 'px';
                panelEl.style.top = '8px';
            } else {
                panelEl.style.left = toolbarRect.left + 'px';
                panelEl.style.top = (toolbarRect.bottom + 4) + 'px';
            }
            var pr = panelEl.getBoundingClientRect();
            if (pr.right > window.innerWidth - 8) {
                panelEl.style.left = Math.max(8, window.innerWidth - pr.width - 8) + 'px';
            }
            if (pr.bottom > window.innerHeight - 8) {
                panelEl.style.top = Math.max(8, window.innerHeight - pr.height - 8) + 'px';
            }
        }
        function onOutsideClick(e) {
            if (!panelEl.contains(e.target)) {
                var templateBtn = document.querySelector('[data-action="templates"]');
                if (templateBtn && templateBtn.contains(e.target)) { return; }
                hide();
            }
        }
        setTimeout(function() {
            document.addEventListener('mousedown', onOutsideClick);
        }, 0);
        panelEl._onOutsideClick = onOutsideClick;
        toolbar.updateStates();
    }

    function hide() {
        if (!panelEl) { return; }
        isVisible = false;
        panelEl.style.display = 'none';
        if (panelEl._onOutsideClick) {
            document.removeEventListener('mousedown', panelEl._onOutsideClick);
            panelEl._onOutsideClick = null;
        }
        toolbar.updateStates();
    }

    function getIsVisible() {
        return isVisible;
    }

    return {
        init: init,
        toggle: toggle,
        show: show,
        hide: hide,
        getIsVisible: getIsVisible,
    };
});
