/**
 * Video element type — YouTube or HTML5 video embed.
 *
 * @module     mod_slides/editorVideo
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var TYPE = 'video';

    var DEFAULTS = {
        type: TYPE,
        x: 100,
        y: 100,
        w: 480,
        h: 270,
        src: '',
        alt: '',
        autoplay: false,
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
    }

    function innerStyle(el) {
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var style = 'width:100%;height:100%;border:none;border-radius:4px;pointer-events:none;display:block;opacity:' + opacity + ';';
        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return style;
    }

    function getEmbedUrl(url) {
        if (!url) { return ''; }

        // YouTube
        var ytMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&?#]+)/);
        if (ytMatch) {
            return 'https://www.youtube.com/embed/' + ytMatch[1] + '?rel=0';
        }

        // Vimeo
        var vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
        if (vimeoMatch) {
            return 'https://player.vimeo.com/video/' + vimeoMatch[1];
        }

        // Direct URL (mp4, webm, etc.)
        return url;
    }

    function isDirectVideo(url) {
        return /\.(mp4|webm|ogg)(\?.*)?$/i.test(url);
    }

    function renderVideo(el) {
        var url = el.src || '';
        if (!url) {
            var placeholder = document.createElement('div');
            placeholder.style.cssText = 'width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#1a1a2e;color:#fff;border-radius:4px;font-size:14px;';
            try { placeholder.textContent = M.util.get_string('addvideo', 'mod_slides'); }
            catch (e) { placeholder.textContent = 'Video'; }
            return placeholder;
        }

        if (isDirectVideo(url)) {
            var vid = document.createElement('video');
            vid.src = url;
            vid.style.cssText = innerStyle(el);
            vid.controls = true;
            vid.preload = 'metadata';
            return vid;
        }

        // YouTube/Vimeo iframe
        var iframe = document.createElement('iframe');
        iframe.src = getEmbedUrl(url);
        iframe.style.cssText = innerStyle(el);
        iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
        iframe.allowFullscreen = true;
        iframe.frameBorder = '0';
        return iframe;
    }

    var PROPERTY_DEFS = [
        { key: 'src',           label: 'videourl',      control: 'text' },
        { key: 'alt',           label: 'alt',            control: 'text' },
        { key: 'opacity',       label: 'opacity',        control: 'number', min: 0, max: 100, step: 5 },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color',  control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        renderVideo: renderVideo,
        PROPERTY_DEFS: PROPERTY_DEFS,
    };
});
