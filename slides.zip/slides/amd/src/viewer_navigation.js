/**
 * Viewer slide navigator — bottom thumbnail strip (Genially-style).
 *
 * Renders a compact preview of every slide, toggles the floating panel from
 * the grid button / page counter and jumps straight to the chosen slide.
 * Heavy media (iframes, video players, audio) is replaced by light placeholders
 * so hundreds of slides stay cheap to render.
 *
 * @module     mod_slides/viewer_navigation
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([
    'mod_slides/editorBackground',
    'mod_slides/editorImage',
    'mod_slides/editorEquation',
    'mod_slides/editorShapes',
    'mod_slides/editorPencil',
    'mod_slides/editorIcons',
], function(background, imageMod, equation, shapes, pencil, icons) {
    'use strict';

    var CANVAS_W = 960;
    var THUMB_W = 168;

    var cfg = null;
    var root = null;
    var panel = null;
    var gridEl = null;
    var trackEl = null;
    var toggleBtns = [];
    var closeBtn = null;
    var built = false;
    var open = false;

    /* ---- Helpers ---------------------------------------------------------- */
    function getStr(key, param) {
        try {
            var s = (window.M && M.util && M.util.get_string) ?
                M.util.get_string(key, 'mod_slides') : '';
            if (param !== undefined && s && s.indexOf('{$a}') !== -1) {
                s = s.replace('{$a}', String(param));
            }
            return s || key;
        } catch (e) {
            return key;
        }
    }

    function pct(v, total) {
        return (v / total * 100) + '%';
    }

    function canvasHeight() {
        var h = (cfg && typeof cfg.getCanvasHeight === 'function') ? cfg.getCanvasHeight() : 0;
        return h > 0 ? h : 540;
    }

    /* ---- Panel open / close ------------------------------------------------ */
    function setOpen(next) {
        if (!panel || open === next) { return; }
        open = next;

        toggleBtns.forEach(function(btn) {
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });

        if (open) {
            panel.hidden = false;
            // Force a reflow so the slideUp animation runs from the hidden state.
            void panel.offsetWidth;
            panel.classList.add('is-open');
            sync(cfg.getCurrent(), true);
        } else {
            panel.classList.remove('is-open');
            var onEnd = function(e) {
                if (e && e.target !== panel) { return; }
                panel.removeEventListener('transitionend', onEnd);
                if (!open) { panel.hidden = true; }
            };
            panel.addEventListener('transitionend', onEnd);
            // Safety net when transitions are disabled (reduced motion).
            window.setTimeout(onEnd, 250);
        }
    }

    function toggle() {
        setOpen(!open);
    }

    function close() {
        setOpen(false);
    }

    /* ---- Thumbnail rendering ----------------------------------------------- */
    function renderThumbElement(parent, el) {
        var div = document.createElement('div');
        div.className = 'slides-thumb-el slides-thumb-el--' + (el.type || 'text');
        div.style.cssText = 'position:absolute;left:' + pct(el.x, CANVAS_W) +
            ';top:' + pct(el.y, canvasHeight()) +
            ';width:' + pct(el.w, CANVAS_W) +
            ';height:' + pct(el.h, canvasHeight()) + ';';

        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var thumbScale = THUMB_W / CANVAS_W;

        if (el.type === 'image') {
            div.style.overflow = 'hidden';
            if (el.src) {
                var img = document.createElement('img');
                img.src = el.src;
                img.alt = '';
                if (imageMod && imageMod.hasCrop(el)) {
                    div.style.borderRadius = (el.borderRadius || 0) + 'px';
                    img.style.cssText = imageMod.croppedImgStyle(el) + 'pointer-events:none;';
                } else {
                    img.style.cssText = 'width:100%;height:100%;object-fit:contain;display:block;opacity:' + opacity + ';pointer-events:none;';
                }
                div.appendChild(img);
            } else {
                div.style.background = '#f8f9fa';
                div.style.border = '1px dashed #adb5bd';
            }

        } else if (el.type === 'video') {
            div.style.cssText += 'background:#1a1a2e;border-radius:3px;display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var play = document.createElement('div');
            play.style.cssText = 'width:36%;height:36%;color:rgba(255,255,255,0.9);';
            play.innerHTML = icons.get('play', {size: '100%'});
            div.appendChild(play);

        } else if (el.type === 'pdf') {
            div.style.cssText += 'background:#f8f9fa;border:1px dashed #dee2e6;border-radius:3px;' +
                'display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var pdfIcon = document.createElement('div');
            pdfIcon.style.cssText = 'width:40%;height:40%;color:#dc3545;pointer-events:none;';
            pdfIcon.innerHTML = icons.get('pdf', {size: '100%'});
            div.appendChild(pdfIcon);

        } else if (el.type === 'html') {
            div.style.cssText += 'background:#f8f9fa;border:1px dashed #dee2e6;border-radius:3px;' +
                'display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var htmlIcon = document.createElement('div');
            htmlIcon.style.cssText = 'width:40%;height:40%;color:#6f42c1;pointer-events:none;';
            htmlIcon.innerHTML = icons.get('code', {size: '100%'});
            div.appendChild(htmlIcon);

        } else if (el.type === 'audio') {
            div.style.cssText += 'background:#eef5ff;border:1px dashed #b6d4fe;border-radius:3px;' +
                'display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var micIcon = document.createElement('div');
            micIcon.style.cssText = 'width:40%;height:40%;color:#0d6efd;pointer-events:none;';
            micIcon.innerHTML = icons.get('mic', {size: '100%'});
            div.appendChild(micIcon);

        } else if (el.type === 'pencil' && pencil && pencil.renderSvg) {
            div.style.overflow = 'visible';
            var miniSvg = pencil.renderSvg(el);
            miniSvg.setAttribute('viewBox', '0 0 ' + el.w + ' ' + el.h);
            miniSvg.style.cssText = 'width:100%;height:100%;display:block;pointer-events:none;';
            div.appendChild(miniSvg);

        } else if (el.type === 'shape' && shapes && shapes.innerStyle) {
            div.style.overflow = 'visible';
            var innerDiv = document.createElement('div');
            innerDiv.className = 'shape-inner';
            innerDiv.style.cssText = shapes.innerStyle(el);
            div.appendChild(innerDiv);

        } else if (el.type === 'equation') {
            var eqJustify = el.align === 'left' ? 'flex-start' : (el.align === 'right' ? 'flex-end' : 'center');
            div.style.cssText += 'display:flex;align-items:center;justify-content:' + eqJustify + ';overflow:hidden;' +
                'font-size:' + Math.max(3, (el.fontSize || 32) * thumbScale) + 'px;' +
                'color:' + (el.color || '#000') + ';line-height:1.2;box-sizing:border-box;opacity:' + opacity + ';';
            div.innerHTML = equation.renderHtml(el.text || '');

        } else if (el.type === 'action') {
            div.style.cssText += 'display:flex;align-items:center;justify-content:center;overflow:hidden;' +
                'border-radius:3px;opacity:' + opacity + ';' +
                'background:' + (el.background || '#0d6efd') + ';color:#fff;' +
                'font-size:' + Math.max(3, (el.fontSize || 16) * thumbScale) + 'px;line-height:1.1;';
            div.textContent = el.label || '';

        } else if (el.type === 'footer') {
            div.style.cssText += 'display:flex;align-items:center;justify-content:center;overflow:hidden;' +
                'background:' + (el.background || '#f8f9fa') + ';opacity:' + opacity + ';' +
                'font-size:' + Math.max(3, (el.fontSize || 14) * thumbScale) + 'px;' +
                'color:' + (el.color || '#000') + ';white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
            div.textContent = el.text || '';

        } else if (el.type === 'link') {
            div.style.cssText += 'display:flex;align-items:center;justify-content:center;overflow:hidden;' +
                'border-radius:3px;background:' + (el.background || '#e7f1ff') + ';opacity:' + opacity + ';' +
                'font-size:' + Math.max(3, (el.fontSize || 16) * thumbScale) + 'px;' +
                'color:' + (el.color || '#0d6efd') + ';white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
            div.textContent = el.text || el.url || '';

        } else {
            div.style.cssText += 'font-size:' + Math.max(3, (el.fontSize || 24) * thumbScale) +
                'px;color:' + (el.color || '#000') +
                ';text-align:' + (el.align || 'left') +
                ';font-family:' + (el.fontfamily || 'sans-serif') + ';' +
                (el.bold ? 'font-weight:bold;' : '') +
                (el.italic ? 'font-style:italic;' : '') +
                'overflow:hidden;line-height:1.3;white-space:pre-wrap;box-sizing:border-box;opacity:' + opacity + ';';
            div.textContent = el.text || '';
        }

        parent.appendChild(div);
    }

    function renderThumb(btn, slide) {
        var frame = btn.querySelector('.slides-thumbnav-frame');
        if (!frame) { return; }
        frame.innerHTML = '';
        frame.style.background = background.toCss(slide.background);

        (slide.elements || []).forEach(function(el) {
            if (el._visible === false) { return; }
            renderThumbElement(frame, el);
        });
    }

    function render() {
        if (!gridEl || !cfg) { return; }
        var slides = cfg.getSlides() || [];
        gridEl.innerHTML = '';

        slides.forEach(function(slide, idx) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'slides-thumbnav-item';
            btn.dataset.idx = idx;
            btn.setAttribute('aria-label', getStr('slidethumb', idx + 1));

            var frame = document.createElement('div');
            frame.className = 'slides-thumbnav-frame';
            frame.style.aspectRatio = CANVAS_W + ' / ' + canvasHeight();
            btn.appendChild(frame);

            var badge = document.createElement('span');
            badge.className = 'slides-thumbnav-badge';
            badge.textContent = idx + 1;
            btn.appendChild(badge);

            btn.addEventListener('click', function() {
                cfg.goTo(idx, 'user');
                close();
            });

            gridEl.appendChild(btn);
            renderThumb(btn, slide);
        });

        built = true;
        sync(cfg.getCurrent(), true);
    }

    /* ---- Active slide sync -------------------------------------------------- */
    function sync(idx, scrollIntoView) {
        if (!built || !gridEl) { return; }
        var items = gridEl.querySelectorAll('.slides-thumbnav-item');
        var active = null;
        for (var i = 0; i < items.length; i++) {
            var isActive = (i === idx);
            items[i].classList.toggle('is-active', isActive);
            items[i].setAttribute('aria-current', isActive ? 'true' : 'false');
            if (isActive) { active = items[i]; }
        }
        if (active && scrollIntoView && open && trackEl) {
            try {
                active.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
            } catch (e) {
                active.scrollIntoView(false);
            }
        }
    }

    /* ---- Wiring ------------------------------------------------------------- */
    function init(config) {
        cfg = config;
        if (!cfg || !cfg.root) { return; }
        root = cfg.root;

        panel = root.querySelector('.slides-thumbnail-panel');
        gridEl = root.querySelector('.slides-thumbnail-grid');
        trackEl = root.querySelector('.slides-thumbnail-track');
        closeBtn = root.querySelector('.slides-thumbnail-close');
        toggleBtns = Array.prototype.slice.call(root.querySelectorAll('[data-action="slidenav"]'));

        if (!panel || !gridEl || !toggleBtns.length) { return; }

        toggleBtns.forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                toggle();
            });
        });

        if (closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                close();
            });
        }

        // Click outside the panel closes it. Plain canvas clicks are swallowed
        // (stopPropagation) so closing never advances the slide by accident;
        // real controls (arrows, fullscreen, links...) still receive the click.
        var viewport = root.querySelector('.slides-viewport');
        if (viewport) {
            viewport.addEventListener('click', function(e) {
                if (!open || panel.contains(e.target)) { return; }
                if (e.target.closest && e.target.closest('[data-action="slidenav"]')) { return; }
                if (e.target.closest && e.target.closest('a, button, video, iframe, input, select, textarea, [data-no-nav]')) {
                    close();
                    return;
                }
                e.stopPropagation();
                e.preventDefault();
                close();
            }, true);
        }
    }

    return {
        init: init,
        render: render,
        sync: sync,
        close: close,
        isOpen: function() { return open; },
    };
});
