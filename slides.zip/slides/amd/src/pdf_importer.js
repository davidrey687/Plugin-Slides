/**
 * Import tool: PDF (visual HD) and PPTX (editable objects).
 *
 * The modal markup lives in templates/import_modal.mustache (included from
 * editor.mustache); this module only wires it up and runs the two pipelines.
 *
 * PDF mode — pure visual fidelity:
 *   Every page is rasterized at viewport scale 2.0 (1920×1080 for a 16:9
 *   slide PDF) through pdf.js and uploaded as the slide background image.
 *   No text layer is extracted: what the original document draws is what
 *   the slide shows, with no ghost/duplicated text. Teachers can layer
 *   interactive elements (buttons, audio, links) on top of the image.
 *   Page-to-canvas fit is automatic: cover when the page aspect is within
 *   3% of the canvas (no visible crop on slide PDFs), contain otherwise
 *   (full A4/letter page visible with white bars).
 *
 * PPTX mode — editable objects: delegated to mod_slides/pptx_importer
 * (native text boxes, images and shapes; the package's images are uploaded
 * through the same uploadBlob endpoint).
 *
 * Backgrounds always go through media_upload_ajax (the DB column is TEXT
 * /64KB — data URLs are forbidden); if the upload fails the slide falls
 * back to a solid colour and the import continues.
 *
 * Everything stays inside the plugin folder; the deck is inserted with a
 * single undo step (editorState.addSlidesBulk) so autosave persists it once.
 *
 * @module     mod_slides/pdf_importer
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/pptx_importer'], function(state, pptxImport) {
    'use strict';

    var pdfPromise = null;
    var openCtx = null;

    var ACCEPT = {
        pdf: '.pdf,application/pdf',
        pptx: '.pptx,.ppsx,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/zip',
    };

    function str(key, param) {
        try { return M.util.get_string(key, 'mod_slides', param); } catch (e) { return key; }
    }

    /* ======================================================================
     *  pdf.js loader (local vendor copy, script-tag fallback to fetch+eval)
     * ====================================================================== */

    function baseUrl() {
        var root = (typeof M !== 'undefined' && M.cfg && M.cfg.wwwroot) ? M.cfg.wwwroot : '';
        return root + '/mod/slides/vendor/pdfjs';
    }

    /**
     * Candidate locations for the local pdf.js build, best guess first.
     * Mirrors the KaTeX loader: configured wwwroot, a path derived from the
     * page URL (sub-directory installs) and finally a root-relative path.
     *
     * @return {String[]}
     */
    function candidateBases() {
        var out = [];
        var push = function(url) {
            if (url && out.indexOf(url) === -1) { out.push(url); }
        };
        push(baseUrl());
        try {
            var base = new URL(document.baseURI);
            base.search = '';
            base.hash = '';
            base.pathname = base.pathname.replace(/\/[^\/]*$/, '/vendor/pdfjs/');
            push(base.href.replace(/\/$/, ''));
        } catch (e) { /* URL unsupported: keep the other candidates. */ }
        push('/mod/slides/vendor/pdfjs');
        return out;
    }

    /**
     * Run a classic (UMD) bundle in global scope while RequireJS's `define`
     * is briefly hidden, so the UMD wrapper takes the plain-browser branch
     * and exposes `window.pdfjsLib` instead of registering a named module.
     *
     * @param {String} code Bundle source.
     */
    function runGlobal(code) {
        var hadDefine = 'define' in window;
        var savedDefine = window.define;
        var hadModule = 'module' in window;
        var savedModule = window.module;
        var hadExports = 'exports' in window;
        var savedExports = window.exports;
        try {
            if (hadDefine) { window.define = undefined; }
            if (hadModule) { window.module = undefined; }
            if (hadExports) { window.exports = undefined; }
            (0, eval)(code); // eslint-disable-line no-eval
        } finally {
            if (hadDefine) { window.define = savedDefine; }
            if (hadModule) { window.module = savedModule; }
            if (hadExports) { window.exports = savedExports; }
        }
    }

    /**
     * Resolve the global pdfjsLib from the plugin's vendor folder.
     *
     * @return {Promise<Object>}
     */
    function loadPdfJs() {
        if (window.pdfjsLib) { return Promise.resolve(window.pdfjsLib); }
        if (pdfPromise) { return pdfPromise; }

        pdfPromise = new Promise(function(resolve, reject) {
            var bases = candidateBases();
            var i = 0;

            function attempt() {
                if (i >= bases.length) {
                    pdfPromise = null;
                    reject(new Error('pdfjs-load-failed'));
                    return;
                }
                var base = bases[i++];
                var url = base + '/pdf.min.js';

                if (typeof fetch !== 'function') {
                    attemptScriptTag(base, resolve, reject);
                    return;
                }
                fetch(url, { credentials: 'same-origin' })
                    .then(function(res) {
                        if (!res.ok) { throw new Error('http ' + res.status); }
                        return res.text();
                    })
                    .then(function(code) {
                        runGlobal(code);
                        if (window.pdfjsLib) {
                            finishLoad(base, resolve);
                        } else {
                            attempt();
                        }
                    })
                    .catch(function() {
                        attemptScriptTag(base, resolve, reject);
                    });
            }

            function attemptScriptTag(base, res, rej) {
                var savedDefine = window.define;
                var hadDefine = 'define' in window;
                var restored = false;
                var restore = function() {
                    if (restored) { return; }
                    restored = true;
                    if (hadDefine) { window.define = savedDefine; }
                };
                var script = document.createElement('script');
                script.src = base + '/pdf.min.js';
                script.async = true;
                script.onload = function() {
                    restore();
                    if (window.pdfjsLib) {
                        finishLoad(base, res);
                    } else {
                        attempt();
                    }
                };
                script.onerror = function() {
                    restore();
                    attempt();
                };
                // Hide define while the UMD bundle runs (global branch).
                if (hadDefine) {
                    try { window.define = undefined; } catch (e) { /* ignore */ }
                }
                document.head.appendChild(script);
            }

            attempt();
        });
        return pdfPromise;
    }

    function finishLoad(base, resolve) {
        try {
            window.pdfjsLib.GlobalWorkerOptions.workerSrc = base + '/pdf.worker.min.js';
        } catch (e) { /* worker optional */ }
        resolve(window.pdfjsLib);
    }

    /* ======================================================================
     *  Small helpers
     * ====================================================================== */

    function readFile(file) {
        if (file && typeof file.arrayBuffer === 'function') {
            return file.arrayBuffer();
        }
        return new Promise(function(resolve, reject) {
            var reader = new FileReader();
            reader.onload = function() { resolve(reader.result); };
            reader.onerror = function() { reject(reader.error || new Error('read')); };
            reader.readAsArrayBuffer(file);
        });
    }

    function uploadBlob(blob, filename) {
        var root = document.getElementById('slides-editor');
        if (!root || !window.M || !M.cfg) { return Promise.resolve(null); }
        var cmid = parseInt(root.dataset.cmid, 10);
        var sesskey = root.dataset.sesskey;
        if (!cmid || !sesskey) { return Promise.resolve(null); }

        var fd = new FormData();
        fd.append('cmid', cmid);
        fd.append('sesskey', sesskey);
        fd.append('media', blob, filename || 'image.png');

        return fetch(M.cfg.wwwroot + '/mod/slides/classes/local/media_upload_ajax.php', {
            method: 'POST',
            body: fd,
            credentials: 'same-origin',
        }).then(function(res) {
            if (!res.ok) { return null; }
            return res.json();
        }).then(function(data) {
            return (data && data.url) ? data.url : null;
        }).catch(function() {
            return null;
        });
    }

    function canvasToBlob(canvas, type, quality) {
        return new Promise(function(resolve) {
            if (typeof canvas.toBlob !== 'function') { resolve(null); return; }
            try {
                canvas.toBlob(function(blob) { resolve(blob || null); }, type, quality);
            } catch (e) {
                resolve(null);
            }
        });
    }

    /* ======================================================================
     *  PDF pipeline — HD page raster, no text layer (visual mode)
     * ====================================================================== */

    /**
     * Render one page at viewport scale 2.0 into an offscreen canvas and
     * upload it as the slide background.
     *
     * @param {Object} pdfjsLib global library
     * @param {Object} page     pdf.js page
     * @param {Object} vp       page.getViewport({scale: 2})
     * @param {Number} pageNum  1-based page number (upload filename)
     * @param {Object} opts     {canvasW, canvasH, rasterCanvas, isCancelled}
     * @return {Promise<String|null>} background image URL (null → solid bg)
     */
    function renderPageBackground(pdfjsLib, page, vp, pageNum, opts) {
        var canvas = opts.rasterCanvas;
        if (!canvas) {
            canvas = document.createElement('canvas');
            opts.rasterCanvas = canvas;
        }
        canvas.width = vp.width;
        canvas.height = vp.height;
        var ctx = canvas.getContext('2d');
        if (!ctx) { return Promise.resolve(null); }

        var renderTask;
        try {
            renderTask = page.render({
                canvasContext: ctx,
                viewport: vp,
            });
        } catch (e) {
            return Promise.resolve(null);
        }

        return renderTask.promise.then(function() {
            return canvasToBlob(canvas, 'image/png');
        }).then(function(blob) {
            if (!blob) { return null; }
            if (blob.size <= 3 * 1024 * 1024) {
                return { blob: blob, ext: 'png' };
            }
            // Huge page: re-encode as JPEG to keep the upload light.
            return canvasToBlob(canvas, 'image/jpeg', 0.92).then(function(jpeg) {
                return jpeg ? { blob: jpeg, ext: 'jpg' } : { blob: blob, ext: 'png' };
            });
        }).then(function(out) {
            if (!out) { return null; }
            if (opts.isCancelled()) { return null; }
            // Never a data URL: the background column is TEXT/64KB in MySQL.
            return uploadBlob(out.blob, 'pdfpage_' + pageNum + '.' + out.ext);
        }).catch(function() {
            return null;
        });
    }

    /**
     * Auto fit: cover when the page aspect is within 3% of the canvas
     * (slide exports — no visible crop), contain otherwise (full document
     * page with white bars). Never distorts.
     */
    function autoFit(vp, opts) {
        var pageAspect = vp.width / vp.height;
        var canvasAspect = opts.canvasW / opts.canvasH;
        if (!isFinite(pageAspect) || !isFinite(canvasAspect) || canvasAspect <= 0) {
            return 'cover';
        }
        return Math.abs(pageAspect - canvasAspect) / canvasAspect <= 0.03 ? 'cover' : 'contain';
    }

    /**
     * Convert one PDF page: HD background raster only (no text overlay).
     *
     * @return {Promise<Object|null>} slide (null when cancelled)
     */
    function convertPage(pdfjsLib, page, pageNum, opts) {
        var vp = page.getViewport({ scale: 2 });
        var fit = autoFit(vp, opts);

        return renderPageBackground(pdfjsLib, page, vp, pageNum, opts).then(function(bgUrl) {
            if (opts.isCancelled()) { return null; }

            var background = bgUrl
                ? { type: 'image', image: bgUrl, imageFit: fit, color: '#ffffff' }
                : { type: 'solid', color: '#ffffff' };

            // Blank pages still become slides so the page numbering stays
            // aligned with the source document.
            return {
                id: 0,
                title: str('importpdfpage', pageNum),
                sortorder: 0,
                elements: [],
                background: background,
                transition: 'none',
            };
        });
    }

    function convertDocument(pdfjsLib, pdf, opts) {
        var slides = [];
        var n = 0;

        function step() {
            if (opts.isCancelled() || n >= pdf.numPages) {
                return Promise.resolve(slides);
            }
            n++;
            opts.onProgress(n, pdf.numPages);
            return pdf.getPage(n).then(function(page) {
                return convertPage(pdfjsLib, page, n, opts).then(function(slide) {
                    if (slide) { slides.push(slide); }
                    // Yield so the progress bar can paint.
                    return new Promise(function(resolve) { setTimeout(resolve, 0); });
                });
            }).then(step);
        }

        return step();
    }

    /* ======================================================================
     *  Modal (static markup from templates/import_modal.mustache)
     * ====================================================================== */

    function $(id) { return document.getElementById(id); }

    function setTabsDisabled(disabled) {
        ['slides-import-tab-pdf', 'slides-import-tab-pptx'].forEach(function(id) {
            var tab = $(id);
            if (tab) { tab.disabled = !!disabled; }
        });
    }

    function closeModal() {
        if (!openCtx) { return; }
        var ctx = openCtx;
        if (ctx.onDocKey) {
            document.removeEventListener('keydown', ctx.onDocKey, true);
        }
        if (ctx.backdrop) { ctx.backdrop.hidden = true; }
        // Leave a clean slate for the next open: runImport hides the drop
        // zone and only the error path restores it.
        ctx.dropEl.hidden = false;
        ctx.fileEl.hidden = true;
        ctx.progressEl.hidden = true;
        openCtx = null;
    }

    function showError(message) {
        if (!openCtx) { return; }
        var ctx = openCtx;
        ctx.errorEl.textContent = message;
        ctx.errorEl.hidden = false;
        ctx.dropEl.hidden = false;
        ctx.fileEl.hidden = !ctx.file;
        ctx.progressEl.hidden = true;
        ctx.startBtn.disabled = !ctx.file;
        ctx.cancelBtn.disabled = false;
        ctx.processing = false;
        setTabsDisabled(false);
    }

    function clearFile() {
        if (!openCtx) { return; }
        var ctx = openCtx;
        ctx.file = null;
        ctx.fileEl.hidden = true;
        ctx.fileNameEl.textContent = '';
        ctx.fileSizeEl.textContent = '';
        ctx.startBtn.disabled = true;
    }

    function fileMatchesMode(file) {
        if (!file) { return false; }
        if (openCtx.mode === 'pdf') {
            return file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
        }
        return /\.(pptx|ppsx|potx)$/i.test(file.name || '') ||
            file.type === 'application/vnd.openxmlformats-officedocument.presentationml.presentation' ||
            file.type === 'application/zip' ||
            file.type === 'application/x-zip-compressed';
    }

    function setFile(file) {
        if (!openCtx || !file || openCtx.processing) { return; }
        if (!fileMatchesMode(file)) {
            clearFile();
            showError(openCtx.mode === 'pdf' ? str('importpdfbadtype') : str('importpptxbadtype'));
            return;
        }
        var ctx = openCtx;
        ctx.file = file;
        ctx.errorEl.hidden = true;
        ctx.fileEl.hidden = false;
        ctx.fileNameEl.textContent = file.name;
        ctx.fileSizeEl.textContent = formatSize(file.size || 0);
        ctx.startBtn.disabled = false;
    }

    function formatSize(bytes) {
        if (bytes >= 1048576) { return (bytes / 1048576).toFixed(1) + ' MB'; }
        if (bytes >= 1024) { return Math.round(bytes / 1024) + ' KB'; }
        return bytes + ' B';
    }

    function updateProgress(done, total) {
        if (!openCtx) { return; }
        var ctx = openCtx;
        var pct = total > 0 ? Math.round((done / total) * 100) : 0;
        ctx.fillEl.style.width = pct + '%';
        var key = ctx.mode === 'pptx' ? 'importpptxprogress' : 'importpdfprogress';
        ctx.statusEl.textContent = str(key, done + ' / ' + total);
    }

    /**
     * Switch the active tab (PDF / PPTX): accept filter, panel, and the
     * current file is dropped when it no longer matches the new mode.
     */
    function setMode(mode) {
        if (!openCtx || openCtx.processing || openCtx.mode === mode) { return; }
        var ctx = openCtx;
        ctx.mode = mode;

        var pdf = mode === 'pdf';
        var tabPdf = $('slides-import-tab-pdf');
        var tabPptx = $('slides-import-tab-pptx');
        var panelPdf = $('slides-import-panel-pdf');
        var panelPptx = $('slides-import-panel-pptx');

        if (tabPdf) {
            tabPdf.classList.toggle('is-active', pdf);
            tabPdf.setAttribute('aria-selected', pdf ? 'true' : 'false');
            tabPdf.tabIndex = pdf ? 0 : -1;
        }
        if (tabPptx) {
            tabPptx.classList.toggle('is-active', !pdf);
            tabPptx.setAttribute('aria-selected', pdf ? 'false' : 'true');
            tabPptx.tabIndex = pdf ? -1 : 0;
        }
        if (panelPdf) { panelPdf.hidden = !pdf; }
        if (panelPptx) { panelPptx.hidden = pdf; }

        if (ctx.inputEl) { ctx.inputEl.accept = ACCEPT[mode]; }
        ctx.errorEl.hidden = true;

        if (ctx.file && !fileMatchesMode(ctx.file)) { clearFile(); }
    }

    function openModal() {
        var backdrop = $('slides-import-backdrop');
        if (!backdrop || openCtx) { return; }

        var ctx = {
            backdrop: backdrop,
            mode: '',
            file: null,
            processing: false,
            cancelled: false,
            onDocKey: null,
            dropEl: $('slides-import-drop'),
            inputEl: $('slides-import-input'),
            fileEl: $('slides-import-file'),
            fileNameEl: $('slides-import-filename'),
            fileSizeEl: $('slides-import-filesize'),
            modeEl: $('slides-import-mode'),
            progressEl: $('slides-import-progress'),
            fillEl: $('slides-import-fill'),
            statusEl: $('slides-import-status'),
            errorEl: $('slides-import-error'),
            startBtn: $('slides-import-start'),
            cancelBtn: $('slides-import-cancel'),
            closeBtn: $('slides-import-close'),
        };
        if (!ctx.dropEl || !ctx.startBtn || !ctx.errorEl) { return; }
        openCtx = ctx;

        // Reset to a clean slate.
        ctx.cancelled = false;
        ctx.processing = false;
        ctx.errorEl.hidden = true;
        ctx.dropEl.hidden = false;
        ctx.fileEl.hidden = true;
        ctx.progressEl.hidden = true;
        ctx.startBtn.disabled = true;
        ctx.cancelBtn.disabled = false;
        if (ctx.inputEl) { ctx.inputEl.value = ''; }
        if (ctx.modeEl) {
            var addRadio = ctx.modeEl.querySelector('input[value="add"]');
            if (addRadio) { addRadio.checked = true; }
        }
        setTabsDisabled(false);
        // Force a real transition (mode starts empty) so tabs, panels and
        // the accept filter are back in PDF state even after a PPTX run.
        setMode('pdf');

        if (!backdrop.dataset.wired) {
            backdrop.dataset.wired = '1';
            wireEvents();
        }

        backdrop.hidden = false;
        ctx.onDocKey = function(e) {
            if (e.key === 'Escape' && openCtx === ctx && !ctx.processing) {
                e.stopPropagation();
                e.preventDefault();
                closeModal();
            }
        };
        document.addEventListener('keydown', ctx.onDocKey, true);
    }

    function wireEvents() {
        var backdrop = $('slides-import-backdrop');
        if (!backdrop) { return; }
        var modal = $('slides-import-modal');

        function ctx() { return openCtx; }

        var closeBtn = $('slides-import-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                var c = ctx();
                if (!c) { return; }
                if (c.processing) { c.cancelled = true; return; }
                closeModal();
            });
        }

        backdrop.addEventListener('click', function(e) {
            var c = ctx();
            if (!c || e.target !== backdrop || c.processing) { return; }
            closeModal();
        });

        // Keep the browser from navigating away when a file is dropped on
        // the dimmed area outside the dialog.
        backdrop.addEventListener('dragover', function(e) { e.preventDefault(); });
        backdrop.addEventListener('drop', function(e) {
            e.preventDefault();
            var c = ctx();
            if (!c || c.processing) { return; }
            var dt = e.dataTransfer;
            if (dt && dt.files && dt.files[0]) { setFile(dt.files[0]); }
        });

        ['slides-import-tab-pdf', 'slides-import-tab-pptx'].forEach(function(id) {
            var tab = $(id);
            if (!tab) { return; }
            tab.addEventListener('click', function() {
                setMode(tab.dataset.mode === 'pptx' ? 'pptx' : 'pdf');
            });
        });

        var drop = $('slides-import-drop');
        var input = $('slides-import-input');
        if (drop) {
            drop.addEventListener('click', function() {
                var c = ctx();
                if (c && !c.processing && input) { input.click(); }
            });
            drop.addEventListener('keydown', function(e) {
                var c = ctx();
                if (c && !c.processing && (e.key === 'Enter' || e.key === ' ')) {
                    e.preventDefault();
                    if (input) { input.click(); }
                }
            });
            ['dragenter', 'dragover'].forEach(function(ev) {
                drop.addEventListener(ev, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    drop.classList.add('is-over');
                });
            });
            ['dragleave', 'drop'].forEach(function(ev) {
                drop.addEventListener(ev, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    drop.classList.remove('is-over');
                });
            });
            drop.addEventListener('drop', function(e) {
                var c = ctx();
                if (!c || c.processing) { return; }
                var dt = e.dataTransfer;
                if (dt && dt.files && dt.files[0]) { setFile(dt.files[0]); }
            });
        }

        if (input) {
            input.addEventListener('change', function() {
                if (input.files && input.files[0]) { setFile(input.files[0]); }
                input.value = '';
            });
        }

        if (modal) {
            // Allow dropping anywhere on the modal while idle.
            modal.addEventListener('dragover', function(e) { e.preventDefault(); });
            modal.addEventListener('drop', function(e) {
                e.preventDefault();
                var c = ctx();
                if (!c || c.processing) { return; }
                var dt = e.dataTransfer;
                if (dt && dt.files && dt.files[0]) { setFile(dt.files[0]); }
            });
        }

        var startBtn = $('slides-import-start');
        if (startBtn) {
            startBtn.addEventListener('click', function() { runImport(); });
        }

        var cancelBtn = $('slides-import-cancel');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', function() {
                var c = ctx();
                if (!c) { return; }
                if (c.processing) {
                    c.cancelled = true;
                    c.cancelBtn.disabled = true;
                    c.statusEl.textContent = str('importpdfcancelling');
                    return;
                }
                closeModal();
            });
        }
    }

    function runImport() {
        var ctx = openCtx;
        if (!ctx || !ctx.file || ctx.processing) { return; }
        var file = ctx.file;
        var mode = ctx.mode;
        var modeEl = ctx.modeEl;
        var radio = modeEl ? modeEl.querySelector('input[name="slidesimportmode"]:checked') : null;
        var replace = !!(radio && radio.value === 'replace');

        ctx.processing = true;
        ctx.cancelled = false;
        ctx.dropEl.hidden = true;
        ctx.fileEl.hidden = true;
        ctx.errorEl.hidden = true;
        ctx.progressEl.hidden = false;
        ctx.startBtn.disabled = true;
        ctx.cancelBtn.disabled = false;
        setTabsDisabled(true);
        updateProgress(0, 1);

        var root = document.getElementById('slides-editor');
        var canvasW = parseInt(root && root.dataset.canvaswidth, 10) || 960;
        var canvasH = parseInt(root && root.dataset.canvasheight, 10) || 540;

        var opts = {
            canvasW: canvasW,
            canvasH: canvasH,
            rasterCanvas: null,
            upload: uploadBlob,
            isCancelled: function() { return ctx.cancelled; },
            onProgress: updateProgress,
        };

        var pipeline;
        if (mode === 'pptx') {
            pipeline = pptxImport.importFile(file, opts);
        } else {
            pipeline = loadPdfJs()
                .then(function(pdfjsLib) {
                    return readFile(file).then(function(data) {
                        return pdfjsLib.getDocument({ data: data }).promise;
                    }).then(function(pdf) {
                        return convertDocument(pdfjsLib, pdf, opts).then(function(slides) {
                            try { pdf.destroy(); } catch (e) { /* ignore */ }
                            return slides;
                        });
                    });
                });
        }

        pipeline
            .then(function(slides) {
                if (!openCtx || openCtx !== ctx) { return; }
                if (ctx.cancelled) {
                    // Cancelled: discard whatever was converted so far.
                    closeModal();
                    return;
                }
                var count = slides.length;
                if (count > 0) {
                    state.addSlidesBulk(slides, { replace: replace });
                }
                closeModal();
                if (count > 0) {
                    var status = document.getElementById('editor-status');
                    if (status) { status.textContent = str('importpdfdone', count); }
                }
            })
            .catch(function(err) {
                if (!openCtx || openCtx !== ctx) { return; }
                var msg;
                if (err && (err.name === 'PasswordException' || err.code === 1 || err.code === 2)) {
                    msg = str('importpdfpassword');
                } else if (err && err.message === 'pdfjs-load-failed') {
                    msg = str('importpdfnolib');
                } else if (err && err.message === 'jszip-load-failed') {
                    msg = str('importpptxnolib');
                } else if (mode === 'pptx') {
                    msg = str('importpptxerror');
                } else {
                    msg = str('importpdferror');
                }
                showError(msg);
            });
    }

    return {
        openModal: openModal,
    };
});
