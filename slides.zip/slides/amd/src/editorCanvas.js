/**
 * Canvas — renders the 960px editor canvas, handles selection + drag + resize + text editing.
 *
 * @module     mod_slides/editorCanvas
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/editorTextelem', 'mod_slides/editorPencil', 'mod_slides/editorBackground', 'mod_slides/editorIcons', 'mod_slides/editorImage', 'mod_slides/interactive_buttons'], function(state, textelem, pencil, background, icons, image, interactiveButtons) {
    'use strict';

    var CANVAS_W = 960;
    var CANVAS_MIN_ELT = 20;
    var GRID_SIZE = 10;
    var canvasEl = null;
    var viewportEl = null;
    var types = { text: textelem };

    var drawingMode = false;
    var drawingPoints = [];
    var drawingDiv = null;
    var drawingSvg = null;
    var emptyImagePicker = null;
    var equationEditor = null;
    var htmlEditor = null;
    // External scaler injected by the app (zoom_controller). When set it
    // owns the transform: scale() of the canvas; the legacy width-based
    // auto-fit below only runs as a fallback.
    var scalerFn = null;
    // Floating link toolbar injected by the app (link_manager). Rendered for
    // the selected element and repositioned live while it is dragged/resized.
    var selectionToolbarFn = null;
    var selectionToolbar = null;

    // Touch double-tap bookkeeping (dblclick is unreliable on touch).
    var lastTapTime = 0;
    var lastTapIdx = -1;

    /**
     * Active crop session: image box (ix/iy/iw/ih) and crop rect (rx/ry/rw/rh)
     * in frame-local canvas units. Committed on apply, discarded on cancel.
     */
    var cropState = null;

    var CROP_HANDLES = [
        { dir: 'nw', cursor: 'nwse-resize', x: '-5px', y: '-5px' },
        { dir: 'n',  cursor: 'ns-resize',   x: '50%',  y: '-5px' },
        { dir: 'ne', cursor: 'nesw-resize', x: '100%', y: '-5px' },
        { dir: 'e',  cursor: 'ew-resize',   x: '100%', y: '50%' },
        { dir: 'se', cursor: 'nwse-resize', x: '100%', y: '100%' },
        { dir: 's',  cursor: 'ns-resize',   x: '50%',  y: '100%' },
        { dir: 'sw', cursor: 'nesw-resize', x: '-5px', y: '100%' },
        { dir: 'w',  cursor: 'ew-resize',   x: '-5px', y: '50%' },
    ];

    function str(key) {
        try { return M.util.get_string(key, 'mod_slides'); } catch (e) { return key; }
    }

    /**
     * Register the handler used when an empty image placeholder is clicked
     * (defaults to the plain file picker when unset).
     *
     * @param {Function} fn function(el, elemIdx)
     */
    function setEmptyImagePicker(fn) {
        emptyImagePicker = typeof fn === 'function' ? fn : null;
    }

    /**
     * Register the handler used when an equation element is double clicked
     * (opens the equation editor modal with the TeX prefilled).
     *
     * @param {Function} fn function(slideIdx, elemIdx)
     */
    function setEquationEditor(fn) {
        equationEditor = typeof fn === 'function' ? fn : null;
    }

    /**
     * Register the handler used when an HTML/Embed element is double clicked
     * (reopens the HTML modal with the markup prefilled).
     *
     * @param {Function} fn function(slideIdx, elemIdx)
     */
    function setHtmlEditor(fn) {
        htmlEditor = typeof fn === 'function' ? fn : null;
    }

    var HANDLES = [
        { dir: 'nw', cursor: 'nwse-resize', x: -5, y: -5 },
        { dir: 'n',  cursor: 'ns-resize',   x: '50%', y: -5 },
        { dir: 'ne', cursor: 'nesw-resize', x: '100%', y: -5 },
        { dir: 'e',  cursor: 'ew-resize',   x: '100%', y: '50%' },
        { dir: 'se', cursor: 'nwse-resize', x: '100%', y: '100%' },
        { dir: 's',  cursor: 'ns-resize',   x: '50%', y: '100%' },
        { dir: 'sw', cursor: 'nesw-resize', x: -5, y: '100%' },
        { dir: 'w',  cursor: 'ew-resize',   x: -5, y: '50%' },
    ];

    function init(cv, vp) {
        canvasEl = cv;
        viewportEl = vp;
        state.subscribe(render);

        if (typeof ResizeObserver !== 'undefined') {
            // Observe the workspace (wrap), NOT the viewport: with the zoom
            // controller the viewport is resized BY the scale, so observing
            // it would loop (scale → viewport resize → rescale → …).
            new ResizeObserver(scaleCanvas).observe(viewportEl.parentNode || viewportEl);
        } else {
            window.addEventListener('resize', scaleCanvas);
        }
        scaleCanvas();

        canvasEl.addEventListener('pointerdown', function(e) {
            if (drawingMode) {
                startDrawing(e);
                return;
            }
            if (e.target === canvasEl) {
                state.deselectElement();
            }
        });

        canvasEl.addEventListener('pointermove', function(e) {
            if (drawingMode && drawingPoints.length > 0) {
                continueDrawing(e);
            }
        });

        canvasEl.addEventListener('pointerup', function(e) {
            if (drawingMode && drawingPoints.length > 0) {
                finishDrawing();
            }
        });

        canvasEl.addEventListener('pointercancel', function() {
            if (drawingMode && drawingPoints.length > 0) {
                finishDrawing();
            }
        });

        canvasEl.addEventListener('wheel', function(e) {
            if (!e.shiftKey) { return; }
            var s = state.get();
            if (s.selected === null) { return; }
            e.preventDefault();
            var slide = s.slides[s.current];
            var el = slide.elements[s.selected];
            if (!el || el._locked) { return; }
            var factor = e.deltaY < 0 ? 10 : -10;
            var aspect = el.w / el.h;
            var newW = Math.max(CANVAS_MIN_ELT, el.w + factor);
            var newH = Math.max(CANVAS_MIN_ELT, Math.round(newW / aspect));
            var canvasH = getCanvasHeight();
            newW = Math.round(newW / GRID_SIZE) * GRID_SIZE;
            newH = Math.round(newH / GRID_SIZE) * GRID_SIZE;
            newW = Math.min(CANVAS_W - el.x, Math.max(CANVAS_MIN_ELT, newW));
            newH = Math.min(canvasH - el.y, Math.max(CANVAS_MIN_ELT, newH));
            state.beginDragSnapshot();
            el.w = newW;
            el.h = newH;
            state.markDirty();
            render();
        }, { passive: false });

        // Clipboard paste support (Ctrl+V) for images
        document.addEventListener('paste', function(e) {
            var items = (e.clipboardData || e.originalEvent.clipboardData).items;
            for (var i = 0; i < items.length; i++) {
                if (items[i].type.indexOf('image') !== -1) {
                    e.preventDefault();
                    var blob = items[i].getAsFile();
                    if (!blob) { continue; }
                    var root = document.getElementById('slides-editor');
                    if (!root) { continue; }
                    var cmid = parseInt(root.dataset.cmid, 10);
                    var sesskey = root.dataset.sesskey;
                    if (!cmid || !sesskey) { continue; }

                    var fd = new FormData();
                    fd.append('cmid', cmid);
                    fd.append('sesskey', sesskey);
                    fd.append('media', blob, blob.name || 'pasted-image.png');

                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', M.cfg.wwwroot + '/mod/slides/classes/local/media_upload_ajax.php', true);
                    xhr.timeout = 60000;
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            try {
                                var res = JSON.parse(xhr.responseText);
                                if (res && res.url) {
                                    var s = state.get();
                                    if (s.selected !== null) {
                                        var slide = s.slides[s.current];
                                        var el = slide.elements[s.selected];
                                        if (el && el.type === 'image' && !el.src) {
                                            state.updateElementAtomic(s.current, s.selected, {
                                                src: res.url,
                                                alt: blob.name || 'pasted-image'
                                            });
                                            return;
                                        }
                                    }
                                    var imgEl = Object.assign({}, { type: 'image', x: 100, y: 100, w: 300, h: 200, opacity: 100, borderRadius: 0 }, {
                                        src: res.url,
                                        alt: blob.name || 'pasted-image'
                                    });
                                    state.addElement(s.current, imgEl);
                                }
                            } catch (e) { /* ignore */ }
                        }
                    };
                    xhr.send(fd);
                    break;
                }
            }
        });

        render();
    }

    function scaleCanvas() {
        if (!viewportEl || !canvasEl) { return; }
        // The zoom controller owns the scale once wired (slider / Ctrl+wheel /
        // Fit). It keeps its own fit base and the user's zoom level.
        if (scalerFn) { scalerFn(); return; }
        // Legacy auto-fit (no zoom controller): fill the viewport width.
        var vw = viewportEl.clientWidth;
        var scale = vw / CANVAS_W;
        canvasEl.style.transform = 'scale(' + scale + ')';
        // Same contract as zoom_controller: styles.css counter-scales
        // embedded iframes/video (they don't re-raster under transform).
        canvasEl.style.setProperty('--slide-scale', String(scale));
    }

    /**
     * Inject the active scaler (zoom_controller.applyScale).
     *
     * @param {Function|null} fn
     */
    function setScaler(fn) {
        scalerFn = fn || null;
        scaleCanvas();
    }

    /**
     * Inject the builder that draws the floating 🔗 link toolbar over the
     * selected element (link_manager.renderToolbar). The callback receives
     * (canvasEl, element, slideIdx, elemIdx) and returns either null or
     * {node, update(el)} — update() keeps the bar glued to the element
     * while a drag or resize moves it without a re-render.
     *
     * @param {Function|null} fn
     */
    function setSelectionToolbar(fn) {
        selectionToolbarFn = fn || null;
        selectionToolbar = null;
        render();
    }

    function getCanvasHeight() {
        return parseInt(canvasEl.dataset.height, 10) || 540;
    }

    function openFilePickerForImage(el) {
        // Create hidden file input
        var input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.multiple = false;
        input.style.display = 'none';
        document.body.appendChild(input);

        input.addEventListener('change', function() {
            var file = input.files[0];
            if (!file) {
                if (document.body.contains(input)) {
                    document.body.removeChild(input);
                }
                return;
            }
            var root = document.getElementById('slides-editor');
            if (!root) {
                if (document.body.contains(input)) {
                    document.body.removeChild(input);
                }
                return;
            }
            var cmid = parseInt(root.dataset.cmid, 10);
            var sesskey = root.dataset.sesskey;
            if (!cmid || !sesskey) {
                if (document.body.contains(input)) {
                    document.body.removeChild(input);
                }
                return;
            }

            var fd = new FormData();
            fd.append('cmid', cmid);
            fd.append('sesskey', sesskey);
            fd.append('media', file, file.name);

            var xhr = new XMLHttpRequest();
            xhr.open('POST', M.cfg.wwwroot + '/mod/slides/classes/local/media_upload_ajax.php', true);
            xhr.timeout = 60000;
            xhr.onload = function() {
                if (xhr.status === 200) {
                    try {
                        var res = JSON.parse(xhr.responseText);
                        if (res && res.url) {
                            state.updateElementAtomic(state.get().current, state.get().selected, {
                                src: res.url,
                                alt: file.name
                            });
                        }
                    } catch (e) { /* ignore */ }
                }
                if (document.body.contains(input)) {
                    document.body.removeChild(input);
                }
            };
            xhr.onerror = function() {
                if (document.body.contains(input)) {
                    document.body.removeChild(input);
                }
            };
            xhr.send(fd);
        });

        input.click();
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    /* ========================================================================
     *  Render
     * ======================================================================== */
    function render() {
        if (!canvasEl) { return; }
        var s = state.get();

        // A crop session dies as soon as its element/slide goes away, or if
        // the frame is resized externally (properties fields, undo/redo).
        if (cropState) {
            var csEl = s.slides[cropState.slideIdx] && s.slides[cropState.slideIdx].elements[cropState.elemIdx];
            if (cropState.slideIdx !== s.current || !csEl || csEl.type !== 'image' || !csEl.src ||
                    csEl.w !== cropState.fw || csEl.h !== cropState.fh) {
                stopCrop();
            }
        }

        var slide = s.slides[s.current];
        if (!slide) {
            canvasEl.innerHTML = '<div style="padding:40px;text-align:center;color:#888;">' + str('emptystate') + '</div>';
            return;
        }

        // Background
        canvasEl.style.background = background.toCss(slide.background);

        canvasEl.innerHTML = '';

        (slide.elements || []).forEach(function(el, idx) {
            // Skip hidden elements
            if (el._visible === false) { return; }

            var typeMod = types[el.type];
            var div = document.createElement('div');
            div.className = 'editor-element slide-element slide-element--' + (el.type || 'text');
            div.dataset.idx = idx;

            // Image elements
            if (el.type === 'image') {
                div.style.cssText = typeMod ? typeMod.outerStyle(el) :
                    'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
                
                if (el.src && cropState && cropState.elemIdx === idx) {
                    // Crop session: full source image + dim, rect and handles.
                    renderCropInto(div, el, idx);
                } else if (el.src) {
                    var img = document.createElement('img');
                    img.src = el.src;
                    img.alt = el.alt || '';
                    img.draggable = false;
                    var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
                    var br = el.borderRadius || 0;
                    if (typeMod && typeMod.hasCrop(el)) {
                        div.style.cssText += typeMod.croppedContainerStyle(el);
                        img.style.cssText = typeMod.croppedImgStyle(el) + 'pointer-events:none;';
                    } else {
                        img.style.cssText = 'width:100%;height:100%;object-fit:contain;opacity:' + opacity +
                            ';border-radius:' + br + 'px;pointer-events:none;display:block;';
                    }
                    div.appendChild(img);
                } else {
                    // Empty image placeholder — dashed border with click hint
                    div.style.border = '2px dashed #adb5bd';
                    div.style.borderRadius = (el.borderRadius || 0) + 'px';
                    div.style.background = '#f8f9fa';
                    div.style.display = 'flex';
                    div.style.flexDirection = 'column';
                    div.style.alignItems = 'center';
                    div.style.justifyContent = 'center';
                    div.style.cursor = 'pointer';
                    div.style.pointerEvents = 'auto';
                    
                    var icon = document.createElement('div');
                    icon.innerHTML = icons.get('image', {size: 48});
                    icon.style.color = '#adb5bd';
                    icon.style.marginBottom = '8px';
                    div.appendChild(icon);
                    
                    var hint = document.createElement('div');
                    hint.textContent = 'Click para agregar imagen';
                    hint.style.fontSize = '13px';
                    hint.style.color = '#888';
                    hint.style.textAlign = 'center';
                    hint.style.pointerEvents = 'none';
                    div.appendChild(hint);
                    
                    // Click handler for empty image — photo bank (or file picker fallback)
                    div.addEventListener('click', function(e) {
                        e.stopPropagation();
                        if (!el.src) {
                            if (emptyImagePicker) {
                                emptyImagePicker(el, idx);
                            } else {
                                openFilePickerForImage(el);
                            }
                        }
                    });
                }

            // Video elements
            } else if (el.type === 'video') {
                div.style.cssText = typeMod ? typeMod.outerStyle(el) :
                    'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
                if (typeMod && typeMod.renderVideo) {
                    div.appendChild(typeMod.renderVideo(el));
                }

            // Recorded audio player (media_recorder.js) — same interaction
            // model as video: no pointer events, drag owns the gestures.
            } else if (el.type === 'audio') {
                div.style.cssText = typeMod ? typeMod.outerStyle(el) :
                    'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
                if (typeMod && typeMod.renderAudio) {
                    div.appendChild(typeMod.renderAudio(el));
                } else if (el.src) {
                    var audioFallback = document.createElement('audio');
                    audioFallback.src = el.src;
                    audioFallback.controls = true;
                    audioFallback.style.cssText = 'width:100%;height:100%;pointer-events:none;';
                    div.appendChild(audioFallback);
                }

            // HTML / embed elements — markup is rendered live, but a transparent
            // overlay keeps iframes from swallowing the drag/resize pointers.
            } else if (el.type === 'html') {
                var htmlShadow = el.shadowEnabled ?
                    'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                    (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';' : '';
                div.style.cssText = (typeMod && typeMod.outerStyle ? typeMod.outerStyle(el) :
                    'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;') +
                    'overflow:hidden;' + htmlShadow;
                var htmlInner = document.createElement('div');
                htmlInner.className = 'html-embed-content';
                htmlInner.style.cssText = 'width:100%;height:100%;box-sizing:border-box;overflow:hidden;' +
                    'opacity:' + ((el.opacity !== undefined) ? el.opacity / 100 : 1) + ';' +
                    (el.borderRadius ? 'border-radius:' + el.borderRadius + 'px;' : '');
                htmlInner.innerHTML = el.text || '';
                div.appendChild(htmlInner);

                var htmlOverlay = document.createElement('div');
                htmlOverlay.className = 'html-embed-overlay';
                div.appendChild(htmlOverlay);

            // Pencil elements
            } else if (el.type === 'pencil' && pencil && pencil.renderSvg) {
                div.style.cssText = typeMod ? typeMod.outerStyle(el) :
                    'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
                var svg = pencil.renderSvg(el);
                div.appendChild(svg);

            // PDF resource elements (icon card, resizable via handles)
            } else if (el.type === 'pdf') {
                div.style.cssText = typeMod ? typeMod.outerStyle(el) :
                    'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';
                if (typeMod && typeMod.renderPdf) {
                    div.appendChild(typeMod.renderPdf(el));
                }

            // Shapes with inner clip-path
            } else if (typeMod && typeMod.innerStyle) {
                div.style.cssText = typeMod.outerStyle(el);
                var inner = document.createElement('div');
                inner.className = 'shape-inner';
                inner.style.cssText = typeMod.innerStyle(el);
                div.appendChild(inner);

            // Interactive action buttons (Genially-style): styled button.
            } else if (el.type === 'action') {
                div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:hidden;' +
                    interactiveButtons.buttonInnerStyle(el) +
                    'font-size:' + (el.fontSize || 20) + 'px;';
                var actionIconHtml = interactiveButtons.buttonIconHtml(el);
                if (actionIconHtml) {
                    div.innerHTML = actionIconHtml;
                    div.title = el.label || '';
                } else {
                    div.textContent = el.label || '';
                }

            // Text elements — render with lists and highlight support
            } else {
                div.style.cssText = typeMod ? typeMod.inlineStyles(el) :
                    'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;';

                if (typeMod && typeMod.renderText) {
                    div.innerHTML = typeMod.renderText(el);
                } else {
                    div.textContent = el.text || '';
                }
            }

            if (idx === s.selected || s.multiSelected.indexOf(idx) >= 0) {
                // No resize handles while the element is being cropped.
                if (!(cropState && cropState.elemIdx === idx)) {
                    div.classList.add('is-selected');
                    renderHandles(div, el);
                }
            }

            // Sequence badge for click-to-reveal animations (PowerPoint style).
            // Lives inside the element box so overflow:hidden types keep it,
            // and never eats pointers so dragging still works.
            if ((el.animOrder || 0) > 0) {
                var animBadge = document.createElement('span');
                animBadge.className = 'anim-badge';
                animBadge.textContent = '[' + el.animOrder + ']';
                animBadge.title = str('animorder');
                div.appendChild(animBadge);
            }

            div.addEventListener('pointerdown', function(e) {
                if (cropState) {
                    if (cropState.elemIdx === idx) { return; }
                    // Click away from the cropped image: leave crop mode first.
                    cancelCrop();
                    return;
                }
                if (e.pointerType === 'touch') {
                    var now = Date.now();
                    if ((el.type === 'text' || el.type === 'equation' || el.type === 'html') && now - lastTapTime < 400 && lastTapIdx === idx) {
                        lastTapTime = 0;
                        lastTapIdx = -1;
                        if (el.type === 'equation' && equationEditor && !el._locked) {
                            equationEditor(s.current, idx);
                            return;
                        }
                        if (el.type === 'html' && htmlEditor && !el._locked) {
                            htmlEditor(s.current, idx);
                            return;
                        }
                        if (div.contentEditable !== 'true' && !el._locked) {
                            // Do NOT selectElement here: it triggers a synchronous
                            // render that detaches this div before startTextEdit runs.
                            startTextEdit(div, s.current, idx);
                        }
                        return;
                    }
                    lastTapTime = now;
                    lastTapIdx = idx;
                } else if (e.detail === 2) {
                    return;
                }
                if (div.contentEditable === 'true') { return; }
                if (e.target.classList.contains('editor-handle')) { return; }
                if (el._locked) { return; }

                // Tap on an already-selected text element → edit mode (PowerPoint
                // mobile pattern). A real drag still moves the element; only a
                // press that lifts without moving enters the editor. The div is
                // re-queried on pointerup because startDrag re-renders.
                if (el.type === 'text' && !e.shiftKey &&
                        state.get().selected === idx && state.get().multiSelected.length <= 1) {
                    var tapX = e.clientX;
                    var tapY = e.clientY;
                    var tapMoved = false;
                    var tapId = e.pointerId;
                    var tapMove = function(ev) {
                        if (ev.pointerId !== tapId) { return; }
                        if (Math.abs(ev.clientX - tapX) > 4 || Math.abs(ev.clientY - tapY) > 4) {
                            tapMoved = true;
                        }
                    };
                    var tapUp = function(ev) {
                        if (ev.pointerId !== tapId) { return; }
                        document.removeEventListener('pointermove', tapMove);
                        document.removeEventListener('pointerup', tapUp);
                        document.removeEventListener('pointercancel', tapUp);
                        if (tapMoved) { return; }
                        var live = canvasEl.querySelector('[data-idx="' + idx + '"]');
                        if (live && live.contentEditable !== 'true') {
                            startTextEdit(live, s.current, idx);
                        }
                    };
                    document.addEventListener('pointermove', tapMove);
                    document.addEventListener('pointerup', tapUp);
                    document.addEventListener('pointercancel', tapUp);
                }

                e.stopPropagation();
                state.selectElement(idx, e.shiftKey);
                startDrag(e, div, idx);
            });

            div.addEventListener('dblclick', function(e) {
                if (cropState) { return; }
                if (div.contentEditable === 'true') { return; }
                e.stopPropagation();
                if (el.type === 'equation' && equationEditor) {
                    equationEditor(s.current, idx);
                    return;
                }
                if (el.type === 'html') {
                    if (htmlEditor && !el._locked) { htmlEditor(s.current, idx); }
                    return;
                }
                startTextEdit(div, s.current, idx);
            });

            canvasEl.appendChild(div);
        });

        // Floating link toolbar (🔗 Edit / Remove link) for the selected
        // element — single selection only, never during a crop session.
        selectionToolbar = null;
        if (selectionToolbarFn && !cropState && s.selected !== null &&
                s.selected !== undefined &&
                (!s.multiSelected || s.multiSelected.length <= 1)) {
            var selEl = slide.elements[s.selected];
            if (selEl && !selEl._locked && selEl._visible !== false) {
                selectionToolbar = selectionToolbarFn(canvasEl, selEl, s.current, s.selected);
            }
        }

        if (cropState) {
            renderCropToolbar();
        }
    }

    /* ========================================================================
     *  Crop mode (PowerPoint-style) for image elements
     * ======================================================================== */

    /**
     * Enter crop mode for an image element. The image box (where the full
     * source sits) and the crop rect are kept in frame-local units; nothing
     * touches the state until the user applies.
     */
    function startCrop(elemIdx) {
        if (cropState) { return; }
        var s = state.get();
        var slideIdx = s.current;
        var slide = s.slides[slideIdx];
        var el = slide && slide.elements[elemIdx];
        if (!el || el.type !== 'image' || !el.src) { return; }

        var probe = new Image();
        probe.onload = function() {
            if (cropState) { return; }
            var nw = probe.naturalWidth || el.w;
            var nh = probe.naturalHeight || el.h;
            var w = el.w;
            var h = el.h;
            if (image.hasCrop(el)) {
                var c = el.crop;
                cropState = {
                    slideIdx: slideIdx,
                    elemIdx: elemIdx,
                    fw: w,
                    fh: h,
                    ix: -(c.x / c.w) * w,
                    iy: -(c.y / c.h) * h,
                    iw: w / c.w,
                    ih: h / c.h,
                    rx: 0, ry: 0, rw: w, rh: h,
                };
            } else {
                var scale = Math.min(w / nw, h / nh);
                var iw = nw * scale;
                var ih = nh * scale;
                var ix = (w - iw) / 2;
                var iy = (h - ih) / 2;
                cropState = {
                    slideIdx: slideIdx,
                    elemIdx: elemIdx,
                    fw: w,
                    fh: h,
                    ix: ix, iy: iy, iw: iw, ih: ih,
                    rx: ix, ry: iy, rw: iw, rh: ih,
                };
            }
            if (state.get().current !== slideIdx) { cropState = null; return; }
            state.selectElement(elemIdx, false);
            document.addEventListener('keydown', onCropKey, true);
            render();
        };
        probe.src = el.src;
    }

    function stopCrop() {
        if (!cropState) { return; }
        cropState = null;
        document.removeEventListener('keydown', onCropKey, true);
    }

    function cancelCrop() {
        stopCrop();
        render();
    }

    function onCropKey(e) {
        if (!cropState) { return; }
        if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            applyCrop();
        } else if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            cancelCrop();
        } else if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'y')) {
            // Undo/redo invalidates the working rect — leave crop mode first.
            cancelCrop();
        }
    }

    /** Commit the working rect: new frame = rect, crop = rect over image box. */
    function applyCrop() {
        if (!cropState) { return; }
        var cs = cropState;
        var s = state.get();
        var slide = s.slides[cs.slideIdx];
        var el = slide && slide.elements[cs.elemIdx];
        stopCrop();
        if (!el) { render(); return; }

        var nw = Math.max(CANVAS_MIN_ELT, Math.round(cs.rw));
        var nh = Math.max(CANVAS_MIN_ELT, Math.round(cs.rh));
        var crop = {
            x: Math.round(((cs.rx - cs.ix) / cs.iw) * 10000) / 10000,
            y: Math.round(((cs.ry - cs.iy) / cs.ih) * 10000) / 10000,
            w: Math.round((nw / cs.iw) * 10000) / 10000,
            h: Math.round((nh / cs.ih) * 10000) / 10000,
        };
        crop.w = Math.min(1, Math.max(0.01, crop.w));
        crop.h = Math.min(1, Math.max(0.01, crop.h));
        crop.x = Math.max(0, Math.min(crop.x, 1 - crop.w));
        crop.y = Math.max(0, Math.min(crop.y, 1 - crop.h));

        state.updateElementAtomic(cs.slideIdx, cs.elemIdx, {
            x: Math.round(el.x + cs.rx),
            y: Math.round(el.y + cs.ry),
            w: nw,
            h: nh,
            crop: crop,
        });
    }

    /** Draw the full source image, dim strips, crop rect and handles. */
    function renderCropInto(div, el, idx) {
        var cs = cropState;
        div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w +
            'px;height:' + el.h + 'px;overflow:visible;';

        var img = document.createElement('img');
        img.src = el.src;
        img.alt = el.alt || '';
        img.draggable = false;
        img.style.cssText = 'position:absolute;max-width:none;left:' + cs.ix + 'px;top:' + cs.iy +
            'px;width:' + cs.iw + 'px;height:' + cs.ih + 'px;object-fit:fill;pointer-events:none;';
        div.appendChild(img);

        var strips = [
            { x: cs.ix, y: cs.iy, w: cs.rx - cs.ix, h: cs.ih },
            { x: cs.rx + cs.rw, y: cs.iy, w: (cs.ix + cs.iw) - (cs.rx + cs.rw), h: cs.ih },
            { x: cs.rx, y: cs.iy, w: cs.rw, h: cs.ry - cs.iy },
            { x: cs.rx, y: cs.ry + cs.rh, w: cs.rw, h: (cs.iy + cs.ih) - (cs.ry + cs.rh) },
        ];
        strips.forEach(function(st) {
            if (st.w <= 0.5 || st.h <= 0.5) { return; }
            var dim = document.createElement('div');
            dim.className = 'crop-dim';
            dim.style.cssText = 'left:' + st.x + 'px;top:' + st.y + 'px;width:' + st.w + 'px;height:' + st.h + 'px;';
            div.appendChild(dim);
        });

        var rect = document.createElement('div');
        rect.className = 'crop-rect';
        rect.style.cssText = 'left:' + cs.rx + 'px;top:' + cs.ry + 'px;width:' + cs.rw + 'px;height:' + cs.rh + 'px;';
        div.appendChild(rect);

        CROP_HANDLES.forEach(function(h) {
            var handle = document.createElement('div');
            handle.className = 'crop-handle crop-handle--' + h.dir;
            handle.style.cursor = h.cursor;
            handle.style.left = h.x;
            handle.style.top = h.y;
            handle.addEventListener('pointerdown', function(e) {
                e.stopPropagation();
                e.preventDefault();
                startCropResize(h.dir, e);
            });
            div.appendChild(handle);
        });

        // Dragging anywhere on the element pans the image under the rect.
        div.addEventListener('pointerdown', function(e) {
            e.stopPropagation();
            e.preventDefault();
            startCropPan(e);
        });
    }

    /** Floating [Apply][Cancel] bar above the element being cropped. */
    function renderCropToolbar() {
        var s = state.get();
        var slide = s.slides[s.current];
        var el = slide && slide.elements[cropState.elemIdx];
        if (!el) { return; }

        var bar = document.createElement('div');
        bar.className = 'crop-toolbar';
        bar.style.left = el.x + 'px';
        bar.style.top = (el.y >= 52 ? el.y - 52 : el.y + el.h + 10) + 'px';

        var hint = document.createElement('span');
        hint.className = 'crop-toolbar-hint';
        hint.textContent = str('crophint');
        bar.appendChild(hint);

        var apply = document.createElement('button');
        apply.type = 'button';
        apply.className = 'btn btn-sm btn-primary';
        apply.textContent = str('cropapply');
        apply.addEventListener('pointerdown', function(e) { e.stopPropagation(); });
        apply.addEventListener('click', function(e) {
            e.stopPropagation();
            applyCrop();
        });
        bar.appendChild(apply);

        var cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'btn btn-sm btn-secondary';
        cancel.textContent = str('cropcancel');
        cancel.addEventListener('pointerdown', function(e) { e.stopPropagation(); });
        cancel.addEventListener('click', function(e) {
            e.stopPropagation();
            cancelCrop();
        });
        bar.appendChild(cancel);

        canvasEl.appendChild(bar);
    }

    /** Resize the crop rect with one handle; rect stays inside the image box. */
    function startCropResize(dir, e) {
        var cs = cropState;
        if (!cs) { return; }
        var scale = viewportEl.clientWidth / CANVAS_W;
        var startX = e.clientX;
        var startY = e.clientY;
        var activeId = e.pointerId;
        var o = { rx: cs.rx, ry: cs.ry, rw: cs.rw, rh: cs.rh };
        var minSize = Math.max(8, Math.min(30, Math.min(cs.iw, cs.ih) / 4));

        function onMove(ev) {
            if (ev.pointerId !== activeId) { return; }
            var dx = (ev.clientX - startX) / scale;
            var dy = (ev.clientY - startY) / scale;
            var rx = o.rx;
            var ry = o.ry;
            var rw = o.rw;
            var rh = o.rh;

            if (dir.indexOf('e') !== -1) { rw = o.rw + dx; }
            if (dir.indexOf('s') !== -1) { rh = o.rh + dy; }
            if (dir.indexOf('w') !== -1) { rx = o.rx + dx; rw = o.rw - dx; }
            if (dir.indexOf('n') !== -1) { ry = o.ry + dy; rh = o.rh - dy; }

            if (rw < minSize) {
                if (dir.indexOf('w') !== -1) { rx = (o.rx + o.rw) - minSize; }
                rw = minSize;
            }
            if (rh < minSize) {
                if (dir.indexOf('n') !== -1) { ry = (o.ry + o.rh) - minSize; }
                rh = minSize;
            }
            if (rx < cs.ix) { rw -= (cs.ix - rx); rx = cs.ix; }
            if (ry < cs.iy) { rh -= (cs.iy - ry); ry = cs.iy; }
            if (rx + rw > cs.ix + cs.iw) { rw = (cs.ix + cs.iw) - rx; }
            if (ry + rh > cs.iy + cs.ih) { rh = (cs.iy + cs.ih) - ry; }

            cs.rx = rx;
            cs.ry = ry;
            cs.rw = rw;
            cs.rh = rh;
            render();
        }

        function onUp(ev) {
            if (ev && ev.pointerId !== activeId) { return; }
            document.removeEventListener('pointermove', onMove);
            document.removeEventListener('pointerup', onUp);
            document.removeEventListener('pointercancel', onUp);
        }

        document.addEventListener('pointermove', onMove);
        document.addEventListener('pointerup', onUp);
        document.addEventListener('pointercancel', onUp);
    }

    /** Pan the image behind the fixed rect (image must keep covering it). */
    function startCropPan(e) {
        var cs = cropState;
        if (!cs) { return; }
        var scale = viewportEl.clientWidth / CANVAS_W;
        var startX = e.clientX;
        var startY = e.clientY;
        var activeId = e.pointerId;
        var o = { ix: cs.ix, iy: cs.iy };

        function onMove(ev) {
            if (ev.pointerId !== activeId) { return; }
            var dx = (ev.clientX - startX) / scale;
            var dy = (ev.clientY - startY) / scale;
            var minIx = (cs.rx + cs.rw) - cs.iw;
            var maxIx = cs.rx;
            var minIy = (cs.ry + cs.rh) - cs.ih;
            var maxIy = cs.ry;
            cs.ix = Math.max(minIx, Math.min(maxIx, o.ix + dx));
            cs.iy = Math.max(minIy, Math.min(maxIy, o.iy + dy));
            render();
        }

        function onUp(ev) {
            if (ev && ev.pointerId !== activeId) { return; }
            document.removeEventListener('pointermove', onMove);
            document.removeEventListener('pointerup', onUp);
            document.removeEventListener('pointercancel', onUp);
        }

        document.addEventListener('pointermove', onMove);
        document.addEventListener('pointerup', onUp);
        document.addEventListener('pointercancel', onUp);
    }

    /* ========================================================================
     *  Resize handles (8 — PowerPoint-style)
     * ======================================================================== */
    function renderHandles(div, el) {
        HANDLES.forEach(function(h) {
            var handle = document.createElement('div');
            handle.className = 'editor-handle editor-handle--' + h.dir;
            handle.dataset.dir = h.dir;
            handle.style.cursor = h.cursor;

            handle.style.left = (typeof h.x === 'number') ? h.x + 'px' : h.x;
            handle.style.top  = (typeof h.y === 'number') ? h.y + 'px' : h.y;

            handle.addEventListener('pointerdown', function(e) {
                e.stopPropagation();
                e.preventDefault();
                startResize(e, div, el, h.dir);
            });

            div.appendChild(handle);
        });

        // Rotation handle (shapes only — the only type exposing `angle`).
        if (el.type === 'shape' && !el._locked) {
            var rot = document.createElement('div');
            rot.className = 'editor-handle editor-handle--rotate';
            rot.style.left = '50%';
            rot.style.top = '-26px';
            rot.style.cursor = 'grab';
            rot.title = str('angle');
            rot.addEventListener('pointerdown', function(e) {
                e.stopPropagation();
                e.preventDefault();
                startRotate(e, div, el);
            });
            div.appendChild(rot);
        }
    }

    /* ========================================================================
     *  Rotate logic (direct manipulation on the canvas)
     * ======================================================================== */
    function startRotate(e, div, el) {
        var rect = div.getBoundingClientRect();
        var cx = rect.left + rect.width / 2;
        var cy = rect.top + rect.height / 2;
        var origAngle = el.angle || 0;
        var startPointer = Math.atan2(e.clientY - cy, e.clientX - cx) * 180 / Math.PI;
        var snapStep = e.shiftKey ? 0 : 5;
        var activeId = e.pointerId;

        state.beginDragSnapshot();

        function onMove(ev) {
            if (ev.pointerId !== activeId) { return; }
            var now = Math.atan2(ev.clientY - cy, ev.clientX - cx) * 180 / Math.PI;
            var next = origAngle + (now - startPointer);
            next = ((next % 360) + 360) % 360;
            if (snapStep > 0) { next = Math.round(next / snapStep) * snapStep; }
            if (next >= 360) { next = 0; }
            el.angle = next;
            state.markDirty();
        }

        function onUp(ev) {
            if (ev && ev.pointerId !== activeId) { return; }
            document.removeEventListener('pointermove', onMove);
            document.removeEventListener('pointerup', onUp);
            document.removeEventListener('pointercancel', onUp);
            state.markDirty();
        }

        document.addEventListener('pointermove', onMove);
        document.addEventListener('pointerup', onUp);
        document.addEventListener('pointercancel', onUp);
    }

    /* ========================================================================
     *  Resize logic
     * ======================================================================== */
    function startResize(e, div, el, dir) {
        var scale = viewportEl.clientWidth / CANVAS_W;
        var canvasH = getCanvasHeight();
        var startX = e.clientX;
        var startY = e.clientY;
        var origX = el.x;
        var origY = el.y;
        var origW = el.w;
        var origH = el.h;
        var snapToGrid = !e.shiftKey;
        var activeId = e.pointerId;

        state.beginDragSnapshot();

        function onMove(ev) {
            if (ev.pointerId !== activeId) { return; }
            var dx = (ev.clientX - startX) / scale;
            var dy = (ev.clientY - startY) / scale;

            var x = origX, y = origY, w = origW, h = origH;

            if (dir.indexOf('e') !== -1) { w = Math.max(CANVAS_MIN_ELT, Math.min(CANVAS_W - origX, origW + dx)); }
            if (dir.indexOf('w') !== -1) { w = Math.max(CANVAS_MIN_ELT, origW - dx); x = origX + origW - w; }
            if (dir.indexOf('s') !== -1) { h = Math.max(CANVAS_MIN_ELT, Math.min(canvasH - origY, origH + dy)); }
            if (dir.indexOf('n') !== -1) { h = Math.max(CANVAS_MIN_ELT, origH - dy); y = origY + origH - h; }

            x = Math.max(0, Math.min(CANVAS_W - w, x));
            y = Math.max(0, Math.min(canvasH - h, y));

            if (snapToGrid) {
                x = Math.round(x / GRID_SIZE) * GRID_SIZE;
                y = Math.round(y / GRID_SIZE) * GRID_SIZE;
                w = Math.max(CANVAS_MIN_ELT, Math.round(w / GRID_SIZE) * GRID_SIZE);
                h = Math.max(CANVAS_MIN_ELT, Math.round(h / GRID_SIZE) * GRID_SIZE);
            }

            el.x = Math.round(x);
            el.y = Math.round(y);
            el.w = Math.round(w);
            el.h = Math.round(h);

            div.style.left = el.x + 'px';
            div.style.top  = el.y + 'px';
            div.style.width  = el.w + 'px';
            div.style.height = el.h + 'px';
            if (selectionToolbar) { selectionToolbar.update(el); }
            state.markDirty();
        }

        function onUp(ev) {
            if (ev && ev.pointerId !== activeId) { return; }
            document.removeEventListener('pointermove', onMove);
            document.removeEventListener('pointerup', onUp);
            document.removeEventListener('pointercancel', onUp);
        }

        document.addEventListener('pointermove', onMove);
        document.addEventListener('pointerup', onUp);
        document.addEventListener('pointercancel', onUp);
    }

    /* ========================================================================
     *  Drag (move)
     * ======================================================================== */
    function startDrag(e, div, elemIdx) {
        var s = state.get();
        var slide = s.slides[s.current];
        var el = slide.elements[elemIdx];
        var scale = viewportEl.clientWidth / CANVAS_W;
        var canvasH = getCanvasHeight();

        var startX = e.clientX;
        var startY = e.clientY;
        var origX = el.x;
        var origY = el.y;
        var snapToGrid = !e.shiftKey;
        var activeId = e.pointerId;

        var multiElements = [];
        if (s.multiSelected.length > 1) {
            s.multiSelected.forEach(function(idx) {
                var elem = slide.elements[idx];
                multiElements.push({
                    idx: idx,
                    origX: elem.x,
                    origY: elem.y,
                    w: elem.w,
                    h: elem.h,
                });
            });
        }

        state.beginDragSnapshot();

        function onMove(ev) {
            if (ev.pointerId !== activeId) { return; }
            var dx = (ev.clientX - startX) / scale;
            var dy = (ev.clientY - startY) / scale;
            var newX = Math.max(0, Math.min(CANVAS_W - el.w, origX + dx));
            var newY = Math.max(0, Math.min(canvasH - el.h, origY + dy));

            if (snapToGrid) {
                newX = Math.round(newX / GRID_SIZE) * GRID_SIZE;
                newY = Math.round(newY / GRID_SIZE) * GRID_SIZE;
            }

            var deltaX = Math.round(newX) - origX;
            var deltaY = Math.round(newY) - origY;

            el.x = Math.round(newX);
            el.y = Math.round(newY);
            div.style.left = el.x + 'px';
            div.style.top = el.y + 'px';
            if (selectionToolbar) { selectionToolbar.update(el); }

            if (multiElements.length > 0) {
                multiElements.forEach(function(me) {
                    var elem = slide.elements[me.idx];
                    elem.x = Math.max(0, Math.min(CANVAS_W - me.w, me.origX + deltaX));
                    elem.y = Math.max(0, Math.min(canvasH - me.h, me.origY + deltaY));
                });
                render();
            }

            state.markDirty();
        }

        function onUp(ev) {
            if (ev && ev.pointerId !== activeId) { return; }
            document.removeEventListener('pointermove', onMove);
            document.removeEventListener('pointerup', onUp);
            document.removeEventListener('pointercancel', onUp);
        }

        document.addEventListener('pointermove', onMove);
        document.addEventListener('pointerup', onUp);
        document.addEventListener('pointercancel', onUp);
    }

    /* ========================================================================
     *  Text editing
     * ======================================================================== */
    function startTextEdit(div, slideIdx, elemIdx) {
        var s = state.get();
        var el = s.slides[slideIdx].elements[elemIdx];
        if (el.type !== 'text') { return; }

        div.contentEditable = 'true';
        div.focus();

        var range = document.createRange();
        range.selectNodeContents(div);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);

        div.addEventListener('blur', function onBlur() {
            div.contentEditable = 'false';
            var newText = div.textContent;
            state.updateElementAtomic(slideIdx, elemIdx, { text: newText });
            div.removeEventListener('blur', onBlur);
        });
    }

    /**
     * Enter edit mode on the currently selected text element, using the LIVE
     * rendered div (not a stale closure reference).
     */
    function startEditingSelected() {
        var s = state.get();
        if (s.selected === null) { return; }
        var el = s.slides[s.current] && s.slides[s.current].elements[s.selected];
        if (!el || el.type !== 'text' || el._locked) { return; }
        var div = canvasEl && canvasEl.querySelector('[data-idx="' + s.selected + '"]');
        if (!div) { return; }
        startTextEdit(div, s.current, s.selected);
    }

    /* ---- register element type --------------------------------------------- */
    function registerType(id, typeModule) {
        types[id] = typeModule;
    }

    /* ---- Drawing mode (pencil tool) ---------------------------------------- */
    function setDrawingMode(enabled) {
        drawingMode = enabled;
        if (canvasEl) {
            canvasEl.style.cursor = enabled ? 'crosshair' : 'default';
        }
    }

    function isDrawingMode() {
        return drawingMode;
    }

    function getCanvasCoords(e) {
        var rect = canvasEl.getBoundingClientRect();
        var scale = CANVAS_W / rect.width;
        return {
            x: Math.round((e.clientX - rect.left) * scale),
            y: Math.round((e.clientY - rect.top) * scale),
        };
    }

    function startDrawing(e) {
        e.preventDefault();
        e.stopPropagation();

        // Keep receiving moves when the pointer leaves the canvas.
        if (canvasEl.setPointerCapture && e.pointerId !== undefined) {
            try { canvasEl.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
        }

        var coords = getCanvasCoords(e);
        drawingPoints = [coords];

        var svgNS = 'http://www.w3.org/2000/svg';
        drawingDiv = document.createElement('div');
        drawingDiv.className = 'editor-element slide-element slide-element--pencil';
        drawingDiv.style.cssText = 'left:' + coords.x + 'px;top:' + coords.y + 'px;width:0;height:0;';

        drawingSvg = document.createElementNS(svgNS, 'svg');
        drawingSvg.setAttribute('width', '100%');
        drawingSvg.setAttribute('height', '100%');
        drawingSvg.setAttribute('viewBox', '0 0 10 10');
        drawingSvg.setAttribute('preserveAspectRatio', 'none');
        drawingSvg.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:visible;';

        var path = document.createElementNS(svgNS, 'path');
        path.setAttribute('d', 'M 0 0');
        path.setAttribute('stroke', pencil.DEFAULTS.stroke);
        path.setAttribute('stroke-width', pencil.DEFAULTS.strokeWidth);
        path.setAttribute('fill', 'none');
        path.setAttribute('stroke-linecap', 'round');
        path.setAttribute('stroke-linejoin', 'round');
        drawingSvg.appendChild(path);

        drawingDiv.appendChild(drawingSvg);
        canvasEl.appendChild(drawingDiv);
    }

    function continueDrawing(e) {
        e.preventDefault();
        var coords = getCanvasCoords(e);
        drawingPoints.push(coords);

        var bounds = pencil.computeBounds(drawingPoints);
        var w = Math.max(1, bounds.maxX - bounds.minX);
        var h = Math.max(1, bounds.maxY - bounds.minY);

        drawingDiv.style.left = bounds.minX + 'px';
        drawingDiv.style.top = bounds.minY + 'px';
        drawingDiv.style.width = w + 'px';
        drawingDiv.style.height = h + 'px';

        drawingSvg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);

        var relPoints = drawingPoints.map(function(p) {
            return { x: p.x - bounds.minX, y: p.y - bounds.minY };
        });

        var pathData = 'M ' + relPoints[0].x + ' ' + relPoints[0].y;
        for (var i = 1; i < relPoints.length; i++) {
            pathData += ' L ' + relPoints[i].x + ' ' + relPoints[i].y;
        }
        drawingSvg.querySelector('path').setAttribute('d', pathData);
    }

    function finishDrawing() {
        if (drawingPoints.length < 2) {
            if (drawingDiv && drawingDiv.parentNode) {
                drawingDiv.parentNode.removeChild(drawingDiv);
            }
            drawingPoints = [];
            drawingDiv = null;
            drawingSvg = null;
            return;
        }

        var bounds = pencil.computeBounds(drawingPoints);
        var normalized = pencil.normalizePoints(drawingPoints);

        var element = Object.assign({}, pencil.DEFAULTS, {
            x: bounds.minX,
            y: bounds.minY,
            w: Math.max(1, bounds.maxX - bounds.minX),
            h: Math.max(1, bounds.maxY - bounds.minY),
            points: normalized,
        });

        var s = state.get();
        state.addElement(s.current, element);

        drawingPoints = [];
        drawingDiv = null;
        drawingSvg = null;
    }

    return {
        init: init,
        render: render,
        registerType: registerType,
        setDrawingMode: setDrawingMode,
        isDrawingMode: isDrawingMode,
        setEmptyImagePicker: setEmptyImagePicker,
        setSelectionToolbar: setSelectionToolbar,
        setEquationEditor: setEquationEditor,
        setHtmlEditor: setHtmlEditor,
        setScaler: setScaler,
        startCrop: startCrop,
        cancelCrop: cancelCrop,
        startEditingSelected: startEditingSelected,
    };
});
