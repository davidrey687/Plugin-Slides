/**
 * Toolbar for the slides editor — grouped actions with labels + SVG icons.
 *
 * @module     mod_slides/editorToolbar
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState'], function(state) {
    'use strict';

    var actions = {};

    function registerAction(id, cfg) {
        actions[id] = {
            id: id,
            label: cfg.label || id,
            svg: cfg.svg || '',
            handler: cfg.handler || function() {},
            priority: cfg.priority || 100,
            type: cfg.type || 'button',
            group: cfg.group || 'default',
            isActive: typeof cfg.isActive === 'function' ? cfg.isActive : null,
        };
    }

    function render(container) {
        var sorted = Object.values(actions).sort(function(a, b) {
            return a.priority - b.priority;
        });

        // Group actions by group
        var groups = {};
        sorted.forEach(function(action) {
            if (!groups[action.group]) { groups[action.group] = []; }
            groups[action.group].push(action);
        });

        container.innerHTML = '';

        Object.keys(groups).forEach(function(groupName) {
            var groupActions = groups[groupName];
            var wrapper = document.createElement('div');
            wrapper.className = 'toolbar-group';

            var btns = document.createElement('div');
            btns.className = 'toolbar-group-btns';

            groupActions.forEach(function(action) {
                if (action.type === 'separator') {
                    var sep = document.createElement('span');
                    sep.className = 'toolbar-sep';
                    sep.setAttribute('aria-hidden', 'true');
                    btns.appendChild(sep);
                    return;
                }

                var btn = document.createElement('button');
                btn.className = 'btn btn-sm toolbar-btn';
                btn.dataset.action = action.id;
                btn.title = action.label;
                if (action.isActive) {
                    btn.setAttribute('aria-pressed', 'false');
                }

                if (action.svg) {
                    btn.innerHTML = action.svg;
                } else {
                    btn.textContent = action.label;
                }

                btn.addEventListener('click', function(e) { action.handler(e); });
                btns.appendChild(btn);
            });

            wrapper.appendChild(btns);

            if (groupName !== 'default') {
                var label = document.createElement('div');
                label.className = 'toolbar-group-label';
                label.textContent = groupName;
                wrapper.appendChild(label);
            }

            container.appendChild(wrapper);
        });
    }

    function updateStates() {
        var s = state.get();
        document.querySelectorAll('.toolbar-btn').forEach(function(btn) {
            var id = btn.dataset.action;
            var action = actions[id];
            if (id === 'undo') { btn.disabled = !state.canUndo(); }
            if (id === 'redo') { btn.disabled = !state.canRedo(); }
            if (id === 'delete') {
                // Enabled if: element selected (delete element) OR slides > 1 (delete slide)
                var hasElement = (s.selected !== null);
                var canDeleteSlide = (s.slides.length > 1);
                btn.disabled = !hasElement && !canDeleteSlide;
            }
            if (action && action.isActive) {
                var active = !btn.disabled && action.isActive();
                btn.classList.toggle('is-active', active);
                btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            }
        });
    }

    return {
        register: registerAction,
        render: render,
        updateStates: updateStates,
    };
});
