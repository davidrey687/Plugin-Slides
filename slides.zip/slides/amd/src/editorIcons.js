/**
 * Central icon catalogue for the slides editor.
 * Grid 24×24, stroke 1.75, round caps/joins, currentColor.
 *
 * @module     mod_slides/editorIcons
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var PATHS = {
        /* Clipboard */
        cut: '<circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.5 16.5 18 4"/><path d="M15.5 16.5 6 4"/>',
        copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M4 16H3a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v1"/>',
        paste: '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M9 12h6"/><path d="M9 16h4"/>',

        /* Slides */
        newslide: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M12 8v8"/><path d="M8 12h8"/>',
        duplicate: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M4 16H3a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v1"/><path d="M14.5 14.5h4"/><path d="M16.5 12.5v4"/>',
        importslides: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M12 17v4"/><path d="M8 21h8"/><path d="M12 7v5"/><path d="m9.5 9.5 2.5 2.5 2.5-2.5"/>',
        trash: '<path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>',

        /* Insert */
        text: '<path d="M4 7V4h16v3"/><path d="M12 4v16"/><path d="M9 20h6"/>',
        image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>',
        video: '<path d="m22 8-6 4 6 4V8Z"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
        mic: '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3"/>',
        audio: '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3"/>',
        shape: '<rect x="3" y="3" width="11" height="11" rx="1.5"/><circle cx="16" cy="16" r="5"/>',
        pencil: '<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
        rline: '<path d="M7 17 17 7"/><path d="M9 7h8v8"/>',
        link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
        pdf: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 7h10"/><path d="M12 7v10"/><path d="M7 14h10"/><path d="M9 17h6"/><path d="M9 11h6"/>',
        code: '<path d="m8 6-6 6 6 6"/><path d="m16 6 6 6-6 6"/>',
        sparkles: '<path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6Z"/><path d="M19 14l.7 2.3L22 17l-2.3.7L19 20l-.7-2.3L16 17l2.3-.7Z"/><path d="M5 15l.5 1.5L7 17l-1.5.5L5 19l-.5-1.5L3 17l1.5-.5Z"/>',

        /* Z-order */
        bringfront: '<rect x="3" y="3" width="13" height="13" rx="2"/><rect x="8" y="8" width="13" height="13" rx="2" fill="currentColor" fill-opacity="0.22"/><path d="M14.5 14.5 21 8"/><path d="M15 8h6v6"/>',
        sendback: '<rect x="8" y="8" width="13" height="13" rx="2"/><rect x="3" y="3" width="13" height="13" rx="2" fill="currentColor" fill-opacity="0.22"/><path d="M14.5 14.5 8 21"/><path d="M9 21H3v-6"/>',
        bringforward: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M12 8V3"/><path d="M8.5 6.5 12 3l3.5 3.5"/>',
        sendbackward: '<rect x="4" y="3" width="16" height="10" rx="2"/><path d="M12 16v5"/><path d="M8.5 17.5 12 21l3.5-3.5"/>',

        /* Design */
        templates: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 9v12"/>',
        grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        background: '<path d="M12 3a9 9 0 0 0 0 18h1.5a1.5 1.5 0 0 0 0-3H12a2 2 0 0 1 0-4h2.6A6.5 6.5 0 0 0 21 7.5C21 5 17 3 12 3z"/><circle cx="7.5" cy="10.5" r="1" fill="currentColor" stroke="none"/><circle cx="12" cy="7.5" r="1" fill="currentColor" stroke="none"/><circle cx="16.5" cy="10.5" r="1" fill="currentColor" stroke="none"/>',

        /* History / document */
        undo: '<path d="M3 10h11a5 5 0 0 1 0 10h-3"/><path d="m7 6-4 4 4 4"/>',
        redo: '<path d="M21 10H10a5 5 0 0 0 0 10h3"/><path d="m17 6 4 4-4 4"/>',
        save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/>',

        /* Playback / export */
        play: '<path d="M7 4.5v15l13-7.5z" fill="currentColor" stroke="currentColor" stroke-linejoin="round"/>',
        present: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4"/><path d="M8 21h8"/><path d="M10 8.5v5l4.5-2.5z" fill="currentColor" stroke="none"/>',
        exportpdf: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 21h16"/>',
        footer: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 15h18"/><path d="M7 18h4"/>',
        chart: '<path d="M4 20V4"/><path d="M4 20h16"/><rect x="7" y="12" width="3" height="8" rx="1"/><rect x="12" y="7" width="3" height="13" rx="1"/><rect x="17" y="14" width="3" height="6" rx="1"/>',
        equation: '<path d="M4 5h4l3 14h5"/><path d="M14 10.5c0-1.4 1.1-2.5 2.5-2.5S19 9.1 19 10.5c0 1.7-3 2.8-3 5.5h3"/><path d="M6.5 8.5h4"/>',

        /* Text formatting (alignment / lists) */
        'align-left': '<path d="M4 6h16"/><path d="M4 12h10"/><path d="M4 18h14"/>',
        'align-center': '<path d="M6 6h12"/><path d="M4 12h16"/><path d="M7 18h10"/>',
        'align-right': '<path d="M4 6h16"/><path d="M10 12h10"/><path d="M6 18h14"/>',
        'align-justify': '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
        'list-none': '<path d="M4 6h16"/><path d="M4 12h9"/><path d="M4 18h13"/>',
        'list-bullet': '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
        'list-number': '<path d="M10 6h11"/><path d="M10 12h11"/><path d="M10 18h11"/><path d="M4 6h1v4"/><path d="M4 10h2"/><path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>',

        /* Layers */
        'eye-open': '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'eye-closed': '<path d="M2 12s3.5-7 10-7c1.7 0 3.2.5 4.5 1.2"/><path d="M20.8 9.2c.7 1 1.2 2 1.2 2.8s-3.5 7-10 7c-1.3 0-2.5-.3-3.5-.7"/><path d="m3 3 18 18"/>',
        'lock-open': '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/>',
        'lock-closed': '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/><circle cx="12" cy="16" r="1.2" fill="currentColor" stroke="none"/>',

        /* Transitions */
        'transition-none': '<path d="M6 6l12 12"/><path d="M18 6 6 18"/>',
        'transition-fade': '<circle cx="12" cy="12" r="9" opacity="0.35"/><circle cx="12" cy="12" r="5.5" opacity="0.65"/><circle cx="12" cy="12" r="2" fill="currentColor" stroke="none"/>',
        'transition-push': '<rect x="2" y="6" width="10" height="12" rx="2" opacity="0.35"/><rect x="12" y="6" width="10" height="12" rx="2"/><path d="M17 12h5"/><path d="m19 9 3 3-3 3"/>',
        'transition-slide-left': '<rect x="12" y="6" width="10" height="12" rx="2" opacity="0.35"/><rect x="2" y="6" width="10" height="12" rx="2"/><path d="M7 12H2"/><path d="m5 9-3 3 3 3"/>',
        'transition-slide-up': '<rect x="6" y="12" width="12" height="10" rx="2" opacity="0.35"/><rect x="6" y="2" width="12" height="10" rx="2"/><path d="M12 7V2"/><path d="m9 5 3-3 3 3"/>',
        'transition-slide-down': '<rect x="6" y="2" width="12" height="10" rx="2" opacity="0.35"/><rect x="6" y="12" width="12" height="10" rx="2"/><path d="M12 17v5"/><path d="m9 19 3 3 3-3"/>',
        'transition-zoom': '<circle cx="11" cy="11" r="7" opacity="0.4"/><circle cx="11" cy="11" r="3.5"/><path d="m20 20-4-4"/><path d="M11 8v6"/><path d="M8 11h6"/>',
        'transition-flip': '<path d="M12 3v18"/><path d="M8 7 4 12l4 5"/><path d="m16 7 4 5-4 5"/><path d="M4 12h4"/><path d="M16 12h4"/>',
        'transition-reveal': '<rect x="2" y="4" width="20" height="16" rx="2" opacity="0.35"/><path d="M2 4h8v16H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M10 12h10"/><path d="m17 9 3 3-3 3"/>',
        'transition-cube': '<path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
        'transition-cut': '<circle cx="12" cy="12" r="9"/><path d="M6 6l12 12"/><path d="M18 6 6 18"/>',
        'transition-transform': '<path d="M21 8V4h-4"/><path d="M20 4 12 12"/><path d="M3 16v4h4"/><path d="M4 20l8-8"/><path d="M14 20h6v-6"/><path d="M20 20 14 14"/>',

        /* Panel / chrome */
        collapse: '<path d="M10 6l6 6-6 6"/><path d="M5 5v14"/>',
        expand: '<path d="M14 6l-6 6 6 6"/><path d="M19 5v14"/>',
        plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
        'chevron-down': '<path d="m6 9 6 6 6-6"/>',
        'chevron-left': '<path d="m15 6-6 6 6 6"/>',
        'chevron-right': '<path d="m9 6 6 6-6 6"/>',
        file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',

        /* Viewer */
        fullscreen: '<path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/>',
        page: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
    };

    /**
     * Build an inline SVG string for an icon.
     *
     * @param {String} name path key
     * @param {Object} [opts] {size: Number, cls: String}
     * @return {String} SVG markup or '' if unknown
     */
    function get(name, opts) {
        opts = opts || {};
        var body = PATHS[name];
        if (!body) {
            return '';
        }
        var size = opts.size || 20;
        var cls = opts.cls ? ' class="' + opts.cls + '"' : '';
        return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" ' +
            'fill="none" stroke="currentColor" stroke-width="1.75" ' +
            'stroke-linecap="round" stroke-linejoin="round" ' +
            'aria-hidden="true" focusable="false"' + cls + '>' + body + '</svg>';
    }

    return {
        get: get,
        PATHS: PATHS,
    };
});
