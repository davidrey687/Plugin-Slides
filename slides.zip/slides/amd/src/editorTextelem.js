/**
 * Text element type — registered with the editor canvas.
 *
 * @module     mod_slides/editorTextelem
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(function() {
    'use strict';

    var TYPE = 'text';

    var FONT_FAMILIES = [
        { value: 'sans-serif',                labelKey: 'font-sans-serif', fallback: 'Sans-serif', cat: 'system-sans' },
        { value: 'Arial, sans-serif',         label: 'Arial',              cat: 'system-sans' },
        { value: '"Arial Black", sans-serif', label: 'Arial Black',        cat: 'system-sans' },
        { value: '"Calibri", sans-serif',     label: 'Calibri',            cat: 'system-sans' },
        { value: 'Candara, sans-serif',       label: 'Candara',            cat: 'system-sans' },
        { value: 'Corbel, sans-serif',        label: 'Corbel',             cat: 'system-sans' },
        { value: '"Century Gothic", sans-serif', label: 'Century Gothic',  cat: 'system-sans' },
        { value: '"Segoe UI", sans-serif',    label: 'Segoe UI',           cat: 'system-sans' },
        { value: 'Tahoma, sans-serif',        label: 'Tahoma',             cat: 'system-sans' },
        { value: '"Trebuchet MS", sans-serif', label: 'Trebuchet MS',      cat: 'system-sans' },
        { value: 'Verdana, sans-serif',       label: 'Verdana',            cat: 'system-sans' },
        { value: '"Franklin Gothic Book", sans-serif', label: 'Franklin Gothic Book', cat: 'system-sans' },
        { value: '"Gill Sans MT", sans-serif', label: 'Gill Sans MT',      cat: 'system-sans' },
        { value: '"Lucida Sans", sans-serif', label: 'Lucida Sans',        cat: 'system-sans' },
        { value: 'Helvetica, sans-serif',     label: 'Helvetica',          cat: 'system-sans' },
        { value: '"Helvetica Neue", sans-serif', label: 'Helvetica Neue',  cat: 'system-sans' },

        { value: 'Georgia, serif',            label: 'Georgia',            cat: 'system-serif' },
        { value: '"Times New Roman", serif',  label: 'Times New Roman',    cat: 'system-serif' },
        { value: 'Cambria, serif',            label: 'Cambria',            cat: 'system-serif' },
        { value: 'Garamond, serif',           label: 'Garamond',           cat: 'system-serif' },
        { value: '"Book Antiqua", serif',     label: 'Book Antiqua',       cat: 'system-serif' },
        { value: '"Palatino Linotype", serif', label: 'Palatino Linotype', cat: 'system-serif' },
        { value: 'Constantia, serif',         label: 'Constantia',         cat: 'system-serif' },
        { value: '"Century Schoolbook", serif', label: 'Century Schoolbook', cat: 'system-serif' },
        { value: '"Bookman Old Style", serif', label: 'Bookman Old Style', cat: 'system-serif' },

        { value: '"Courier New", monospace',  label: 'Courier New',        cat: 'system-mono' },
        { value: 'Courier, monospace',        label: 'Courier',            cat: 'system-mono' },
        { value: 'Consolas, monospace',       label: 'Consolas',           cat: 'system-mono' },
        { value: '"Lucida Console", monospace', label: 'Lucida Console',   cat: 'system-mono' },
        { value: 'Monaco, monospace',         label: 'Monaco',             cat: 'system-mono' },

        { value: 'Impact, sans-serif',        label: 'Impact',             cat: 'system-decorative' },
        { value: '"Comic Sans MS", cursive',  label: 'Comic Sans MS',      cat: 'system-decorative' },
        { value: 'Copperplate, fantasy',      label: 'Copperplate',        cat: 'system-decorative' },
        { value: '"Brush Script MT", cursive', label: 'Brush Script MT',   cat: 'system-decorative' },

        { value: '"Roboto", sans-serif',      label: 'Roboto',             cat: 'web' },
        { value: '"Open Sans", sans-serif',   label: 'Open Sans',          cat: 'web' },
        { value: '"Lato", sans-serif',        label: 'Lato',               cat: 'web' },
        { value: '"Montserrat", sans-serif',  label: 'Montserrat',         cat: 'web' },
        { value: '"Poppins", sans-serif',     label: 'Poppins',            cat: 'web' },
        { value: '"Oswald", sans-serif',      label: 'Oswald',             cat: 'web' },
        { value: '"Playfair Display", serif', label: 'Playfair Display',   cat: 'web' },
        { value: '"Merriweather", serif',     label: 'Merriweather',       cat: 'web' },
        { value: 'Anton, sans-serif',         label: 'Anton',              cat: 'web' },
        { value: '"Bebas Neue", sans-serif',  label: 'Bebas Neue',         cat: 'web' },
        { value: '"Dancing Script", cursive', label: 'Dancing Script',     cat: 'web' },
        { value: 'Caveat, cursive',           label: 'Caveat',             cat: 'web' },
    ];

    var FONT_SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 44, 48, 54, 60, 66, 72, 80, 88, 96];

    var DEFAULTS = {
        type: TYPE,
        x: 80,
        y: 80,
        w: 400,
        h: 40,
        text: 'Nuevo texto',
        fontfamily: 'sans-serif',
        fontSize: 28,
        color: '#000000',
        highlight: '',
        align: 'left',
        bold: false,
        italic: false,
        underline: false,
        strikethrough: false,
        listType: 'none',
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    function cssClass() {
        return 'slide-element--' + TYPE;
    }

    function inlineStyles(el) {
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var style = 'position:absolute;left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;' +
            'font-size:' + el.fontSize + 'px;color:' + el.color + ';' +
            'text-align:' + el.align + ';' +
            'font-family:' + (el.fontfamily || 'sans-serif') + ';' +
            'opacity:' + opacity + ';' +
            'transform-origin:center center;' +
            (el.bold ? 'font-weight:bold;' : '') +
            (el.italic ? 'font-style:italic;' : '') +
            (el.underline ? 'text-decoration:underline;' : '');

        if (el.strikethrough) {
            style += el.underline
                ? 'text-decoration:underline line-through;'
                : 'text-decoration:line-through;';
        }

        if (el.highlight) {
            style += 'background-color:' + el.highlight + ';padding:2px 4px;border-radius:2px;';
        }

        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }

        return style;
    }

    function renderText(el) {
        var text = el.text || '';

        if (el.listType === 'bullet') {
            var lines = text.split('\n');
            var html = '<ul style="margin:0;padding-left:20px;">';
            lines.forEach(function(line) {
                html += '<li>' + escapeHtml(line) + '</li>';
            });
            html += '</ul>';
            return html;
        }

        if (el.listType === 'number') {
            var lines2 = text.split('\n');
            var html2 = '<ol style="margin:0;padding-left:20px;">';
            lines2.forEach(function(line) {
                html2 += '<li>' + escapeHtml(line) + '</li>';
            });
            html2 += '</ol>';
            return html2;
        }

        return escapeHtml(text);
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function getFontFamilyOptions() {
        return FONT_FAMILIES.map(function(f) {
            var label;
            if (f.labelKey) {
                try {
                    label = M.util.get_string(f.labelKey, 'mod_slides');
                } catch (e) {
                    label = f.fallback || f.labelKey;
                }
            } else {
                label = f.label;
            }
            return { value: f.value, label: label, cat: f.cat };
        });
    }

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        cssClass: cssClass,
        inlineStyles: inlineStyles,
        renderText: renderText,
        getFontFamilyOptions: getFontFamilyOptions,
        FONT_SIZES: FONT_SIZES,

        PROPERTY_DEFS: [
            { key: 'fontfamily',  label: 'font-family',  control: 'select', options: [], applyfontafter: true },
            { key: 'fontSize',    label: 'font-size',     control: 'fontsize' },
            { key: 'color',       label: 'color',         control: 'color' },
            { key: 'highlight',   label: 'highlight',     control: 'color', clearable: true },
            { key: 'align',       label: 'alignment',     control: 'iconselect', options: [
                { value: 'left',    icon: 'align-left',    labelKey: 'left',    fallback: 'Left' },
                { value: 'center',  icon: 'align-center',  labelKey: 'center',  fallback: 'Center' },
                { value: 'right',   icon: 'align-right',   labelKey: 'right',   fallback: 'Right' },
                { value: 'justify', icon: 'align-justify', labelKey: 'justify', fallback: 'Justify' },
            ]},
            { key: 'listType',    label: 'list-bullet',   control: 'iconselect', options: [
                { value: 'none',   icon: 'list-none',   labelKey: 'list-none',   fallback: 'None' },
                { value: 'bullet', icon: 'list-bullet', labelKey: 'list-bullet', fallback: 'Bullets' },
                { value: 'number', icon: 'list-number', labelKey: 'list-number', fallback: 'Numbering' },
            ]},
            { key: 'opacity',        label: 'opacity',        control: 'number', min: 0, max: 100, step: 5 },
            { key: 'bold',          label: 'bold',          control: 'checkbox' },
            { key: 'italic',        label: 'italic',        control: 'checkbox' },
            { key: 'underline',     label: 'underline',     control: 'checkbox' },
            { key: 'strikethrough', label: 'strikethrough', control: 'checkbox' },
            { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
            { key: 'shadowColor',   label: 'shadow-color',  control: 'color' },
            { key: 'shadowBlur',    label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
            { key: 'shadowX',       label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
            { key: 'shadowY',       label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
        ],
    };
});
