/**
 * PDF Resource element type — attached from the editor modal (file picker or
 * drag & drop), stored in the Moodle File API (slides_pdf area) and opened in
 * a new browser tab when clicked during presentation.
 *
 * @module     mod_slides/editorPdf
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorIcons'], function(icons) {
    'use strict';

    var TYPE = 'pdf';

    var DEFAULTS = {
        type: TYPE,
        x: 100,
        y: 100,
        w: 280,
        h: 180,
        src: '',
        pdftitle: '',
        alt: '',
        opacity: 100,
        borderRadius: 8,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    /**
     * Outer wrapper style — carries the real pixel geometry so the canvas
     * resize handles (x/y/w/h) and drag work exactly like any other element.
     */
    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h +
            'px;position:absolute;overflow:hidden;box-sizing:border-box;';
    }

    /**
     * Inner card style — fills 100% of the outer wrapper.
     */
    function innerStyle(el) {
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var br = el.borderRadius || 0;
        var shadow = '';
        if (el.shadowEnabled) {
            shadow = 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return 'display:flex;flex-direction:column;align-items:center;justify-content:center;' +
            'width:100%;height:100%;box-sizing:border-box;overflow:hidden;cursor:pointer;' +
            'background:#f8f9fa;border:2px dashed #dee2e6;border-radius:' + br + 'px;' +
            'opacity:' + opacity + ';' + shadow;
    }

    /**
     * PDF preview card: fallback layer (icon + title, also visible while the
     * PDF loads) with an embedded iframe on top. The iframe has
     * pointer-events:none so drag/resize/selection keep working in the editor.
     */
    function renderPdf(el) {
        var card = document.createElement('div');
        card.className = 'pdf-card';
        card.style.cssText = 'position:relative;' + innerStyle(el);
        card.setAttribute('data-pdf-preview', 'true');

        var iconDiv = document.createElement('div');
        iconDiv.style.cssText = 'margin-bottom:8px;color:#dc3545;pointer-events:none;';
        iconDiv.innerHTML = icons.get('pdf', {size: 48});
        card.appendChild(iconDiv);

        var titleDiv = document.createElement('div');
        titleDiv.style.cssText = 'font-size:12px;color:#495057;text-align:center;padding:0 8px;' +
            'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;pointer-events:none;';
        titleDiv.textContent = el.pdftitle || el.alt || 'PDF';
        card.appendChild(titleDiv);

        if (el.src) {
            var iframe = document.createElement('iframe');
            var hash = el.src.indexOf('#') >= 0 ? '&' : '#';
            iframe.src = el.src + hash + 'toolbar=0&navpanes=0&view=FitH';
            iframe.title = el.pdftitle || el.alt || 'PDF';
            iframe.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;' +
                'border:none;background:transparent;pointer-events:none;';
            card.appendChild(iframe);
        }

        return card;
    }

    var PROPERTY_DEFS = [
        { key: 'pdftitle',      label: 'pdftitle',     control: 'text' },
        { key: 'alt',           label: 'pdfalt',       control: 'text' },
        { key: 'opacity',       label: 'opacity',      control: 'number', min: 0, max: 100, step: 5 },
        { key: 'borderRadius',  label: 'borderradius', control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color', control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',  control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',     control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',     control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        innerStyle: innerStyle,
        renderPdf: renderPdf,
        PROPERTY_DEFS: PROPERTY_DEFS,
    };
});
