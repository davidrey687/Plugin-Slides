/**
 * Link element type — clickable URL button.
 *
 * @module     mod_slides/editorLink
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var TYPE = 'link';

    var DEFAULTS = {
        type: TYPE,
        x: 360,
        y: 252,
        w: 240,
        h: 36,
        text: '',
        url: '',
        target: '_blank',
        fontfamily: 'sans-serif',
        fontSize: 16,
        color: '#0d6efd',
        background: '#e7f1ff',
        align: 'center',
        bold: true,
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    /**
     * Visual styles only — no width/height so it can be combined with
     * outerStyle (px dimensions) without the later width:100% overriding it.
     */
    function visualCss(el) {
        var bg = el.background || '#e7f1ff';
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var align = el.align || 'center';
        var justify = align === 'left' ? 'flex-start' : (align === 'right' ? 'flex-end' : 'center');
        var style = 'background:' + bg +
            ';display:flex;align-items:center;justify-content:' + justify + ';' +
            'font-size:' + (el.fontSize || 16) + 'px;color:' + (el.color || '#0d6efd') + ';' +
            'font-family:' + (el.fontfamily || 'sans-serif') + ';' +
            'opacity:' + opacity + ';border-radius:6px;' +
            'text-decoration:underline;box-sizing:border-box;overflow:hidden;' +
            'white-space:nowrap;text-overflow:ellipsis;' +
            (el.bold ? 'font-weight:bold;' : '');
        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return style;
    }

    function outerStyle(el) {
        return 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;' +
            'position:absolute;overflow:hidden;box-sizing:border-box;';
    }

    /**
     * Self-contained styles for the editor canvas: px dimensions from
     * outerStyle + visuals from visualCss. Never includes width/height:100%.
     */
    function inlineStyles(el) {
        return outerStyle(el) + visualCss(el);
    }

    function renderText(el) {
        var text = el.text || '';
        if (!text) {
            text = el.url || '';
        }
        return escapeHtml(text);
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    var PROPERTY_DEFS = [
        { key: 'url',          label: 'linkurl',      control: 'text' },
        { key: 'text',         label: 'linkname',     control: 'text' },
        { key: 'target',       label: 'linktarget',   control: 'select', options: [
            { value: '_blank', labelKey: 'linknewtab',  fallback: 'New tab' },
            { value: '_self',  labelKey: 'linksametab', fallback: 'Same tab' },
        ]},
        { key: 'fontfamily',   label: 'font-family',  control: 'select', options: [] },
        { key: 'fontSize',     label: 'font-size',    control: 'number', min: 8, max: 72, step: 1 },
        { key: 'color',        label: 'color',        control: 'color' },
        { key: 'background',   label: 'fill',         control: 'color' },
        { key: 'align',        label: 'alignment',    control: 'iconselect', options: [
            { value: 'left',   icon: 'align-left',   labelKey: 'left',   fallback: 'Left' },
            { value: 'center', icon: 'align-center', labelKey: 'center', fallback: 'Center' },
            { value: 'right',  icon: 'align-right',  labelKey: 'right',  fallback: 'Right' },
        ]},
        { key: 'opacity',        label: 'opacity',        control: 'number', min: 0, max: 100, step: 5 },
        { key: 'bold',          label: 'bold',          control: 'checkbox' },
        { key: 'shadowEnabled', label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',   label: 'shadow-color',  control: 'color' },
        { key: 'shadowBlur',    label: 'shadow-blur',   control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',       label: 'shadow-x',      control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',       label: 'shadow-y',      control: 'number', min: -20, max: 20, step: 1 },
    ];

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        outerStyle: outerStyle,
        inlineStyles: inlineStyles,
        renderText: renderText,
        PROPERTY_DEFS: PROPERTY_DEFS,
    };
});
