/**
 * PPTX → editable slides importer (native objects).
 *
 * Unzips the .pptx package with JSZip, walks every slide's spTree and
 * rebuilds its shapes, text boxes and images as first-class slide elements:
 *
 *   - p:sp  → text element (editable) and/or shape element (fill/stroke)
 *   - p:pic → image element; the binary is pulled from /ppt/media and
 *             uploaded through the caller-provided opts.upload() so the
 *             src is a real pluginfile URL (the DB never stores data URLs)
 *   - p:cxnSp → shape 'line' with the connector angle
 *   - p:grpSp → recursed with the group transform stack (translate + scale)
 *   - p:graphicFrame (tables/charts/SmartArt) → skipped in v1, by design
 *
 * Geometry: PowerPoint EMU are mapped with independent X/Y factors onto the
 * stage units (960×540 / 960×720), matching the deck canvas. Placeholder
 * geometry (p:ph) is resolved through the slide → layout → master chain,
 * because real decks position title/body boxes in the master, not the slide.
 *
 * Rotation (p:spPr/a:xfrm@rot) is ignored: the editor has no persisted
 * rotation field yet.
 *
 * @module     mod_slides/pptx_importer
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    var zipPromise = null;

    var REL_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';

    var IMAGE_EXT = {
        png: 'image/png',
        jpg: 'image/jpeg',
        jpeg: 'image/jpeg',
        gif: 'image/gif',
        webp: 'image/webp',
        bmp: 'image/bmp',
        // Rasterised to PNG client-side before upload (see svgToPng).
        svg: 'image/svg+xml',
    };

    function str(key, param) {
        try { return M.util.get_string(key, 'mod_slides', param); } catch (e) { return key; }
    }

    /* ======================================================================
     *  JSZip loader (local vendor copy, script-tag fallback to fetch+eval)
     * ====================================================================== */

    function baseUrl() {
        var root = (typeof M !== 'undefined' && M.cfg && M.cfg.wwwroot) ? M.cfg.wwwroot : '';
        return root + '/mod/slides/vendor/jszip';
    }

    function candidateBases() {
        var out = [];
        var push = function(url) {
            if (url && out.indexOf(url) === -1) { out.push(url); }
        };
        push(baseUrl());
        try {
            var base = new URL(document.baseURI);
            base.search = '';
            base.hash = '';
            base.pathname = base.pathname.replace(/\/[^\/]*$/, '/vendor/jszip/');
            push(base.href.replace(/\/$/, ''));
        } catch (e) { /* URL unsupported: keep the other candidates. */ }
        push('/mod/slides/vendor/jszip');
        return out;
    }

    /**
     * Run a classic (UMD) bundle in global scope while RequireJS's `define`
     * (plus Node's module/exports shims, which JSZip checks first) are
     * briefly hidden, so the UMD wrapper takes the plain-browser branch and
     * exposes `window.JSZip`.
     *
     * @param {String} code Bundle source.
     */
    function runGlobal(code) {
        var hadDefine = 'define' in window;
        var savedDefine = window.define;
        var hadModule = 'module' in window;
        var savedModule = window.module;
        var hadExports = 'exports' in window;
        var savedExports = window.exports;
        try {
            if (hadDefine) { window.define = undefined; }
            if (hadModule) { window.module = undefined; }
            if (hadExports) { window.exports = undefined; }
            (0, eval)(code); // eslint-disable-line no-eval
        } finally {
            if (hadDefine) { window.define = savedDefine; }
            if (hadModule) { window.module = savedModule; }
            if (hadExports) { window.exports = savedExports; }
        }
    }

    function loadJszip() {
        if (window.JSZip) { return Promise.resolve(window.JSZip); }
        if (zipPromise) { return zipPromise; }

        zipPromise = new Promise(function(resolve, reject) {
            var bases = candidateBases();
            var i = 0;

            function attempt() {
                if (i >= bases.length) {
                    zipPromise = null;
                    reject(new Error('jszip-load-failed'));
                    return;
                }
                var base = bases[i++];
                var url = base + '/jszip.min.js';

                if (typeof fetch !== 'function') {
                    attemptScriptTag(base, resolve, reject);
                    return;
                }
                fetch(url, { credentials: 'same-origin' })
                    .then(function(res) {
                        if (!res.ok) { throw new Error('http ' + res.status); }
                        return res.text();
                    })
                    .then(function(code) {
                        runGlobal(code);
                        if (window.JSZip) { resolve(window.JSZip); } else { attempt(); }
                    })
                    .catch(function() {
                        attemptScriptTag(base, resolve, reject);
                    });
            }

            function attemptScriptTag(base, res, rej) {
                var savedDefine = window.define;
                var hadDefine = 'define' in window;
                var hadModule = 'module' in window;
                var savedModule = window.module;
                var hadExports = 'exports' in window;
                var savedExports = window.exports;
                var restored = false;
                var restore = function() {
                    if (restored) { return; }
                    restored = true;
                    if (hadDefine) { window.define = savedDefine; }
                    if (hadModule) { window.module = savedModule; }
                    if (hadExports) { window.exports = savedExports; }
                };
                var script = document.createElement('script');
                script.src = base + '/jszip.min.js';
                script.async = true;
                script.onload = function() {
                    restore();
                    if (window.JSZip) { resolve(window.JSZip); } else { attempt(); }
                };
                script.onerror = function() {
                    restore();
                    attempt();
                };
                if (hadDefine) {
                    try { window.define = undefined; } catch (e) { /* ignore */ }
                }
                if (hadModule) {
                    try { window.module = undefined; } catch (e) { /* ignore */ }
                }
                if (hadExports) {
                    try { window.exports = undefined; } catch (e) { /* ignore */ }
                }
                document.head.appendChild(script);
            }

            attempt();
        });
        return zipPromise;
    }

    /* ======================================================================
     *  Small helpers
     * ====================================================================== */

    function readFile(file) {
        if (file && typeof file.arrayBuffer === 'function') {
            return file.arrayBuffer();
        }
        return new Promise(function(resolve, reject) {
            var reader = new FileReader();
            reader.onload = function() { resolve(reader.result); };
            reader.onerror = function() { reject(reader.error || new Error('read')); };
            reader.readAsArrayBuffer(file);
        });
    }

    function resolvePath(base, target) {
        var parts = base.split('/');
        parts.pop();
        target.split('/').forEach(function(p) {
            if (p === '' || p === '.') { return; }
            if (p === '..') { parts.pop(); return; }
            parts.push(p);
        });
        return parts.join('/');
    }

    function num(v, dflt) {
        var n = Number(v);
        return isFinite(n) ? n : dflt;
    }

    function fileText(zip, path) {
        var entry = zip.file(path);
        if (!entry) { return Promise.resolve(''); }
        return entry.async('string').catch(function() { return ''; });
    }

    /* ---- XML helpers (namespace-agnostic via localName) ---- */

    function parseXml(text) {
        if (!text) { return null; }
        var doc = new DOMParser().parseFromString(text, 'application/xml');
        if (!doc || !doc.documentElement || doc.getElementsByTagName('parsererror').length) {
            return null;
        }
        return doc;
    }

    function els(el, local) {
        if (!el || !el.getElementsByTagNameNS) { return []; }
        return Array.prototype.slice.call(el.getElementsByTagNameNS('*', local));
    }

    function childEl(el, local) {
        if (!el || !el.childNodes) { return null; }
        var list = el.childNodes;
        for (var i = 0; i < list.length; i++) {
            var n = list[i];
            if (n.nodeType === 1 && n.localName === local) { return n; }
        }
        return null;
    }

    function childrenEl(el, local) {
        var out = [];
        if (!el || !el.childNodes) { return out; }
        var list = el.childNodes;
        for (var i = 0; i < list.length; i++) {
            var n = list[i];
            if (n.nodeType === 1 && n.localName === local) { out.push(n); }
        }
        return out;
    }

    function relAttr(el, name) {
        if (!el) { return ''; }
        return el.getAttribute('r:' + name) || el.getAttributeNS(REL_NS, name) || '';
    }

    /* ---- Colours ---- */

    /**
     * Hex colour from a fill container (a:solidFill, a:ln…) or null when it
     * carries no supported colour child.
     */
    function colorOf(fillEl, theme) {
        if (!fillEl) { return null; }
        var srgb = childEl(fillEl, 'srgbClr');
        if (srgb) {
            var v = srgb.getAttribute('val');
            return v ? '#' + v : null;
        }
        var scheme = childEl(fillEl, 'schemeClr');
        if (scheme) {
            var name = scheme.getAttribute('val') || '';
            if (theme && theme[name]) { return theme[name]; }
            if (theme && name === 'phClr') { return theme.accent1 || '#0d6efd'; }
            return null;
        }
        var sys = childEl(fillEl, 'sysClr');
        if (sys) {
            var last = sys.getAttribute('lastClr');
            return last ? '#' + last : null;
        }
        return null;
    }

    /* ---- Fonts ---- */

    /**
     * Map a PPTX a:latin@typeface onto the editor's font list; unknown but
     * safe names pass through so the deck keeps the original typeface.
     */
    function mapFontFamily(typeface) {
        var name = String(typeface || '').replace(/^["']|["']$/g, '').trim();
        if (!name) { return 'Arial, sans-serif'; }
        var hay = name.toLowerCase();

        if (/courier|consolas|mono/.test(hay)) {
            if (/consolas/.test(hay)) { return 'Consolas, monospace'; }
            return '"Courier New", monospace';
        }
        if (/times/.test(hay)) { return '"Times New Roman", serif'; }
        if (/georgia/.test(hay)) { return 'Georgia, serif'; }
        if (/cambria|constantia/.test(hay)) { return 'Cambria, serif'; }
        if (/garamond/.test(hay)) { return 'Garamond, serif'; }
        if (/bookman/.test(hay)) { return '"Bookman Old Style", serif'; }
        if (/palatino|book antiqua/.test(hay)) { return '"Book Antiqua", serif'; }
        if (/arial black/.test(hay)) { return '"Arial Black", sans-serif'; }
        if (/impact/.test(hay)) { return 'Impact, sans-serif'; }
        if (/verdana/.test(hay)) { return 'Verdana, sans-serif'; }
        if (/tahoma/.test(hay)) { return 'Tahoma, sans-serif'; }
        if (/segoe/.test(hay)) { return '"Segoe UI", sans-serif'; }
        if (/calibri/.test(hay)) { return '"Calibri", sans-serif'; }
        if (/candara/.test(hay)) { return 'Candara, sans-serif'; }
        if (/corbel/.test(hay)) { return 'Corbel, sans-serif'; }
        if (/century gothic/.test(hay)) { return '"Century Gothic", sans-serif'; }
        if (/trebuchet/.test(hay)) { return '"Trebuchet MS", sans-serif'; }
        if (/franklin/.test(hay)) { return '"Franklin Gothic Book", sans-serif'; }
        if (/gill sans/.test(hay)) { return '"Gill Sans MT", sans-serif'; }
        if (/helvetica neue/.test(hay)) { return '"Helvetica Neue", sans-serif'; }
        if (/helvetica/.test(hay)) { return 'Helvetica, sans-serif'; }
        if (/arial|sans/.test(hay)) { return 'Arial, sans-serif'; }

        if (/^[\w\u00C0-\u024F .-]{1,40}$/.test(name)) {
            return '"' + name + '", sans-serif';
        }
        return 'Arial, sans-serif';
    }

    /* ---- Shape catalogue mapping (OOXML prst → shapes_library keys) ---- */

    var PRST_MAP = {
        'rect': 'rect',
        'roundRect': 'roundedrect',
        'round1Rect': 'roundedrect',
        'round2SameRect': 'roundedrect',
        'round2DiagonalRect': 'roundedrect',
        'snip1Rect': 'rect',
        'snip2Rect': 'rect',
        'snipRoundRect': 'roundedrect',
        'ellipse': 'ellipse',
        'triangle': 'triangle',
        'rtTriangle': 'triangle',
        'diamond': 'diamond',
        'parallelogram': 'parallelogram',
        'trapezoid': 'trapezoid',
        'pentagon': 'pentagon',
        'hexagon': 'hexagon',
        'heptagon': 'hexagon',
        'octagon': 'octagon',
        'decagon': 'hexagon',
        'dodecagon': 'hexagon',
        'cross': 'cross',
        'heart': 'heart',
        'lightningBolt': 'bolt',
        'cloud': 'cloud',
        'sun': 'star8',
        'star4': 'star4',
        'star5': 'star5',
        'star6': 'star6',
        'star7': 'star8',
        'star8': 'star8',
        'star10': 'star12',
        'star12': 'star12',
        'star16': 'star12',
        'star24': 'star12',
        'star32': 'star12',
        'irregularSeal1': 'star12',
        'irregularSeal2': 'star12',
        'mathPlus': 'eqplus',
        'mathMinus': 'eqminus',
        'mathMultiply': 'eqmultiply',
        'mathDivide': 'eqdivide',
        'mathEqual': 'eqequals',
        'rightArrow': 'arrowright',
        'leftArrow': 'arrowleft',
        'upArrow': 'arrowup',
        'downArrow': 'arrowdown',
        'leftRightArrow': 'arrowright',
        'upDownArrow': 'arrowup',
        'notchedRightArrow': 'arrowright',
        'bentArrow': 'arrowright',
        'uturnArrow': 'arrowright',
        'chevron': 'arrowright',
        'homePlate': 'arrowright',
        'flowChartProcess': 'flowprocess',
        'flowChartAlternateProcess': 'flowprocess',
        'flowChartDecision': 'flowdecision',
        'flowChartTerminator': 'flowterminator',
        'flowChartDocument': 'flowprocess',
        'flowChartMagneticDisk': 'flowprocess',
        'flowChartMagneticDrum': 'flowprocess',
        'flowChartConnector': 'flowterminator',
        'flowChartDelay': 'flowterminator',
        'smileyFace': 'circle',
        'donut': 'circle',
        'pie': 'circle',
        'teardrop': 'droplet',
        'plaque': 'rect',
        'frame': 'rect',
        'halfFrame': 'rect',
        'corner': 'rect',
        'diagStripe': 'rect',
        'cube': 'rect',
        'can': 'rect',
        'bevel': 'rect',
        'foldedCorner': 'rect',
        'blockArc': 'rect',
        'arc': 'rect',
        'moon': 'rect',
        'noSmoking': 'circle',
        'ribbon': 'ribbon',
        'ellipseRibbon': 'ribbon',
        'wedgeRectCallout': 'speechbubble',
        'wedgeRoundRectCallout': 'speechbubble',
        'wedgeEllipseCallout': 'speechbubble',
        'borderCallout1': 'speechbubble',
        'line': 'line',
        'straightConnector1': 'line',
    };

    function mapPrest(prst) {
        if (!prst) { return 'rect'; }
        return PRST_MAP[prst] || 'rect';
    }

    /* ======================================================================
     *  Package reading
     * ====================================================================== */

    function readRels(zip, relsPath) {
        var entry = zip.file(relsPath);
        if (!entry) { return Promise.resolve({}); }
        return entry.async('string').then(function(text) {
            var doc = parseXml(text);
            var map = {};
            if (!doc) { return map; }
            var partBase = relsPath.replace('/_rels/', '/').replace(/\.rels$/, '');
            els(doc, 'Relationship').forEach(function(rel) {
                var id = rel.getAttribute('Id');
                var target = rel.getAttribute('Target');
                if (id && target && target.indexOf('http') !== 0 && target.indexOf('/') !== 0) {
                    // Targets are URI-encoded ('image%201.png'); decode so
                    // zip.file() and the upload filename match the entry.
                    var decoded = target;
                    try { decoded = decodeURIComponent(target); } catch (e) { /* keep raw */ }
                    map[id] = { path: resolvePath(partBase, decoded) };
                }
            });
            return map;
        }).catch(function() { return {}; });
    }

    function findRel(rels, pattern) {
        var out = null;
        Object.keys(rels).forEach(function(id) {
            if (pattern.test(rels[id].path)) { out = rels[id].path; }
        });
        return out;
    }

    function readTheme(zip) {
        return fileText(zip, 'ppt/theme/theme1.xml').then(function(text) {
            var doc = parseXml(text);
            var theme = {};
            if (!doc) { return theme; }
            var scheme = els(doc, 'clrScheme')[0];
            if (!scheme) { return theme; }
            Array.prototype.forEach.call(scheme.childNodes, function(node) {
                if (node.nodeType !== 1) { return; }
                var srgb = childEl(node, 'srgbClr');
                if (srgb && srgb.getAttribute('val')) {
                    theme[node.localName] = '#' + srgb.getAttribute('val');
                    return;
                }
                var sys = childEl(node, 'sysClr');
                if (sys && sys.getAttribute('lastClr')) {
                    theme[node.localName] = '#' + sys.getAttribute('lastClr');
                }
            });
            return theme;
        }).catch(function() { return {}; });
    }

    /**
     * Slide order + source slide size (EMU). Falls back to a numeric sort
     * and the standard 16:9 size when presentation.xml is unavailable.
     *
     * @return {Promise<{paths:String[], sldCx:Number, sldCy:Number,
     *                   unitX:Number, unitY:Number}>}
     */
    function readPresentation(zip, opts) {
        var relsP = readRels(zip, 'ppt/_rels/presentation.xml.rels');
        var presP = fileText(zip, 'ppt/presentation.xml').then(parseXml);

        return Promise.all([relsP, presP]).then(function(all) {
            var rels = all[0];
            var doc = all[1];
            var paths = [];
            var sldCx = 12192000;
            var sldCy = 6858000;

            if (doc) {
                var sldSz = els(doc, 'sldSz')[0];
                if (sldSz) {
                    sldCx = num(sldSz.getAttribute('cx'), sldCx);
                    sldCy = num(sldSz.getAttribute('cy'), sldCy);
                }
                var lst = els(doc, 'sldIdLst')[0];
                if (lst) {
                    childrenEl(lst, 'sldId').forEach(function(idEl) {
                        var rid = relAttr(idEl, 'id');
                        if (rid && rels[rid] && rels[rid].path) { paths.push(rels[rid].path); }
                    });
                }
            }

            if (!paths.length) {
                paths = Object.keys(zip.files).filter(function(name) {
                    return /^ppt\/slides\/slide\d+\.xml$/.test(name);
                }).sort(function(a, b) {
                    return num(a.match(/slide(\d+)/)[1], 0) - num(b.match(/slide(\d+)/)[1], 0);
                });
            }

            if (sldCx <= 0) { sldCx = 12192000; }
            if (sldCy <= 0) { sldCy = 6858000; }

            return {
                paths: paths,
                sldCx: sldCx,
                sldCy: sldCy,
                unitX: opts.canvasW / sldCx,
                unitY: opts.canvasH / sldCy,
            };
        });
    }

    /* ======================================================================
     *  Layout / master resolution (placeholder geometry + default styles)
     * ====================================================================== */

    /**
     * slide → layout → master resolver with per-path caches.
     * `prime(slidePath, slideRels)` must run before walking the slide;
     * `resolver()` then returns the current layout entry (or null).
     */
    function makeLayoutRef(zip) {
        var current = { value: null };
        var layoutCache = {};
        var masterCache = {};

        function loadRels(path) {
            return readRels(zip, path.replace(/\/([^/]+)$/, '/_rels/$1.rels'));
        }

        function prime(slidePath, slideRels) {
            var layoutPath = findRel(slideRels, /slideLayout\d*\.xml$/);
            if (!layoutPath) {
                current.value = null;
                return Promise.resolve();
            }

            var entry = layoutCache[layoutPath];
            if (!entry) {
                entry = {
                    doc: null,
                    rels: {},
                    master: null,
                    masterP: null,
                    masterRef: null,
                };
                entry.masterRef = function() { return entry.master; };
                layoutCache[layoutPath] = entry;
                entry.masterP = Promise.all([
                    fileText(zip, layoutPath),
                    loadRels(layoutPath),
                ]).then(function(all) {
                    entry.doc = parseXml(all[0]);
                    entry.rels = all[1];
                    var masterPath = findRel(entry.rels, /slideMaster\d*\.xml$/);
                    if (!masterPath) { return null; }
                    if (masterCache[masterPath]) {
                        entry.master = masterCache[masterPath];
                        return null;
                    }
                    // Master rels are needed too: the master's p:bg may
                    // carry the inherited background image.
                    return Promise.all([
                        fileText(zip, masterPath),
                        loadRels(masterPath),
                    ]).then(function(all) {
                        var mdoc = parseXml(all[0]);
                        entry.master = masterCache[masterPath] = {
                            doc: mdoc,
                            rels: all[1],
                            styles: readMasterStyles(mdoc),
                        };
                    });
                });
            }
            current.value = entry;
            return entry.masterP;
        }

        var resolver = function() { return current.value; };
        resolver.prime = prime;
        return resolver;
    }

    /**
     * Collect p:txStyles (titleStyle/bodyStyle/otherStyle) from a master.
     * @return {Object|null} map name → element
     */
    function readMasterStyles(masterDoc) {
        if (!masterDoc) { return null; }
        var tx = els(masterDoc, 'txStyles')[0];
        if (!tx) { return null; }
        var styles = {};
        ['titleStyle', 'bodyStyle', 'otherStyle'].forEach(function(name) {
            var node = childEl(tx, name);
            if (node) { styles[name] = node; }
        });
        return styles;
    }

    /**
     * Default run properties (size/colour/font) for a placeholder type,
     * read from the master's p:txStyles/lvl1pPr/a:defRPr.
     */
    function resolveMasterStyle(ctx, phType) {
        var layout = ctx.layoutRef();
        if (!layout) { return null; }
        var master = layout.masterRef ? layout.masterRef() : null;
        if (!master || !master.styles) { return null; }
        var styleName = 'bodyStyle';
        if (phType === 'title' || phType === 'ctrTitle') { styleName = 'titleStyle'; }
        var style = master.styles[styleName];
        if (!style) { return null; }

        var def = childEl(style, 'defRPr');
        if (!def) {
            var lvl = childEl(style, 'lvl1pPr');
            def = lvl ? childEl(lvl, 'defRPr') : null;
        }
        if (!def) { return null; }

        var out = {};
        var sz = def.getAttribute('sz');
        if (sz) { out.sz = num(sz, 0); }
        if (def.getAttribute('b') === '1') { out.bold = true; }
        var fill = childEl(def, 'solidFill');
        if (fill) {
            var hex = colorOf(fill, ctx.theme);
            if (hex) { out.color = hex; }
        }
        var latin = childEl(def, 'latin');
        if (latin && latin.getAttribute('typeface')) {
            out.fontfamily = mapFontFamily(latin.getAttribute('typeface'));
        }
        return out;
    }

    /* ======================================================================
     *  Geometry
     * ====================================================================== */

    /**
     * Read a:xfrm into canvas units through the running group transform.
     * @return {Object|null} {x, y, w, h} stage units
     */
    function xfrmGeom(xfrm, tr, ctx) {
        if (!xfrm) { return null; }
        var off = childEl(xfrm, 'off');
        var ext = childEl(xfrm, 'ext');
        if (!off && !ext) { return null; }
        var ex = num(off ? off.getAttribute('x') : 0, 0);
        var ey = num(off ? off.getAttribute('y') : 0, 0);
        var cx = num(ext ? ext.getAttribute('cx') : 0, 0);
        var cy = num(ext ? ext.getAttribute('cy') : 0, 0);
        return absGeom(ex, ey, cx, cy, tr, ctx);
    }

    /**
     * EMU box → stage units (independent X/Y factors, no letterbox).
     */
    function absGeom(ex, ey, cx, cy, tr, ctx) {
        var x = (tr.tx + ex * tr.sxx) * ctx.unitX;
        var y = (tr.ty + ey * tr.sxy) * ctx.unitY;
        var w = cx * tr.sxx * ctx.unitX;
        var h = cy * tr.sxy * ctx.unitY;
        return {
            x: Math.round(x),
            y: Math.round(y),
            w: Math.max(2, Math.round(w)),
            h: Math.max(2, Math.round(h)),
        };
    }

    /**
     * Compose a child group transform: children live in the chOff/chExt box.
     */
    function groupTransform(xfrm, tr) {
        if (!xfrm) { return tr; }
        var off = childEl(xfrm, 'off');
        var ext = childEl(xfrm, 'ext');
        var chOff = childEl(xfrm, 'chOff');
        var chExt = childEl(xfrm, 'chExt');
        var gx = num(off ? off.getAttribute('x') : 0, 0);
        var gy = num(off ? off.getAttribute('y') : 0, 0);
        var gcx = num(ext ? ext.getAttribute('cx') : 0, 0);
        var gcy = num(ext ? ext.getAttribute('cy') : 0, 0);
        var cx0 = num(chOff ? chOff.getAttribute('x') : 0, 0);
        var cy0 = num(chOff ? chOff.getAttribute('y') : 0, 0);
        var ccx = num(chExt ? chExt.getAttribute('cx') : 0, 0);
        var ccy = num(chExt ? chExt.getAttribute('cy') : 0, 0);
        var kx = (ccx > 0) ? gcx / ccx : 1;
        var ky = (ccy > 0) ? gcy / ccy : 1;
        return {
            tx: tr.tx + (gx - cx0 * kx) * tr.sxx,
            ty: tr.ty + (gy - cy0 * ky) * tr.sxy,
            sxx: tr.sxx * kx,
            sxy: tr.sxy * ky,
        };
    }

    function phInfo(sp) {
        var nv = childEl(sp, 'nvSpPr') || childEl(sp, 'nvPicPr') || childEl(sp, 'nvCxnSpPr') ||
            childEl(sp, 'nvGraphicFramePr') || childEl(sp, 'nvGrpSpPr');
        if (!nv) { return null; }
        var nvPr = childEl(nv, 'nvPr');
        if (!nvPr) { return null; }
        var ph = childEl(nvPr, 'ph');
        if (!ph) { return null; }
        return {
            type: ph.getAttribute('type') || '',
            idx: ph.getAttribute('idx') || '',
        };
    }

    /**
     * Score placeholder matches inside one document: same idx wins, then
     * same type. Layout/master coordinates are slide-space (identity).
     *
     * @return {Object|null} {geom}
     */
    function matchPhInDoc(doc, ph, ctx) {
        if (!doc) { return null; }
        var identity = { tx: 0, ty: 0, sxx: 1, sxy: 1 };
        var bestScore = -1;
        var bestGeom = null;
        els(doc, 'sp').forEach(function(node) {
            var info = phInfo(node);
            if (!info) { return; }
            var score = -1;
            if (ph.idx !== '' && info.idx === ph.idx) { score = 2; }
            else if (ph.idx === '' && info.idx === '' && ph.type && info.type === ph.type) { score = 2; }
            else if (ph.type && info.type === ph.type) { score = 1; }
            else if (!ph.type && !info.type && info.idx === '') { score = 1; }
            if (score > bestScore) {
                var spPr = childEl(node, 'spPr');
                var xfrm = spPr ? childEl(spPr, 'xfrm') : null;
                var geom = xfrmGeom(xfrm, identity, ctx);
                if (geom) {
                    bestScore = score;
                    bestGeom = geom;
                }
            }
        });
        return bestGeom ? { geom: bestGeom } : null;
    }

    /**
     * Geometry of a placeholder by walking slide → layout → master
     * (real decks keep title/body boxes out of the slide XML).
     *
     * @return {Object|null} {x,y,w,h} stage units
     */
    function resolvePhGeom(ph, ctx) {
        var layout = ctx.layoutRef();
        if (!layout) { return null; }
        var hit = matchPhInDoc(layout.doc, ph, ctx);
        if (hit) { return hit.geom; }
        var master = layout.masterRef ? layout.masterRef() : null;
        if (master) {
            var mhit = matchPhInDoc(master.doc, ph, ctx);
            if (mhit) { return mhit.geom; }
        }
        return null;
    }

    /* ======================================================================
     *  Per-slide: fills, lines, text
     * ====================================================================== */

    /**
     * Shape fill colour from p:spPr.
     * @return {String|undefined} '' = explicit no-fill; undefined = not set
     */
    function readShapeFill(spPr, ctx) {
        if (!spPr) { return undefined; }
        if (childEl(spPr, 'noFill')) { return ''; }
        var solid = childEl(spPr, 'solidFill');
        if (solid) { return colorOf(solid, ctx.theme) || '#0d6efd'; }
        var grad = childEl(spPr, 'gradFill');
        if (grad) {
            var stop = els(grad, 'srgbClr')[0];
            if (stop && stop.getAttribute('val')) { return '#' + stop.getAttribute('val'); }
            var scheme = els(grad, 'schemeClr')[0];
            if (scheme && ctx.theme[scheme.getAttribute('val')]) {
                return ctx.theme[scheme.getAttribute('val')];
            }
            return '#0d6efd';
        }
        if (childEl(spPr, 'blipFill') || childEl(spPr, 'pattFill')) { return ''; }
        return undefined;
    }

    /**
     * Line (a:ln) colour + width from p:spPr.
     * @return {{stroke:String, strokeWidth:Number}}
     */
    function readLine(spPr, ctx) {
        var out = { stroke: '#1a1a2e', strokeWidth: 0 };
        if (!spPr) { return out; }
        var ln = childEl(spPr, 'ln');
        if (!ln) { return out; }
        if (childEl(ln, 'noFill')) { out.strokeWidth = 0; return out; }
        var w = ln.getAttribute('w');
        if (w) { out.strokeWidth = Math.max(1, Math.round(num(w, 0) * ctx.unitX)); }
        var solid = childEl(ln, 'solidFill');
        if (solid) {
            out.stroke = colorOf(solid, ctx.theme) || out.stroke;
            if (!out.strokeWidth) { out.strokeWidth = 1; }
        }
        return out;
    }

    /**
     * Parse a p:txBody into a single text-element payload.
     *
     * One element per box: paragraphs joined with \n. First run wins for
     * size/colour/style (mixed run formatting is flattened by design).
     *
     * @return {Object|null} {text, fontSize, color, fontfamily, bold,
     *                        italic, underline, align, listType}
     */
    function parseTxBody(txBody, ctx, ph) {
        if (!txBody) { return null; }
        var paras = childrenEl(txBody, 'p');
        if (!paras.length) { return null; }

        var lines = [];
        var align = 'left';
        var alignSet = false;
        var bullets = [];
        var first = null;
        var maxSz = 0;
        var endSz = 0;

        paras.forEach(function(p) {
            var pPr = childEl(p, 'pPr');
            if (pPr && pPr.getAttribute('algn') && !alignSet) {
                var a = pPr.getAttribute('algn');
                align = (a === 'ctr') ? 'center' : (a === 'r' ? 'right' : 'left');
                alignSet = true;
            }

            var bullet = '';
            if (pPr) {
                var buChar = childEl(pPr, 'buChar');
                if (buChar) { bullet = buChar.getAttribute('char') || '•'; }
                else if (childEl(pPr, 'buAutoNum')) { bullet = 'ordered'; }
            }
            bullets.push(bullet);

            var line = '';
            Array.prototype.forEach.call(p.childNodes, function(node) {
                if (node.nodeType !== 1) { return; }
                if (node.localName === 'r') {
                    var t = childEl(node, 't');
                    line += t ? t.textContent : '';
                    var rPr = childEl(node, 'rPr');
                    if (rPr && !first) { first = rPr; }
                    if (rPr) {
                        var sz = num(rPr.getAttribute('sz'), 0);
                        if (sz > maxSz) { maxSz = sz; }
                    }
                } else if (node.localName === 'br') {
                    line += '\n';
                } else if (node.localName === 'fld') {
                    var ft = childEl(node, 't');
                    line += ft ? ft.textContent : '';
                }
            });

            var endPr = childEl(p, 'endParaRPr');
            if (endPr) {
                var esz = num(endPr.getAttribute('sz'), 0);
                if (esz > endSz) { endSz = esz; }
            }

            lines.push(line);
        });

        var text = lines.join('\n');
        if (!text.trim()) { return null; }

        // Bullets: uniform lists use the renderer's real list; mixed
        // paragraphs get the bullet character prefixed manually.
        var nonEmpty = [];
        lines.forEach(function(l, i) { if (l.trim()) { nonEmpty.push(i); } });
        var allBullet = nonEmpty.length > 0 &&
            nonEmpty.every(function(i) { return bullets[i] && bullets[i] !== 'ordered'; });
        var allOrdered = nonEmpty.length > 0 &&
            nonEmpty.every(function(i) { return bullets[i] === 'ordered'; });
        var listType = 'none';
        if (allBullet) {
            listType = 'bullet';
        } else if (allOrdered) {
            listType = 'ordered';
        } else {
            text = lines.map(function(l, i) {
                var b = bullets[i];
                if (b && b !== 'ordered' && l.trim()) { return b + ' ' + l; }
                return l;
            }).join('\n');
        }

        // Run properties: first run wins; master txStyles then 18pt fallback.
        var fallback = resolveMasterStyle(ctx, ph ? ph.type : '') || {};
        var sz = first ? num(first.getAttribute('sz'), 0) : 0;
        if (!sz) { sz = maxSz || endSz || fallback.sz || 1800; }
        var fontSize = Math.max(6, Math.round((sz / 100) * 12700 * ctx.unitX));

        var color = null;
        if (first) { color = colorOf(childEl(first, 'solidFill'), ctx.theme); }
        if (!color) { color = fallback.color || '#1a1a2e'; }

        var family = fallback.fontfamily || 'Arial, sans-serif';
        if (first) {
            var latin = childEl(first, 'latin');
            if (latin && latin.getAttribute('typeface')) {
                family = mapFontFamily(latin.getAttribute('typeface'));
            }
        }

        return {
            text: text,
            fontSize: fontSize,
            color: color,
            fontfamily: family,
            bold: !!(first && (first.getAttribute('b') === '1' || first.getAttribute('b') === 'true')) ||
                !!fallback.bold,
            italic: !!(first && (first.getAttribute('i') === '1' || first.getAttribute('i') === 'true')),
            underline: !!(first && first.getAttribute('u') && first.getAttribute('u') !== 'none'),
            align: align,
            listType: listType,
        };
    }

    /* ======================================================================
     *  Per-slide: node walkers
     * ====================================================================== */

    function emitShape(shapeKey, geom, fill, line) {
        return {
            type: 'shape',
            shape: shapeKey,
            x: geom.x,
            y: geom.y,
            w: geom.w,
            h: geom.h,
            fill: fill,
            stroke: line.stroke,
            strokeWidth: line.strokeWidth,
            opacity: 100,
            angle: 0,
        };
    }

    function emitText(geom, data) {
        return {
            type: 'text',
            x: geom.x,
            y: geom.y,
            w: geom.w,
            h: geom.h,
            text: data.text,
            fontfamily: data.fontfamily,
            fontSize: data.fontSize,
            color: data.color,
            highlight: '',
            align: data.align,
            bold: data.bold,
            italic: data.italic,
            underline: data.underline,
            strikethrough: false,
            listType: data.listType,
            opacity: 100,
        };
    }

    /* ---- Shared image extraction (p:pic, picture fills, backgrounds) ---- */

    /** Lower-case extension of a zip path ('' when the path has none). */
    function extOf(path) {
        return (path.split('.').pop() || '').toLowerCase();
    }

    /**
     * Resolve an a:blip to a supported media path inside the package.
     * Prefers the raster r:embed (Office writes a PNG fallback next to
     * modern SVGs) and falls back to the a:svgBlip extension.
     *
     * @return {String|null}
     */
    function blipToZipPath(blip, rels) {
        if (!blip || !rels) { return null; }
        var rid = relAttr(blip, 'embed');
        if (rid && rels[rid] && rels[rid].path && IMAGE_EXT[extOf(rels[rid].path)]) {
            return rels[rid].path;
        }
        var exts = els(blip, 'ext');
        for (var i = 0; i < exts.length; i++) {
            var svgBlips = els(exts[i], 'svgBlip');
            if (!svgBlips.length) { continue; }
            var srid = relAttr(svgBlips[0], 'embed');
            if (srid && rels[srid] && rels[srid].path && IMAGE_EXT[extOf(rels[srid].path)]) {
                return rels[srid].path;
            }
        }
        return null;
    }

    /**
     * a:srcRect crop (1000ths of a percent) → 0..1 fractions, or null.
     */
    function readSrcRect(blipFill) {
        var srcRect = blipFill ? childEl(blipFill, 'srcRect') : null;
        if (!srcRect) { return null; }
        var l = num(srcRect.getAttribute('l'), 0);
        var t = num(srcRect.getAttribute('t'), 0);
        var r = num(srcRect.getAttribute('r'), 0);
        var b = num(srcRect.getAttribute('b'), 0);
        if (!(l || t || r || b)) { return null; }
        var cw = 1 - (l + r) / 100000;
        var ch = 1 - (t + b) / 100000;
        if (cw <= 0.01 || ch <= 0.01) { return null; }
        return { x: l / 100000, y: t / 100000, w: cw, h: ch };
    }

    /**
     * Reserve a z-order slot and fill it once the media upload resolves.
     *
     * @param {Object} sizeHint {w, h} display box in canvas units (SVG sizing)
     * @return {Boolean} whether the image was queued
     */
    function pushImageElement(ctx, elements, geom, zipPath, crop, sizeHint) {
        if (!IMAGE_EXT[extOf(zipPath)]) { return false; }
        var slot = elements.length;
        elements.push(null);
        ctx.pending.push(
            uploadZipImage(ctx, zipPath, IMAGE_EXT[extOf(zipPath)], sizeHint).then(function(url) {
                if (!url) { return; }
                var el = {
                    type: 'image',
                    x: geom.x,
                    y: geom.y,
                    w: geom.w,
                    h: geom.h,
                    src: url,
                    alt: '',
                    opacity: 100,
                };
                if (crop) { el.crop = crop; }
                elements[slot] = el;
            })
        );
        return true;
    }

    function handleSp(node, tr, elements, ctx) {
        var spPr = childEl(node, 'spPr');
        var xfrm = spPr ? childEl(spPr, 'xfrm') : null;
        var ph = phInfo(node);
        var geom = xfrmGeom(xfrm, tr, ctx);
        if (!geom && ph) { geom = resolvePhGeom(ph, ctx); }

        var txBody = childEl(node, 'txBody');
        var textData = parseTxBody(txBody, ctx, ph);

        // Picture-filled shape (a:blipFill in spPr): render as an image
        // element — logos are often shapes with a picture fill, not p:pic.
        var picFill = spPr ? childEl(spPr, 'blipFill') : null;
        if (picFill && geom) {
            var fillPath = blipToZipPath(childEl(picFill, 'blip'), ctx.rels);
            if (fillPath) {
                pushImageElement(ctx, elements, geom, fillPath,
                    readSrcRect(picFill), { w: geom.w, h: geom.h });
                if (textData) { elements.push(emitText(geom, textData)); }
                return;
            }
        }

        var fill = readShapeFill(spPr, ctx);
        var line = readLine(spPr, ctx);
        var prstEl = spPr ? childEl(spPr, 'prstGeom') : null;
        var custEl = spPr ? childEl(spPr, 'custGeom') : null;

        var isPlaceholder = !!ph;
        // A p:sp carrying p:txBody is a text box: transparent unless spPr
        // spells out its own colour (a:solidFill / a:gradFill). Theme
        // fillRef defaults are deliberately ignored — they painted every
        // imported text box accent1-blue. Plain shapes keep accent1.
        var isTextBox = !!txBody;
        var fillOut;
        if (fill === '') {
            fillOut = '';
        } else if (fill !== undefined) {
            fillOut = fill;
        } else {
            fillOut = (isPlaceholder || isTextBox) ? '' : (ctx.theme.accent1 || '#0d6efd');
        }

        // Freeform (custGeom) outlines are skipped when they carry no fill —
        // a plain rect border would be wrong; filled customs approximate to
        // their mapped preset.
        var shouldDraw = fillOut !== '' ||
            (line.strokeWidth > 0 && !custEl);

        if (geom && textData) {
            // Draw the backing shape first so the text lands on top.
            if (shouldDraw) {
                elements.push(emitShape(
                    mapPrest(prstEl ? prstEl.getAttribute('prst') : ''),
                    geom, fillOut, line
                ));
            }
            elements.push(emitText(geom, textData));
        } else if (geom && shouldDraw) {
            elements.push(emitShape(
                mapPrest(prstEl ? prstEl.getAttribute('prst') : ''),
                geom, fillOut, line
            ));
        } else if (!geom && textData) {
            // No geometry anywhere: place by placeholder kind so titles and
            // bodies still show up at sane spots.
            var w = ctx.canvasW;
            var h = ctx.canvasH;
            var box = (ph && (ph.type === 'title' || ph.type === 'ctrTitle'))
                ? { x: Math.round(w * 0.05), y: Math.round(h * 0.05), w: Math.round(w * 0.9), h: Math.round(h * 0.16) }
                : { x: Math.round(w * 0.05), y: Math.round(h * 0.28), w: Math.round(w * 0.9), h: Math.round(h * 0.6) };
            elements.push(emitText(box, textData));
        }
    }

    function handlePic(node, tr, elements, ctx) {
        var spPr = childEl(node, 'spPr');
        var xfrm = spPr ? childEl(spPr, 'xfrm') : null;
        var ph = phInfo(node);
        var geom = xfrmGeom(xfrm, tr, ctx);
        if (!geom && ph) { geom = resolvePhGeom(ph, ctx); }
        if (!geom) { return; }

        var blipFill = childEl(node, 'blipFill');
        var zipPath = blipToZipPath(childEl(blipFill, 'blip'), ctx.rels);
        if (!zipPath) { return; }

        pushImageElement(ctx, elements, geom, zipPath,
            readSrcRect(blipFill), { w: geom.w, h: geom.h });
    }

    function handleCxn(node, tr, elements, ctx) {
        var spPr = childEl(node, 'spPr');
        var xfrm = spPr ? childEl(spPr, 'xfrm') : null;
        var geom = xfrmGeom(xfrm, tr, ctx);
        if (!geom) { return; }
        var line = readLine(spPr, ctx);
        if (!line.strokeWidth) { line.strokeWidth = 2; }

        var flipH = xfrm ? xfrm.getAttribute('flipH') === '1' : false;
        var flipV = xfrm ? xfrm.getAttribute('flipV') === '1' : false;

        // The renderer draws a horizontal bar rotated about the centre, so
        // grow the box to the connector's diagonal before rotating it.
        var diag = Math.max(geom.w, Math.sqrt(geom.w * geom.w + geom.h * geom.h));
        var barH = Math.max(4, line.strokeWidth * 2);
        var cx = geom.x + geom.w / 2;
        var cy = geom.y + geom.h / 2;
        var slope = (flipV !== flipH) ? -1 : 1;
        var angle = Math.round(Math.atan2(slope * geom.h, geom.w) * 180 / Math.PI * 10) / 10;

        elements.push({
            type: 'shape',
            shape: 'line',
            x: Math.round(cx - diag / 2),
            y: Math.round(cy - barH / 2),
            w: Math.round(diag),
            h: barH,
            fill: '',
            stroke: line.stroke,
            strokeWidth: line.strokeWidth,
            opacity: 100,
            angle: angle,
        });
    }

    function walk(node, tr, elements, ctx) {
        Array.prototype.forEach.call(node.childNodes, function(n) {
            if (n.nodeType !== 1) { return; }
            switch (n.localName) {
                case 'sp':
                    handleSp(n, tr, elements, ctx);
                    break;
                case 'pic':
                    handlePic(n, tr, elements, ctx);
                    break;
                case 'cxnSp':
                    handleCxn(n, tr, elements, ctx);
                    break;
                case 'grpSp': {
                    var grpPr = childEl(n, 'grpSpPr');
                    var grpXfrm = grpPr ? childEl(grpPr, 'xfrm') : null;
                    walk(n, groupTransform(grpXfrm, tr), elements, ctx);
                    break;
                }
                // graphicFrame (tables/charts/SmartArt) and unknown nodes
                // are skipped in v1 — deliberate scope cut.
                default:
                    break;
            }
        });
    }

    /* ======================================================================
     *  Per-slide: background + assembly
     * ====================================================================== */

    /**
     * Extract a binary from the zip and upload it once per package.
     * SVG is rasterised to PNG first: the media uploader only stores
     * raster formats (any other extension is coerced to .webm server-side).
     *
     * @param {Object} [size] {w, h} target box in canvas units (SVG hint)
     * @return {Promise<String|null>} public URL
     */
    function uploadZipImage(ctx, zipPath, mime, size) {
        if (ctx.imgCache[zipPath]) { return ctx.imgCache[zipPath]; }
        var name = zipPath.split('/').pop() || 'image.png';
        var p = ctx.zip.file(zipPath).async('uint8array').then(function(data) {
            if (mime === 'image/svg+xml') {
                return svgToPng(data, size).then(function(png) {
                    if (!png) { return null; }
                    return ctx.opts.upload(png, name.replace(/\.svg$/i, '') + '.png');
                });
            }
            var blob = new Blob([data], { type: mime });
            return ctx.opts.upload(blob, name);
        }).catch(function() {
            return null;
        });
        ctx.imgCache[zipPath] = p;
        return p;
    }

    /**
     * Rasterise SVG bytes to a PNG blob through an offscreen canvas.
     *
     * @param {Uint8Array} bytes
     * @param {Object} [size] {w, h} target box in canvas units
     * @return {Promise<Blob|null>}
     */
    function svgToPng(bytes, size) {
        return new Promise(function(resolve) {
            var url = null;
            try {
                var blob = new Blob([bytes], { type: 'image/svg+xml' });
                url = URL.createObjectURL(blob);
                var img = new Image();
                img.onload = function() {
                    var targetW = (size && size.w) || 400;
                    var targetH = (size && size.h) || 300;
                    var natW = img.naturalWidth || 0;
                    var natH = img.naturalHeight || 0;
                    var w;
                    var h;
                    if (natW > 0 && natH > 0) {
                        // At least 2× the display box, aspect preserved.
                        var ar = natW / natH;
                        w = Math.max(natW, Math.round(targetW * 2));
                        h = Math.round(w / ar);
                        var minH = Math.round(targetH * 2);
                        if (h < minH) { h = minH; w = Math.round(h * ar); }
                    } else {
                        w = Math.round(targetW * 2);
                        h = Math.round(targetH * 2);
                    }
                    var cap = 1600;
                    if (Math.max(w, h) > cap) {
                        var s = cap / Math.max(w, h);
                        w = Math.max(1, Math.round(w * s));
                        h = Math.max(1, Math.round(h * s));
                    }
                    try {
                        var canvas = document.createElement('canvas');
                        canvas.width = w;
                        canvas.height = h;
                        var g = canvas.getContext('2d');
                        g.drawImage(img, 0, 0, w, h);
                        canvas.toBlob(function(out) {
                            URL.revokeObjectURL(url);
                            resolve(out || null);
                        }, 'image/png');
                    } catch (e) {
                        URL.revokeObjectURL(url);
                        resolve(null);
                    }
                };
                img.onerror = function() {
                    URL.revokeObjectURL(url);
                    resolve(null);
                };
                img.src = url;
            } catch (e) {
                if (url) { URL.revokeObjectURL(url); }
                resolve(null);
            }
        });
    }

    /**
     * Rasterise an a:gradFill to a PNG: the server-side exporters only
     * understand solid colours and images, so gradients travel as images.
     *
     * @return {Object} {type:'solid', color} fallback or
     *                   {pendingBlob:Promise<Blob>, name, color}
     */
    function gradBg(grad, ctx) {
        var first = null;
        try {
            var stops = [];
            els(grad, 'gs').forEach(function(gs) {
                var col = colorOf(gs, ctx.theme);
                if (!col) { return; }
                if (first === null) { first = col; }
                stops.push({
                    pos: Math.min(1, Math.max(0, num(gs.getAttribute('pos'), 0) / 100000)),
                    color: col,
                });
            });
            if (stops.length < 2) {
                return { type: 'solid', color: first || '#ffffff' };
            }
            stops.sort(function(a, b) { return a.pos - b.pos; });

            var w = Math.max(1, Math.round(ctx.canvasW));
            var h = Math.max(1, Math.round(ctx.canvasH));
            var canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            var g2d = canvas.getContext('2d');
            if (!g2d) { return { type: 'solid', color: first || '#ffffff' }; }

            var fill;
            if (childEl(grad, 'path')) {
                fill = g2d.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) / 2);
            } else {
                var lin = childEl(grad, 'lin');
                // OOXML ang: 60000ths of a degree, clockwise from +x with
                // y pointing down — the canvas coordinate convention.
                var ang = (lin ? num(lin.getAttribute('ang'), 0) : 0) / 60000;
                var rad = ang * Math.PI / 180;
                var dx = Math.cos(rad);
                var dy = Math.sin(rad);
                var len = Math.abs(w * dx) + Math.abs(h * dy);
                fill = g2d.createLinearGradient(
                    w / 2 - dx * len / 2, h / 2 - dy * len / 2,
                    w / 2 + dx * len / 2, h / 2 + dy * len / 2
                );
            }
            stops.forEach(function(s) { fill.addColorStop(s.pos, s.color); });
            g2d.fillStyle = fill;
            g2d.fillRect(0, 0, w, h);

            return {
                pendingBlob: new Promise(function(resolve) {
                    try {
                        canvas.toBlob(function(b) { resolve(b || null); }, 'image/png');
                    } catch (e) { resolve(null); }
                }),
                name: 'slidebg_gradient.png',
                color: first || '#ffffff',
            };
        } catch (e) {
            return { type: 'solid', color: first || '#ffffff' };
        }
    }

    /**
     * Parse `p:bg` from any package part (slide, layout or master).
     *
     * @param {Element|Document} root Part root, document or its cSld.
     * @param {Object} rels          That part's relationship map.
     * @return {Object|null} null when the part defines no background;
     *   {type:'solid', color} | {pending:path, mime, color} |
     *   {pendingBlob:Promise, name, color}
     */
    function readBgFromDoc(root, rels, ctx) {
        if (!root) { return null; }
        var el = root.nodeType === 9 ? root.documentElement : root;
        var cSld = (el.localName === 'cSld') ? el : childEl(el, 'cSld');
        if (!cSld) { return null; }
        var bg = childEl(cSld, 'bg');
        if (!bg) { return null; }

        var bgPr = childEl(bg, 'bgPr');
        if (!bgPr) {
            var bgRef = childEl(bg, 'bgRef');
            var scheme = bgRef ? childEl(bgRef, 'schemeClr') : null;
            var hex = scheme && ctx.theme[scheme.getAttribute('val')];
            return { type: 'solid', color: hex || '#ffffff' };
        }
        var solid = childEl(bgPr, 'solidFill');
        if (solid) {
            return { type: 'solid', color: colorOf(solid, ctx.theme) || '#ffffff' };
        }
        var grad = childEl(bgPr, 'gradFill');
        if (grad) {
            return gradBg(grad, ctx);
        }
        var blipFill = childEl(bgPr, 'blipFill');
        var path = blipToZipPath(blipFill ? childEl(blipFill, 'blip') : null, rels || {});
        if (path) {
            return { pending: path, mime: IMAGE_EXT[extOf(path)], color: '#ffffff' };
        }
        return { type: 'solid', color: '#ffffff' };
    }

    /**
     * Slide background with OOXML inheritance: slide → layout → master.
     * A level only participates when it defines a p:bg of its own; images
     * resolve through the same upload barrier as p:pic.
     *
     * @return {{type:String, color:String}|{pending:String, mime:String}|
     *          {pendingBlob:Promise, name:String, color:String}}
     */
    function readSlideBackground(cSld, ctx) {
        var own = readBgFromDoc(cSld, ctx.rels, ctx);
        if (own) { return own; }

        var layout = ctx.layoutRef ? ctx.layoutRef() : null;
        if (layout) {
            var fromLayout = readBgFromDoc(layout.doc, layout.rels, ctx);
            if (fromLayout) { return fromLayout; }

            var master = layout.masterRef ? layout.masterRef() : null;
            if (master) {
                var fromMaster = readBgFromDoc(master.doc, master.rels, ctx);
                if (fromMaster) { return fromMaster; }
            }
        }
        return { type: 'solid', color: '#ffffff' };
    }

    function convertSlide(zip, path, pageNum, info, opts, caches) {
        var entry = zip.file(path);
        if (!entry) { return Promise.resolve(null); }

        var relsPath = path.replace(/\/([^/]+)$/, '/_rels/$1.rels');
        return Promise.all([
            entry.async('string').catch(function() { return ''; }),
            readRels(zip, relsPath),
        ]).then(function(all) {
            var doc = parseXml(all[0]);
            if (!doc || opts.isCancelled()) { return null; }
            var rels = all[1];

            // Placeholder geometry lives in the layout/master: prime the
            // resolver before walking.
            return caches.layoutRef.prime(path, rels).then(function() {
                if (opts.isCancelled()) { return null; }

                var elements = [];
                var ctx = {
                    unitX: info.unitX,
                    unitY: info.unitY,
                    canvasW: opts.canvasW,
                    canvasH: opts.canvasH,
                    theme: caches.theme,
                    rels: rels,
                    opts: opts,
                    zip: zip,
                    imgCache: caches.imgCache,
                    pending: [],
                    layoutRef: caches.layoutRef,
                };

                var cSld = els(doc, 'cSld')[0] || doc.documentElement;
                var spTree = childEl(cSld, 'spTree');
                if (spTree) {
                    walk(spTree, { tx: 0, ty: 0, sxx: 1, sxy: 1 }, elements, ctx);
                }

                var background = readSlideBackground(cSld, ctx);

                function finish(bg) {
                    if (opts.isCancelled()) { return null; }
                    return {
                        id: 0,
                        title: str('importpptxpage', pageNum),
                        sortorder: 0,
                        elements: elements.filter(Boolean),
                        background: bg,
                        transition: 'none',
                    };
                }

                // Barrier: every p:pic upload must land (or fail) before the
                // slide is handed back, otherwise elements go missing.
                return Promise.all(ctx.pending).then(function() {
                    if (opts.isCancelled()) { return null; }

                    var bgUpload = null;
                    if (background.pending) {
                        bgUpload = uploadZipImage(ctx, background.pending, background.mime,
                            { w: opts.canvasW, h: opts.canvasH });
                    } else if (background.pendingBlob) {
                        bgUpload = background.pendingBlob.then(function(blob) {
                            return blob ? ctx.opts.upload(blob, background.name || 'background.png') : null;
                        });
                    }
                    if (bgUpload) {
                        return bgUpload.then(function(url) {
                            if (opts.isCancelled()) { return null; }
                            return finish(url
                                ? { type: 'image', image: url, imageFit: 'cover', color: background.color || '#ffffff' }
                                : { type: 'solid', color: background.color || '#ffffff' });
                        });
                    }
                    return finish(background);
                });
            });
        }).catch(function() {
            return null;
        });
    }

    /* ======================================================================
     *  Public API
     * ====================================================================== */

    /**
     * Convert a .pptx file into deck slides.
     *
     * @param {File} file
     * @param {Object} opts {canvasW, canvasH, upload(blob, filename),
     *                       onProgress(done,total), isCancelled()}
     * @return {Promise<Object[]>} slides
     */
    function importFile(file, opts) {
        return loadJszip().then(function(JSZip) {
            return readFile(file).then(function(buf) {
                return JSZip.loadAsync(buf);
            });
        }).then(function(zip) {
            var caches = {
                theme: {},
                imgCache: {},
                layoutRef: makeLayoutRef(zip),
            };
            return readTheme(zip).then(function(theme) {
                caches.theme = theme;
                return readPresentation(zip, opts);
            }).then(function(info) {
                if (!info.paths.length) {
                    throw new Error('pptx-no-slides');
                }
                var slides = [];
                var idx = 0;

                function step() {
                    if (opts.isCancelled() || idx >= info.paths.length) {
                        return Promise.resolve(slides);
                    }
                    var path = info.paths[idx];
                    idx++;
                    opts.onProgress(idx, info.paths.length);
                    return convertSlide(zip, path, idx, info, opts, caches).then(function(slide) {
                        if (slide) { slides.push(slide); }
                        return new Promise(function(resolve) { setTimeout(resolve, 0); });
                    }).then(step);
                }

                return step();
            });
        });
    }

    return {
        importFile: importFile,
        loadJszip: loadJszip,
    };
});
