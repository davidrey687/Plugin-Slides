/**
 * Viewer — renders slides with navigation, fullscreen, transitions, and PDF export.
 *
 * @module     mod_slides/viewer
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorBackground', 'mod_slides/viewerRead', 'mod_slides/editorImage', 'mod_slides/editorEquation', 'mod_slides/animations', 'mod_slides/interactive_buttons', 'mod_slides/viewer_navigation', 'mod_slides/shapes_library'], function(background, reader, imageMod, equation, animations, interactiveButtons, viewerNav, shapesLib) {
    'use strict';

    var root, viewportEl, canvasEl, slides = [], current = 0;
    var navPrevEl = null, navNextEl = null;
    var isFullscreen = false;
    var transitionEnabled = true;

    var CANVAS_W = 960;
    var CANVAS_H = 540;

    var PLAY_SVG = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" ' +
        'stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' +
        '<path d="M7 4.5v15l13-7.5z" fill="currentColor" stroke="currentColor" stroke-linejoin="round"/></svg>';

    function scaleCanvas() {
        if (!viewportEl || !canvasEl) { return; }
        var vw = viewportEl.clientWidth;
        var scale = vw / CANVAS_W;
        // transform: scale() — the exact mechanism the editor uses
        // (zoom_controller), so text layout and sub-pixel rendering match
        // between editor and viewer. `.slides-canvas` already carries
        // transform-origin: top left in styles.css.
        canvasEl.style.transform = 'scale(' + scale + ')';
        // Iframes (PDF plugin, YouTube) and <video> rasterize at their own
        // layout size and do NOT re-raster under an ancestor transform —
        // expose the factor so styles.css can lay them out at the final
        // device size and counter-scale (net transform 1:1 = crisp).
        canvasEl.style.setProperty('--slide-scale', String(scale));
    }

    function escapeHtml(str) {
        return String(str == null ? '' : str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function escapeAttr(str) {
        return String(str == null ? '' : str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function getStr(key) {
        try {
            var s = (window.M && M.util && M.util.get_string) ? M.util.get_string(key, 'mod_slides') : '';
            return s || key;
        } catch (e) {
            return key;
        }
    }

    function getYoutubeId(url) {
        var m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&?#]+)/);
        return m ? m[1] : null;
    }

    function getCanvasHeight() {
        if (canvasEl && canvasEl.dataset && canvasEl.dataset.height) {
            var h = parseInt(canvasEl.dataset.height, 10);
            if (h > 0) { return h; }
        }
        return 540;
    }

    function init(cfg) {
        root = document.getElementById('slides-viewer');
        if (!root) { return; }

        viewportEl = root.querySelector('.slides-viewport');
        canvasEl = root.querySelector('.slides-canvas');
        CANVAS_H = getCanvasHeight();

        var hint = root.querySelector('.slides-hint');
        if (hint) {
            setTimeout(function() { hint.classList.add('is-hidden'); }, 3000);
        }

        var btnPrev = root.querySelector('.slides-btn-arrow--prev');
        var btnNext = root.querySelector('.slides-btn-arrow--next');
        if (btnPrev) { btnPrev.addEventListener('click', function() { prev('user'); }); }
        if (btnNext) { btnNext.addEventListener('click', function() { next('user'); }); }

        navPrevEl = root.querySelector('.slides-nav-zone--prev');
        navNextEl = root.querySelector('.slides-nav-zone--next');

        // Delegated navigation: the strips have pointer-events:none so the
        // click lands on whatever is really under the cursor (canvas, link,
        // video...). Interactive elements are left alone, everything else in
        // the left/right 15% bands navigates like the strips used to.
        var swipeStartX = null;
        var swipeStartY = null;
        var swipeSuppressClick = false;
        if (viewportEl) {
            viewportEl.addEventListener('click', function(e) {
                if (swipeSuppressClick) {
                    swipeSuppressClick = false;
                    e.preventDefault();
                    e.stopPropagation();
                    return;
                }
                onViewportClick(e);
            });
            viewportEl.addEventListener('mousemove', onViewportMove);
            viewportEl.addEventListener('mouseleave', function() { setHotZone(null); });

            // Touch: a horizontal swipe navigates; vertical gestures keep
            // scrolling the page (see touch-action: pan-y in CSS).
            viewportEl.addEventListener('touchstart', function(e) {
                swipeSuppressClick = false;
                if (e.touches.length !== 1 || isInteractive(e.target)) {
                    swipeStartX = null;
                    return;
                }
                swipeStartX = e.touches[0].clientX;
                swipeStartY = e.touches[0].clientY;
            }, { passive: true });
            viewportEl.addEventListener('touchmove', function(e) {
                if (swipeStartX === null || e.touches.length !== 1) { return; }
                var dx = e.touches[0].clientX - swipeStartX;
                var dy = e.touches[0].clientY - swipeStartY;
                if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
                    swipeSuppressClick = true;
                    swipeStartX = null;
                    if (dx < 0) { next('user'); } else { prev('user'); }
                }
            }, { passive: true });
            viewportEl.addEventListener('touchend', function() { swipeStartX = null; }, { passive: true });
            viewportEl.addEventListener('touchcancel', function() { swipeStartX = null; }, { passive: true });
        }

        var btnFS = root.querySelector('.slides-btn-fullscreen');
        if (btnFS) { btnFS.addEventListener('click', toggleFullscreen); }

        var btnPresent = root.querySelector('.slides-btn-present');
        if (btnPresent) { btnPresent.addEventListener('click', startPresentation); }

        var btnExport = root.querySelector('.slides-btn-export');
        if (btnExport) { btnExport.addEventListener('click', exportPDF); }

        // Check for URL param to start from beginning
        var urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('present') === '1') {
            current = 0;
            transitionEnabled = false;
            setTimeout(function() {
                toggleFullscreen();
                transitionEnabled = true;
            }, 300);
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                // Close the thumbnail panel first; a second Escape exits fullscreen.
                if (viewerNav.isOpen()) {
                    e.stopPropagation();
                    viewerNav.close();
                    return;
                }
                if (isFullscreen) { exitFullscreen(); }
            }
            // Leave navigation keys to focused form controls (read panel, inputs...).
            var t = e.target;
            if (t && t.closest && t.closest('input, select, textarea, button, [contenteditable]:not([contenteditable="false"])')) {
                return;
            }
            if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); next('user'); }
            if (e.key === 'ArrowLeft') { e.preventDefault(); prev('user'); }
            if (e.key === 'Home') { goTo(0, 'user'); }
            if (e.key === 'End') { goTo(slides.length - 1, 'user'); }
        });

        // Keep the class in sync when the browser exits fullscreen itself.
        document.addEventListener('fullscreenchange', function() {
            if (!document.fullscreenElement && isFullscreen) {
                isFullscreen = false;
                root.classList.remove('is-fullscreen');
            }
        });

        loadSlides(cfg);

        reader.init({
            root: root,
            getSlides: function() { return slides; },
            getCurrent: function() { return current; },
            goTo: function(idx, source) { goTo(idx, source); }
        });

        // Genially-style thumbnail navigator (bottom panel).
        viewerNav.init({
            root: root,
            getSlides: function() { return slides; },
            getCurrent: function() { return current; },
            getCanvasHeight: function() { return CANVAS_H; },
            goTo: function(idx, source) { goTo(idx, source); }
        });
        viewerNav.render();

        if (typeof ResizeObserver !== 'undefined') {
            new ResizeObserver(scaleCanvas).observe(viewportEl);
        } else {
            window.addEventListener('resize', scaleCanvas);
        }
        scaleCanvas();
    }

    function loadSlides(cfg) {
        if (cfg && cfg.slides) {
            slides = cfg.slides;
        } else {
            var dataEl = root.querySelector('.slides-data');
            if (dataEl) {
                try { slides = JSON.parse(dataEl.textContent); } catch (e) { slides = []; }
            }
        }

        slides.forEach(function(s) {
            if (typeof s.background === 'string') {
                try { s.background = JSON.parse(s.background); } catch (e) { s.background = { color: '#ffffff' }; }
            }
            // Uniform background shape ({type, color, image, imageFit}) so
            // solid, gradient and image backgrounds (PDF imports) render the
            // same here as in the editor and the print export.
            s.background = background.normalize(s.background);
            if (!s.transition) { s.transition = 'none'; }
        });

        renderSlide();
        updateCounter();
        updateProgress();

        // Formulas rendered while katex is still loading fall back to the TeX
        // source; repaint the active slide as soon as the engine is ready.
        if (!window.katex) {
            equation.whenReady(function() {
                renderSlide();
                updateCounter();
                updateProgress();
                viewerNav.render();
            });
        }
    }

    function shapeInnerCss(el) {
        var sw = el.strokeWidth || 0;
        var angle = el.angle || 0;
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var shadow = '';
        if (el.shadowEnabled) {
            shadow = 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }

        if (el.shape === 'line') {
            var barH = Math.max(2, sw);
            var style = 'width:100%;height:' + barH + 'px;position:absolute;top:calc(50% - ' + (barH / 2) + 'px);' +
                'background:' + (el.stroke || '#1a1a2e') + ';border-radius:' + (barH / 2) + 'px;' +
                'transform-origin:center center;opacity:' + opacity + ';' + shadow;
            if (angle !== 0) { style += 'transform:rotate(' + angle + 'deg);'; }
            return style;
        }

        var def = shapesLib.SHAPES[el.shape] || shapesLib.SHAPES.rect;
        var clip = def.clip || '';
        // Preserve an empty fill as transparent instead of falling back to blue.
        var fill = (el.fill === '' || el.fill === 'transparent') ? 'transparent' : (el.fill || '#0d6efd');
        var style2 = 'width:100%;height:100%;background:' + fill + ';box-sizing:border-box;' +
            'transform-origin:center center;opacity:' + opacity + ';';

        if (clip.indexOf('clip-path') === -1 && sw > 0) {
            style2 += 'border:' + sw + 'px solid ' + (el.stroke || '#1a1a2e') + ';';
        }
        style2 += clip;
        if (angle !== 0) { style2 += 'transform:rotate(' + angle + 'deg);'; }
        style2 += shadow;
        return style2;
    }

    function pencilSvgMarkup(el) {
        var w = el.w || 300;
        var h = el.h || 200;
        var stroke = el.stroke || '#1a1a2e';
        var sw = (el.strokeWidth !== undefined && el.strokeWidth !== null) ? el.strokeWidth : 3;
        var fill = (el.pathfill && el.pathfill !== 'transparent') ? el.pathfill : 'none';
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var pts = el.points || [];
        if (pts.length < 2) { return ''; }

        var d = 'M ' + pts[0].x + ' ' + pts[0].y;
        for (var i = 1; i < pts.length; i++) {
            d += ' L ' + pts[i].x + ' ' + pts[i].y;
        }

        return '<svg width="100%" height="100%" viewBox="0 0 ' + w + ' ' + h + '" ' +
            'preserveAspectRatio="none" style="position:absolute;top:0;left:0;width:100%;height:100%;opacity:' + opacity + ';overflow:visible;">' +
            '<path d="' + escapeAttr(d) + '" fill="' + escapeAttr(fill) + '" stroke="' + escapeAttr(stroke) + '" stroke-width="' + sw + '" ' +
            'stroke-linecap="round" stroke-linejoin="round"/></svg>';
    }

    function textContentHtml(el) {
        if (el.listType === 'bullet') {
            var lines = (el.text || '').split('\n');
            var ul = '<ul style="margin:0;padding-left:20px;">';
            lines.forEach(function(line) { ul += '<li>' + escapeHtml(line) + '</li>'; });
            return ul + '</ul>';
        }
        if (el.listType === 'number') {
            var lines2 = (el.text || '').split('\n');
            var ol = '<ol style="margin:0;padding-left:20px;">';
            lines2.forEach(function(line) { ol += '<li>' + escapeHtml(line) + '</li>'; });
            return ol + '</ol>';
        }
        return escapeHtml(el.text || '');
    }

    function textStyleCss(el) {
        var textDecoration = '';
        if (el.underline && el.strikethrough) { textDecoration = 'text-decoration:underline line-through;'; }
        else if (el.underline) { textDecoration = 'text-decoration:underline;'; }
        else if (el.strikethrough) { textDecoration = 'text-decoration:line-through;'; }

        var highlight = el.highlight ? 'background-color:' + el.highlight + ';padding:2px 4px;border-radius:2px;' : '';
        var opacity = (el.opacity !== undefined && el.opacity < 100) ? 'opacity:' + (el.opacity / 100) + ';' : '';
        var shadow = '';
        if (el.shadowEnabled) {
            shadow = 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }

        return 'font-size:' + (el.fontSize || 24) + 'px;color:' + (el.color || '#000') + ';' +
            'text-align:' + (el.align || 'left') + ';' +
            'font-family:' + (el.fontfamily || 'sans-serif') + ';' +
            opacity + shadow +
            (el.bold ? 'font-weight:bold;' : '') +
            (el.italic ? 'font-style:italic;' : '') +
            textDecoration + highlight;
    }

    /**
     * Full-viewport animated pop-up for "label" action buttons: translucent
     * backdrop, optional video on top (YouTube iframe or direct file — takes
     * priority over the photo), optional image when there is no video, and
     * the explanatory text below. Closes with the ✖ button, the ESC key or a
     * backdrop click.
     *
     * @param {string} text
     * @param {string} [img] Image URL from the photo bank (optional).
     * @param {string} [video] YouTube or direct-file video URL (optional).
     */
    function showLabelPopup(text, img, video) {
        var backdrop = document.createElement('div');
        backdrop.className = 'slides-interactive-popup-backdrop';

        var modal = document.createElement('div');
        modal.className = 'slides-interactive-popup';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');

        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'slides-interactive-popup-close';
        try {
            closeBtn.setAttribute('aria-label', M.util.get_string('ibpopupclose', 'mod_slides'));
        } catch (e) {
            closeBtn.setAttribute('aria-label', 'Close');
        }
        closeBtn.innerHTML = '&times;';
        modal.appendChild(closeBtn);

        /* Video wins over the photo; only one media block is shown. */
        var vinfo = video ? interactiveButtons.getVideoInfo(video) : null;
        if (vinfo && vinfo.embed) {
            var vWrapYt = document.createElement('div');
            vWrapYt.className = 'slides-interactive-popup-video';
            var iframe = document.createElement('iframe');
            iframe.src = vinfo.embed;
            iframe.title = text || 'Video';
            iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
            iframe.setAttribute('allowfullscreen', '');
            vWrapYt.appendChild(iframe);
            modal.appendChild(vWrapYt);
        } else if (vinfo && vinfo.file) {
            var vWrap = document.createElement('div');
            vWrap.className = 'slides-interactive-popup-video';
            var vidEl = document.createElement('video');
            vidEl.src = vinfo.file;
            vidEl.controls = true;
            vidEl.preload = 'metadata';
            vidEl.playsInline = true;
            vWrap.appendChild(vidEl);
            modal.appendChild(vWrap);
        } else if (img) {
            var imgEl = document.createElement('img');
            imgEl.className = 'slides-interactive-popup-img';
            imgEl.src = img;
            imgEl.alt = '';
            imgEl.addEventListener('error', function() { imgEl.style.display = 'none'; });
            modal.appendChild(imgEl);
        }

        var textEl = document.createElement('div');
        textEl.className = 'slides-interactive-popup-text';
        textEl.textContent = text || '';
        modal.appendChild(textEl);

        function close() {
            document.removeEventListener('keydown', onKey);
            if (backdrop.parentNode) { backdrop.parentNode.removeChild(backdrop); }
        }
        function onKey(e) {
            if (e.key === 'Escape') {
                e.stopPropagation();
                close();
            }
        }
        closeBtn.addEventListener('click', function(e) { e.stopPropagation(); close(); });
        backdrop.addEventListener('click', function(e) { e.stopPropagation(); close(); });
        modal.addEventListener('click', function(e) { e.stopPropagation(); });
        document.addEventListener('keydown', onKey);

        backdrop.appendChild(modal);
        // Fullscreen only paints descendants of the fullscreen element (the
        // viewer root), and the CSS-only fallback overlays it too: appending
        // to <body> would leave the pop-up invisible during presentation.
        var fsEl = document.fullscreenElement || document.webkitFullscreenElement;
        var host;
        if (fsEl) {
            host = (root && fsEl.contains(root)) ? root : fsEl;
        } else if (root && root.parentNode) {
            host = root;
        } else {
            host = document.body;
        }
        host.appendChild(backdrop);
    }

    function createElementNode(el) {
        var div = document.createElement('div');
        div.className = 'slide-element slide-element--' + (el.type || 'text');

        if (el.type === 'image' && el.src) {
            var imgClip = (imageMod && imageMod.hasCrop(el))
                ? imageMod.croppedContainerStyle(el)
                : '';
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:hidden;' + imgClip;
            var img = document.createElement('img');
            img.src = el.src;
            img.alt = el.alt || '';
            var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
            var br = el.borderRadius || 0;
            if (imageMod && imageMod.hasCrop(el)) {
                img.style.cssText = imageMod.croppedImgStyle(el);
            } else {
                img.style.cssText = 'width:100%;height:100%;object-fit:contain;opacity:' + opacity + ';border-radius:' + br + 'px;display:block;';
            }
            div.appendChild(img);
        } else if (el.type === 'video' && el.src) {
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:hidden;background:#111;';
            var url = el.src;
            var ytId = getYoutubeId(url);
            if (ytId) {
                var iframe = document.createElement('iframe');
                iframe.src = 'https://www.youtube.com/embed/' + ytId + '?rel=0';
                iframe.style.cssText = 'width:100%;height:100%;border:none;border-radius:4px;';
                iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
                iframe.allowFullscreen = true;
                div.appendChild(iframe);
            } else if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)) {
                var vid = document.createElement('video');
                vid.src = url;
                vid.style.cssText = 'width:100%;height:100%;border:none;border-radius:4px;object-fit:contain;';
                vid.controls = true;
                div.appendChild(vid);
            } else {
                var vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
                var embed = vimeoMatch ? ('https://player.vimeo.com/video/' + vimeoMatch[1]) : url;
                var viframe = document.createElement('iframe');
                viframe.src = embed;
                viframe.style.cssText = 'width:100%;height:100%;border:none;border-radius:4px;';
                viframe.allowFullscreen = true;
                div.appendChild(viframe);
            }
        } else if (el.type === 'pdf' && el.src) {
            var pdfOpacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
            var pdfBr = el.borderRadius || 0;
            var pdfShadow = el.shadowEnabled ? 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' + (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';' : '';
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:hidden;z-index:10;border-radius:' + pdfBr + 'px;opacity:' + pdfOpacity + ';' + pdfShadow;
            // Fallback layer (icon + title), visible while the PDF loads.
            var pdfFallback = '<div style="position:absolute;left:0;top:0;width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#f8f9fa;">' +
                '<svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="#dc3545" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom:8px;">' +
                '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 7h10"/><path d="M12 7v10"/><path d="M7 14h10"/><path d="M9 17h6"/><path d="M9 11h6"/>' +
                '</svg>' +
                '<span style="font-size:12px;color:#495057;text-align:center;padding:0 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;">' + escapeHtml(el.pdftitle || el.alt || 'PDF Document') + '</span>' +
                '</div>';
            // Interactive embed: the browser's own PDF viewer handles pages/scroll.
            var pdfFrame = '<iframe src="' + escapeAttr(el.src) + '" title="' + escapeAttr(el.pdftitle || el.alt || 'PDF') +
                '" style="position:absolute;left:0;top:0;width:100%;height:100%;border:none;background:transparent;"></iframe>';
            // Floating ↗ button opens the full PDF in a new tab.
            var pdfOpenBtn = '<button type="button" title="' + escapeAttr(getStr('pdfopennewtab')) +
                '" style="position:absolute;top:6px;right:6px;z-index:2;border:1px solid #ced4da;' +
                'background:rgba(255,255,255,0.92);border-radius:6px;padding:5px 7px;cursor:pointer;' +
                'line-height:0;color:#212529;box-shadow:0 1px 3px rgba(0,0,0,0.18);">' +
                '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>' +
                '<polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>' +
                '</button>';
            div.innerHTML = pdfFallback + pdfFrame + pdfOpenBtn;
            div.querySelector('button').addEventListener('click', function(e) {
                e.stopPropagation();
                window.open(el.src, '_blank');
            });
        } else if (el.type === 'shape') {
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:visible;';
            var inner = document.createElement('div');
            inner.className = 'shape-inner';
            inner.style.cssText = shapeInnerCss(el);
            div.appendChild(inner);
        } else if (el.type === 'pencil') {
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:visible;';
            div.innerHTML = pencilSvgMarkup(el);
        } else if (el.type === 'footer') {
            div.style.cssText = 'left:' + el.x + 'px;top:' + (el.y != null ? el.y : 500) + 'px;width:' + (el.w || 960) + 'px;height:' + (el.h || 40) + 'px;position:absolute;overflow:hidden;' +
                'background:' + (el.background || '#f8f9fa') + ';display:flex;align-items:center;' +
                'justify-content:' + (el.align === 'left' ? 'flex-start' : el.align === 'right' ? 'flex-end' : 'center') + ';' +
                textStyleCss(el);
            div.textContent = el.text || '';
        } else if (el.type === 'link') {
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:hidden;z-index:11;';
            var linkA = document.createElement('a');
            linkA.href = el.url || '#';
            linkA.target = el.target === '_self' ? '_self' : '_blank';
            linkA.rel = 'noopener noreferrer';
            linkA.textContent = el.text || el.url || '';
            var linkOpacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
            var linkAlign = el.align || 'center';
            var linkJustify = linkAlign === 'left' ? 'flex-start' : (linkAlign === 'right' ? 'flex-end' : 'center');
            var linkShadow = el.shadowEnabled ? 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' + (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';' : '';
            linkA.style.cssText = 'display:flex;align-items:center;justify-content:' + linkJustify + ';' +
                'width:100%;height:100%;box-sizing:border-box;overflow:hidden;' +
                'white-space:nowrap;text-overflow:ellipsis;' +
                'background:' + (el.background || '#e7f1ff') + ';border-radius:6px;' +
                'font-size:' + (el.fontSize || 16) + 'px;color:' + (el.color || '#0d6efd') + ';' +
                'font-family:' + (el.fontfamily || 'sans-serif') + ';' +
                'text-decoration:underline;cursor:pointer;opacity:' + linkOpacity + ';' +
                (el.bold ? 'font-weight:bold;' : '') + linkShadow;
            div.appendChild(linkA);
        } else if (el.type === 'equation') {
            var eqAlign = el.align === 'left' ? 'flex-start' : (el.align === 'right' ? 'flex-end' : 'center');
            var eqShadow = el.shadowEnabled ? 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';' : '';
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;' +
                'display:flex;align-items:center;justify-content:' + eqAlign + ';overflow:hidden;box-sizing:border-box;' +
                'line-height:1.2;text-align:' + (el.align || 'center') + ';font-size:' + (el.fontSize || 32) + 'px;' +
                'color:' + (el.color || '#000') + ';' +
                'opacity:' + ((el.opacity !== undefined) ? el.opacity / 100 : 1) + ';' + eqShadow;
            div.innerHTML = equation.renderHtml(el.text || '');
        } else if (el.type === 'html') {
            // Interactive embed: no protective overlay here, so students can
            // drive the video/widget directly (the markup was sanitised on save).
            var htmlOpacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
            var htmlBr = el.borderRadius || 0;
            var htmlShadow = el.shadowEnabled ? 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';' : '';
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;' +
                'overflow:hidden;box-sizing:border-box;opacity:' + htmlOpacity + ';' +
                (htmlBr ? 'border-radius:' + htmlBr + 'px;' : '') + htmlShadow;
            div.className += ' html-embed';
            div.innerHTML = el.text || '';
        } else if (el.type === 'audio') {
            // Recorded audio: live controls for students (no overlay).
            var aOpacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
            var aShadow = el.shadowEnabled ? 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';' : '';
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;' +
                'overflow:hidden;box-sizing:border-box;opacity:' + aOpacity + ';' + aShadow;
            var aud = document.createElement('audio');
            aud.src = el.src || '';
            aud.controls = true;
            aud.preload = 'metadata';
            aud.style.cssText = 'width:100%;height:100%;display:block;';
            div.appendChild(aud);
        } else if (el.type === 'action') {
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:hidden;z-index:11;' +
                interactiveButtons.buttonInnerStyle(el) +
                'font-size:' + (el.fontSize || 20) + 'px;';
            div.classList.add('slide-element--action');
            var actionIconHtml = interactiveButtons.buttonIconHtml(el);
            if (actionIconHtml) {
                div.innerHTML = actionIconHtml;
                div.title = el.label || '';
            } else {
                div.textContent = el.label || '';
            }
            div.addEventListener('click', function(ev) {
                ev.stopPropagation();
                interactiveButtons.run(el, {
                    goTo: function(idx) { goTo(idx, 'user'); },
                    open: function(url, target) { window.open(url, target); },
                    showLabel: function(text, img, video) { showLabelPopup(text, img, video); },
                });
            });
        } else {
            div.style.cssText = 'left:' + el.x + 'px;top:' + el.y + 'px;width:' + el.w + 'px;height:' + el.h + 'px;position:absolute;overflow:hidden;' +
                'white-space:pre-wrap;word-wrap:break-word;line-height:1.35;' + textStyleCss(el);
            div.innerHTML = textContentHtml(el);
        }

        // Interactive link on an image / shape / text: the whole container
        // (centre, edges, corners and transparent pixels) navigates because
        // the handler sits on the wrapper div. data-no-nav keeps the
        // delegated viewport click from advancing the slide and stops the
        // touch swipe from hijacking the gesture; cursor:pointer comes from
        // .slide-element--linked in styles.css. The editor never adds this
        // (drag and resize own the primary click there).
        if (el.url && LINKED_TYPES.indexOf(el.type || 'text') !== -1) {
            div.setAttribute('data-no-nav', '');
            div.classList.add('slide-element--linked');
            div.addEventListener('click', function(ev) {
                ev.stopPropagation();
                var target = el.target === '_self' ? '_self' : '_blank';
                window.open(el.url, target, target === '_blank' ? 'noopener,noreferrer' : '');
            });
        }

        return div;
    }

    function renderSlide() {
        if (!canvasEl) { return; }
        var slide = slides[current];
        if (!slide) { return; }

        var prevSlide = canvasEl.querySelector('.slide.is-active');

        var slideDiv = document.createElement('div');
        slideDiv.className = 'slide is-active';
        slideDiv.style.background = background.toCss(slide.background);

        (slide.elements || []).forEach(function(el) {
            if (el._visible === false) { return; }
            slideDiv.appendChild(createElementNode(el));
        });

        if (transitionEnabled && prevSlide) {
            var transition = slide.transition || 'none';
            if (transition === 'fade') {
                slideDiv.style.animation = 'slideFadeIn 0.5s ease';
            } else if (transition === 'push') {
                slideDiv.style.animation = 'slidePushIn 0.5s ease';
            } else if (transition === 'slide-left') {
                slideDiv.style.animation = 'slideSlideLeftIn 0.5s ease';
            } else if (transition === 'slide-up') {
                slideDiv.style.animation = 'slideSlideUpIn 0.5s ease';
            } else if (transition === 'slide-down') {
                slideDiv.style.animation = 'slideSlideDownIn 0.5s ease';
            } else if (transition === 'zoom') {
                slideDiv.style.animation = 'slideZoomIn 0.5s ease';
            } else if (transition === 'flip') {
                slideDiv.style.animation = 'slideFlipIn 0.5s ease';
            } else if (transition === 'reveal') {
                slideDiv.style.animation = 'slideRevealIn 0.5s ease';
            } else if (transition === 'cube') {
                slideDiv.style.animation = 'slideCubeIn 0.5s ease';
            } else if (transition === 'cut') {
                slideDiv.style.animation = 'none';
            } else if (transition === 'transform') {
                slideDiv.style.animation = 'slideTransformIn 0.5s ease';
            }
        }

        canvasEl.innerHTML = '';
        canvasEl.appendChild(slideDiv);

        // Click-to-reveal animations: hide the tagged elements and reset the
        // step counter. MUST run after the appendChild so slideDiv.parentNode
        // (= canvasEl) is available as the query root for revealStep/recede.
        animations.prepareSlide(slideDiv, slide);
    }

    /* ---- Navigation strips (delegated) ------------------------------------ */
    var NAV_ZONE = 0.15;
    var INTERACTIVE_SEL = 'a, audio, button, video, iframe, input, textarea, select, .slides-progress, [data-no-nav]';
    /** Element types whose whole container navigates when a URL is attached.
     *  (`link` is not listed: its own <a> already fills the box.) */
    var LINKED_TYPES = ['image', 'shape', 'text'];

    function isInteractive(target) {
        return !!(target && target.closest && target.closest(INTERACTIVE_SEL));
    }

    function navZoneAt(clientX) {
        if (!viewportEl) { return null; }
        var rect = viewportEl.getBoundingClientRect();
        if (!rect.width) { return null; }
        var ratio = (clientX - rect.left) / rect.width;
        if (ratio <= NAV_ZONE) { return 'prev'; }
        if (ratio >= 1 - NAV_ZONE) { return 'next'; }
        return null;
    }

    function onViewportClick(e) {
        if (e.defaultPrevented || isInteractive(e.target)) { return; }
        // PowerPoint pattern: while the slide still has hidden animation
        // steps, ANY click on the presentation reveals the next group; the
        // side bands only navigate once the sequence is exhausted.
        if (animations.hasPending()) {
            animations.advance();
            return;
        }
        var zone = navZoneAt(e.clientX);
        if (zone === 'prev') { prev(); }
        else if (zone === 'next') { next(); }
    }

    function setHotZone(hot) {
        if (navPrevEl) { navPrevEl.classList.toggle('is-hot', hot === 'prev'); }
        if (navNextEl) { navNextEl.classList.toggle('is-hot', hot === 'next'); }
        if (viewportEl) { viewportEl.style.cursor = hot ? 'pointer' : ''; }
    }

    function onViewportMove(e) {
        setHotZone(isInteractive(e.target) ? null : navZoneAt(e.clientX));
    }

    function next(source) {
        // Animation steps first: one click/arrow reveals one sequence step;
        // only a slide without pending steps advances to the next slide.
        if (animations.advance()) {
            if (source !== 'reader') { reader.stop('user'); }
            return;
        }
        if (current < slides.length - 1) {
            current++;
            renderSlide();
            updateCounter();
            updateProgress();
        }
        if (source !== 'reader') { reader.stop('user'); }
    }

    function prev(source) {
        // Revert one animation step before jumping to the previous slide.
        if (animations.recede()) {
            if (source !== 'reader') { reader.stop('user'); }
            return;
        }
        if (current > 0) {
            current--;
            renderSlide();
            updateCounter();
            updateProgress();
        }
        if (source !== 'reader') { reader.stop('user'); }
    }

    function goTo(idx, source) {
        if (idx >= 0 && idx < slides.length) {
            current = idx;
            renderSlide();
            // Direct jumps (Home / End / reader) show the completed slide.
            animations.finishAll();
            updateCounter();
            updateProgress();
        }
        if (source !== 'reader') { reader.stop('user'); }
    }

    function updateCounter() {
        // The counter is a button (opens the thumbnail panel) wrapping a
        // .slides-counter-current span; update only the span so the button
        // chrome (the " / N" suffix) survives.
        var currentEl = root.querySelector('.slides-counter-current');
        if (currentEl) {
            currentEl.textContent = current + 1;
        } else {
            var counter = root.querySelector('.slides-counter');
            if (counter) {
                counter.textContent = (current + 1) + ' / ' + slides.length;
            }
        }
        viewerNav.sync(current, true);
    }

    function updateProgress() {
        var bar = root.querySelector('.slides-progress-bar');
        if (bar && slides.length > 0) {
            var pct = ((current + 1) / slides.length) * 100;
            bar.style.width = pct + '%';
        }
    }

    function toggleFullscreen() {
        var fsEl = document.fullscreenElement || document.webkitFullscreenElement;
        if (fsEl || root.classList.contains('is-fullscreen')) {
            exitFullscreen();
            return;
        }
        enterFullscreen();
    }

    function enterFullscreen() {
        var req = root.requestFullscreen || root.webkitRequestFullscreen;
        var onEnter = function() {
            isFullscreen = true;
            root.classList.add('is-fullscreen');
        };
        if (!req) {
            // No native API (e.g. iPhone Safari): CSS-only fullscreen overlay.
            onEnter();
            return;
        }
        var p;
        try {
            p = req.call(root);
        } catch (e) {
            onEnter();
            return;
        }
        if (p && typeof p.then === 'function') {
            p.then(onEnter, onEnter);
        } else {
            onEnter();
        }
    }

    function exitFullscreen() {
        var fsEl = document.fullscreenElement || document.webkitFullscreenElement;
        var exit = document.exitFullscreen || document.webkitExitFullscreen;
        if (fsEl && exit) {
            try { exit.call(document); } catch (e) { /* ignore */ }
        }
        isFullscreen = false;
        root.classList.remove('is-fullscreen');
    }

    function startPresentation() {
        reader.stop('user');
        current = 0;
        renderSlide();
        updateCounter();
        updateProgress();
        toggleFullscreen();
    }

    function exportElementHtml(el) {
        if (el._visible === false) { return ''; }

        var pos = 'left:' + (el.x || 0) + 'px;top:' + (el.y || 0) + 'px;width:' + (el.w || 0) + 'px;height:' + (el.h || 0) + 'px;';
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var opacityStyle = opacity < 1 ? 'opacity:' + opacity + ';' : '';
        var shadow = el.shadowEnabled ? 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' + (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';' : '';
        var rotate = el.angle ? 'transform:rotate(' + el.angle + 'deg);transform-origin:center center;' : '';

        // Nested helpers receive opacity/shadow neutralised so they are not applied twice.
        var flat = {};
        var k;
        for (k in el) {
            if (Object.prototype.hasOwnProperty.call(el, k)) { flat[k] = el[k]; }
        }
        flat.opacity = 100;
        flat.shadowEnabled = false;

        if (el.type === 'image') {
            if (!el.src) { return ''; }
            var br = el.borderRadius || 0;
            var brStyle = br ? 'border-radius:' + br + 'px;' : '';
            var cropped = imageMod && imageMod.hasCrop(flat);
            var clipStyle = cropped ? 'overflow:hidden;' : '';
            var imgTag = '<img src="' + escapeAttr(el.src) + '" alt="' + escapeAttr(el.alt || '') + '"';
            if (cropped) {
                imgTag += ' style="' + escapeAttr(imageMod.croppedImgStyle(flat)) + '"';
            }
            imgTag += '>';
            return '<div class="slide-el" style="' + escapeAttr(pos + opacityStyle + shadow + brStyle + clipStyle) + '">' +
                imgTag + '</div>';
        }

        if (el.type === 'video') {
            if (!el.src) { return ''; }
            var url = el.src;
            var ytId = getYoutubeId(url);
            if (ytId) {
                var thumb = 'https://img.youtube.com/vi/' + ytId + '/hqdefault.jpg';
                return '<div class="slide-el video-print" style="' + escapeAttr(pos + opacityStyle + shadow) + '">' +
                    '<img src="' + escapeAttr(thumb) + '" alt="">' +
                    '<div class="play">' + PLAY_SVG + '</div></div>';
            }
            if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)) {
                return '<div class="slide-el video-print" style="' + escapeAttr(pos + opacityStyle + shadow) + '">' +
                    '<video src="' + escapeAttr(url) + '" preload="metadata" muted playsinline ' +
                    'style="width:100%;height:100%;object-fit:contain;background:#111;"></video></div>';
            }
            var vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
            if (vimeoMatch) {
                return '<div class="slide-el video-print" style="' + escapeAttr(pos + opacityStyle + shadow) + '">' +
                    '<img src="https://vumbnail.com/' + vimeoMatch[1] + '.jpg" alt="">' +
                    '<div class="play">' + PLAY_SVG + '</div></div>';
            }
            return '<div class="slide-el video-print" style="' + escapeAttr(pos + opacityStyle + shadow) + '">' +
                '<div class="play">' + PLAY_SVG + '</div></div>';
        }

        if (el.type === 'shape') {
            // Opacity / angle / shadow live on the inner node (matches editor).
            return '<div class="slide-el" style="' + escapeAttr(pos + 'overflow:visible;') + '">' +
                '<div class="shape-inner" style="' + escapeAttr(shapeInnerCss(el)) + '"></div></div>';
        }

        if (el.type === 'pencil') {
            return '<div class="slide-el" style="' + escapeAttr(pos + 'overflow:visible;') + '">' +
                pencilSvgMarkup(el) + '</div>';
        }

        if (el.type === 'footer') {
            var fAlign = el.align === 'left' ? 'flex-start' : el.align === 'right' ? 'flex-end' : 'center';
            var footerStyle = pos + opacityStyle + shadow +
                'background:' + (el.background || '#f8f9fa') +
                ';display:flex;align-items:center;justify-content:' + fAlign + ';' + textStyleCss(flat);
            return '<div class="slide-el" style="' + escapeAttr(footerStyle) + '">' +
                escapeHtml(el.text || '') + '</div>';
        }

        if (el.type === 'link') {
            var lAlign = el.align === 'left' ? 'flex-start' : el.align === 'right' ? 'flex-end' : 'center';
            var linkBoxStyle = pos + opacityStyle + shadow +
                'background:' + (el.background || '#e7f1ff') + ';border-radius:6px;' +
                'display:flex;align-items:center;justify-content:' + lAlign + ';';
            var linkTextStyle = 'font-size:' + (el.fontSize || 20) + 'px;color:' + (el.color || '#0d6efd') +
                ';text-decoration:underline;' + (el.bold ? 'font-weight:bold;' : '') +
                'font-family:' + (el.fontfamily || 'sans-serif') + ';';
            return '<div class="slide-el" style="' + escapeAttr(linkBoxStyle) + '">' +
                '<span style="' + escapeAttr(linkTextStyle) + '">' + escapeHtml(el.text || el.url || '') + '</span>' +
                '</div>';
        }

        if (el.type === 'pdf') {
            if (!el.src) { return ''; }
            var pdfBr = el.borderRadius || 0;
            var pdfBrStyle = pdfBr ? 'border-radius:' + pdfBr + 'px;' : '';
            var pdfTitle = escapeHtml(el.pdftitle || el.alt || 'PDF Document');
            var pdfIconSvg = '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="#dc3545" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 7h10"/><path d="M12 7v10"/><path d="M7 14h10"/><path d="M9 17h6"/><path d="M9 11h6"/></svg>';
            return '<div class="slide-el" style="' + escapeAttr(pos + opacityStyle + shadow + pdfBrStyle) + '">' +
                '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;background:#f8f9fa;border:2px dashed #dee2e6;">' +
                pdfIconSvg +
                '<span style="font-size:11px;color:#495057;text-align:center;padding:0 8px;margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;">' + pdfTitle + '</span>' +
                '</div></div>';
        }

        if (el.type === 'equation') {
            var eqAlign = el.align === 'left' ? 'flex-start' : (el.align === 'right' ? 'flex-end' : 'center');
            var eqStyle = pos + opacityStyle + shadow +
                'display:flex;align-items:center;justify-content:' + eqAlign + ';' +
                'line-height:1.2;text-align:' + (el.align || 'center') + ';' +
                'font-size:' + (el.fontSize || 32) + 'px;color:' + (el.color || '#000') + ';';
            return '<div class="slide-el slide-el--equation" style="' + escapeAttr(eqStyle) + '">' +
                equation.renderHtml(el.text || '') + '</div>';
        }

        if (el.type === 'html') {
            // Print the sanitised markup as-is: iframes keep their own chrome,
            // plain content flows inside the fixed-size box.
            var htmlStyle = pos + opacityStyle + shadow + 'overflow:hidden;box-sizing:border-box;';
            return '<div class="slide-el slide-el--html" style="' + escapeAttr(htmlStyle) + '">' +
                (el.text || '') + '</div>';
        }

        if (el.type === 'audio') {
            var auStyle = pos + opacityStyle + shadow + 'overflow:hidden;box-sizing:border-box;';
            return '<div class="slide-el slide-el--audio" style="' + escapeAttr(auStyle) + '">' +
                '<audio controls preload="metadata" src="' + escapeAttr(el.src || '') + '"' +
                ' style="width:100%;height:100%;display:block;"></audio></div>';
        }

        // text (default)
        var textStyles = pos + opacityStyle + shadow + rotate +
            'white-space:pre-wrap;word-wrap:break-word;line-height:1.35;' + textStyleCss(flat);
        return '<div class="slide-el" style="' + escapeAttr(textStyles) + '">' + textContentHtml(el) + '</div>';
    }

    /**
     * Open the print window first (popup blockers allow it inside the click),
     * then write it once KaTeX is actually ready, so formulas come out
     * typeset instead of as raw LaTeX. A hard 4s cap keeps the teacher
     * waiting even if katex never loads.
     *
     * @param {Window} printWin
     */
    function exportPDF() {
        var printWin = window.open('', '_blank');
        if (!printWin) { return; }

        var started = false;
        var run = function() {
            if (started) { return; }
            started = true;
            exportPDFInto(printWin);
        };
        equation.whenReady(run);
        window.setTimeout(run, 4000);
    }

    function exportPDFInto(printWin) {

        CANVAS_H = getCanvasHeight();

        var css =
            '@page { size: landscape; margin: 0; }' +
            'html, body { margin:0; padding:0; background:#fff; }' +
            '*, *::before, *::after {' +
            '  -webkit-print-color-adjust: exact !important;' +
            '  print-color-adjust: exact !important;' +
            '  color-adjust: exact !important;' +
            '}' +
            '.slide-wrap {' +
            '  position:relative; overflow:hidden; page-break-after:always; break-after:page;' +
            '  background:#fff;' +
            '}' +
            '.slide-wrap:last-child { page-break-after:auto; break-after:auto; }' +
            '.slide-page {' +
            '  width:' + CANVAS_W + 'px; height:' + CANVAS_H + 'px;' +
            '  position:relative; overflow:hidden; transform-origin:top left;' +
            '}' +
            '.slide-el {' +
            '  position:absolute; box-sizing:border-box; white-space:pre-wrap;' +
            '  word-wrap:break-word; line-height:1.35;' +
            '}' +
            '.slide-el > img { display:block; width:100%; height:100%; object-fit:contain; }' +
            '.slide-el iframe, .slide-el video { width:100%; height:100%; border:none; display:block; }' +
            '.slide-el ul, .slide-el ol { margin:0; padding-left:20px; }' +
            '.slide-el--equation { overflow:visible; }' +
            '.slide-el--equation .katex-display { margin:0; }' +
            // Keep the TeX annotation clipped even if katex.min.css is slow
            // to apply: it would otherwise print the raw source under the glyph.
            '.katex-mathml { clip:rect(1px,1px,1px,1px);border:0;height:1px;overflow:hidden;' +
            'padding:0;position:absolute;width:1px; }' +
            '.shape-inner { width:100%; height:100%; box-sizing:border-box; }' +
            '.video-print { background:#111; overflow:hidden; }' +
            '.video-print > img {' +
            '  position:absolute; top:0; left:0; width:100%; height:100%;' +
            '  object-fit:cover; opacity:0.92;' +
            '}' +
            '.video-print > .play {' +
            '  position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);' +
            '  width:48px; height:48px; border-radius:50%; background:rgba(0,0,0,0.7);' +
            '  color:#fff; display:flex; align-items:center; justify-content:center;' +
            '  z-index:2; box-sizing:border-box;' +
            '}' +
            '.video-print > .play svg { width:20px; height:20px; display:block; }';

        var html = '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">' +
            '<meta name="viewport" content="width=device-width, initial-scale=1">' +
            '<title>Export PDF</title>' +
            // KaTeX stylesheet so the printed formulas keep their fonts.
            '<link rel="stylesheet" href="' + escapeAttr(equation.getCssUrl()) + '">' +
            '<style>' + css + '</style></head><body>';

        slides.forEach(function(slide, slideIdx) {
            var bg = background.toCss(slide.background);
            html += '<div class="slide-wrap" data-idx="' + slideIdx + '">' +
                '<div class="slide-page" style="' + escapeAttr('background:' + bg + ';') + '">';

            (slide.elements || []).forEach(function(el) {
                html += exportElementHtml(el);
            });

            html += '</div></div>';
        });

        // Fixed landscape page box (fits A4 + Letter). Scale content to fit, center it.
        html += '<script>' +
            '(function() {' +
            '  var W = ' + CANVAS_W + ';' +
            '  var H = ' + CANVAS_H + ';' +
            '  var pageW = 1056, pageH = 794;' +
            '  var s = Math.min(pageW / W, pageH / H);' +
            '  var ox = (pageW - W * s) / 2;' +
            '  var oy = (pageH - H * s) / 2;' +
            '  var wraps = document.querySelectorAll(".slide-wrap");' +
            '  for (var i = 0; i < wraps.length; i++) {' +
            '    wraps[i].style.width = pageW + "px";' +
            '    wraps[i].style.height = pageH + "px";' +
            '    var p = wraps[i].querySelector(".slide-page");' +
            '    if (p) { p.style.transform = "translate(" + ox + "px," + oy + "px) scale(" + s + ")"; }' +
            '  }' +
            '  window.addEventListener("load", function() {' +
            '    setTimeout(function() { window.print(); }, 300);' +
            '  });' +
            '})();' +
            '<\/script></body></html>';

        printWin.document.write(html);
        printWin.document.close();
    }

    return { init: init };
});
