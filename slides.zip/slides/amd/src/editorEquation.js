/**
 * Equation element type — "+" secondary toolbar row, LaTeX equation modal, local
 * KaTeX loader and TeX rendering helpers shared by the editor and the viewer.
 *
 * The TeX source is stored in the standard `text` field of the element (so it
 * round-trips through deck_sanitizer untouched); the visual formula is always
 * rendered at runtime from that code.
 *
 * @module     mod_slides/editorEquation
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/editorIcons'], function(state, icons) {
    'use strict';

    var TYPE = 'equation';

    var DEFAULTS = {
        type: TYPE,
        x: 280,
        y: 220,
        w: 400,
        h: 90,
        text: '',
        fontSize: 32,
        color: '#000000',
        align: 'center',
        opacity: 100,
        shadowEnabled: false,
        shadowColor: '#00000080',
        shadowBlur: 10,
        shadowX: 2,
        shadowY: 2,
    };

    /* ======================================================================
     *  Local KaTeX (slides/vendor/katex)
     * ====================================================================== */

    var katexPromise = null;
    var loadFailed = false;
    var loadedBase = null;

    function str(key) {
        try { return M.util.get_string(key, 'mod_slides'); } catch (e) { return key; }
    }

    /**
     * KaTeX disables its DOM renderer when the document is in quirks mode
     * (`document.compatMode === 'BackCompat'`). Some Moodle integrations load
     * the editor inside a frame without a doctype, which leaves KaTeX unable
     * to render anything. Report standards mode to the renderer before
     * katex.min.js executes so it keeps its working render implementation.
     */
    function ensureStandardsMode() {
        try {
            if (typeof document === 'undefined' || document.compatMode === 'CSS1Compat') {
                return;
            }
            Object.defineProperty(document, 'compatMode', {
                configurable: true,
                get: function() { return 'CSS1Compat'; }
            });
        } catch (e) {
            try {
                Object.defineProperty(Document.prototype, 'compatMode', {
                    configurable: true,
                    get: function() { return 'CSS1Compat'; }
                });
            } catch (err) { /* KaTeX will report the original error. */ }
        }
    }

    ensureStandardsMode();

    function baseUrl() {
        var root = (typeof M !== 'undefined' && M.cfg && M.cfg.wwwroot) ? M.cfg.wwwroot : '';
        return root + '/mod/slides/vendor/katex';
    }

    /**
     * Candidate locations for the local katex build, best guess first:
     *  1. the configured $CFG->wwwroot (works for root installs),
     *  2. a path derived from the current page URL (works for sub-directory
     *     installs or when wwwroot does not match the host the teacher uses),
     *  3. root-relative.
     * The first one that actually loads wins, so a wrong base URL can no
     * longer leave the teacher staring at raw LaTeX code.
     *
     * @return {String[]}
     */
    function candidateBases() {
        var out = [];
        var push = function(url) {
            if (url && out.indexOf(url) === -1) { out.push(url); }
        };

        push(baseUrl());
        try {
            var base = new URL(document.baseURI);
            base.search = '';
            base.hash = '';
            base.pathname = base.pathname.replace(/\/[^\/]*$/, '/vendor/katex/');
            push(base.href.replace(/\/$/, ''));
        } catch (e) { /* URL unsupported: keep the other candidates. */ }
        push('/mod/slides/vendor/katex');

        return out;
    }

    function getCssUrl() {
        return (loadedBase || baseUrl()) + '/katex.min.css';
    }

    function injectCss(href, tag) {
        var found = document.querySelector('link[data-slides-katex="' + tag + '"]');
        if (!found) {
            found = document.createElement('link');
            found.rel = 'stylesheet';
            found.href = href;
            found.setAttribute('data-slides-katex', tag);
            document.head.appendChild(found);
        }
        return found;
    }

    /**
     * katex.min.css hides the MathML annotation that carries the TeX source;
     * without it the source becomes visible text inside every button, which is
     * exactly what teachers complain about. Resolves once the sheet is applied
     * (or after a grace period so a slow stylesheet cannot stall the dialog).
     *
     * @param {HTMLLinkElement} link
     * @return {Promise}
     */
    function cssReady(link) {
        return new Promise(function(resolve) {
            if (!link) { resolve(); return; }
            if (link.sheet) { resolve(); return; }

            var settled = false;
            var done = function() {
                if (settled) { return; }
                settled = true;
                resolve();
            };
            link.addEventListener('load', done);
            link.addEventListener('error', done);
            setTimeout(done, 3000);
        });
    }

    /**
     * Inject katex.min.css + katex.min.js once. Resolves with window.katex
     * (or null when none of the candidate locations could be loaded).
     *
     * @return {Promise}
     */
    function preload() {
        ensureStandardsMode();

        if (window.katex) {
            if (!loadedBase) { loadedBase = candidateBases()[0]; }
            // Belt and braces: make sure the sheet that hides the MathML
            // annotation is requested even when katex itself came from cache.
            injectCss(getCssUrl(), '0');
            return Promise.resolve(window.katex);
        }
        if (katexPromise) { return katexPromise; }

        var bases = candidateBases();

        katexPromise = new Promise(function(resolve) {
            var attempt = 0;

            function fail(message) {
                loadFailed = true;
                if (typeof console !== 'undefined' && console.warn) {
                    console.warn('[mod_slides] ' + message);
                }
                resolve(null);
            }

            function tryNext() {
                if (attempt >= bases.length) {
                    fail('KaTeX no se pudo cargar. Probado en: ' + bases.join(' | '));
                    return;
                }

                var index = attempt++;
                var base = bases[index];
                var css = injectCss(base + '/katex.min.css', String(index));

                var script = document.createElement('script');
                script.src = base + '/katex.min.js';
                script.onload = function() {
                    if (!window.katex) {
                        // Script ran but did not expose katex: try the next base.
                        tryNext();
                        return;
                    }
                    // Only hand katex over once its stylesheet is applied, so
                    // the first painted formula is never unstyled (an unstyled
                    // KaTeX node shows its hidden TeX annotation as plain text).
                    cssReady(css).then(function() {
                        loadedBase = base;
                        loadFailed = false;
                        resolve(window.katex);
                    });
                };
                script.onerror = function() {
                    if (script.parentNode) { script.parentNode.removeChild(script); }
                    if (css.parentNode) { css.parentNode.removeChild(css); }
                    tryNext();
                };
                document.head.appendChild(script);
            }

            tryNext();
        });
        return katexPromise;
    }

    /** Run fn once katex is available (immediately when it already is). */
    function whenReady(fn) {
        preload().then(function() { fn(); });
    }

    /** True when katex could not be loaded from any candidate location. */
    function hasFailed() {
        return loadFailed;
    }

    function escapeHtml(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    /**
     * Render TeX to an HTML string (synchronous). Falls back to the escaped
     * source while katex is still loading — callers re-render after whenReady.
     *
     * @param {String} tex
     * @return {String}
     */
    function renderHtml(tex) {
        tex = tex || '';
        if (window.katex) {
            try {
                return window.katex.renderToString(tex, {
                    throwOnError: false,
                    displayMode: false,
                    trust: false,
                });
            } catch (e) { /* fall through to the text fallback */ }
        }
        return '<span class="eq-fallback">' + escapeHtml(tex) + '</span>';
    }

    /* ======================================================================
     *  Element type (registered with the editor canvas + properties panel)
     * ====================================================================== */

    function cssClass() {
        return 'slide-element--' + TYPE;
    }

    function justifyOf(align) {
        if (align === 'left') { return 'flex-start'; }
        if (align === 'right') { return 'flex-end'; }
        return 'center';
    }

    function inlineStyles(el) {
        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var style = 'position:absolute;left:' + el.x + 'px;top:' + el.y + 'px;' +
            'width:' + el.w + 'px;height:' + el.h + 'px;' +
            'display:flex;align-items:center;justify-content:' + justifyOf(el.align) + ';' +
            'font-size:' + (el.fontSize || 32) + 'px;color:' + (el.color || '#000000') + ';' +
            'text-align:' + (el.align || 'center') + ';' +
            'opacity:' + opacity + ';' +
            'transform-origin:center center;' +
            'line-height:1.2;box-sizing:border-box;overflow:hidden;';

        if (el.shadowEnabled) {
            style += 'box-shadow:' + (el.shadowX || 0) + 'px ' + (el.shadowY || 0) + 'px ' +
                (el.shadowBlur || 0) + 'px ' + (el.shadowColor || '#00000080') + ';';
        }
        return style;
    }

    function renderText(el) {
        return renderHtml(el.text || '');
    }

    var PROPERTY_DEFS = [
        { key: 'fontSize',        label: 'font-size',  control: 'fontsize' },
        { key: 'color',           label: 'color',      control: 'color' },
        { key: 'align',           label: 'alignment',  control: 'iconselect', options: [
            { value: 'left',    icon: 'align-left',    labelKey: 'left',    fallback: 'Left' },
            { value: 'center',  icon: 'align-center',  labelKey: 'center',  fallback: 'Center' },
            { value: 'right',   icon: 'align-right',   labelKey: 'right',   fallback: 'Right' },
        ]},
        { key: 'opacity',         label: 'opacity',     control: 'number', min: 0, max: 100, step: 5 },
        { key: 'shadowEnabled',   label: 'shadow-enabled', control: 'checkbox' },
        { key: 'shadowColor',     label: 'shadow-color',   control: 'color' },
        { key: 'shadowBlur',      label: 'shadow-blur',    control: 'number', min: 0, max: 50, step: 1 },
        { key: 'shadowX',         label: 'shadow-x',       control: 'number', min: -20, max: 20, step: 1 },
        { key: 'shadowY',         label: 'shadow-y',       control: 'number', min: -20, max: 20, step: 1 },
    ];

    /* ======================================================================
     *  LaTeX symbol tables
     * ====================================================================== */

    var TABS = [
        {
            id: 'operators',
            labelKey: 'eqtaboperators',
            symbols: [
                { tex: '\\cdot' }, { tex: '\\times' }, { tex: '\\div' },
                { tex: '\\pm' }, { tex: '\\mp' }, { tex: '\\neq' },
                { tex: '\\le' }, { tex: '\\ge' }, { tex: '\\approx' },
                { tex: '\\infty' }, { tex: '\\in' }, { tex: '\\notin' },
                { tex: '\\subset' }, { tex: '\\subseteq' }, { tex: '\\cup' },
                { tex: '\\cap' }, { tex: '\\forall' }, { tex: '\\exists' },
                { tex: '\\partial' }, { tex: '\\nabla' }, { tex: '\\propto' },
                { tex: '\\equiv' }, { tex: '\\sim' }, { tex: '\\oplus' },
                { tex: '\\otimes' }, { tex: '\\angle' }, { tex: '\\perp' },
                { tex: '\\parallel' }, { tex: '\\%'},
            ],
        },
        {
            id: 'arrows',
            labelKey: 'eqtabarrows',
            symbols: [
                { tex: '\\rightarrow' }, { tex: '\\leftarrow' },
                { tex: '\\Rightarrow' }, { tex: '\\Leftarrow' },
                { tex: '\\Leftrightarrow' }, { tex: '\\leftrightarrow' },
                { tex: '\\uparrow' }, { tex: '\\downarrow' },
                { tex: '\\updownarrow' }, { tex: '\\mapsto' },
                { tex: '\\longrightarrow' }, { tex: '\\longleftarrow' },
                { tex: '\\longleftrightarrow' }, { tex: '\\Longleftrightarrow' },
                { tex: '\\nearrow' }, { tex: '\\searrow' },
                { tex: '\\hookrightarrow' }, { tex: '\\rightharpoonup' },
            ],
        },
        {
            id: 'greek',
            labelKey: 'eqtabgreek',
            symbols: [
                { tex: '\\alpha' }, { tex: '\\beta' }, { tex: '\\gamma' },
                { tex: '\\delta' }, { tex: '\\epsilon' }, { tex: '\\zeta' },
                { tex: '\\eta' }, { tex: '\\theta' }, { tex: '\\iota' },
                { tex: '\\kappa' }, { tex: '\\lambda' }, { tex: '\\mu' },
                { tex: '\\nu' }, { tex: '\\xi' }, { tex: '\\pi' },
                { tex: '\\rho' }, { tex: '\\sigma' }, { tex: '\\tau' },
                { tex: '\\upsilon' }, { tex: '\\phi' }, { tex: '\\chi' },
                { tex: '\\psi' }, { tex: '\\omega' },
                { tex: '\\Gamma' }, { tex: '\\Delta' }, { tex: '\\Theta' },
                { tex: '\\Lambda' }, { tex: '\\Xi' }, { tex: '\\Pi' },
                { tex: '\\Sigma' }, { tex: '\\Phi' }, { tex: '\\Psi' },
                { tex: '\\Omega' },
            ],
        },
        {
            id: 'advanced',
            labelKey: 'eqtabadvanced',
            symbols: [
                { tex: '\\frac{a}{b}' }, { tex: '\\sqrt{x}' },
                { tex: '\\sqrt[3]{x}' }, { tex: 'x^{n}' }, { tex: 'x_{n}' },
                { tex: '\\int_{a}^{b}' }, { tex: '\\iint_{a}^{b}' },
                { tex: '\\sum_{i=1}^{n}' }, { tex: '\\prod_{i=1}^{n}' },
                { tex: '\\lim_{x \\to 0}' }, { tex: '\\frac{\\partial}{\\partial x}' },
                { tex: '\\sin' }, { tex: '\\cos' }, { tex: '\\tan' },
                { tex: '\\log' }, { tex: '\\ln' }, { tex: 'e^{x}' },
                { tex: '\\begin{pmatrix}a\\\\b\\end{pmatrix}' },
                { tex: '\\begin{bmatrix}a\\\\b\\end{bmatrix}' },
            ],
        },
    ];

    /* ======================================================================
     *  "+" secondary toolbar row
     * ====================================================================== */

    // Secondary toolbar tools. Extend with addMenuItem() from the app module.
    var MENU_ITEMS = [
        { id: 'equation', labelKey: 'addequation', icon: 'equation', handler: function() { openModal({}); } },
    ];

    var secondaryOpen = false;
    var secondaryAnchor = null;

    /**
     * Register an extra entry in the secondary toolbar row.
     *
     * @param {Object} item {id, labelKey, icon, handler}
     */
    function addMenuItem(item) {
        if (!item || !item.id) { return; }
        var pos = -1;
        MENU_ITEMS.forEach(function(existing, i) {
            if (existing.id === item.id) { pos = i; }
        });
        if (pos >= 0) {
            MENU_ITEMS[pos] = item;
        } else {
            MENU_ITEMS.push(item);
        }
        // Re-render if the secondary row is currently visible.
        if (secondaryOpen) {
            renderSecondary(secondaryAnchor);
        }
    }

    /**
     * Render the secondary toolbar row inside its container.
     *
     * @param {HTMLElement} anchor The "+" button (for aria-expanded).
     */
    function renderSecondary(anchor) {
        var container = document.getElementById('slides-secondary-toolbar');
        if (!container) { return; }

        container.innerHTML = '';
        container.hidden = false;

        MENU_ITEMS.forEach(function(item) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'slides-secondary-tool';
            btn.setAttribute('role', 'button');
            btn.setAttribute('aria-label', str(item.labelKey));
            btn.title = str(item.labelKey);
            btn.innerHTML = icons.get(item.icon, { size: 18 });
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                item.handler();
                // Row stays open — the "+" button is the sole toggle.
            });
            container.appendChild(btn);
        });
    }

    function closeSecondary() {
        var container = document.getElementById('slides-secondary-toolbar');
        if (!container) { return; }
        container.hidden = true;
        container.innerHTML = '';
        if (secondaryAnchor) {
            secondaryAnchor.setAttribute('aria-expanded', 'false');
        }
        secondaryOpen = false;
        secondaryAnchor = null;
        // Remove Escape handler
        if (escHandler) {
            document.removeEventListener('keydown', escHandler, true);
            escHandler = null;
        }
    }

    var escHandler = null;

    /**
     * Toggle the secondary toolbar row.
     *
     * @param {HTMLElement} anchor The "+" button.
     */
    function toggleSecondary(anchor) {
        if (!anchor) { return; }

        var container = document.getElementById('slides-secondary-toolbar');
        if (!container) { return; }

        if (secondaryOpen) {
            closeSecondary();
            return;
        }

        // Open
        secondaryOpen = true;
        secondaryAnchor = anchor;
        anchor.setAttribute('aria-expanded', 'true');
        renderSecondary(anchor);

        // Escape key closes the row
        escHandler = function(e) {
            if (e.key === 'Escape') {
                e.stopPropagation();
                e.preventDefault();
                closeSecondary();
                anchor.focus();
            }
        };
        document.addEventListener('keydown', escHandler, true);
    }

    /* ======================================================================
     *  Equation modal
     * ====================================================================== */

    var modalCtx = null;

    function closeModal() {
        if (!modalCtx) { return; }
        if (modalCtx.onDocKey) {
            document.removeEventListener('keydown', modalCtx.onDocKey, true);
        }
        if (modalCtx.backdrop && modalCtx.backdrop.parentNode) {
            modalCtx.backdrop.remove();
        }
        modalCtx = null;
    }

    /**
     * Insert `snippet` at the textarea caret (replacing the selection) and
     * leave the caret inside the first {...} placeholder when there is one.
     * When the textarea is not focused the last known caret (fallbackPos) wins,
     * so symbols still land where the user last typed.
     *
     * @param {HTMLTextAreaElement} ta
     * @param {String} snippet
     * @param {Number} [fallbackPos]
     */
    function insertAtCursor(ta, snippet, fallbackPos) {
        if (!ta) { return typeof fallbackPos === 'number' ? fallbackPos : 0; }
        var start = ta.selectionStart;
        var end = ta.selectionEnd;
        if (ta !== document.activeElement || typeof start !== 'number') {
            start = end = (typeof fallbackPos === 'number') ? fallbackPos : ta.value.length;
        }

        var before = ta.value.slice(0, start);
        var after = ta.value.slice(end);
        ta.value = before + snippet + after;

        var caret = before.length + snippet.length;
        var ph = (snippet.indexOf('\\begin') === -1) ? snippet.match(/\{[^{}]*\}/) : null;
        ta.focus();
        if (ph && ph[0].length > 2) {
            caret = before.length + ph.index + 1;
            ta.setSelectionRange(caret, caret + ph[0].length - 2);
        } else {
            ta.setSelectionRange(caret, caret);
        }

        var ev;
        try {
            ev = new Event('input', { bubbles: true });
        } catch (e) {
            ev = document.createEvent('Event');
            ev.initEvent('input', true, true);
        }
        ta.dispatchEvent(ev);

        // With the source hidden the textarea cannot report its own selection,
        // so callers must take the new caret from here and keep it in sync.
        return caret;
    }

    /**
     * Button content for a symbol. Teachers must never see the raw LaTeX
     * command here: while katex is not ready (or could not be loaded) the
     * button keeps a neutral placeholder instead of the source code.
     *
     * @param {Object} sym
     * @return {String} HTML
     */
    function symbolMarkup(sym) {
        if (window.katex) {
            try {
                return window.katex.renderToString(sym.tex, {
                    throwOnError: false,
                    displayMode: false,
                    trust: false,
                });
            } catch (e) { /* fall through to the placeholder */ }
        }
        return '<span class="eq-btn-placeholder" aria-hidden="true">&hellip;</span>';
    }

    /**
     * Open the equation editor.
     *
     * @param {Object} [opts]
     * @param {String} [opts.tex]      Prefilled TeX (edit mode when non-empty).
     * @param {Function} [opts.onApply] Called with the final TeX source.
     */
    function openModal(opts) {
        opts = opts || {};
        closeModal();

        var initialTex = opts.tex || '';
        var isEdit = !!initialTex;
        var savedCaret = initialTex.length;

        var backdrop = document.createElement('div');
        backdrop.className = 'eq-dialog-backdrop';

        var modal = document.createElement('div');
        modal.className = 'eq-dialog eq-dialog--equation';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-label', str('eqmodaltitle'));

        /* Header */
        var header = document.createElement('div');
        header.className = 'eq-header';
        var title = document.createElement('div');
        title.className = 'eq-title';
        title.textContent = str('eqmodaltitle');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'eq-close';
        closeBtn.setAttribute('aria-label', str('cancel'));
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', closeModal);
        header.appendChild(title);
        header.appendChild(closeBtn);
        modal.appendChild(header);

        /* Body */
        var body = document.createElement('div');
        body.className = 'eq-body';

        // KaTeX status line: never let the teacher read raw LaTeX instead of
        // symbols — show progress, then an explicit error if loading failed.
        var loadState = document.createElement('div');
        loadState.className = 'eq-loadstate';
        body.appendChild(loadState);

        // Tabs + symbol grids.
        var tabBar = document.createElement('div');
        tabBar.className = 'eq-tabs';
        tabBar.setAttribute('role', 'tablist');
        var panels = {};
        var tabBtns = {};
        var firstTabId = TABS[0].id;

        TABS.forEach(function(tab) {
            var tabBtn = document.createElement('button');
            tabBtn.type = 'button';
            tabBtn.className = 'eq-tab';
            tabBtn.setAttribute('role', 'tab');
            tabBtn.textContent = str(tab.labelKey);
            tabBtn.addEventListener('click', function() { activateTab(tab.id); });
            tabBtns[tab.id] = tabBtn;
            tabBar.appendChild(tabBtn);

            var grid = document.createElement('div');
            grid.className = 'eq-grid';
            grid.setAttribute('role', 'tabpanel');
            grid.style.display = 'none';
            tab.symbols.forEach(function(sym) {
                var sbtn = document.createElement('button');
                sbtn.type = 'button';
                sbtn.className = 'eq-btn';
                sbtn.title = sym.tex;
                sbtn.setAttribute('aria-label', sym.tex);
                sbtn.innerHTML = symbolMarkup(sym);
                sbtn.addEventListener('mousedown', function(e) {
                    // Keep the textarea selection alive while clicking a symbol.
                    e.preventDefault();
                });
                sbtn.addEventListener('click', function() {
                    savedCaret = insertAtCursor(input, sym.tex, savedCaret);
                });
                grid.appendChild(sbtn);
            });
            panels[tab.id] = grid;
            body.appendChild(grid);
        });
        body.insertBefore(tabBar, body.firstChild);

        function activateTab(id) {
            Object.keys(panels).forEach(function(k) {
                panels[k].style.display = (k === id) ? 'grid' : 'none';
                tabBtns[k].classList.toggle('is-active', k === id);
                tabBtns[k].setAttribute('aria-selected', k === id ? 'true' : 'false');
            });
        }

        /* Live preview (the formula the teacher is building) */
        var preview = document.createElement('div');
        preview.className = 'eq-preview';
        preview.setAttribute('role', 'status');
        preview.setAttribute('aria-label', str('eqpreviewlabel'));
        body.appendChild(preview);

        /* Source, hidden by default like Moodle's "Edit equation using TeX" */
        var texLink = document.createElement('button');
        texLink.type = 'button';
        texLink.className = 'eq-texlink';
        texLink.textContent = str('eqedittex');
        texLink.setAttribute('aria-expanded', 'false');
        body.appendChild(texLink);

        var sourceGroup = document.createElement('div');
        sourceGroup.className = 'eq-source';
        sourceGroup.style.display = 'none';
        var inputLabel = document.createElement('label');
        inputLabel.className = 'eq-label';
        inputLabel.setAttribute('for', 'eq-source-input');
        inputLabel.textContent = str('eqinputlabel');
        var input = document.createElement('textarea');
        input.id = 'eq-source-input';
        input.className = 'eq-input';
        input.value = initialTex;
        input.spellcheck = false;
        input.rows = 3;
        sourceGroup.appendChild(inputLabel);
        sourceGroup.appendChild(input);
        body.appendChild(sourceGroup);

        function isSourceOpen() {
            return sourceGroup.style.display !== 'none';
        }

        texLink.addEventListener('click', function() {
            var open = !isSourceOpen();
            sourceGroup.style.display = open ? 'block' : 'none';
            texLink.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (open) {
                input.focus();
                var pos = Math.min(savedCaret, input.value.length);
                input.setSelectionRange(pos, pos);
            } else {
                // Park the caret where the last symbol landed so the next one
                // still inserts at the right spot while the source is closed.
                savedCaret = Math.min(savedCaret, input.value.length);
                texLink.focus();
            }
            updateLoadState();
        });

        var errEl = document.createElement('div');
        errEl.className = 'eq-error';
        body.appendChild(errEl);

        modal.appendChild(body);

        /* Footer */
        var footer = document.createElement('div');
        footer.className = 'eq-footer';
        var cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.textContent = str('cancel');
        cancelBtn.addEventListener('click', closeModal);
        var applyBtn = document.createElement('button');
        applyBtn.type = 'button';
        applyBtn.className = 'btn btn-primary';
        applyBtn.textContent = str(isEdit ? 'equpdate' : 'eqinsert');
        applyBtn.addEventListener('click', apply);
        footer.appendChild(cancelBtn);
        footer.appendChild(applyBtn);
        modal.appendChild(footer);

        /* Wiring */
        function updateLoadState() {
            if (window.katex) {
                loadState.style.display = 'none';
                loadState.classList.remove('is-error');
                loadState.textContent = '';
                return;
            }
            loadState.style.display = 'block';
            loadState.classList.toggle('is-error', hasFailed());
            loadState.textContent = str(hasFailed() ? 'eqloaderror' : 'eqloading');
        }

        function renderPreview() {
            errEl.textContent = '';

            // Renderer first: while katex is missing the teacher gets an
            // explanation (progress / failure), never the LaTeX source.
            if (!window.katex) {
                preview.classList.remove('is-error');
                preview.innerHTML = '<span class="' + (hasFailed() ? 'eq-loaderror' : 'eq-loading') + '">' +
                    escapeHtml(str(hasFailed() ? 'eqloaderror' : 'eqloading')) + '</span>';
                return;
            }

            var tex = (input.value || '').trim();
            if (!tex) {
                preview.classList.remove('is-error');
                preview.innerHTML = '<span class="eq-preview-empty">' +
                    escapeHtml(str('eqpreviewempty')) + '</span>';
                return;
            }
            try {
                window.katex.render(tex, preview, {
                    throwOnError: false,
                    displayMode: true,
                    trust: false,
                });
                preview.classList.toggle('is-error', !!preview.querySelector('.katex-error'));
            } catch (e) {
                preview.classList.add('is-error');
                preview.textContent = e.message || String(e);
            }
        }

        function apply() {
            var tex = (input.value || '').trim();
            if (!tex) {
                errEl.textContent = str('eqempty');
                if (!isSourceOpen()) {
                    texLink.click();
                } else {
                    input.focus();
                }
                return;
            }
            var handler = opts.onApply || defaultApply;
            closeModal();
            handler(tex);
        }

        input.addEventListener('input', renderPreview);
        // Remember the caret so symbols still insert at the right spot after
        // the focus has moved to a tab or a symbol button.
        ['click', 'keyup', 'select', 'input'].forEach(function(evt) {
            input.addEventListener(evt, function() {
                if (typeof input.selectionStart === 'number') {
                    savedCaret = input.selectionStart;
                }
            });
        });
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                apply();
            }
        });

        modal.addEventListener('click', function(e) { e.stopPropagation(); });
        backdrop.addEventListener('click', closeModal);

        document.body.appendChild(backdrop);
        backdrop.appendChild(modal);

        // Escape / editor shortcuts must not leak through the modal.
        modalCtx = {
            backdrop: backdrop,
            onDocKey: function(e) {
                if (e.key === 'Escape') {
                    e.stopPropagation();
                    e.preventDefault();
                    closeModal();
                    return;
                }
                var tag = e.target && e.target.tagName;
                if (tag === 'TEXTAREA' || tag === 'INPUT') { return; }
                if (e.key === 'Delete' || e.key === 'Backspace' ||
                        e.key.indexOf('Arrow') === 0 || e.key === 'PageUp' || e.key === 'PageDown') {
                    e.stopPropagation();
                }
            },
        };
        document.addEventListener('keydown', modalCtx.onDocKey, true);

        activateTab(firstTabId);
        updateLoadState();
        renderPreview();

        // Repaint grids + preview once katex finishes loading (or report why
        // it could not be loaded at all).
        whenReady(function() {
            if (!modalCtx || modalCtx.backdrop !== backdrop) { return; }
            TABS.forEach(function(tab) {
                var grid = panels[tab.id];
                var btns = grid.querySelectorAll('.eq-btn');
                tab.symbols.forEach(function(sym, i) {
                    if (btns[i]) { btns[i].innerHTML = symbolMarkup(sym); }
                });
            });
            updateLoadState();
            renderPreview();
        });

        // The source starts hidden, so focus the tabs instead of a textarea
        // the teacher cannot see (skip on touch where the keyboard stays away).
        if (!window.matchMedia('(pointer: coarse)').matches) {
            if (tabBtns[firstTabId]) { tabBtns[firstTabId].focus(); }
        }
    }

    /** Default action for a brand-new equation: centre it on the active slide. */
    function defaultApply(tex) {
        var canvas = document.getElementById('editor-canvas');
        var canvasH = (canvas && parseInt(canvas.dataset.height, 10)) || 540;
        var w = DEFAULTS.w;
        var h = DEFAULTS.h;
        state.addElement(state.get().current, Object.assign({}, DEFAULTS, {
            text: tex,
            x: Math.round((960 - w) / 2),
            y: Math.round((canvasH - h) / 2),
        }));
    }

    return {
        type: TYPE,
        DEFAULTS: DEFAULTS,
        cssClass: cssClass,
        inlineStyles: inlineStyles,
        renderText: renderText,
        PROPERTY_DEFS: PROPERTY_DEFS,

        // KaTeX loading / rendering.
        preload: preload,
        whenReady: whenReady,
        renderHtml: renderHtml,
        getCssUrl: getCssUrl,
        hasFailed: hasFailed,

        // Toolbar secondary row.
        toggleSecondary: toggleSecondary,
        addMenuItem: addMenuItem,

        // Modal.
        openModal: openModal,
        closeModal: closeModal,
        insertAtCursor: insertAtCursor,
    };
});
