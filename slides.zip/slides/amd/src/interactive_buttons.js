/**
 * Interactive action buttons (Genially-style): catalog of action buttons,
 * configuration modal and execution hook for the viewer.
 *
 * Action elements carry:
 *   type: 'action'
 *   actionId: catalog id
 *   slideIdx: slide the button lives on
 *   x / y / w / h: canvas geometry
 *   label: display label
 *   bg: background color
 *   behavior: { kind: 'slide' | 'url' | 'label', slide?: int, url?: string,
 *               text?: string, img?: string, video?: string }
 *
 * @module     mod_slides/interactive_buttons
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/shapes_library'], function(state, shapesLib) {
    'use strict';

    var CANVAS_W = 960;

    // Photo-bank opener injected by the editor app; the viewer never loads
    // the bank, it only renders what is already stored in the behaviour.
    var imagePicker = null;
    // Video recorder opener injected by the editor app (Record → Upload flow
    // reused as a picker for label videos). Never loaded by the viewer.
    var videoRecorder = null;

    var ACTIONS = [
        /* Navigation (kind: slide). */
        { id: 'nav-home', cat: 'nav', icon: 'home', kind: 'slide', slide: 0, label: 'Iniciar', bg: '#0d6efd', text: 'Ir al inicio' },
        { id: 'nav-menu', cat: 'nav', icon: 'menu', kind: 'slide', slide: 0, label: 'Men\u00fa', bg: '#343a40', text: 'Ir al men\u00fa' },
        { id: 'nav-back', cat: 'nav', icon: 'undo', kind: 'slide', slide: -1, label: 'Atr\u00e1s', bg: '#6c757d', text: 'Volver' },
        { id: 'nav-prev', cat: 'nav', icon: 'prev', kind: 'slide', slide: -2, label: 'Anterior', bg: '#6c757d', text: 'Diapositiva anterior' },
        { id: 'nav-next', cat: 'nav', icon: 'next', kind: 'slide', slide: -3, label: 'Siguiente', bg: '#6c757d', text: 'Diapositiva siguiente' },
        { id: 'nav-first', cat: 'nav', icon: 'first', kind: 'slide', slide: 0, label: 'Primero', bg: '#6c757d', text: 'Ir a la primera diapositiva' },
        { id: 'nav-last', cat: 'nav', icon: 'last', kind: 'slide', label: '\u00daltimo', bg: '#6c757d', text: 'Ir a la \u00faltima diapositiva' },
        { id: 'nav-arrowright', cat: 'nav', icon: 'arrowright', kind: 'slide', slide: -3, label: 'Derecha', bg: '#495057', text: 'Diapositiva siguiente' },
        { id: 'nav-arrowleft', cat: 'nav', icon: 'arrowleft', kind: 'slide', slide: -2, label: 'Izquierda', bg: '#495057', text: 'Diapositiva anterior' },
        { id: 'nav-arrowup', cat: 'nav', icon: 'arrowup', kind: 'slide', slide: 0, label: 'Arriba', bg: '#495057', text: 'Ir al inicio' },
        { id: 'nav-arrowdown', cat: 'nav', icon: 'arrowdown', kind: 'slide', label: 'Abajo', bg: '#495057', text: 'Ir al final' },
        { id: 'nav-close', cat: 'nav', icon: 'close', kind: 'label', label: 'Cerrar', bg: '#dc3545', text: 'Contenido finalizado.' },
        { id: 'nav-plus', cat: 'nav', icon: 'plus', kind: 'label', label: 'A\u00f1adir', bg: '#28a745', text: 'Pulsa para a\u00f1adir contenido.' },
        { id: 'nav-minus', cat: 'nav', icon: 'minus', kind: 'label', label: 'Quitar', bg: '#6c757d', text: 'Contenido reducido.' },
        /* Information / content actions (floating label card). */
        { id: 'act-info', cat: 'info', icon: 'info', kind: 'label', text: 'Esta diapositiva incluye informaci\u00f3n.', label: 'Info', bg: '#17a2b8' },
        { id: 'act-question', cat: 'info', icon: 'question', kind: 'label', text: '\u00bfQu\u00e9 te gustar\u00eda saber?', label: 'Pregunta', bg: '#ffc107' },
        { id: 'act-exclamation', cat: 'info', icon: 'exclamation', kind: 'label', text: '\u00a1Cuidado! Contenido importante.', label: '\u00a1Cuidado!', bg: '#dc3545' },
        { id: 'act-more', cat: 'info', icon: 'more', kind: 'label', text: 'Pulsa para ver m\u00e1s contenido.', label: 'M\u00e1s', bg: '#6f42c1' },
        { id: 'act-location', cat: 'info', icon: 'location', kind: 'url', url: 'https://maps.google.com/?q=ejemplo', label: 'Ubicaci\u00f3n', bg: '#fd7e14' },
        { id: 'act-star', cat: 'info', icon: 'star', kind: 'label', text: 'Marcado como favorito.', label: 'Favorito', bg: '#ffc107' },
        { id: 'act-search', cat: 'info', icon: 'search', kind: 'label', text: 'Escribe aqu\u00ed lo que quieres buscar.', label: 'Buscar', bg: '#495057' },
        { id: 'act-quote', cat: 'info', icon: 'quote', kind: 'label', text: 'Cita destacada del contenido.', label: 'Cita', bg: '#6f42c1' },
        { id: 'act-tag', cat: 'info', icon: 'tag', kind: 'label', text: 'Etiqueta informativa.', label: 'Etiqueta', bg: '#20c997' },
        /* Multimedia actions. */
        { id: 'act-play', cat: 'media', icon: 'play', kind: 'url', url: 'https://www.ejemplo.com/reproducir', label: 'Reproducir', bg: '#e83e8c' },
        { id: 'act-image', cat: 'media', icon: 'image', kind: 'label', text: 'Muestra una imagen relacionada.', label: 'Imagen', bg: '#0d6efd' },
        { id: 'act-video', cat: 'media', icon: 'video', kind: 'label', text: 'Reproduce el v\u00eddeo de la lecci\u00f3n.', label: 'V\u00eddeo', bg: '#dc3545' },
        /* Action helpers. */
        { id: 'act-link', cat: 'action', icon: 'link', kind: 'url', url: 'https://www.ejemplo.com', label: 'Enlace', bg: '#dc3545' },
        { id: 'act-share', cat: 'action', icon: 'share', kind: 'label', text: 'Comparte este contenido.', label: 'Compartir', bg: '#0d6efd' },
        { id: 'act-attach', cat: 'action', icon: 'clip', kind: 'label', text: 'Archivo adjunto disponible.', label: 'Adjunto', bg: '#6c757d' },
        { id: 'act-phone', cat: 'action', icon: 'phone', kind: 'url', url: 'tel:+34000000000', label: 'Tel\u00e9fono', bg: '#20c997' },
        { id: 'act-mail', cat: 'action', icon: 'mail', kind: 'url', url: 'mailto:ejemplo@ejemplo.com', label: 'Correo', bg: '#0d6efd' },
        { id: 'act-chat', cat: 'action', icon: 'chat', kind: 'label', text: '\u00bfNecesitas ayuda? Escr\u00edbenos.', label: 'Chat', bg: '#20c997' },
        { id: 'act-check', cat: 'action', icon: 'check', kind: 'label', text: '\u00a1Respuesta correcta!', label: 'Correcto', bg: '#28a745' },
        /* Social media (kind: url). */
        { id: 'soc-facebook', cat: 'soc', icon: 'facebook', kind: 'url', url: 'https://www.facebook.com/', label: 'Facebook', bg: '#1877f2' },
        { id: 'soc-twitter', cat: 'soc', icon: 'twitter', kind: 'url', url: 'https://twitter.com/', label: 'X / Twitter', bg: '#111111' },
        { id: 'soc-instagram', cat: 'soc', icon: 'instagram', kind: 'url', url: 'https://www.instagram.com/', label: 'Instagram', bg: '#e1306c' },
        { id: 'soc-youtube', cat: 'soc', icon: 'youtube', kind: 'url', url: 'https://www.youtube.com/', label: 'YouTube', bg: '#ff0000' },
        { id: 'soc-whatsapp', cat: 'soc', icon: 'whatsapp', kind: 'url', url: 'https://wa.me/', label: 'WhatsApp', bg: '#25d366' },
        { id: 'soc-linkedin', cat: 'soc', icon: 'linkedin', kind: 'url', url: 'https://www.linkedin.com/', label: 'LinkedIn', bg: '#0a66c2' },
        { id: 'soc-tiktok', cat: 'soc', icon: 'tiktok', kind: 'url', url: 'https://www.tiktok.com/', label: 'TikTok', bg: '#111111' },
        { id: 'soc-pinterest', cat: 'soc', icon: 'pinterest', kind: 'url', url: 'https://www.pinterest.com/', label: 'Pinterest', bg: '#e60023' },
        { id: 'soc-telegram', cat: 'soc', icon: 'telegram', kind: 'url', url: 'https://t.me/', label: 'Telegram', bg: '#229ed9' },
    ];
    function str(key) {
        try { return M.util.get_string(key, 'mod_slides'); } catch (e) { return key; }
    }

    /**
     * Inject cross-module openers (photo bank and video recorder live in the
     * editor app so the viewer keeps no editor-only dependency).
     *
     * @param {{imagePicker: Function, videoRecorder: Function}} opts
     */
    function init(opts) {
        imagePicker = (opts && typeof opts.imagePicker === 'function') ? opts.imagePicker : null;
        videoRecorder = (opts && typeof opts.videoRecorder === 'function') ? opts.videoRecorder : null;
    }

    /**
     * Classify a stored video URL: YouTube links resolve to an embed URL,
     * anything else is treated as a direct file (pluginfile / uploaded webm…).
     *
     * @param {string} url
     * @return {{youtube: string|null, embed: string|null, file: string|null}}
     */
    function getVideoInfo(url) {
        var out = { youtube: null, embed: null, file: null };
        if (!url) { return out; }
        var id = null;
        // youtu.be/<id>
        var m = url.match(/youtu\.be\/([A-Za-z0-9_-]{6,})/i);
        // youtube.com/(watch?v=|embed/|shorts/|live/|v/)
        if (!m) { m = url.match(/youtube\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|shorts\/|live\/|v\/)([A-Za-z0-9_-]{6,})/i); }
        // youtube-nocookie.com/embed/<id>
        if (!m) { m = url.match(/youtube-nocookie\.com\/embed\/([A-Za-z0-9_-]{6,})/i); }
        if (m) {
            id = m[1];
            out.youtube = id;
            out.embed = 'https://www.youtube.com/embed/' + id;
        } else {
            out.file = url;
        }
        return out;
    }

    /**
     * Upload a local video file through the plugin endpoint (same FormData
     * contract as media_recorder: cmid + sesskey + media file).
     *
     * @param {File} file
     * @param {Function} onOk  called with the public URL
     * @param {Function} onErr called with an error message
     */
    function uploadVideoFile(file, onOk, onErr) {
        var root = document.getElementById('slides-editor');
        var cmid = parseInt(root && root.dataset.cmid, 10);
        var sesskey = (root && root.dataset.sesskey) || '';
        if (!cmid || !sesskey) {
            if (onErr) { onErr(str('recordererror')); }
            return;
        }
        var fd = new FormData();
        fd.append('cmid', cmid);
        fd.append('sesskey', sesskey);
        fd.append('media', file, file.name || ('video_' + Date.now()));

        var xhr = new XMLHttpRequest();
        try {
            xhr.open('POST', M.cfg.wwwroot + '/mod/slides/classes/local/media_upload_ajax.php', true);
        } catch (ex) {
            if (onErr) { onErr(str('recordererror')); }
            return;
        }
        xhr.timeout = 120000;
        xhr.onload = function() {
            var resp = null;
            try { resp = JSON.parse(xhr.responseText || ''); } catch (e) { /* ignore */ }
            if (xhr.status === 200 && resp && resp.url) {
                if (onOk) { onOk(resp.url); }
            } else if (onErr) {
                onErr((resp && resp.error) || (str('recordererror') + ' — HTTP ' + xhr.status));
            }
        };
        xhr.onerror = function() { if (onErr) { onErr(str('recordererror') + ' — network'); } };
        xhr.ontimeout = function() { if (onErr) { onErr(str('recordererror') + ' — timeout'); } };
        try {
            xhr.send(fd);
        } catch (ex) {
            if (onErr) { onErr(str('recordererror')); }
        }
    }

    function iconMarkup(name, size) {
        size = size || 20;
        var bodies = {
            /* Navigation. */
            home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
            menu: '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
            prev: '<path d="m15 6-6 6 6 6"/>',
            next: '<path d="m9 6 6 6-6 6"/>',
            first: '<path d="M18 18 10 12l8-6z" fill="currentColor" stroke="none"/><path d="M6 6v12"/>',
            last: '<path d="m6 6 8 6-8 6z" fill="currentColor" stroke="none"/><path d="M18 6v12"/>',
            undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5A5.5 5.5 0 0 1 20 14.5 5.5 5.5 0 0 1 14.5 20H11"/>',
            arrowright: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
            arrowleft: '<path d="M19 12H5"/><path d="m11 18-6-6 6-6"/>',
            arrowup: '<path d="M12 19V5"/><path d="m6 11 6-6 6 6"/>',
            arrowdown: '<path d="M12 5v14"/><path d="m6 13 6 6 6-6"/>',
            close: '<path d="M18 6 6 18"/><path d="M6 6l12 12"/>',
            plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
            minus: '<path d="M5 12h14"/>',
            /* Information. */
            info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-5"/><path d="M12 8h.01"/>',
            question: '<circle cx="12" cy="12" r="10"/><path d="M9.5 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/>',
            exclamation: '<path d="M10.3 3 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
            more: '<circle cx="5" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.2" fill="currentColor" stroke="none"/>',
            eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
            location: '<path d="M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
            star: '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>',
            search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
            clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
            bulb: '<path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.1V18h6v-1.2c0-.8.4-1.6 1-2.1A7 7 0 0 0 12 2z"/>',
            quote: '<path d="M10 11H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v6a4 4 0 0 1-4 4"/><path d="M20 11h-4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v6a4 4 0 0 1-4 4"/>',
            bookmark: '<path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
            tag: '<path d="M20.59 13.41 12 22l-9-9V3h10l7.59 7.59a2 2 0 0 1 0 2.82z"/><circle cx="7.5" cy="7.5" r="1" fill="currentColor" stroke="none"/>',
            pin: '<path d="M12 17v5"/><path d="M9 10.76V3h6v7.76a3 3 0 0 0 .88 2.12l1.12 1.12H7l1.12-1.12A3 3 0 0 0 9 10.76z"/>',
            /* Multimedia. */
            play: '<path d="M6 4l14 8-14 8z"/>',
            pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
            stop: '<rect x="5" y="5" width="14" height="14" rx="2"/>',
            volume: '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>',
            mute: '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="m22 9-6 6"/><path d="m16 9 6 6"/>',
            image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
            video: '<path d="m23 7-7 5 7 5z"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
            music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
            mic: '<rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10v1a7 7 0 0 1-14 0v-1"/><path d="M12 18v4"/><path d="M8 22h8"/>',
            camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
            /* Actions. */
            link: '<path d="M10 13a4 4 0 0 0 6.36.36l3-3a4 4 0 0 0-5.66-5.66l-1.72 1.73"/><path d="M14 11a4 4 0 0 0-6.36-.36l-3 3a4 4 0 0 0 5.66 5.66l1.72-1.73"/>',
            settings: '<circle cx="12" cy="12" r="3.5"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 14.4 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1.82.33l.06.06a2 2 0 0 1-2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82z',
            download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
            upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
            share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.59 13.51 6.83 3.98"/><path d="m15.41 6.51-6.82 3.98"/>',
            clip: '<path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
            send: '<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
            edit: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
            print: '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
            fullscreen: '<path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/>',
            refresh: '<path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10"/><path d="M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
            lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
            unlock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
            phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>',
            mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 7L2 7"/>',
            chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
            cart: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
            check: '<path d="M20 6 9 17l-5-5"/>',
            trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
            /* Social media (brand marks, simplified). */
            facebook: '<path fill="currentColor" stroke="none" d="M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4z"/>',
            twitter: '<path fill="currentColor" stroke="none" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>',
            instagram: '<rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><path d="M17.5 6.5h.01"/>',
            youtube: '<path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33 2.78 2.78 0 0 0 1.94 2c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.33 29 29 0 0 0-.46-5.33z"/><path d="m9.75 15.02 6.5-3.27-6.5-3.27z"/>',
            whatsapp: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8z"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
            linkedin: '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>',
            tiktok: '<path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/>',
            pinterest: '<circle cx="12" cy="12" r="10"/><path d="M8.5 13.5 10 8.5"/><path d="M12 7.5a3 3 0 0 1 3 3c0 2.4-1.4 4-3 4-.7 0-1.4-.3-1.9-.7"/>',
            telegram: '<path d="m21.5 3.5-19 7 6.5 2.5 2.5 6.5z"/><path d="M21.5 3.5 9 13"/>',
        };
        var body = bodies[name] || bodies.link;
        return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" ' +
            'fill="none" stroke="currentColor" stroke-width="1.75" ' +
            'stroke-linecap="round" stroke-linejoin="round" ' +
            'aria-hidden="true" focusable="false">' + body + '</svg>';
    }

    function actionIcon(a) {
        if (a && a.icon) { return a.icon; }
        var base = (a.id || '').replace(/^nav-/, '').replace(/^act-/, '').replace(/^soc-/, '');
        var map = {
            home: 'home', menu: 'menu', back: 'undo', prev: 'prev', next: 'next',
            info: 'info', question: 'question', exclamation: 'exclamation', more: 'more',
            link: 'link', location: 'location', settings: 'settings', play: 'play', view: 'eye',
        };
        return map[base] || base;
    }
    function getAction(id) {
        for (var i = 0; i < ACTIONS.length; i++) {
            if (ACTIONS[i].id === id) { return ACTIONS[i]; }
        }
        return ACTIONS[0];
    }

    // Full shape catalog usable as button silhouettes ("line" excluded).
    var SHAPE_KEYS = Object.keys(shapesLib.SHAPES).filter(function(key) {
        return key !== 'line';
    });

    /**
     * Shared inner styling for action buttons (editor + viewer): background,
     * text colour and silhouette from the chosen shape. Legacy buttons
     * without a shape (or plain 'rect') keep the border-radius look.
     *
     * @param {Object} el
     * @return {string} CSS declarations for the button box.
     */
    function buttonInnerStyle(el) {
        var style = 'background:' + (el.bg || '#0d6efd') + ';' +
            'color:' + (el.color || '#ffffff') + ';' +
            'display:flex;align-items:center;justify-content:center;' +
            'box-sizing:border-box;';
        var def = el.shape ? shapesLib.SHAPES[el.shape] : null;
        if (el.shape && el.shape !== 'rect' && def) {
            style += 'border-radius:0;' + def.clip;
        } else {
            style += 'border-radius:' + (el.borderRadius || 10) + 'px;';
        }
        return style;
    }

    /**
     * Icon markup for an action button element — the catalog thumbnails are
     * circular icons, so created buttons show the icon (the label becomes
     * the hover tooltip). Returns '' when the id is unknown so callers can
     * fall back to plain label text.
     *
     * @param {Object} el
     * @return {string} SVG markup or ''.
     */
    function buttonIconHtml(el) {
        if (!el) { return ''; }
        var key = null;
        if (el.actionId) {
            var a = getAction(el.actionId);
            if (a && a.id === el.actionId) { key = a.icon || actionIcon(a); }
        }
        if (!key && typeof el.icon === 'string' && el.icon) { key = el.icon; }
        if (!key) { return ''; }
        var size = Math.max(18, Math.min(48, Math.round((el.h || 64) * 0.42)));
        return iconMarkup(key, size);
    }

    function createFromCatalog(actionId, slideIdx) {
        var a = getAction(actionId);
        var s = state.get();
        var idx = (typeof slideIdx === 'number') ? slideIdx : s.current;
        var el = {
            type: 'action',
            actionId: actionId,
            slideIdx: idx,
            x: Math.round((CANVAS_W - 220) / 2),
            y: 120,
            w: 220,
            h: 64,
            label: a.label || '',
            bg: a.bg || '#0d6efd',
            shape: 'circle',
            behavior: {
                kind: a.kind || 'label',
                slide: (a.kind === 'slide') ? ((a.slide === undefined || a.slide === null) ? idx : a.slide) : undefined,
                url: (a.kind === 'url') ? (a.url || '') : undefined,
                text: (a.kind === 'label') ? (a.text || '') : undefined,
                img: (a.kind === 'label') ? '' : undefined,
            },
        };
        if (a.id === 'nav-prev' || a.id === 'nav-arrowleft') { el.behavior.slide = Math.max(0, idx - 1); }
        if (a.id === 'nav-next' || a.id === 'nav-arrowright') { el.behavior.slide = idx + 1; }
        if (a.id === 'nav-last' || a.id === 'nav-arrowdown') { el.behavior.slide = Math.max(0, (s.slides || []).length - 1); }
        state.addElement(idx, el);
        return el;
    }

    function openCatalog(opts) {
        opts = opts || {};
        var s = state.get();
        var idx = (typeof opts.slideIdx === 'number') ? opts.slideIdx : s.current;

        var backdrop = document.createElement('div');
        backdrop.className = 'ib-backdrop';
        var modal = document.createElement('div');
        modal.className = 'ib-modal ib-modal--catalog';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');

        var header = document.createElement('div');
        header.className = 'ib-header';
        var title = document.createElement('div');
        title.className = 'ib-title';
        title.textContent = str('ibmodaltitle');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'btn btn-sm btn-secondary';
        closeBtn.textContent = str('cancel');
        closeBtn.addEventListener('click', close);
        header.appendChild(title);
        header.appendChild(closeBtn);
        modal.appendChild(header);

        var body = document.createElement('div');
        body.className = 'ib-body';

        /* Search box (Genially-style "Buscar elemento"). */
        var searchInput = document.createElement('input');
        searchInput.type = 'search';
        searchInput.className = 'ib-search';
        searchInput.placeholder = str('ibsearch');
        searchInput.setAttribute('aria-label', str('ibsearch'));
        body.appendChild(searchInput);

        /* Category tabs. */
        var cats = [
            ['all', 'ibcat-all'],
            ['nav', 'ibcat-nav'],
            ['info', 'ibcat-info'],
            ['media', 'ibcat-media'],
            ['action', 'ibcat-actions'],
            ['soc', 'ibcat-social'],
        ];
        var activeCat = 'all';
        var tabBtns = {};
        var tabsWrap = document.createElement('div');
        tabsWrap.className = 'ib-tabs';
        cats.forEach(function(pair) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'ib-tab' + (pair[0] === activeCat ? ' is-active' : '');
            b.textContent = str(pair[1]);
            b.addEventListener('click', function() {
                if (tabBtns[activeCat]) { tabBtns[activeCat].classList.remove('is-active'); }
                activeCat = pair[0];
                b.classList.add('is-active');
                renderGrid();
            });
            tabBtns[pair[0]] = b;
            tabsWrap.appendChild(b);
        });
        body.appendChild(tabsWrap);

        /* Circular icon grid. */
        var grid = document.createElement('div');
        grid.className = 'ib-grid ib-grid--icons';
        body.appendChild(grid);

        function normalize(txt) {
            var t = (txt || '').toLowerCase();
            try { return t.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) { return t; }
        }

        function renderGrid() {
            grid.textContent = '';
            var q = normalize(searchInput.value);
            var shown = 0;
            ACTIONS.forEach(function(a) {
                if (activeCat !== 'all' && a.cat !== activeCat) { return; }
                if (q && normalize(a.label).indexOf(q) === -1) { return; }
                shown++;
                var item = document.createElement('button');
                item.type = 'button';
                item.className = 'ib-item ib-item--circle';
                item.title = a.label;
                var circle = document.createElement('span');
                circle.className = 'ib-item-circle';
                circle.style.background = a.bg;
                circle.innerHTML = iconMarkup(actionIcon(a), 20);
                var label = document.createElement('span');
                label.className = 'ib-item-label';
                label.textContent = a.label;
                item.appendChild(circle);
                item.appendChild(label);
                item.addEventListener('click', function() {
                    createFromCatalog(a.id, idx);
                    close();
                    openConfig({ slideIdx: idx, elemIdx: state.get().selected });
                });
                grid.appendChild(item);
            });
            if (!shown) {
                var empty = document.createElement('div');
                empty.className = 'ib-empty';
                empty.textContent = str('ibnoresults');
                grid.appendChild(empty);
            }
        }
        searchInput.addEventListener('input', renderGrid);
        renderGrid();

        modal.appendChild(body);

        backdrop.addEventListener('click', close);
        document.body.appendChild(backdrop);
        backdrop.appendChild(modal);
        modal.addEventListener('click', function(e) { e.stopPropagation(); });
        try { searchInput.focus(); } catch (ignore) { /* focus is best-effort */ }

        function close() {
            if (backdrop.parentNode) { backdrop.parentNode.removeChild(backdrop); }
            if (modal.parentNode) { modal.parentNode.removeChild(modal); }
        }

        return { close: close };
    }
    function openConfig(opts) {
        opts = opts || {};
        var slideIdx = (typeof opts.slideIdx === 'number') ? opts.slideIdx : state.get().current;
        var elemIdx = (typeof opts.elemIdx === 'number') ? opts.elemIdx : state.selected;
        var slide = (state.get().slides || [])[slideIdx];
        var el = (slide && slide.elements) ? slide.elements[elemIdx] : null;
        if (!el || el.type !== 'action') { return null; }

        var backdrop = document.createElement('div');
        backdrop.className = 'ib-backdrop';
        var modal = document.createElement('div');
        modal.className = 'ib-modal';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');

        var header = document.createElement('div');
        header.className = 'ib-header';
        var title = document.createElement('div');
        title.className = 'ib-title';
        title.textContent = str('ibmodaltitle');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'btn btn-sm btn-secondary';
        closeBtn.textContent = str('cancel');
        closeBtn.addEventListener('click', close);
        header.appendChild(title);
        header.appendChild(closeBtn);
        modal.appendChild(header);

        var body = document.createElement('div');
        body.className = 'ib-body';

        var labelWrap = document.createElement('div');
        labelWrap.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
        var labelLbl = document.createElement('label');
        labelLbl.textContent = str('lbltext');
        labelLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        var labelInput = document.createElement('input');
        labelInput.type = 'text';
        labelInput.value = el.label || '';
        labelInput.style.cssText = 'padding:8px 10px;border:1px solid #ced4da;border-radius:6px;font-size:14px;outline:none;';
        labelWrap.appendChild(labelLbl);
        labelWrap.appendChild(labelInput);
        body.appendChild(labelWrap);

        var kindWrap = document.createElement('div');
        kindWrap.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
        var kindLbl = document.createElement('label');
        kindLbl.textContent = str('ibkind');
        kindLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        var kindSel = document.createElement('select');
        kindSel.style.cssText = 'padding:8px 10px;border:1px solid #ced4da;border-radius:6px;font-size:14px;outline:none;background:#fff;';
        [['slide', 'ibkind-slide'], ['url', 'ibkind-url'], ['label', 'ibkind-label']].forEach(function(p) {
            var o = document.createElement('option');
            o.value = p[0];
            o.textContent = str(p[1]);
            kindSel.appendChild(o);
        });
        kindSel.value = (el.behavior && el.behavior.kind) || 'label';
        kindWrap.appendChild(kindLbl);
        kindWrap.appendChild(kindSel);
        body.appendChild(kindWrap);

        var extraWrap = document.createElement('div');
        extraWrap.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
        var extraSel = document.createElement('select');
        extraSel.style.cssText = 'padding:8px 10px;border:1px solid #ced4da;border-radius:6px;font-size:14px;outline:none;background:#fff;';
        var slideCount = (state.get().slides || []).length;
        for (var si = 0; si < slideCount; si++) {
            var so = document.createElement('option');
            so.value = String(si);
            so.textContent = str('slide' + (si + 1));
            extraSel.appendChild(so);
        }
        extraSel.value = String((typeof el.behavior.slide === 'number') ? el.behavior.slide : 0);
        var extraLbl = document.createElement('label');
        extraLbl.textContent = str('ibtarget');
        extraLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        extraWrap.appendChild(extraLbl);
        extraWrap.appendChild(extraSel);
        body.appendChild(extraWrap);

        var urlWrap = document.createElement('div');
        urlWrap.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
        var urlLbl = document.createElement('label');
        urlLbl.textContent = str('iburl');
        urlLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        var urlInput = document.createElement('input');
        urlInput.type = 'text';
        urlInput.value = (el.behavior && el.behavior.url) || '';
        urlInput.style.cssText = 'padding:8px 10px;border:1px solid #ced4da;border-radius:6px;font-size:14px;outline:none;';
        urlWrap.appendChild(urlLbl);
        urlWrap.appendChild(urlInput);
        body.appendChild(urlWrap);

        var textWrap = document.createElement('div');
        textWrap.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
        var textLbl = document.createElement('label');
        textLbl.textContent = str('ibtext');
        textLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        var textArea = document.createElement('textarea');
        textArea.rows = 3;
        textArea.value = (el.behavior && el.behavior.text) || el.label || '';
        textArea.style.cssText = 'padding:8px 10px;border:1px solid #ced4da;border-radius:6px;font-size:14px;outline:none;resize:vertical;';
        textWrap.appendChild(textLbl);
        textWrap.appendChild(textArea);
        body.appendChild(textWrap);

        /* Label extras: photo from the bank (kind = label only). */
        var imgWrap = document.createElement('div');
        imgWrap.style.cssText = 'display:flex;flex-direction:column;gap:6px;';
        var imgLbl = document.createElement('label');
        imgLbl.textContent = str('ibimg');
        imgLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        imgWrap.appendChild(imgLbl);
        var imgRow = document.createElement('div');
        imgRow.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
        var imgPickBtn = document.createElement('button');
        imgPickBtn.type = 'button';
        imgPickBtn.className = 'btn btn-sm btn-secondary';
        imgPickBtn.textContent = str('ibimgselect');
        var imgThumb = document.createElement('img');
        imgThumb.style.cssText = 'max-width:72px;max-height:48px;border:1px solid #ced4da;border-radius:6px;display:none;object-fit:contain;';
        var imgRmBtn = document.createElement('button');
        imgRmBtn.type = 'button';
        imgRmBtn.className = 'btn btn-sm btn-outline-danger';
        imgRmBtn.textContent = str('ibimgrm');
        imgRmBtn.style.display = 'none';
        var imgVal = (el.behavior && el.behavior.img) ? el.behavior.img : '';
        function syncImgPreview() {
            if (imgVal) {
                imgThumb.src = imgVal;
                imgThumb.style.display = 'block';
                imgRmBtn.style.display = 'inline-block';
            } else {
                imgThumb.style.display = 'none';
                imgRmBtn.style.display = 'none';
            }
        }
        syncImgPreview();
        imgPickBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (!imagePicker) { return; }
            imagePicker({
                onSelect: function(srcUrl) {
                    imgVal = srcUrl || '';
                    syncImgPreview();
                },
            });
        });
        imgRmBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            imgVal = '';
            syncImgPreview();
        });
        imgRow.appendChild(imgPickBtn);
        imgRow.appendChild(imgThumb);
        imgRow.appendChild(imgRmBtn);
        imgWrap.appendChild(imgRow);
        body.appendChild(imgWrap);

        /* Label extras: video for the popup (kind = label only). Priority over
           the photo in the viewer. Sources: pasted YouTube link, direct URL,
           local file upload or the embedded recorder. */
        var vidWrap = document.createElement('div');
        vidWrap.style.cssText = 'display:flex;flex-direction:column;gap:6px;';
        var vidLbl = document.createElement('label');
        vidLbl.textContent = str('ibvideo');
        vidLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        vidWrap.appendChild(vidLbl);
        var vidRow = document.createElement('div');
        vidRow.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
        var vidUrlInput = document.createElement('input');
        vidUrlInput.type = 'text';
        vidUrlInput.placeholder = str('ibvideourl');
        vidUrlInput.value = (el.behavior && el.behavior.video) ? el.behavior.video : '';
        vidUrlInput.style.cssText = 'flex:1 1 180px;min-width:140px;padding:7px 10px;border:1px solid #ced4da;border-radius:6px;font-size:13px;outline:none;';
        var vidFileBtn = document.createElement('button');
        vidFileBtn.type = 'button';
        vidFileBtn.className = 'btn btn-sm btn-secondary';
        vidFileBtn.textContent = str('ibuploadvideo');
        var vidFileInput = document.createElement('input');
        vidFileInput.type = 'file';
        vidFileInput.accept = 'video/webm,video/mp4,video/ogg,video/*';
        vidFileInput.style.display = 'none';
        var vidRecBtn = document.createElement('button');
        vidRecBtn.type = 'button';
        vidRecBtn.className = 'btn btn-sm btn-secondary';
        vidRecBtn.textContent = str('recordvideo');
        if (!videoRecorder) { vidRecBtn.style.display = 'none'; }
        var vidThumb = document.createElement('div');
        vidThumb.className = 'ib-video-thumb';
        vidThumb.style.display = 'none';
        var vidRmBtn = document.createElement('button');
        vidRmBtn.type = 'button';
        vidRmBtn.className = 'btn btn-sm btn-outline-danger';
        vidRmBtn.textContent = str('ibvideorm');
        vidRmBtn.style.display = 'none';

        var videoVal = (el.behavior && el.behavior.video) ? el.behavior.video : '';
        function syncVideoPreview() {
            vidThumb.innerHTML = '';
            if (!videoVal) {
                vidThumb.style.display = 'none';
                vidRmBtn.style.display = 'none';
                return;
            }
            vidThumb.style.display = 'inline-flex';
            vidRmBtn.style.display = 'inline-block';
            var info = getVideoInfo(videoVal);
            if (info.youtube) {
                vidThumb.classList.add('ib-video-thumb--yt');
                vidThumb.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="#fff" aria-hidden="true"><path d="M8 5.5v13l11-6.5z"/></svg>';
            } else {
                vidThumb.classList.remove('ib-video-thumb--yt');
                var pv = document.createElement('video');
                pv.src = videoVal;
                pv.preload = 'metadata';
                pv.muted = true;
                pv.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;pointer-events:none;';
                vidThumb.appendChild(pv);
            }
        }
        syncVideoPreview();

        vidUrlInput.addEventListener('input', function() {
            videoVal = vidUrlInput.value.trim();
            syncVideoPreview();
        });
        vidFileBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            vidFileInput.click();
        });
        vidFileInput.addEventListener('change', function() {
            var f = vidFileInput.files && vidFileInput.files[0];
            if (!f) { return; }
            vidFileBtn.disabled = true;
            vidFileBtn.textContent = str('recorderuploading');
            uploadVideoFile(f, function(url) {
                vidFileBtn.disabled = false;
                vidFileBtn.textContent = str('ibuploadvideo');
                videoVal = url;
                vidUrlInput.value = url;
                syncVideoPreview();
            }, function(err) {
                vidFileBtn.disabled = false;
                vidFileBtn.textContent = str('ibuploadvideo');
                vidFileBtn.title = err || str('recordererror');
                window.setTimeout(function() { vidFileBtn.title = ''; }, 4000);
            });
            vidFileInput.value = '';
        });
        vidRecBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (!videoRecorder) { return; }
            videoRecorder({
                onInsert: function(url) {
                    videoVal = url || '';
                    vidUrlInput.value = videoVal;
                    syncVideoPreview();
                },
            });
        });
        vidRmBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            videoVal = '';
            vidUrlInput.value = '';
            syncVideoPreview();
        });
        vidRow.appendChild(vidUrlInput);
        vidRow.appendChild(vidFileBtn);
        vidRow.appendChild(vidRecBtn);
        vidRow.appendChild(vidThumb);
        vidRow.appendChild(vidRmBtn);
        vidWrap.appendChild(vidRow);
        body.appendChild(vidWrap);

        var geomWrap = document.createElement('div');
        geomWrap.style.cssText = 'display:flex;gap:8px;';
        var bgInput = document.createElement('input');
        bgInput.type = 'color';
        bgInput.value = el.bg || '#0d6efd';
        bgInput.style.cssText = 'width:44px;height:32px;border:1px solid #ced4da;border-radius:6px;padding:2px;';
        var wInput = document.createElement('input');
        wInput.type = 'number';
        wInput.value = String(el.w || 220);
        wInput.style.cssText = 'width:70px;padding:6px;border:1px solid #ced4da;border-radius:6px;font-size:13px;';
        var hInput = document.createElement('input');
        hInput.type = 'number';
        hInput.value = String(el.h || 64);
        hInput.style.cssText = 'width:70px;padding:6px;border:1px solid #ced4da;border-radius:6px;font-size:13px;';
        geomWrap.appendChild(bgInput);
        geomWrap.appendChild(wInput);
        geomWrap.appendChild(hInput);
        body.appendChild(geomWrap);

        /* Shape picker (visual grid — full catalog minus "line"). */
        var shapeVal = (el.shape && shapesLib.SHAPES[el.shape]) ? el.shape : 'roundedrect';
        var shapeItems = {};
        var shapeWrap = document.createElement('div');
        shapeWrap.style.cssText = 'display:flex;flex-direction:column;gap:6px;';
        var shapeLbl = document.createElement('label');
        shapeLbl.textContent = str('ibshape');
        shapeLbl.style.cssText = 'font-size:12px;font-weight:600;color:#495057;';
        shapeWrap.appendChild(shapeLbl);
        var shapeGrid = document.createElement('div');
        shapeGrid.className = 'ib-shape-grid';
        SHAPE_KEYS.forEach(function(key) {
            var item = document.createElement('div');
            item.className = 'ib-shape-item';
            item.title = str('shape-' + key);
            var thumb = document.createElement('div');
            thumb.className = 'ib-shape-thumb';
            thumb.style.cssText = shapesLib.thumbStyle(key, bgInput.value || el.bg || '#0d6efd');
            item.appendChild(thumb);
            var nameEl = document.createElement('div');
            nameEl.className = 'ib-shape-name';
            nameEl.textContent = str('shape-' + key);
            item.appendChild(nameEl);
            item.addEventListener('click', function() {
                if (shapeItems[shapeVal]) { shapeItems[shapeVal].classList.remove('is-active'); }
                shapeVal = key;
                item.classList.add('is-active');
            });
            shapeItems[key] = item;
            shapeGrid.appendChild(item);
        });
        shapeWrap.appendChild(shapeGrid);
        body.appendChild(shapeWrap);
        if (shapeItems[shapeVal]) { shapeItems[shapeVal].classList.add('is-active'); }
        bgInput.addEventListener('input', function() {
            Object.keys(shapeItems).forEach(function(k) {
                var t = shapeItems[k].querySelector('.ib-shape-thumb');
                if (t) { t.style.cssText = shapesLib.thumbStyle(k, bgInput.value); }
            });
        });

        /* Only the fields that belong to the chosen behaviour kind. */
        function syncKind() {
            var kind = kindSel.value;
            extraWrap.style.display = (kind === 'slide') ? '' : 'none';
            urlWrap.style.display = (kind === 'url') ? '' : 'none';
            textWrap.style.display = (kind === 'label') ? '' : 'none';
            imgWrap.style.display = (kind === 'label') ? '' : 'none';
            vidWrap.style.display = (kind === 'label') ? '' : 'none';
        }
        kindSel.addEventListener('change', syncKind);
        syncKind();

        modal.appendChild(body);
        backdrop.addEventListener('click', close);
        document.body.appendChild(backdrop);
        backdrop.appendChild(modal);
        modal.addEventListener('click', function(e) { e.stopPropagation(); });

        function close() {
            if (backdrop && backdrop.parentNode) { backdrop.parentNode.removeChild(backdrop); }
            if (modal && modal.parentNode) { modal.parentNode.removeChild(modal); }
        }

        function save() {
            var behavior = { kind: kindSel.value };
            if (behavior.kind === 'slide') { behavior.slide = parseInt(extraSel.value, 10) || 0; }
            if (behavior.kind === 'url') { behavior.url = urlInput.value.trim(); }
            if (behavior.kind === 'label') {
                behavior.text = textArea.value;
                behavior.img = imgVal;
                behavior.video = videoVal;
            }
            state.updateElementAtomic(slideIdx, elemIdx, {
                behavior: behavior,
                label: labelInput.value,
                bg: bgInput ? bgInput.value : (el.bg || '#0d6efd'),
                shape: shapeVal,
                w: Math.max(40, parseInt(wInput.value, 10) || el.w || 220),
                h: Math.max(24, parseInt(hInput.value, 10) || el.h || 64),
            });
            close();
        }

        var footer = document.createElement('div');
        footer.className = 'ib-footer';
        footer.style.cssText = 'display:flex;justify-content:flex-end;gap:8px;padding:12px 18px;background:#f8f9fa;border-top:1px solid #e9ecef;';
        var cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.textContent = str('cancel');
        cancelBtn.style.cssText = 'padding:7px 16px;font-size:13px;';
        cancelBtn.addEventListener('click', close);
        var saveBtn = document.createElement('button');
        saveBtn.type = 'button';
        saveBtn.className = 'btn btn-primary';
        saveBtn.textContent = str('save');
        saveBtn.style.cssText = 'padding:7px 16px;font-size:13px;';
        saveBtn.addEventListener('click', save);
        footer.appendChild(cancelBtn);
        footer.appendChild(saveBtn);
        modal.appendChild(footer);

        var saveBtnRef = saveBtn;
        modal.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') { e.stopPropagation(); close(); }
            if (e.key === 'Enter') { e.preventDefault(); saveBtnRef.click(); }
        });

        return { close: close };
    }

    function renderToolbar(canvasEl, el, slideIdx, elemIdx) {
        var bar = document.createElement('div');
        bar.className = 'element-action-toolbar';

        var chip = document.createElement('span');
        chip.className = 'element-action-chip';
        chip.textContent = '\uD83D\uDD17';
        chip.title = str('ibaction');
        bar.appendChild(chip);

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-sm btn-secondary element-link-btn';
        btn.textContent = str('ibconfig');
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            openConfig({ slideIdx: slideIdx, elemIdx: elemIdx });
        });
        bar.appendChild(btn);

        bar.addEventListener('pointerdown', function(e) { e.stopPropagation(); });
        bar.addEventListener('click', function(e) { e.stopPropagation(); });

        var top = (el.y >= 40) ? el.y - 40 : el.y + el.h + 8;
        bar.style.left = Math.max(0, Math.min(el.x, CANVAS_W - 210)) + 'px';
        bar.style.top = top + 'px';
        canvasEl.appendChild(bar);

        return { node: bar, update: function(liveEl) { bar.style.left = Math.max(0, Math.min(liveEl.x, CANVAS_W - 210)) + 'px'; bar.style.top = ((liveEl.y >= 40 ? liveEl.y : liveEl.y + liveEl.h + 8)) + 'px'; } };
    }

    function run(el, api) {
        var b = (el && el.behavior) || {};
        if (b.kind === 'slide') {
            if (typeof api.goTo === 'function') { api.goTo(b.slide || 0, 'user'); }
            return;
        }
        if (b.kind === 'url') {
            if (typeof api.open === 'function') { api.open(b.url || '', '_blank'); }
            return;
        }
        if (b.kind === 'label') {
            if (typeof api.showLabel === 'function') { api.showLabel(b.text || '', b.img || '', b.video || ''); }
        }
    }

    return {
        ACTIONS: ACTIONS,
        init: init,
        buttonInnerStyle: buttonInnerStyle,
        buttonIconHtml: buttonIconHtml,
        getAction: getAction,
        createFromCatalog: createFromCatalog,
        openCatalog: openCatalog,
        openConfig: openConfig,
        renderToolbar: renderToolbar,
        run: run,
        getVideoInfo: getVideoInfo,
    };
});
