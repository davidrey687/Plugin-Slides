/**
 * Background helper — converts background objects to CSS strings.
 * Supports solid, linear-gradient, radial-gradient, and image.
 *
 * @module     mod_slides/editorBackground
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    /**
     * Convert a background object to a CSS background string.
     * Handles legacy format {color, image} and new format with type.
     */
    function toCss(bg) {
        if (!bg) { return '#ffffff'; }

        if (!bg.type) {
            if (bg.image) {
                return 'url(' + bg.image + ') center/' + (bg.imageFit || 'cover') + ' no-repeat';
            }
            return bg.color || '#ffffff';
        }

        switch (bg.type) {
            case 'solid':
                return bg.color || '#ffffff';
            case 'linear-gradient':
                return buildLinearGradient(bg.gradient);
            case 'radial-gradient':
                return buildRadialGradient(bg.gradient);
            case 'image':
                if (!bg.image) { return bg.color || '#ffffff'; }
                var fit = bg.imageFit || 'cover';
                return 'url(' + bg.image + ') center/' + fit + ' no-repeat' +
                    (bg.color ? ', ' + bg.color : '');
            default:
                return bg.color || '#ffffff';
        }
    }

    /**
     * Build a CSS linear-gradient string from gradient config.
     */
    function buildLinearGradient(gradient) {
        if (!gradient || !gradient.stops || gradient.stops.length < 2) {
            return '#667eea';
        }
        var angle = gradient.angle || 135;
        var stopsStr = gradient.stops.map(function(s) {
            return s.color + ' ' + s.position + '%';
        }).join(', ');
        return 'linear-gradient(' + angle + 'deg, ' + stopsStr + ')';
    }

    /**
     * Build a CSS radial-gradient string from gradient config.
     */
    function buildRadialGradient(gradient) {
        if (!gradient || !gradient.stops || gradient.stops.length < 2) {
            return '#667eea';
        }
        var stopsStr = gradient.stops.map(function(s) {
            return s.color + ' ' + s.position + '%';
        }).join(', ');
        return 'radial-gradient(circle, ' + stopsStr + ')';
    }

    /**
     * Normalize a raw background value to the new format.
     * Ensures backward compatibility with legacy {color, image} format.
     */
    function normalize(raw) {
        if (!raw) { return { type: 'solid', color: '#ffffff' }; }
        if (raw.type) { return raw; }
        if (raw.image) {
            return {
                type: 'image',
                color: raw.color || '#ffffff',
                image: raw.image,
                imageFit: raw.imageFit || 'cover',
            };
        }
        return { type: 'solid', color: raw.color || '#ffffff' };
    }

    function solid(color) {
        return { type: 'solid', color: color || '#ffffff' };
    }

    function linearGradient(color1, color2, angle) {
        return {
            type: 'linear-gradient',
            gradient: {
                angle: angle || 135,
                stops: [
                    { color: color1 || '#667eea', position: 0 },
                    { color: color2 || '#764ba2', position: 100 },
                ],
            },
        };
    }

    return {
        toCss: toCss,
        normalize: normalize,
        solid: solid,
        linearGradient: linearGradient,
        buildLinearGradient: buildLinearGradient,
        buildRadialGradient: buildRadialGradient,
    };
});
