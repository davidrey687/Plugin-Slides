/**
 * Layers panel — shows element stack in reverse order with visibility, lock, drag reorder.
 *
 * @module     mod_slides/editorLayers
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/editorIcons'], function(state, icons) {
    'use strict';

    var container = null;
    var listEl = null;
    var dragFromIdx = -1;

    var TYPE_LABELS = {
        text: 'type-text', shape: 'type-shape', pencil: 'type-pencil',
        image: 'type-image', video: 'type-video', audio: 'type-audio', footer: 'addfooter', chart: 'addchart',
        link: 'type-link', pdf: 'type-pdf', equation: 'type-equation', html: 'type-html',
    };

    function str(key) {
        return M.util.get_string(key, 'mod_slides');
    }

    function init(c) {
        container = c;
        listEl = container;

        // Delegated events
        listEl.addEventListener('click', handleClick);
        listEl.addEventListener('dblclick', handleDblClick);
        listEl.addEventListener('dragstart', handleDragStart);
        listEl.addEventListener('dragover', handleDragOver);
        listEl.addEventListener('dragleave', handleDragLeave);
        listEl.addEventListener('drop', handleDrop);
        listEl.addEventListener('dragend', handleDragEnd);

        state.subscribe(render);
        render();
    }

    function render() {
        var s = state.get();
        listEl.innerHTML = '';

        var slide = s.slides[s.current];
        if (!slide) { return; }

        var elements = slide.elements || [];
        // Render in reverse order (top layer first)
        for (var i = elements.length - 1; i >= 0; i--) {
            var el = elements[i];
            var item = createLayerItem(el, i, s);
            listEl.appendChild(item);
        }
    }

    function createLayerItem(el, idx, s) {
        var item = document.createElement('div');
        item.className = 'layer-item' + (idx === s.selected ? ' is-selected' : '');
        if (el._visible === false) { item.classList.add('is-hidden-layer'); }
        if (el._locked) { item.classList.add('is-locked'); }
        item.dataset.idx = idx;
        item.draggable = true;

        // Type icon
        var icon = document.createElement('span');
        icon.className = 'layer-icon';
        icon.innerHTML = icons.get(el.type || 'text', {size: 16}) || icons.get('text', {size: 16});
        item.appendChild(icon);

        // Name
        var name = document.createElement('span');
        name.className = 'layer-name';
        var layerName = el._layerName || el.text || str(TYPE_LABELS[el.type] || 'properties');
        if (el.type === 'shape') {
            try { layerName = el._layerName || M.util.get_string('shape-' + (el.shape || 'rect'), 'mod_slides'); }
            catch (e) { layerName = el._layerName || 'Shape'; }
        }
        if (el.type === 'chart') {
            try { layerName = el._layerName || M.util.get_string('addchart', 'mod_slides'); }
            catch (e) { layerName = el._layerName || 'Chart'; }
        }
        if (el.type === 'footer') {
            try { layerName = el._layerName || M.util.get_string('addfooter', 'mod_slides'); }
            catch (e) { layerName = el._layerName || 'Footer'; }
        }
        if (el.type === 'equation') {
            // Never show the LaTeX source in the layer list: teachers do not
            // read \frac{a}{b}. Renaming still wins when it exists.
            layerName = el._layerName || str('type-equation');
        }
        if (el.type === 'html') {
            // Same rule as equations: raw markup is unreadable in the list.
            layerName = el._layerName || str('type-html');
        }
        if (el.type === 'audio') {
            // Prefer the original filename (alt) over the generic type label.
            layerName = el._layerName || el.alt || str('type-audio');
        }
        // Truncate long names
        if (layerName.length > 18) { layerName = layerName.substring(0, 16) + '\u2026'; }
        name.textContent = layerName;
        item.appendChild(name);

        // Spacer
        var spacer = document.createElement('span');
        spacer.style.cssText = 'flex:1;';
        item.appendChild(spacer);

        // Visibility toggle
        var visBtn = document.createElement('button');
        visBtn.className = 'layer-vis';
        visBtn.innerHTML = icons.get(el._visible === false ? 'eye-closed' : 'eye-open', {size: 16});
        visBtn.title = str('layer-visibility');
        visBtn.dataset.action = 'visibility';
        visBtn.dataset.layerIdx = idx;
        item.appendChild(visBtn);

        // Lock toggle
        var lockBtn = document.createElement('button');
        lockBtn.className = 'layer-lock';
        lockBtn.innerHTML = icons.get(el._locked ? 'lock-closed' : 'lock-open', {size: 16});
        lockBtn.title = str('layer-lock');
        lockBtn.dataset.action = 'lock';
        lockBtn.dataset.layerIdx = idx;
        item.appendChild(lockBtn);

        return item;
    }

    function handleClick(e) {
        var btn = e.target.closest('[data-action]');
        if (btn) {
            e.stopPropagation();
            var action = btn.dataset.action;
            var layerIdx = parseInt(btn.dataset.layerIdx, 10);
            var s = state.get();

            if (action === 'visibility') {
                state.toggleLayerVisibility(s.current, layerIdx);
            } else if (action === 'lock') {
                state.toggleLayerLock(s.current, layerIdx);
            }
            return;
        }

        // Click on layer item — select element
        var item = e.target.closest('.layer-item');
        if (item) {
            var idx = parseInt(item.dataset.idx, 10);
            var s2 = state.get();
            var el = s2.slides[s2.current].elements[idx];
            if (el && el._locked) { return; }
            state.selectElement(idx);
        }
    }

    function handleDblClick(e) {
        var item = e.target.closest('.layer-item');
        if (!item) { return; }
        var idx = parseInt(item.dataset.idx, 10);
        startRename(idx, item);
    }

    function startRename(idx, item) {
        var s = state.get();
        var el = s.slides[s.current].elements[idx];
        if (!el) { return; }

        var nameEl = item.querySelector('.layer-name');
        if (!nameEl) { return; }

        var currentName = el._layerName || '';
        var input = document.createElement('input');
        input.type = 'text';
        input.value = currentName;
        input.style.cssText = 'width:100%;padding:1px 3px;border:1px solid #0d6efd;border-radius:2px;font-size:11px;outline:none;';
        nameEl.textContent = '';
        nameEl.appendChild(input);
        input.focus();
        input.select();

        var committed = false;

        function commit() {
            if (committed) { return; }
            committed = true;
            var newName = input.value.trim();
            state.updateElementAtomic(s.current, idx, { _layerName: newName });
        }

        input.addEventListener('blur', commit);
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); commit(); }
            if (e.key === 'Escape') { committed = true; state.notify(); }
        });
    }

    /* ---- Drag & Drop reorder ---- */
    function handleDragStart(e) {
        var item = e.target.closest('.layer-item');
        if (!item) { return; }
        dragFromIdx = parseInt(item.dataset.idx, 10);
        item.classList.add('is-dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', dragFromIdx.toString());
    }

    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        clearDropIndicators();
        var item = e.target.closest('.layer-item');
        if (!item) { return; }
        var rect = item.getBoundingClientRect();
        var midY = rect.top + rect.height / 2;
        if (e.clientY < midY) {
            item.classList.add('drop-above');
        } else {
            item.classList.add('drop-below');
        }
    }

    function handleDragLeave(e) {
        var item = e.target.closest('.layer-item');
        if (item) {
            item.classList.remove('drop-above', 'drop-below');
        }
    }

    function handleDrop(e) {
        e.preventDefault();
        clearDropIndicators();
        if (dragFromIdx < 0) { return; }

        var item = e.target.closest('.layer-item');
        if (!item) { return; }
        var toIdx = parseInt(item.dataset.idx, 10);

        var rect = item.getBoundingClientRect();
        var midY = rect.top + rect.height / 2;
        if (e.clientY >= midY && toIdx > 0) {
            // Dropped below
        } else if (e.clientY < midY) {
            // Dropped above — in reverse list, this means toIdx is the target
        }

        if (dragFromIdx !== toIdx) {
            state.moveLayer(state.get().current, dragFromIdx, toIdx);
        }
    }

    function handleDragEnd() {
        clearDropIndicators();
        dragFromIdx = -1;
        var dragging = listEl.querySelector('.is-dragging');
        if (dragging) { dragging.classList.remove('is-dragging'); }
    }

    function clearDropIndicators() {
        var old = listEl.querySelectorAll('.drop-above, .drop-below');
        for (var i = 0; i < old.length; i++) {
            old[i].classList.remove('drop-above', 'drop-below');
        }
    }

    return { init: init };
});
