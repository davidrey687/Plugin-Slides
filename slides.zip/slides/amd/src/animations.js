/**
 * Click-to-reveal animations (PowerPoint-style).
 *
 * Editor side: a modal that assigns an appearance order (1, 2, 3...) and an
 * effect (appear / fade / slide-up) to the elements of the active slide.
 * The canvas paints a small [n] badge on every animated element.
 *
 * Viewer side: the controller invoked by viewer.js — hides animated elements
 * on slide load and reveals them one step per click / arrow key, falling back
 * to slide navigation when the sequence is exhausted.
 *
 * Fields travel with every element type (like opacity):
 *   animOrder — 0 = not animated, 1..N = appearance sequence
 *   animType  — 'appear' | 'fade' | 'up'
 *
 * @module     mod_slides/animations
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState'], function(state) {
    'use strict';

    var TYPE_LABELS = {
        text: 'type-text', shape: 'type-shape', pencil: 'type-pencil',
        image: 'type-image', video: 'type-video', audio: 'type-audio',
        footer: 'addfooter', chart: 'addchart', link: 'type-link',
        pdf: 'type-pdf', equation: 'type-equation', html: 'type-html',
    };

    function str(key) {
        try { return M.util.get_string(key, 'mod_slides'); } catch (e) { return key; }
    }

    /* ======================================================================
     *  Viewer controller
     * ====================================================================== */

    var canvasRef = null;
    var currentStep = 0;
    var maxStep = 0;

    /**
     * Hide every animated element of a freshly rendered slide.
     *
     * Nodes are matched with the visible elements in render order (the same
     * loop that skips ` _visible === false` elements).
     *
     * @param {HTMLElement} slideDiv Slide container just built by the viewer.
     * @param {Object} slide Slide data (elements array).
     */
    function prepareSlide(slideDiv, slide) {
        canvasRef = slideDiv && slideDiv.parentNode ? slideDiv.parentNode : null;
        currentStep = 0;
        maxStep = 0;
        if (!slideDiv) { return; }
        var nodes = slideDiv.children;
        var ni = 0;
        (slide.elements || []).forEach(function(el) {
            if (el._visible === false) { return; }
            var node = nodes[ni++];
            if (!node) { return; }
            var order = el.animOrder || 0;
            if (order <= 0) { return; }
            node.classList.add('slide-el--anim-hidden');
            node.setAttribute('data-anim-order', String(order));
            node.setAttribute('data-anim-type', el.animType || 'appear');
            var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
            node.style.setProperty('--anim-final', opacity);
            if (order > maxStep) { maxStep = order; }
        });
    }

    /**
     * Resolve the slide canvas used as the query root for reveal/recede.
     * Falls back to a document query when prepareSlide ran before the slide
     * was attached (defence against call-order regressions).
     *
     * @return {HTMLElement|null}
     */
    function resolveCanvas() {
        if (canvasRef && canvasRef.isConnected) { return canvasRef; }
        canvasRef = document.querySelector('#slides-viewer .slides-canvas');
        return canvasRef;
    }

    function revealStep(step) {
        var rootEl = resolveCanvas();
        if (!rootEl) { return; }
        var nodes = rootEl.querySelectorAll('[data-anim-order="' + step + '"]');
        for (var i = 0; i < nodes.length; i++) {
            var n = nodes[i];
            n.classList.remove('slide-el--anim-hidden');
            var type = n.getAttribute('data-anim-type') || 'appear';
            if (type === 'fade') {
                n.classList.add('slide-anim--fade');
                hookCleanup(n);
            } else if (type === 'up') {
                n.classList.add('slide-anim--up');
                hookCleanup(n);
            }
            // 'appear' reveals instantly (no animation class).
        }
    }

    function hookCleanup(node) {
        var cleanup = function() {
            node.classList.remove('slide-anim--fade', 'slide-anim--up');
            node.removeEventListener('animationend', cleanup);
        };
        node.addEventListener('animationend', cleanup);
    }

    /**
     * Advance one animation step.
     *
     * @return {Boolean} true when a step was consumed (caller must not
     *                   navigate to another slide).
     */
    function advance() {
        if (currentStep >= maxStep) { return false; }
        currentStep++;
        revealStep(currentStep);
        return true;
    }

    /**
     * Revert one animation step (hide the current step again, instantly).
     *
     * @return {Boolean} true when a step was reverted.
     */
    function recede() {
        var rootEl = currentStep > 0 ? resolveCanvas() : null;
        if (currentStep <= 0 || !rootEl) { return false; }
        var nodes = rootEl.querySelectorAll('[data-anim-order="' + currentStep + '"]');
        for (var i = 0; i < nodes.length; i++) {
            nodes[i].classList.remove('slide-anim--fade', 'slide-anim--up');
            nodes[i].classList.add('slide-el--anim-hidden');
        }
        currentStep--;
        return true;
    }

    /** @return {Boolean} true while the current slide still has hidden steps. */
    function hasPending() {
        return currentStep < maxStep;
    }

    /** Reveal every remaining step at once (Home / End / jumps / auto-read). */
    function finishAll() {
        for (var s = currentStep + 1; s <= maxStep; s++) {
            revealStep(s);
        }
        currentStep = maxStep;
    }

    /* ======================================================================
     *  Editor modal
     * ====================================================================== */

    var modalCtx = null;
    var renderBodyRef = null;

    // The state store has no unsubscribe: register once and dispatch through
    // a null-able reference so only an open dialog re-renders.
    state.subscribe(function() {
        if (renderBodyRef) { renderBodyRef(); }
    });

    function closeModal() {
        renderBodyRef = null;
        if (!modalCtx) { return; }
        if (modalCtx.onDocKey) {
            document.removeEventListener('keydown', modalCtx.onDocKey, true);
        }
        if (modalCtx.backdrop && modalCtx.backdrop.parentNode) {
            modalCtx.backdrop.remove();
        }
        modalCtx = null;
    }

    /** Animated elements of a slide, sorted by (order, index). */
    function animatedList(slide) {
        var out = [];
        (slide.elements || []).forEach(function(el, idx) {
            if ((el.animOrder || 0) > 0) {
                out.push({ el: el, idx: idx, order: el.animOrder });
            }
        });
        out.sort(function(a, b) {
            return (a.order - b.order) || (a.idx - b.idx);
        });
        return out;
    }

    /** Next free order for a slide (max + 1, minimum 1). */
    function nextOrder(slide) {
        var max = 0;
        (slide.elements || []).forEach(function(el) {
            if ((el.animOrder || 0) > max) { max = el.animOrder; }
        });
        return max + 1;
    }

    /**
     * Renumber the sequence to a gapless 1..N.
     *
     * @param {Number} slideIdx Slide index.
     * @param {Boolean} [alreadySnapshotted] True when the caller already took
     *        an undo snapshot, so the first change must not snapshot again.
     */
    function compact(slideIdx, alreadySnapshotted) {
        var slide = state.get().slides[slideIdx];
        if (!slide) { return; }
        var list = animatedList(slide);
        var changes = [];
        list.forEach(function(entry, i) {
            if (entry.order !== i + 1) {
                changes.push({ idx: entry.idx, order: i + 1 });
            }
        });
        changes.forEach(function(c, i) {
            // First change snapshots (unless the caller already did), the
            // rest ride along: the whole renumber is one undo step.
            if (i === 0 && !alreadySnapshotted) {
                state.updateElementAtomic(slideIdx, c.idx, { animOrder: c.order });
            } else {
                state.updateElement(slideIdx, c.idx, { animOrder: c.order });
            }
        });
    }

    /** Assign or change the effect of the selected element. */
    function setType(slideIdx, elemIdx, type) {
        var slide = state.get().slides[slideIdx];
        var el = slide && slide.elements[elemIdx];
        if (!el) { return; }
        if (!type) {
            if ((el.animOrder || 0) > 0) {
                state.updateElementAtomic(slideIdx, elemIdx, { animOrder: 0, animType: '' });
                compact(slideIdx, true);
            }
            return;
        }
        if ((el.animOrder || 0) > 0) {
            state.updateElementAtomic(slideIdx, elemIdx, { animType: type });
        } else {
            state.updateElementAtomic(slideIdx, elemIdx, {
                animOrder: nextOrder(slide),
                animType: type,
            });
        }
    }

    /** Swap the order of an element with its neighbour in the sequence. */
    function moveSeq(slideIdx, elemIdx, dir) {
        var slide = state.get().slides[slideIdx];
        if (!slide) { return; }
        var list = animatedList(slide);
        var pos = -1;
        list.forEach(function(entry, i) {
            if (entry.idx === elemIdx) { pos = i; }
        });
        if (pos < 0) { return; }
        var other = pos + dir;
        if (other < 0 || other >= list.length) { return; }
        var a = list[pos];
        var b = list[other];
        // One snapshot for the pair: atomic for the first, plain for the second.
        state.updateElementAtomic(slideIdx, a.idx, { animOrder: b.order });
        state.updateElement(slideIdx, b.idx, { animOrder: a.order });
    }

    /** Remove the animation of one element (single undo + compact). */
    function removeAnim(slideIdx, elemIdx) {
        var slide = state.get().slides[slideIdx];
        var el = slide && slide.elements[elemIdx];
        if (!el || (el.animOrder || 0) <= 0) { return; }
        state.updateElementAtomic(slideIdx, elemIdx, { animOrder: 0, animType: '' });
        compact(slideIdx, true);
    }

    /** Remove every animation of the active slide (single undo step). */
    function clearAll(slideIdx) {
        var slide = state.get().slides[slideIdx];
        if (!slide) { return; }
        var list = animatedList(slide);
        if (!list.length) { return; }
        list.forEach(function(entry, i) {
            var props = { animOrder: 0, animType: '' };
            if (i === 0) {
                state.updateElementAtomic(slideIdx, entry.idx, props);
            } else {
                state.updateElement(slideIdx, entry.idx, props);
            }
        });
    }

    function elementLabel(el) {
        var name = el.text || el.alt || el.pdftitle || str(TYPE_LABELS[el.type] || 'properties');
        name = String(name).replace(/\s+/g, ' ').trim();
        if (name.length > 32) { name = name.slice(0, 31) + '…'; }
        return name;
    }

    function animTypeLabel(type) {
        if (type === 'fade') { return str('animfade'); }
        if (type === 'up') { return str('animup'); }
        return str('animappear');
    }

    /**
     * Open the animations dialog for the active slide.
     * Works on the selected element and exposes the full sequence list.
     */
    function openModal() {
        closeModal();

        var backdrop = document.createElement('div');
        backdrop.className = 'anim-dialog-backdrop';

        var modal = document.createElement('div');
        modal.className = 'anim-dialog';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-label', str('animmodaltitle'));

        /* Header */
        var header = document.createElement('div');
        header.className = 'anim-header';
        var title = document.createElement('div');
        title.className = 'anim-title';
        title.textContent = str('animmodaltitle');
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'anim-close';
        closeBtn.setAttribute('aria-label', str('cancel'));
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', closeModal);
        header.appendChild(title);
        header.appendChild(closeBtn);
        modal.appendChild(header);

        /* Body (rebuilt on every state change while the dialog is open) */
        var body = document.createElement('div');
        body.className = 'anim-body';
        modal.appendChild(body);

        /* Footer */
        var footer = document.createElement('div');
        footer.className = 'anim-footer';
        var clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'btn btn-secondary';
        clearBtn.textContent = str('animclearall');
        clearBtn.addEventListener('click', function() {
            clearAll(state.get().current);
        });
        var doneBtn = document.createElement('button');
        doneBtn.type = 'button';
        doneBtn.className = 'btn btn-primary';
        doneBtn.textContent = str('cancel');
        doneBtn.addEventListener('click', closeModal);
        footer.appendChild(clearBtn);
        footer.appendChild(doneBtn);
        modal.appendChild(footer);

        function renderBody() {
            var s = state.get();
            var slide = s.slides[s.current];
            body.innerHTML = '';
            if (!slide) { return; }

            /* -- Selected element ------------------------------------------- */
            var selLabel = document.createElement('div');
            selLabel.className = 'anim-section-label';
            selLabel.textContent = str('animselected');
            body.appendChild(selLabel);

            var selIdx = s.selected;
            var selEl = (selIdx !== null && selIdx !== undefined) ? slide.elements[selIdx] : null;

            if (!selEl) {
                var hint = document.createElement('p');
                hint.className = 'anim-hint';
                hint.textContent = str('animselecthint');
                body.appendChild(hint);
            } else {
                var selRow = document.createElement('div');
                selRow.className = 'anim-selected-row';
                var badge = document.createElement('span');
                badge.className = 'anim-seq-badge is-muted';
                badge.textContent = (selEl.animOrder || 0) > 0 ? '[' + selEl.animOrder + ']' : '[–]';
                var selName = document.createElement('span');
                selName.className = 'anim-selected-name';
                selName.textContent = elementLabel(selEl);
                selRow.appendChild(badge);
                selRow.appendChild(selName);
                body.appendChild(selRow);

                var typeSelect = document.createElement('select');
                typeSelect.className = 'anim-type-select';
                [
                    { value: '', label: str('animnone') },
                    { value: 'appear', label: str('animappear') },
                    { value: 'fade', label: str('animfade') },
                    { value: 'up', label: str('animup') },
                ].forEach(function(opt) {
                    var o = document.createElement('option');
                    o.value = opt.value;
                    o.textContent = opt.label;
                    typeSelect.appendChild(o);
                });
                typeSelect.value = selEl.animOrder > 0 ? (selEl.animType || 'appear') : '';
                typeSelect.addEventListener('change', function() {
                    setType(s.current, selIdx, typeSelect.value);
                });
                body.appendChild(typeSelect);

                var typeHint = document.createElement('p');
                typeHint.className = 'anim-hint';
                typeHint.textContent = str('animhint');
                body.appendChild(typeHint);
            }

            /* -- Sequence list ---------------------------------------------- */
            var seqLabel = document.createElement('div');
            seqLabel.className = 'anim-section-label';
            seqLabel.textContent = str('animsequence');
            body.appendChild(seqLabel);

            var list = animatedList(slide);
            if (!list.length) {
                var empty = document.createElement('p');
                empty.className = 'anim-hint';
                empty.textContent = str('animempty');
                body.appendChild(empty);
                return;
            }

            var ul = document.createElement('div');
            ul.className = 'anim-seq-list';
            list.forEach(function(entry, i) {
                var row = document.createElement('div');
                row.className = 'anim-seq-item';
                if (selIdx !== null && entry.idx === selIdx) {
                    row.classList.add('is-current');
                }

                var rowBadge = document.createElement('span');
                rowBadge.className = 'anim-seq-badge';
                rowBadge.textContent = '[' + (i + 1) + ']';
                var rowName = document.createElement('span');
                rowName.className = 'anim-seq-name';
                rowName.textContent = elementLabel(entry.el);
                var rowType = document.createElement('span');
                rowType.className = 'anim-seq-type';
                rowType.textContent = animTypeLabel(entry.el.animType);

                var actions = document.createElement('span');
                actions.className = 'anim-seq-actions';
                var upBtn = document.createElement('button');
                upBtn.type = 'button';
                upBtn.className = 'anim-seq-btn';
                upBtn.setAttribute('aria-label', str('animmoveup'));
                upBtn.title = str('animmoveup');
                upBtn.textContent = '↑';
                upBtn.disabled = (i === 0);
                upBtn.addEventListener('click', function() {
                    moveSeq(s.current, entry.idx, -1);
                });
                var downBtn = document.createElement('button');
                downBtn.type = 'button';
                downBtn.className = 'anim-seq-btn';
                downBtn.setAttribute('aria-label', str('animmovedown'));
                downBtn.title = str('animmovedown');
                downBtn.textContent = '↓';
                downBtn.disabled = (i === list.length - 1);
                downBtn.addEventListener('click', function() {
                    moveSeq(s.current, entry.idx, 1);
                });
                var delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.className = 'anim-seq-btn is-danger';
                delBtn.setAttribute('aria-label', str('animremove'));
                delBtn.title = str('animremove');
                delBtn.textContent = '✖';
                delBtn.addEventListener('click', function() {
                    removeAnim(s.current, entry.idx);
                });
                actions.appendChild(upBtn);
                actions.appendChild(downBtn);
                actions.appendChild(delBtn);

                // Clicking the row selects the element on the canvas.
                row.addEventListener('click', function(e) {
                    if (e.target && e.target.closest && e.target.closest('button')) { return; }
                    state.selectElement(entry.idx, false);
                });

                row.appendChild(rowBadge);
                row.appendChild(rowName);
                row.appendChild(rowType);
                row.appendChild(actions);
                ul.appendChild(row);
            });
            body.appendChild(ul);
        }

        modal.addEventListener('click', function(e) { e.stopPropagation(); });
        backdrop.addEventListener('click', closeModal);

        document.body.appendChild(backdrop);
        backdrop.appendChild(modal);

        // Escape / editor shortcuts must not leak through the modal.
        modalCtx = {
            backdrop: backdrop,
            onDocKey: function(e) {
                if (e.key === 'Escape') {
                    e.stopPropagation();
                    e.preventDefault();
                    closeModal();
                    return;
                }
                var tag = e.target && e.target.tagName;
                if (tag === 'TEXTAREA' || tag === 'INPUT' || tag === 'SELECT') { return; }
                if (e.key === 'Delete' || e.key === 'Backspace' ||
                        e.key.indexOf('Arrow') === 0 || e.key === 'PageUp' || e.key === 'PageDown') {
                    e.stopPropagation();
                }
            },
        };
        document.addEventListener('keydown', modalCtx.onDocKey, true);

        renderBody();
        // Keep the dialog in sync when the teacher selects another element,
        // switches slides or undoes while it is open.
        renderBodyRef = renderBody;
    }

    return {
        // Editor.
        openModal: openModal,
        closeModal: closeModal,
        // Viewer.
        prepareSlide: prepareSlide,
        advance: advance,
        recede: recede,
        hasPending: hasPending,
        finishAll: finishAll,
    };
});
