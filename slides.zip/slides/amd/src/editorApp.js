/**
 * Editor bootstrap — ties all editor modules together.
 *
 * @module     mod_slides/editorApp
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([
    'mod_slides/editorState',
    'mod_slides/editorToolbar',
    'mod_slides/editorSlidepanel',
    'mod_slides/editorCanvas',
    'mod_slides/editorTextelem',
    'mod_slides/editorShapes',
    'mod_slides/editorProperties',
    'mod_slides/editorSave',
    'mod_slides/editorTemplates',
    'mod_slides/editorPresets',
    'mod_slides/editorPencil',
    'mod_slides/editorImage',
    'mod_slides/editorVideo',
    'mod_slides/editorLink',
    'mod_slides/editorFooter',
    'mod_slides/editorChart',
    'mod_slides/editorBackground',
    'mod_slides/editorLayers',
    'mod_slides/editorIcons',
    'mod_slides/editorFonts',
    'mod_slides/editorPdf',
    'mod_slides/editorImageBank',
    'mod_slides/editorEquation',
    'mod_slides/editorHtml',
    'mod_slides/media_recorder',
    'mod_slides/drawing_editor',
    'mod_slides/animations',
    'mod_slides/zoom_controller',
    'mod_slides/autosave',
    'mod_slides/link_manager',
    'mod_slides/interactive_buttons',
    'mod_slides/shapes_library',
    'mod_slides/pdf_importer',
], function(state, toolbar, slidepanel, canvas, textelem, shapes, properties, save, templates, presets, pencil, image, video, link, footer, chart, background, layers, icons, fonts, pdf, imagebank, equation, html, mediaRecorder, drawingEditor, animations, zoom, autosave, linkManager, interactiveButtons, shapesLib, pdfImporter) {
    'use strict';

    function str(key) {
        return M.util.get_string(key, 'mod_slides');
    }

    // Guard: never persist over a deck that failed to load.
    var deckLoaded = false;
    // Re-entry guard: one manual save at a time (also collapses double-clicks).
    var manualSavingFlag = false;

    function refreshFontOptions() {
        var options = textelem.getFontFamilyOptions();
        textelem.PROPERTY_DEFS[0].options = options;
        link.PROPERTY_DEFS[3].options = options;
    }

    function init() {
        var root = document.getElementById('slides-editor');
        if (!root) { return; }

        var cmid    = parseInt(root.dataset.cmid, 10);
        var sesskey = root.dataset.sesskey;

        canvas.registerType('text', textelem);
        canvas.registerType('shape', shapes);
        canvas.registerType('pencil', pencil);
        canvas.registerType('image', image);
        canvas.registerType('video', video);
        canvas.registerType('link', link);
        canvas.registerType('pdf', pdf);
        canvas.registerType('equation', equation);
        canvas.registerType('html', html);
        canvas.registerType('audio', mediaRecorder);
        canvas.setEmptyImagePicker(function(el, elemIdx) {
            imagebank.open({ mode: 'replace', elemIdx: elemIdx });
        });
        // Interactive links: the floating 🔗 bar over the selected element
        // and the enriched modal (photo bank / shape picker as sources).
        linkManager.init({ shapePicker: openShapePicker });
        interactiveButtons.init({
            imagePicker: function(o) {
                imagebank.open({
                    onSelect: function(srcUrl, alt) {
                        if (o && typeof o.onSelect === 'function') { o.onSelect(srcUrl, alt); }
                    },
                });
            },
            videoRecorder: function(o) {
                mediaRecorder.openModal({
                    mode: 'video',
                    onInsert: function(url, name) {
                        if (o && typeof o.onInsert === 'function') { o.onInsert(url, name); }
                    },
                });
            },
        });
        // Floating toolbar for the selected element: interactive actions get
        // their own "Configure interaction" bar; the 🔗 link bar only appears
        // for elements that already carry a link (to edit / remove it), never
        // for plain text, shapes or lines. New links are attached with the
        // toolbar's "Vínculo" button.
        canvas.setSelectionToolbar(function(canvasEl, el, slideIdx, elemIdx) {
            if (el && el.type === 'action') {
                return interactiveButtons.renderToolbar(canvasEl, el, slideIdx, elemIdx);
            }
            if (!el || !el.url) {
                return null;
            }
            return linkManager.renderToolbar(canvasEl, el, slideIdx, elemIdx);
        });
        properties.setCropStarter(function(elemIdx) {
            canvas.startCrop(elemIdx);
        });
        properties.registerType('text', textelem);
        properties.registerType('shape', shapes);
        properties.registerType('pencil', pencil);
        properties.registerType('image', image);
        properties.registerType('video', video);
        properties.registerType('link', link);
        properties.registerType('pdf', pdf);
        properties.registerType('equation', equation);
        properties.registerType('html', html);
        properties.registerType('audio', mediaRecorder);
        shapes.PROPERTY_DEFS[0].options = shapes.getShapeOptions();
        refreshFontOptions();

        fonts.preload(textelem.getFontFamilyOptions());

        var toolbarEl    = document.getElementById('editor-toolbar');
        var slidepanelEl = document.getElementById('editor-slidepanel');
        var canvasEl     = document.getElementById('editor-canvas');
        var viewportEl   = document.getElementById('editor-viewport');
        var propsEl      = document.getElementById('editor-properties');
        var layersEl     = document.getElementById('layers-list');
        var statusEl     = document.getElementById('editor-status');

        /* ======== CLIPBOARD group ======== */
        toolbar.register('cut', {
            label: str('cut'),
            svg: icons.get('cut'),
            group: str('grpclipboard', 'mod_slides'),
            handler: function() {
                var s = state.get();
                if (s.selected !== null) {
                    state.cutElement(s.current, s.selected);
                }
            },
            priority: 5,
        });
        toolbar.register('copy', {
            label: str('copy'),
            svg: icons.get('copy'),
            group: str('grpclipboard', 'mod_slides'),
            handler: function() {
                var s = state.get();
                if (s.selected !== null) {
                    state.copyElement(s.current, s.selected);
                }
            },
            priority: 10,
        });
        toolbar.register('paste', {
            label: str('paste'),
            svg: icons.get('paste'),
            group: str('grpclipboard', 'mod_slides'),
            handler: function() {
                var s = state.get();
                state.pasteElement(s.current);
            },
            priority: 15,
        });

        /* ======== SLIDES group ======== */
        toolbar.register('addslide', {
            label: str('addslide'),
            svg: icons.get('newslide'),
            group: str('grpslide', 'mod_slides'),
            handler: function() { state.addSlide(); },
            priority: 30,
        });
        toolbar.register('duplicateslide', {
            label: str('duplicateslide'),
            svg: icons.get('duplicate'),
            group: str('grpslide', 'mod_slides'),
            handler: function() {
                var s = state.get();
                state.duplicateSlide(s.current);
            },
            priority: 40,
        });
        toolbar.register('delete', {
            label: str('deleteslide'),
            svg: icons.get('trash'),
            group: str('grpslide', 'mod_slides'),
            handler: function() {
                var s = state.get();
                if (s.selected !== null) {
                    state.deleteElement(s.current, s.selected);
                } else if (s.slides.length > 1) {
                    state.deleteSlide(s.current);
                }
            },
            priority: 50,
        });

        /* ======== INSERT group ======== */
        toolbar.register('addtext', {
            label: str('addtext'),
            svg: icons.get('text'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                var s = state.get();
                state.addElement(s.current, Object.assign({}, textelem.DEFAULTS));
                canvas.startEditingSelected();
            },
            priority: 60,
        });
        toolbar.register('addimage', {
            label: str('addimage'),
            svg: icons.get('image'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                imagebank.open({ mode: 'element' });
            },
            priority: 65,
        });
        toolbar.register('addvideo', {
            label: str('addvideo'),
            svg: icons.get('video'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                openVideoDialog();
            },
            priority: 67,
        });
        toolbar.register('addlink', {
            label: str('addlink'),
            svg: icons.get('link'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                // A linkable element selected without a link yet: attach the
                // URL to that existing element instead of creating a new one.
                var s = state.get();
                var sel = null;
                if (s.selected !== null && s.selected !== undefined &&
                        (!s.multiSelected || s.multiSelected.length <= 1)) {
                    var sl = s.slides[s.current];
                    sel = sl && sl.elements[s.selected];
                }
                if (sel && !sel._locked && !sel.url &&
                        linkManager.LINKABLE.indexOf(sel.type) !== -1) {
                    linkManager.open({ mode: 'edit', slideIdx: s.current, elemIdx: s.selected });
                    return;
                }
                linkManager.open({ mode: 'create' });
            },
            priority: 68,
        });
        toolbar.register('addpdf', {
            label: str('addpdf'),
            svg: icons.get('pdf'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                openPdfDialog();
            },
            priority: 69,
        });
        toolbar.register('addshape', {
            label: str('addshape'),
            svg: icons.get('shape'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                var btn = document.querySelector('[data-action="addshape"]');
                if (btn) {
                    openShapePicker(btn);
                }
            },
            priority: 70,
        });
        toolbar.register('addpencil', {
            label: str('addpencil'),
            svg: icons.get('pencil'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                var isActive = canvas.isDrawingMode();
                canvas.setDrawingMode(!isActive);
                toolbar.updateStates();
            },
            isActive: function() { return canvas.isDrawingMode(); },
            priority: 75,
        });
        toolbar.register('addrline', {
            label: str('addrline'),
            svg: icons.get('rline'),
            group: str('grpinsert', 'mod_slides'),
            handler: function() {
                var s = state.get();
                state.addElement(s.current, Object.assign({}, shapes.DEFAULTS, { shape: 'line', angle: 45 }));
            },
            priority: 80,
        });

        /* ======== ELEMENT group ======== */
        toolbar.register('bringfront', {
            label: str('bringfront'),
            svg: icons.get('bringfront'),
            group: str('grpelement', 'mod_slides'),
            handler: function() {
                var s = state.get();
                if (s.selected !== null) { state.bringToFront(s.current, s.selected); }
            },
            priority: 85,
        });
        toolbar.register('sendback', {
            label: str('sendback'),
            svg: icons.get('sendback'),
            group: str('grpelement', 'mod_slides'),
            handler: function() {
                var s = state.get();
                if (s.selected !== null) { state.sendToBack(s.current, s.selected); }
            },
            priority: 90,
        });
        toolbar.register('bringforward', {
            label: str('bringforward'),
            svg: icons.get('bringforward'),
            group: str('grpelement', 'mod_slides'),
            handler: function() {
                var s = state.get();
                if (s.selected !== null) { state.bringForward(s.current, s.selected); }
            },
            priority: 91,
        });
        toolbar.register('sendbackward', {
            label: str('sendbackward'),
            svg: icons.get('sendbackward'),
            group: str('grpelement', 'mod_slides'),
            handler: function() {
                var s = state.get();
                if (s.selected !== null) { state.sendBackward(s.current, s.selected); }
            },
            priority: 92,
        });

        /* ======== DESIGN group ======== */
        toolbar.register('templates', {
            label: str('templates'),
            svg: icons.get('templates'),
            group: str('grpbackground', 'mod_slides'),
            handler: function() { templates.toggle(); },
            isActive: function() { return templates.getIsVisible(); },
            priority: 100,
        });
        toolbar.register('background', {
            label: str('addbackground'),
            svg: icons.get('background'),
            group: str('grpbackground', 'mod_slides'),
            handler: function(e) { openBackgroundPicker(e && e.currentTarget); },
            priority: 110,
        });

        /* ======== HISTORY group ======== */
        toolbar.register('undo', {
            label: str('undo'),
            svg: icons.get('undo'),
            group: str('grphistory', 'mod_slides'),
            handler: function() { state.undo(); },
            priority: 120,
        });
        toolbar.register('redo', {
            label: str('redo'),
            svg: icons.get('redo'),
            group: str('grphistory', 'mod_slides'),
            handler: function() { state.redo(); },
            priority: 130,
        });

        /* ======== DOCUMENT group ======== */
        toolbar.register('save', {
            label: str('save'),
            svg: icons.get('save'),
            group: str('grpdoc', 'mod_slides'),
            handler: function() { doSave(); },
            priority: 1,
        });

        /* ======== MORE TOOLS secondary row ("+") ======== */
        toolbar.register('moretools', {
            label: str('moretools'),
            svg: icons.get('plus'),
            group: str('grpmore', 'mod_slides'),
            handler: function(e) {
                equation.toggleSecondary(e && e.currentTarget);
            },
            priority: 200,
        });

        // Extra entry in the "+" dropdown: HTML / Embed code.
        equation.addMenuItem({
            id: 'html',
            labelKey: 'addhtml',
            icon: 'code',
            handler: function() { html.openModal({}); },
        });

        // Recorder entries in the "+" dropdown: audio and video clips
        // (Grabar → Probar → Subir → Insertar, 2 min / 1 Mbps cap).
        equation.addMenuItem({
            id: 'recordaudio',
            labelKey: 'recordaudio',
            icon: 'mic',
            handler: function() { mediaRecorder.openModal({ mode: 'audio' }); },
        });
        equation.addMenuItem({
            id: 'recordvideo',
            labelKey: 'recordvideo',
            icon: 'video',
            handler: function() { mediaRecorder.openModal({ mode: 'video' }); },
        });

        // Drawing / whiteboard entry in the "+" dropdown: modal canvas with
        // brush, eraser and undo; saved as a PNG image on the active slide.
        equation.addMenuItem({
            id: 'drawing',
            labelKey: 'adddrawing',
            icon: 'pencil',
            handler: function() { drawingEditor.openModal({}); },
        });

        // Animations entry in the "+" dropdown: click-to-reveal sequence
        // (appear / fade / slide-up) managed per slide, PowerPoint style.
        equation.addMenuItem({
            id: 'animations',
            labelKey: 'addanimations',
            icon: 'sparkles',
            handler: function() { animations.openModal(); },
        });

        // Interactive action buttons entry in the "+" dropdown.
        equation.addMenuItem({
            id: 'interactive',
            labelKey: 'addinteractive',
            icon: 'plus',
            handler: function() { interactiveButtons.openCatalog({}); },
        });

        // Import entry in the "+" row: opens the tabbed importer dialog
        // (PDF = visual HD background per page, PPTX = editable objects),
        // appended or replacing the deck depending on the option chosen
        // in the dialog.
        equation.addMenuItem({
            id: 'importpdf',
            labelKey: 'importslides',
            icon: 'importslides',
            handler: function() { pdfImporter.openModal(); },
        });

        toolbar.render(toolbarEl);

        slidepanel.init(slidepanelEl);
        canvas.init(canvasEl, viewportEl);
        properties.init(propsEl);
        if (layersEl) { layers.init(layersEl); }
        templates.init();

        // Canvas zoom (Canva-style): slider + −/+ + Fit + Ctrl+wheel in the
        // status bar; the canvas module delegates scaleCanvas() to it.
        zoom.init({
            viewport: viewportEl,
            canvas: canvasEl,
            slider: document.getElementById('editor-zoom-slider'),
            label: document.getElementById('editor-zoom-label'),
            outBtn: document.getElementById('editor-zoom-out'),
            inBtn: document.getElementById('editor-zoom-in'),
            fitBtn: document.getElementById('editor-zoom-fit'),
        });
        canvas.setScaler(zoom.applyScale);

        // Double click on an equation element (or the properties button)
        // reopens the modal with the TeX source prefilled.
        canvas.setEquationEditor(function(slideIdx, elemIdx) {
            var slide = state.get().slides[slideIdx];
            var el = slide && slide.elements[elemIdx];
            if (!el) { return; }
            equation.openModal({
                tex: el.text || '',
                onApply: function(tex) {
                    state.updateElementAtomic(slideIdx, elemIdx, { text: tex });
                },
            });
        });
        properties.setEquationStarter(function(slideIdx, elemIdx) {
            var slide = state.get().slides[slideIdx];
            var el = slide && slide.elements[elemIdx];
            if (!el) { return; }
            equation.openModal({
                tex: el.text || '',
                onApply: function(tex) {
                    state.updateElementAtomic(slideIdx, elemIdx, { text: tex });
                },
            });
        });

        // Double click on an HTML/Embed element (or the properties button)
        // reopens the modal with the markup prefilled.
        canvas.setHtmlEditor(function(slideIdx, elemIdx) {
            var slide = state.get().slides[slideIdx];
            var el = slide && slide.elements[elemIdx];
            if (!el) { return; }
            html.openModal({
                code: el.text || '',
                onApply: function(code) {
                    state.updateElementAtomic(slideIdx, elemIdx, { text: code });
                },
            });
        });
        properties.setHtmlStarter(function(slideIdx, elemIdx) {
            var slide = state.get().slides[slideIdx];
            var el = slide && slide.elements[elemIdx];
            if (!el) { return; }
            html.openModal({
                code: el.text || '',
                onApply: function(code) {
                    state.updateElementAtomic(slideIdx, elemIdx, { text: code });
                },
            });
        });

        // KaTeX loads lazily: repaint canvas/thumbnails/preview once ready.
        equation.whenReady(function() { state.notify(); });

        /* ======== Mobile drawers (≤768px, CSS-driven) ======== */
        var slidesToggleBtn = document.getElementById('mobile-slidepanel-toggle');
        var propsToggleBtn  = document.getElementById('mobile-props-toggle');
        var propsPanelEl    = root.querySelector('.editor-panels-right');

        function setDrawer(panelEl, btnEl, open) {
            if (!panelEl) { return; }
            panelEl.classList.toggle('is-drawer-open', open);
            if (btnEl) { btnEl.setAttribute('aria-expanded', open ? 'true' : 'false'); }
        }
        function closeAllDrawers() {
            setDrawer(slidepanelEl, slidesToggleBtn, false);
            setDrawer(propsPanelEl, propsToggleBtn, false);
        }
        if (slidesToggleBtn) {
            slidesToggleBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                var open = !slidepanelEl.classList.contains('is-drawer-open');
                setDrawer(propsPanelEl, propsToggleBtn, false);
                setDrawer(slidepanelEl, slidesToggleBtn, open);
            });
        }
        if (propsToggleBtn) {
            propsToggleBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                var open = !propsPanelEl.classList.contains('is-drawer-open');
                setDrawer(slidepanelEl, slidesToggleBtn, false);
                setDrawer(propsPanelEl, propsToggleBtn, open);
            });
        }
        var canvasWrapEl = document.querySelector('.editor-canvas-wrap');
        if (canvasWrapEl) {
            canvasWrapEl.addEventListener('click', closeAllDrawers);
        }
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') { closeAllDrawers(); }
        });
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) { closeAllDrawers(); }
        });

        window.slidesApplyTemplate = function(presetId) {
            var preset = presets.getPreset(presetId);
            if (!preset) { return; }
            closeBackgroundPicker();
            closeShapePicker();
            var s = state.get();
            if (s.selected !== null) {
                state.applyTemplate(s.current, preset);
            } else {
                state.addTemplateSlide(preset);
            }
        };

        state.subscribe(function() {
            toolbar.updateStates();
            updateStatus(statusEl);
        });

        /* ======== Keyboard shortcuts ======== */
        document.addEventListener('keydown', function(e) {
            var tag = e.target.tagName;
            if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') { return; }
            if (e.target.isContentEditable) { return; }

            if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
                e.preventDefault();
                if (e.shiftKey) { state.redo(); } else { state.undo(); }
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
                e.preventDefault();
                state.redo();
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                doSave();
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
                var sCopy = state.get();
                if (sCopy.selected !== null) {
                    state.copyElement(sCopy.current, sCopy.selected);
                }
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'x') {
                var sCut = state.get();
                if (sCut.selected !== null) {
                    state.cutElement(sCut.current, sCut.selected);
                }
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'v') {
                e.preventDefault();
                state.pasteElement(state.get().current);
            }
            if (e.key === 'Delete' || e.key === 'Backspace') {
                var s = state.get();
                if (s.selected !== null) {
                    e.preventDefault();
                    state.deleteElement(s.current, s.selected);
                } else if (s.slides.length > 1) {
                    e.preventDefault();
                    state.deleteSlide(s.current);
                }
            }
            if (e.key === 'ArrowUp') {
                e.preventDefault();
                var sUp = state.get();
                if (sUp.current > 0) { state.setCurrent(sUp.current - 1); }
            }
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                var sDown = state.get();
                if (sDown.current < sDown.slides.length - 1) { state.setCurrent(sDown.current + 1); }
            }
            if (e.key === 'Escape') {
                var shapePopup = document.getElementById('shape-picker-popup');
                if (shapePopup) {
                    closeShapePicker();
                } else if (canvas.isDrawingMode()) {
                    canvas.setDrawingMode(false);
                    toolbar.updateStates();
                } else {
                    state.deselectElement();
                }
            }
        });

        window.addEventListener('beforeunload', function(e) {
            if (state.isDirty()) {
                e.preventDefault();
                e.returnValue = '';
            }
        });

        statusEl.textContent = str('loading');
        save.load(cmid).then(function(result) {
            var slides = result.slides || [];
            slides.forEach(function(s) {
                if (typeof s.background === 'string') {
                    try { s.background = JSON.parse(s.background); } catch (e) { s.background = { type: 'solid', color: '#ffffff' }; }
                }
                s.background = background.normalize(s.background);
                if (!s.transition) { s.transition = 'none'; }
            });
            state.load(slides);
            deckLoaded = true;
            statusEl.textContent = str('saved');
            // Auto-save: local drafts + debounced quiet saves + status states.
            autosave.init({ cmid: cmid, sesskey: sesskey, statusEl: statusEl });
            autosave.checkRecovery();
        }).catch(function(e) {
            deckLoaded = false;
            console.error('mod_slides: get_deck failed', e);
            statusEl.textContent = str('errorloading');
        });
    }

    function applyStatus(statusEl, kind, text) {
        statusEl.classList.remove('is-dirty', 'is-saving', 'is-saved', 'is-error');
        statusEl.classList.add('is-' + kind);
        statusEl.dataset.state = kind;
        statusEl.textContent = text;
    }

    function doSave() {
        if (!deckLoaded) {
            console.warn('mod_slides: save blocked, deck did not load successfully');
            return;
        }
        if (manualSavingFlag) { return; }
        manualSavingFlag = true;

        var root = document.getElementById('slides-editor');
        var statusEl = document.getElementById('editor-status');
        var genAtSave = state.getGen();

        applyStatus(statusEl, 'saving', str('saving'));
        // Watchdog: a never-settling request must not disable the Save button.
        var flagTimer = setTimeout(function() { manualSavingFlag = false; }, 60000);

        // flush() never races the debounced autosave: it resolves instantly
        // when the deck is already saved, piggybacks on an in-flight save that
        // covers the current content, or fires exactly one request otherwise.
        autosave.flush().then(function() {
            manualSavingFlag = false;
            clearTimeout(flagTimer);
            // Only mark clean if no edit arrived while the save was in flight.
            if (state.isDirty() && state.getGen() === genAtSave) {
                state.setClean();
            }
            if (state.isDirty()) {
                applyStatus(statusEl, 'dirty', str('unsaved'));
            } else {
                applyStatus(statusEl, 'saved', str('saved'));
            }
        }).catch(function() {
            manualSavingFlag = false;
            clearTimeout(flagTimer);
            applyStatus(statusEl, 'error', str('errorsaving'));
        });
    }

    function updateStatus(statusEl) {
        var s = state.get();
        if (s.dirty) {
            // Never clobber the "Saving…" text while an autosave is running.
            if (statusEl.dataset.state === 'saving') { return; }
            statusEl.textContent = str('unsaved');
            statusEl.classList.remove('is-saved', 'is-saving', 'is-error');
            statusEl.classList.add('is-dirty');
            statusEl.dataset.state = 'dirty';
        }
    }

    /* ---- Video URL dialog ---- */
    function openVideoDialog() {
        var url = prompt(str('videourl'), 'https://www.youtube.com/watch?v=');
        if (url) {
            var s = state.get();
            var vidEl = Object.assign({}, video.DEFAULTS, { src: url });
            state.addElement(s.current, vidEl);
        }
    }

    /* ---- PDF upload dialog (drag & drop + file picker) ---- */
    function openPdfDialog() {
        closePdfDialog();
        var s = state.get();

        var backdrop = document.createElement('div');
        backdrop.className = 'pdf-dialog-backdrop';

        var modal = document.createElement('div');
        modal.className = 'pdf-dialog';

        // Header
        var header = document.createElement('div');
        header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;' +
            'padding:14px 18px;border-bottom:1px solid #e9ecef;';
        var title = document.createElement('div');
        title.textContent = str('pdfmodaltitle');
        title.style.cssText = 'font-size:15px;font-weight:600;color:#212529;';
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.setAttribute('aria-label', str('cancel'));
        closeBtn.style.cssText = 'border:none;background:none;font-size:20px;line-height:1;cursor:pointer;color:#6c757d;padding:0 4px;';
        closeBtn.innerHTML = '&times;';
        closeBtn.addEventListener('click', closePdfDialog);
        header.appendChild(title);
        header.appendChild(closeBtn);
        modal.appendChild(header);

        // Body
        var body = document.createElement('div');
        body.style.cssText = 'padding:18px;display:flex;flex-direction:column;gap:14px;';

        // Drop zone
        var dropZone = document.createElement('div');
        dropZone.className = 'pdf-drop-zone';
        dropZone.style.cssText = 'border:2px dashed #ced4da;border-radius:8px;padding:32px 16px;' +
            'text-align:center;cursor:pointer;transition:border-color 0.15s,background 0.15s;' +
            'background:#f8f9fa;';
        dropZone.innerHTML = '<div style="font-size:48px;color:#0d6efd;margin-bottom:8px;">' + icons.get('pdf', {size: 48}) + '</div>' +
            '<div style="font-size:14px;font-weight:500;color:#212529;margin-bottom:4px;">' + str('pdfdropzone') + '</div>' +
            '<div style="font-size:12px;color:#6c757d;">' + str('pdfdropzonehint') + '</div>';

        // Hidden file input
        var fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'application/pdf';
        fileInput.style.display = 'none';
        dropZone.appendChild(fileInput);

        var selectedFile = null;
        var fileNameEl = null;
        var uploadBtn = null;

        function isPdfFile(f) {
            return !!f && (f.type === 'application/pdf' || /\.pdf$/i.test(f.name || ''));
        }

        function updateDropZoneState(hover) {
            // The attach button is only usable when a file is selected.
            if (uploadBtn) {
                uploadBtn.disabled = !selectedFile;
            }
            if (selectedFile) {
                dropZone.style.borderColor = '#198754';
                dropZone.style.background = '#f0fff4';
                if (!fileNameEl) {
                    fileNameEl = document.createElement('div');
                    fileNameEl.style.cssText = 'margin-top:12px;padding:8px 12px;background:#fff;border:1px solid #198754;border-radius:6px;font-size:13px;color:#198754;display:flex;align-items:center;justify-content:space-between;';
                    dropZone.appendChild(fileNameEl);
                }
                fileNameEl.innerHTML = '<span>' + icons.get('file', {size: 16}) + ' ' + escapeHtml(selectedFile.name) + ' (' + formatBytes(selectedFile.size) + ')</span>' +
                    '<button type="button" style="border:none;background:none;color:#dc3545;cursor:pointer;padding:0 4px;" aria-label="' + str('remove') + '">&times;</button>';
                fileNameEl.querySelector('button').addEventListener('click', function(e) {
                    e.stopPropagation();
                    selectedFile = null;
                    fileInput.value = '';
                    dropZone.innerHTML = '<div style="font-size:48px;color:#0d6efd;margin-bottom:8px;">' + icons.get('pdf', {size: 48}) + '</div>' +
                        '<div style="font-size:14px;font-weight:500;color:#212529;margin-bottom:4px;">' + str('pdfdropzone') + '</div>' +
                        '<div style="font-size:12px;color:#6c757d;">' + str('pdfdropzonehint') + '</div>';
                    dropZone.appendChild(fileInput);
                    fileNameEl = null;
                    updateDropZoneState(false);
                });
            } else if (hover) {
                dropZone.style.borderColor = '#0d6efd';
                dropZone.style.background = '#eef5ff';
            } else {
                dropZone.style.borderColor = '#ced4da';
                dropZone.style.background = '#f8f9fa';
            }
        }

        dropZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            updateDropZoneState(true);
        });
        dropZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            updateDropZoneState(false);
        });
        dropZone.addEventListener('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var files = e.dataTransfer.files;
            if (files.length > 0 && isPdfFile(files[0])) {
                selectedFile = files[0];
                fileInput.files = files;
                updateDropZoneState(false);
            } else {
                alert(str('pdfinvalidtype'));
            }
        });
        dropZone.addEventListener('click', function() {
            fileInput.click();
        });
        fileInput.addEventListener('change', function() {
            if (fileInput.files.length > 0 && isPdfFile(fileInput.files[0])) {
                selectedFile = fileInput.files[0];
                updateDropZoneState(false);
            } else if (fileInput.files.length > 0) {
                alert(str('pdfinvalidtype'));
                fileInput.value = '';
            }
        });

        body.appendChild(dropZone);

        // Progress area (hidden initially)
        var progressWrap = document.createElement('div');
        progressWrap.style.cssText = 'display:none;flex-direction:column;gap:8px;';
        var progressBar = document.createElement('div');
        progressBar.style.cssText = 'height:6px;background:#e9ecef;border-radius:3px;overflow:hidden;';
        var progressFill = document.createElement('div');
        progressFill.style.cssText = 'width:0%;height:100%;background:#0d6efd;transition:width 0.2s;';
        progressBar.appendChild(progressFill);
        progressWrap.appendChild(progressBar);
        var progressText = document.createElement('div');
        progressText.style.cssText = 'font-size:12px;color:#6c757d;text-align:center;';
        progressWrap.appendChild(progressText);
        body.appendChild(progressWrap);

        // Error message
        var errEl = document.createElement('div');
        errEl.style.cssText = 'font-size:12px;color:#dc3545;min-height:16px;display:none;';
        body.appendChild(errEl);

        modal.appendChild(body);

        // Footer
        var footerEl = document.createElement('div');
        footerEl.style.cssText = 'display:flex;justify-content:flex-end;gap:8px;' +
            'padding:12px 18px;background:#f8f9fa;border-top:1px solid #e9ecef;';

        var cancelBtn = document.createElement('button');
        cancelBtn.type = 'button';
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.textContent = str('cancel');
        cancelBtn.style.cssText = 'padding:7px 16px;font-size:13px;';
        cancelBtn.addEventListener('click', closePdfDialog);

        uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-primary';
        uploadBtn.textContent = str('pdfupload');
        uploadBtn.style.cssText = 'padding:7px 16px;font-size:13px;';
        uploadBtn.disabled = true;
        uploadBtn.addEventListener('click', uploadPdf);

        footerEl.appendChild(cancelBtn);
        footerEl.appendChild(uploadBtn);
        modal.appendChild(footerEl);

        backdrop.addEventListener('click', closePdfDialog);

        document.body.appendChild(backdrop);
        backdrop.appendChild(modal);
        modal.addEventListener('click', function(e) { e.stopPropagation(); });

        function uploadPdf() {
            try {
                if (!selectedFile) {
                    showErr(str('pdfinvalidtype'));
                    return;
                }

                uploadBtn.disabled = true;
                cancelBtn.disabled = true;
                dropZone.style.pointerEvents = 'none';
                progressWrap.style.display = 'flex';
                progressText.textContent = str('pdfuploading');
                progressFill.style.width = '0%';
                errEl.style.display = 'none';

                // cmid/sesskey are locals of init()/doSave() — read them from
                // the DOM here, otherwise they are ReferenceErrors in this scope.
                var root = document.getElementById('slides-editor');
                var cmid = parseInt(root.dataset.cmid, 10);
                var sesskey = root.dataset.sesskey;

                // multipart/form-data POST: cmid + sesskey + file (Moodle File API).
                var fd = new FormData();
                fd.append('cmid', cmid);
                fd.append('sesskey', sesskey);
                fd.append('pdf', selectedFile, selectedFile.name);

            var xhr = new XMLHttpRequest();
            try {
                xhr.open('POST', M.cfg.wwwroot + '/mod/slides/classes/local/pdf_upload_ajax.php', true);
            } catch (ex) {
                showErr(str('pdfuploaderror') + ' — ' + ex.message);
                return;
            }

            xhr.timeout = 60000;

            xhr.upload.onprogress = function(evt) {
                if (evt.lengthComputable) {
                    var pct = Math.round((evt.loaded / evt.total) * 100);
                    progressFill.style.width = pct + '%';
                    progressText.textContent = str('pdfuploading') + ' ' + pct + '%';
                }
            };
            xhr.upload.onload = function() {
                // File fully sent — now waiting for the server to store it.
                progressFill.style.width = '100%';
                progressText.textContent = str('pdfprocessing');
            };

            function snippet(body) {
                return body ? ' | ' + String(body).substring(0, 200) : '';
            }

            xhr.onload = function() {
                progressFill.style.width = '100%';
                var body = '';
                try { body = xhr.responseText || ''; } catch (e) { /* ignore */ }

                if (xhr.status === 200) {
                    try {
                        var resp = JSON.parse(body);
                        if (resp.url) {
                            progressText.textContent = str('pdfuploadsuccess');
                            state.addElement(s.current, Object.assign({}, pdf.DEFAULTS, {
                                src: resp.url,
                                pdftitle: selectedFile.name.replace(/\.pdf$/i, ''),
                                alt: selectedFile.name,
                            }));
                            setTimeout(closePdfDialog, 500);
                            return;
                        }
                        showErr(resp.error || str('pdfuploaderror'));
                    } catch (ex) {
                        showErr(str('pdfuploaderror') + ' — ' + ex.message + snippet(body));
                    }
                } else {
                    showErr(str('pdfuploaderror') + ' — HTTP ' + xhr.status + snippet(body));
                }
            };
            xhr.onerror = function() {
                showErr(str('pdfuploaderror') + ' — network');
            };
            xhr.ontimeout = function() {
                showErr(str('pdfuploadtimeout'));
            };

            try {
                xhr.send(fd);
            } catch (ex) {
                showErr(str('pdfuploaderror') + ' — ' + ex.message);
            }
            } catch (ex) {
                // Never fail silently: any unexpected error is shown in the dialog.
                showErr(str('pdfuploaderror') + ' — ' + ex.message);
            }
        }

        function showErr(msg) {
            errEl.textContent = msg;
            errEl.style.display = 'block';
            progressWrap.style.display = 'none';
            uploadBtn.disabled = !selectedFile;
            cancelBtn.disabled = false;
            dropZone.style.pointerEvents = 'auto';
        }

        function onKey(e) {
            if (e.key === 'Escape') { closePdfDialog(); }
        }
        modal.addEventListener('keydown', onKey);
    }

    function closePdfDialog() {
        var bd = document.querySelector('.pdf-dialog-backdrop');
        if (bd) { bd.remove(); }
        var md = document.querySelector('.pdf-dialog');
        if (md) { md.remove(); }
    }

    function formatBytes(bytes) {
        if (bytes < 1024) { return bytes + ' B'; }
        if (bytes < 1048576) { return (bytes / 1024).toFixed(1) + ' KB'; }
        return (bytes / 1048576).toFixed(1) + ' MB';
    }

    function escapeHtml(str) {
        return str.replace(/&/g, '&').replace(/</g, '<').replace(/>/g, '>');
    }

    /* ---- Shape picker popup ---- */
    /**
     * Keep a fixed popup anchored to its trigger and inside the viewport.
     * Also traps wheel scrolling so the host page never moves while open.
     */
    function positionPopup(popup, anchorEl) {
        var rect = anchorEl.getBoundingClientRect();
        popup.style.position = 'fixed';
        popup.style.zIndex = '200';
        popup.style.maxHeight = 'calc(100vh - 16px)';
        popup.style.overflowY = 'auto';
        popup.style.overflowX = 'hidden';
        popup.style.overscrollBehavior = 'contain';
        popup.style.left = Math.max(4, Math.min(rect.left, window.innerWidth - popup.offsetWidth - 4)) + 'px';

        var spaceBelow = window.innerHeight - rect.bottom - 8;
        var spaceAbove = rect.top - 8;
        var h = popup.offsetHeight;
        if (h <= spaceBelow || spaceBelow >= spaceAbove) {
            popup.style.top = (rect.bottom + 4) + 'px';
        } else {
            popup.style.top = Math.max(4, rect.top - h - 4) + 'px';
        }
    }

    function trapPopupWheel(popup) {
        popup.addEventListener('wheel', function(e) {
            e.stopPropagation();
            var el = e.target;
            while (el && el !== popup) {
                if (el.scrollHeight > el.clientHeight + 1) {
                    var oy = window.getComputedStyle(el).overflowY;
                    if (oy === 'auto' || oy === 'scroll') {
                        var atTop = el.scrollTop <= 0 && e.deltaY < 0;
                        var atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 1 && e.deltaY > 0;
                        if (atTop || atBottom) {
                            e.preventDefault();
                        }
                        return;
                    }
                }
                el = el.parentElement;
            }
            e.preventDefault();
        }, { passive: false });
    }

    /**
     * Open the shape picker.
     *
     * @param {HTMLElement} anchorEl Button the popup is positioned against.
     * @param {Function} [onPick]    When given (link_manager flow), the chosen
     *                               shape key is handed back instead of being
     *                               inserted as an element.
     */
    function openShapePicker(anchorEl, onPick) {
        closeShapePicker();
        var s = state.get();
        var popup = document.createElement('div');
        popup.className = 'shape-picker-popup';
        popup.id = 'shape-picker-popup';

        var header = document.createElement('div');
        header.className = 'shape-picker-header';
        header.textContent = str('addshape');
        popup.appendChild(header);

        /* Search box (PowerPoint-style library). */
        var searchInput = document.createElement('input');
        searchInput.type = 'search';
        searchInput.className = 'shape-picker-search';
        searchInput.placeholder = str('ibsearch');
        searchInput.setAttribute('aria-label', str('ibsearch'));
        popup.appendChild(searchInput);

        /* Category tabs. */
        var activeCat = 'all';
        var tabBtns = {};
        var tabsWrap = document.createElement('div');
        tabsWrap.className = 'shape-picker-tabs';
        var cats = [['all', 'ibcat-all']].concat(shapesLib.CATEGORIES);
        cats.forEach(function(pair) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'shape-picker-tab' + (pair[0] === activeCat ? ' is-active' : '');
            b.textContent = str(pair[1]);
            b.addEventListener('click', function() {
                if (tabBtns[activeCat]) { tabBtns[activeCat].classList.remove('is-active'); }
                activeCat = pair[0];
                b.classList.add('is-active');
                renderGrid();
            });
            tabBtns[pair[0]] = b;
            tabsWrap.appendChild(b);
        });
        popup.appendChild(tabsWrap);

        var grid = document.createElement('div');
        grid.className = 'shape-picker-grid';

        function normalize(txt) {
            var t = (txt || '').toLowerCase();
            try { return t.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) { return t; }
        }

        function renderGrid() {
            grid.textContent = '';
            var q = normalize(searchInput.value);
            var shown = 0;
            Object.keys(shapesLib.SHAPES).forEach(function(key) {
                if (key === 'line') { return; }
                var shape = shapesLib.SHAPES[key];
                if (activeCat !== 'all' && shape.cat !== activeCat) { return; }
                var label;
                try {
                    label = M.util.get_string('shape-' + key, 'mod_slides');
                } catch (e) {
                    label = shape.label;
                }
                if (q && normalize(label).indexOf(q) === -1) { return; }
                shown++;
                var item = document.createElement('div');
                item.className = 'shape-picker-item';
                item.title = label;

                var thumb = document.createElement('div');
                thumb.className = 'shape-picker-thumb';
                thumb.style.cssText = shapesLib.thumbStyle(key);
                item.appendChild(thumb);

                var labelEl = document.createElement('div');
                labelEl.className = 'shape-picker-label';
                labelEl.textContent = label;
                item.appendChild(labelEl);

                item.addEventListener('click', function() {
                    if (typeof onPick === 'function') {
                        closeShapePicker();
                        onPick(key);
                        return;
                    }
                    var opts = Object.assign({}, shapes.DEFAULTS, { shape: key });
                    if (key === 'circle' || key === 'ellipse') {
                        var size = Math.min(opts.w, opts.h);
                        opts.w = size;
                        opts.h = size;
                    }
                    state.addElement(s.current, opts);
                    closeShapePicker();
                });

                grid.appendChild(item);
            });
            if (!shown) {
                var empty = document.createElement('div');
                empty.className = 'shape-picker-empty';
                empty.textContent = str('ibnoresults');
                grid.appendChild(empty);
            }
        }
        searchInput.addEventListener('input', renderGrid);
        renderGrid();

        popup.appendChild(grid);

        document.body.appendChild(popup);
        if (window.matchMedia('(max-width: 768px)').matches) {
            popup.style.position = 'fixed';
            // Above the link modal backdrop (300) when the picker is opened
            // as the shape source of an interactive link.
            popup.style.zIndex = '360';
            popup.style.left = '8px';
            popup.style.right = '8px';
            popup.style.top = 'auto';
            popup.style.bottom = '8px';
            popup.style.width = 'auto';
            popup.style.maxWidth = 'none';
            popup.style.maxHeight = '50vh';
            popup.style.borderRadius = '12px';
            popup.style.overflowY = 'auto';
        } else {
            positionPopup(popup, anchorEl);
            popup.style.zIndex = '360';
        }
        trapPopupWheel(popup);

        function onOutsideClick(e) {
            if (!popup.contains(e.target) && e.target !== anchorEl && !anchorEl.contains(e.target)) {
                closeShapePicker();
            }
        }
        function onEsc(e) {
            if (e.key === 'Escape') { closeShapePicker(); }
        }
        setTimeout(function() {
            document.addEventListener('click', onOutsideClick);
            document.addEventListener('keydown', onEsc);
        }, 0);

        popup._onOutsideClick = onOutsideClick;
        popup._onEsc = onEsc;
    }

    function closeShapePicker() {
        var existing = document.getElementById('shape-picker-popup');
        if (existing) {
            if (existing._onOutsideClick) {
                document.removeEventListener('click', existing._onOutsideClick);
            }
            if (existing._onEsc) {
                document.removeEventListener('keydown', existing._onEsc);
            }
            existing.remove();
        }
    }

    function closeBackgroundPicker() {
        var existing = document.querySelector('.bg-picker-popup');
        if (existing) {
            if (existing._onOutsideClick) {
                document.removeEventListener('mousedown', existing._onOutsideClick);
            }
            existing.remove();
        }
    }

    /* ---- Background picker with tabs (solid / linear / radial / image) ---- */
    function openBackgroundPicker(anchorEl) {
        var s = state.get();
        var slide = s.slides[s.current];
        var bg = background.normalize(slide.background);

        var wrapper = document.createElement('div');
        wrapper.className = 'bg-picker-popup';
        wrapper.style.cssText = 'position:fixed;z-index:200;background:#fff;border:1px solid #dee2e6;border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,0.15);width:280px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;';

        // Tab bar
        var tabBar = document.createElement('div');
        tabBar.style.cssText = 'display:flex;border-bottom:1px solid #dee2e6;';
        var tabIds = ['solid', 'linear', 'radial', 'image'];
        var tabLabels = [str('bg-solid'), str('bg-linear'), str('bg-radial'), str('bg-image')];
        var panels = {};
        var tabBtns = {};

        tabIds.forEach(function(id, i) {
            var btn = document.createElement('button');
            btn.textContent = tabLabels[i];
            btn.style.cssText = 'flex:1;padding:8px 4px;border:none;background:none;cursor:pointer;font-size:12px;border-bottom:2px solid transparent;';
            btn.addEventListener('click', function() {
                Object.keys(panels).forEach(function(k) { panels[k].style.display = 'none'; });
                Object.keys(tabBtns).forEach(function(k) { tabBtns[k].style.borderBottomColor = 'transparent'; tabBtns[k].style.background = 'none'; });
                panels[id].style.display = 'block';
                btn.style.borderBottomColor = '#0d6efd';
                btn.style.background = '#f8f9fa';
            });
            tabBtns[id] = btn;
            tabBar.appendChild(btn);
        });
        wrapper.appendChild(tabBar);

        // ---- Panel: Solid (PowerPoint-style color grid) ----
        var solidPanel = document.createElement('div');
        solidPanel.style.cssText = 'padding:12px;max-height:380px;overflow-y:auto;';

        // Theme colors palette (10 columns × 7 rows)
        var THEME_COLORS = [
            ['#000000', '#8b0000', '#003366', '#006666', '#4b0082', '#006400', '#000080', '#cc5500', '#663300', '#4d4d00'],
            ['#333333', '#c00000', '#004080', '#008080', '#660099', '#008000', '#0000a3', '#e66a00', '#804000', '#666600'],
            ['#555555', '#e00000', '#0066cc', '#00a3a3', '#8000b3', '#00a300', '#0000cc', '#ff8000', '#994d00', '#808000'],
            ['#888888', '#ff3333', '#3399ff', '#33cccc', '#9933cc', '#33cc33', '#3366ff', '#ff9933', '#b36633', '#999933'],
            ['#aaaaaa', '#ff6666', '#66b3ff', '#66d9d9', '#b366d9', '#66e066', '#6699ff', '#ffb366', '#cc8066', '#b3b366'],
            ['#cccccc', '#ff9999', '#99ccff', '#99e6e6', '#cc99e6', '#99eb99', '#99bbff', '#ffcc99', '#e69999', '#cccc99'],
            ['#ffffff', '#ffcccc', '#cce6ff', '#ccf2f2', '#e6ccf2', '#ccf5cc', '#ccddff', '#ffe6cc', '#f2ccbb', '#e6e6cc']
        ];

        // Standard colors (10 basic saturated colors)
        var STANDARD_COLORS = [
            '#c00000', '#e65c00', '#f0c000', '#339933', '#00a33c',
            '#00a3e0', '#0070c0', '#003399', '#7030a0', '#000000'
        ];

        // Theme colors section
        var themeLabel = document.createElement('div');
        themeLabel.className = 'bg-color-section-label';
        themeLabel.textContent = str('theme-colors');
        solidPanel.appendChild(themeLabel);

        var themeGrid = document.createElement('div');
        themeGrid.className = 'bg-color-grid';

        THEME_COLORS.forEach(function(row) {
            var rowDiv = document.createElement('div');
            rowDiv.className = 'bg-color-row';
            row.forEach(function(color) {
                var swatch = document.createElement('div');
                swatch.className = 'bg-color-swatch';
                swatch.style.background = color;
                if (color === bg.color) { swatch.classList.add('is-active'); }
                swatch.addEventListener('click', function() {
                    state.setSlideBackground(s.current, { type: 'solid', color: color });
                    solidPanel.querySelectorAll('.bg-color-swatch').forEach(function(s) { s.classList.remove('is-active'); });
                    swatch.classList.add('is-active');
                });
                rowDiv.appendChild(swatch);
            });
            themeGrid.appendChild(rowDiv);
        });
        solidPanel.appendChild(themeGrid);

        // Standard colors section
        var stdLabel = document.createElement('div');
        stdLabel.className = 'bg-color-section-label';
        stdLabel.textContent = str('standard-colors');
        solidPanel.appendChild(stdLabel);

        var stdRow = document.createElement('div');
        stdRow.className = 'bg-color-row';
        STANDARD_COLORS.forEach(function(color) {
            var swatch = document.createElement('div');
            swatch.className = 'bg-color-swatch';
            swatch.style.background = color;
            if (color === bg.color) { swatch.classList.add('is-active'); }
            swatch.addEventListener('click', function() {
                state.setSlideBackground(s.current, { type: 'solid', color: color });
                solidPanel.querySelectorAll('.bg-color-swatch').forEach(function(s) { s.classList.remove('is-active'); });
                swatch.classList.add('is-active');
            });
            stdRow.appendChild(swatch);
        });
        solidPanel.appendChild(stdRow);

        // More colors section
        var moreRow = document.createElement('div');
        moreRow.className = 'bg-more-colors';
        var moreColor = document.createElement('input');
        moreColor.type = 'color';
        moreColor.value = bg.color || '#ffffff';
        moreColor.addEventListener('input', function() {
            state.setSlideBackground(s.current, { type: 'solid', color: moreColor.value });
        });
        var moreLabel = document.createElement('label');
        moreLabel.textContent = str('more-colors');
        moreLabel.addEventListener('click', function(e) {
            e.stopPropagation();
        });
        moreRow.appendChild(moreColor);
        moreRow.appendChild(moreLabel);
        solidPanel.appendChild(moreRow);

        panels.solid = solidPanel;
        wrapper.appendChild(solidPanel);

        // ---- Panel: Linear Gradient ----
        var linearPanel = document.createElement('div');
        linearPanel.style.cssText = 'padding:12px;display:none;';
        var lg = (bg.type === 'linear-gradient' && bg.gradient) ? bg.gradient : { angle: 135, stops: [{ color: '#667eea', position: 0 }, { color: '#764ba2', position: 100 }] };

        // Preview
        var lgPreview = document.createElement('div');
        lgPreview.style.cssText = 'width:100%;height:40px;border-radius:4px;margin-bottom:10px;border:1px solid #dee2e6;';
        lgPreview.style.background = background.buildLinearGradient(lg);
        linearPanel.appendChild(lgPreview);

        // Angle
        var lgAngleRow = document.createElement('div');
        lgAngleRow.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:8px;';
        var lgAngleLabel = document.createElement('span');
        lgAngleLabel.textContent = str('gradient-angle');
        lgAngleLabel.style.cssText = 'font-size:11px;min-width:60px;';
        var lgAngle = document.createElement('input');
        lgAngle.type = 'range';
        lgAngle.min = '0';
        lgAngle.max = '360';
        lgAngle.value = lg.angle;
        lgAngle.style.cssText = 'flex:1;';
        var lgAngleVal = document.createElement('span');
        lgAngleVal.textContent = lg.angle + '\u00B0';
        lgAngleVal.style.cssText = 'font-size:11px;min-width:30px;text-align:right;';
        lgAngle.addEventListener('input', function() {
            lg.angle = parseInt(lgAngle.value, 10);
            lgAngleVal.textContent = lg.angle + '\u00B0';
            lgPreview.style.background = background.buildLinearGradient(lg);
        });
        lgAngleRow.appendChild(lgAngleLabel);
        lgAngleRow.appendChild(lgAngle);
        lgAngleRow.appendChild(lgAngleVal);
        linearPanel.appendChild(lgAngleRow);

        // Stops
        var lgStopsContainer = document.createElement('div');
        lgStopsContainer.style.cssText = 'display:flex;flex-direction:column;gap:6px;';

        function renderLgStops() {
            lgStopsContainer.innerHTML = '';
            lg.stops.forEach(function(stop, idx) {
                var row = document.createElement('div');
                row.style.cssText = 'display:flex;align-items:center;gap:6px;';
                var ci = document.createElement('input');
                ci.type = 'color';
                ci.value = stop.color;
                ci.style.cssText = 'width:32px;height:24px;border:1px solid #dee2e6;border-radius:3px;cursor:pointer;';
                ci.addEventListener('input', function() {
                    stop.color = ci.value;
                    lgPreview.style.background = background.buildLinearGradient(lg);
                });
                var pi = document.createElement('input');
                pi.type = 'number';
                pi.min = '0';
                pi.max = '100';
                pi.value = stop.position;
                pi.style.cssText = 'width:50px;padding:2px 4px;border:1px solid #dee2e6;border-radius:3px;font-size:11px;';
                pi.addEventListener('change', function() {
                    stop.position = parseInt(pi.value, 10) || 0;
                    lgPreview.style.background = background.buildLinearGradient(lg);
                });
                var pct = document.createElement('span');
                pct.textContent = '%';
                pct.style.cssText = 'font-size:11px;color:#888;';
                var removeBtn = document.createElement('button');
                removeBtn.textContent = '\u00D7';
                removeBtn.style.cssText = 'border:none;background:none;cursor:pointer;font-size:14px;color:#dc3545;padding:0 4px;';
                removeBtn.addEventListener('click', function() {
                    if (lg.stops.length > 2) {
                        lg.stops.splice(idx, 1);
                        renderLgStops();
                        lgPreview.style.background = background.buildLinearGradient(lg);
                    }
                });
                if (lg.stops.length <= 2) { removeBtn.style.visibility = 'hidden'; }
                row.appendChild(ci);
                row.appendChild(pi);
                row.appendChild(pct);
                row.appendChild(removeBtn);
                lgStopsContainer.appendChild(row);
            });

            if (lg.stops.length < 4) {
                var addBtn = document.createElement('button');
                addBtn.textContent = str('add-stop');
                addBtn.className = 'btn btn-sm btn-secondary';
                addBtn.style.cssText = 'width:100%;margin-top:4px;font-size:11px;';
                addBtn.addEventListener('click', function() {
                    lg.stops.push({ color: '#cccccc', position: 50 });
                    renderLgStops();
                    lgPreview.style.background = background.buildLinearGradient(lg);
                });
                lgStopsContainer.appendChild(addBtn);
            }
        }
        renderLgStops();
        linearPanel.appendChild(lgStopsContainer);

        // Apply button for linear
        var lgApply = document.createElement('button');
        lgApply.className = 'btn btn-sm btn-primary';
        lgApply.textContent = str('bg-apply');
        lgApply.style.cssText = 'width:100%;margin-top:10px;';
        lgApply.addEventListener('click', function() {
            state.setSlideBackground(s.current, { type: 'linear-gradient', gradient: JSON.parse(JSON.stringify(lg)) });
        });
        linearPanel.appendChild(lgApply);

        panels.linear = linearPanel;
        wrapper.appendChild(linearPanel);

        // ---- Panel: Radial Gradient ----
        var radialPanel = document.createElement('div');
        radialPanel.style.cssText = 'padding:12px;display:none;';
        var rg = (bg.type === 'radial-gradient' && bg.gradient) ? bg.gradient : { stops: [{ color: '#667eea', position: 0 }, { color: '#764ba2', position: 100 }] };

        var rgPreview = document.createElement('div');
        rgPreview.style.cssText = 'width:100%;height:40px;border-radius:4px;margin-bottom:10px;border:1px solid #dee2e6;';
        rgPreview.style.background = background.buildRadialGradient(rg);
        radialPanel.appendChild(rgPreview);

        var rgStopsContainer = document.createElement('div');
        rgStopsContainer.style.cssText = 'display:flex;flex-direction:column;gap:6px;';

        function renderRgStops() {
            rgStopsContainer.innerHTML = '';
            rg.stops.forEach(function(stop, idx) {
                var row = document.createElement('div');
                row.style.cssText = 'display:flex;align-items:center;gap:6px;';
                var ci = document.createElement('input');
                ci.type = 'color';
                ci.value = stop.color;
                ci.style.cssText = 'width:32px;height:24px;border:1px solid #dee2e6;border-radius:3px;cursor:pointer;';
                ci.addEventListener('input', function() {
                    stop.color = ci.value;
                    rgPreview.style.background = background.buildRadialGradient(rg);
                });
                var pi = document.createElement('input');
                pi.type = 'number';
                pi.min = '0';
                pi.max = '100';
                pi.value = stop.position;
                pi.style.cssText = 'width:50px;padding:2px 4px;border:1px solid #dee2e6;border-radius:3px;font-size:11px;';
                pi.addEventListener('change', function() {
                    stop.position = parseInt(pi.value, 10) || 0;
                    rgPreview.style.background = background.buildRadialGradient(rg);
                });
                var pct = document.createElement('span');
                pct.textContent = '%';
                pct.style.cssText = 'font-size:11px;color:#888;';
                var removeBtn = document.createElement('button');
                removeBtn.textContent = '\u00D7';
                removeBtn.style.cssText = 'border:none;background:none;cursor:pointer;font-size:14px;color:#dc3545;padding:0 4px;';
                removeBtn.addEventListener('click', function() {
                    if (rg.stops.length > 2) {
                        rg.stops.splice(idx, 1);
                        renderRgStops();
                        rgPreview.style.background = background.buildRadialGradient(rg);
                    }
                });
                if (rg.stops.length <= 2) { removeBtn.style.visibility = 'hidden'; }
                row.appendChild(ci);
                row.appendChild(pi);
                row.appendChild(pct);
                row.appendChild(removeBtn);
                rgStopsContainer.appendChild(row);
            });

            if (rg.stops.length < 4) {
                var addBtn = document.createElement('button');
                addBtn.textContent = str('add-stop');
                addBtn.className = 'btn btn-sm btn-secondary';
                addBtn.style.cssText = 'width:100%;margin-top:4px;font-size:11px;';
                addBtn.addEventListener('click', function() {
                    rg.stops.push({ color: '#cccccc', position: 50 });
                    renderRgStops();
                    rgPreview.style.background = background.buildRadialGradient(rg);
                });
                rgStopsContainer.appendChild(addBtn);
            }
        }
        renderRgStops();
        radialPanel.appendChild(rgStopsContainer);

        var rgApply = document.createElement('button');
        rgApply.className = 'btn btn-sm btn-primary';
        rgApply.textContent = str('bg-apply');
        rgApply.style.cssText = 'width:100%;margin-top:10px;';
        rgApply.addEventListener('click', function() {
            state.setSlideBackground(s.current, { type: 'radial-gradient', gradient: JSON.parse(JSON.stringify(rg)) });
        });
        radialPanel.appendChild(rgApply);

        panels.radial = radialPanel;
        wrapper.appendChild(radialPanel);

        // ---- Panel: Image ----
        var imagePanel = document.createElement('div');
        imagePanel.style.cssText = 'padding:12px;display:none;';

        var imgPreview = document.createElement('div');
        imgPreview.style.cssText = 'width:100%;height:60px;border-radius:4px;margin-bottom:10px;border:1px solid #dee2e6;background-size:cover;background-position:center;';
        if (bg.image) {
            imgPreview.style.backgroundImage = 'url(' + bg.image + ')';
        }
        imagePanel.appendChild(imgPreview);

        // Image fit selector
        var fitRow = document.createElement('div');
        fitRow.style.cssText = 'display:flex;align-items:center;gap:8px;margin-bottom:8px;';
        var fitLabel = document.createElement('span');
        fitLabel.textContent = str('image-fit');
        fitLabel.style.cssText = 'font-size:11px;min-width:60px;';
        var fitSelect = document.createElement('select');
        fitSelect.style.cssText = 'flex:1;padding:4px;border:1px solid #dee2e6;border-radius:3px;font-size:12px;';
        ['cover', 'contain', 'stretch'].forEach(function(opt) {
            var o = document.createElement('option');
            o.value = opt;
            try { o.textContent = str('image-fit-' + opt); } catch (e) { o.textContent = opt; }
            if ((bg.imageFit || 'cover') === opt) { o.selected = true; }
            fitSelect.appendChild(o);
        });
        fitRow.appendChild(fitLabel);
        fitRow.appendChild(fitSelect);
        imagePanel.appendChild(fitRow);

        // File picker button (opens the photo bank: bank / upload / URL)
        var imgBtnRow = document.createElement('div');
        imgBtnRow.style.cssText = 'display:flex;gap:6px;margin-top:8px;';
        var imgBtn = document.createElement('button');
        imgBtn.className = 'btn btn-sm btn-secondary';
        imgBtn.textContent = str('imagebank');
        imgBtn.style.cssText = 'flex:1;';
        imgBtn.addEventListener('click', function() {
            imagebank.open({
                mode: 'background',
                getFit: function() { return fitSelect.value; },
            });
            // Close the picker: its bg snapshot would go stale once the bank
            // applies a new image (a later fit change must not revert it).
            closeBackgroundPicker();
        });
        imgBtnRow.appendChild(imgBtn);

        // Remove image button
        if (bg.image) {
            var removeImgBtn = document.createElement('button');
            removeImgBtn.className = 'btn btn-sm btn-danger';
            removeImgBtn.textContent = str('bg-remove');
            removeImgBtn.addEventListener('click', function() {
                state.setSlideBackground(s.current, { type: 'solid', color: bg.color || '#ffffff' });
                imgPreview.style.backgroundImage = 'none';
                bg.image = '';
                closeBackgroundPicker();
            });
            imgBtnRow.appendChild(removeImgBtn);
        }
        imagePanel.appendChild(imgBtnRow);

        // Apply fit change
        fitSelect.addEventListener('change', function() {
            if (bg.image) {
                state.setSlideBackground(s.current, { type: 'image', color: bg.color || '#ffffff', image: bg.image, imageFit: fitSelect.value });
            }
        });

        panels.image = imagePanel;
        wrapper.appendChild(imagePanel);

        // Apply current background to every slide (one undo step)
        var applyAllRow = document.createElement('div');
        applyAllRow.style.cssText = 'border-top:1px solid #dee2e6;padding:8px 12px;';
        var applyAllBtn = document.createElement('button');
        applyAllBtn.type = 'button';
        applyAllBtn.className = 'btn btn-sm btn-secondary';
        applyAllBtn.style.cssText = 'width:100%;';
        applyAllBtn.textContent = str('applytoall');
        applyAllBtn.addEventListener('click', function() {
            var live = state.get();
            var liveSlide = live.slides[live.current];
            if (liveSlide && liveSlide.background) {
                state.setAllBackgrounds(liveSlide.background);
            }
            closeBackgroundPicker();
        });
        applyAllRow.appendChild(applyAllBtn);
        wrapper.appendChild(applyAllRow);

        // Activate current tab
        var currentTab = 'solid';
        if (bg.type === 'linear-gradient') { currentTab = 'linear'; }
        else if (bg.type === 'radial-gradient') { currentTab = 'radial'; }
        else if (bg.type === 'image') { currentTab = 'image'; }

        Object.keys(panels).forEach(function(k) { panels[k].style.display = 'none'; });
        panels[currentTab].style.display = 'block';
        tabBtns[currentTab].style.borderBottomColor = '#0d6efd';
        tabBtns[currentTab].style.background = '#f8f9fa';

        var editorEl = document.getElementById('slides-editor');
        var popupAnchor = anchorEl || editorEl;
        document.body.appendChild(wrapper);
        if (popupAnchor) {
            positionPopup(wrapper, popupAnchor);
            trapPopupWheel(wrapper);
        }

        function onBgOutsideClick(ev) {
            if (!wrapper.contains(ev.target)) {
                closeBackgroundPicker();
            }
        }
        setTimeout(function() {
            document.addEventListener('mousedown', onBgOutsideClick);
        }, 0);
        wrapper._onOutsideClick = onBgOutsideClick;
    }

    return { init: init };
});
