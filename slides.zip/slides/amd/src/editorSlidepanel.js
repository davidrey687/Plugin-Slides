/**
 * Slide panel — thumbnails, add/delete/duplicate/reorder, rename, drag & drop.
 * Uses event delegation on listEl to survive re-renders.
 *
 * @module     mod_slides/editorSlidepanel
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['mod_slides/editorState', 'mod_slides/editorShapes', 'mod_slides/editorPencil', 'mod_slides/editorBackground', 'mod_slides/editorIcons', 'mod_slides/editorImage', 'mod_slides/editorEquation'], function(state, shapes, pencil, background, icons, imageMod, equation) {
    'use strict';

    var CANVAS_W = 960;
    var THUMB_W = 150;
    var container = null;
    var listEl = null;
    var canvasHeight = 540;
    var renamingIdx = -1;

    // Drag state
    var dragFromIdx = -1;
    var dragOverThumb = null;
    var dragPosition = null; // 'above' | 'below'

    function init(c) {
        container = c;
        listEl = container.querySelector('#slidepanel-list');

        var root = document.getElementById('slides-editor');
        if (root) {
            canvasHeight = parseInt(root.dataset.canvasheight, 10) || 540;
        }

        var addBtn = container.querySelector('#slidepanel-add');
        if (addBtn) {
            addBtn.addEventListener('click', function() { state.addSlide(); });
        }

        // ---- Collapse / expand panel (PowerPoint-style) ----
        var collapseBtn = container.querySelector('#slidepanel-collapse');
        var root = document.getElementById('slides-editor');
        var expandBtn = root ? root.querySelector('#slidepanel-expand') : null;

        function setPanelCollapsed(collapsed) {
            container.classList.toggle('is-collapsed', collapsed);
            if (expandBtn) {
                expandBtn.style.display = collapsed ? 'flex' : 'none';
            }
            try {
                window.localStorage.setItem('slides-panel-collapsed', collapsed ? '1' : '0');
            } catch (e) { /* ignore */ }
            // Let the canvas ResizeObserver re-scale after the transition.
            setTimeout(function() {
                window.dispatchEvent(new Event('resize'));
            }, 200);
        }

        if (collapseBtn) {
            collapseBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                setPanelCollapsed(true);
            });
        }
        if (expandBtn) {
            expandBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                setPanelCollapsed(false);
            });
        }

        // Restore previous state
        try {
            if (window.localStorage.getItem('slides-panel-collapsed') === '1') {
                setPanelCollapsed(true);
            }
        } catch (e) { /* ignore */ }

        // ---- Delegated click — select slide ----
        listEl.addEventListener('click', function(e) {
            if (e.target.tagName === 'INPUT' || e.target.closest('.slide-context-menu')) { return; }
            var thumb = e.target.closest('.slide-thumb');
            if (!thumb) { return; }
            var idx = parseInt(thumb.dataset.idx, 10);
            state.setCurrent(idx);
        });

        // ---- Delegated dblclick — rename ----
        listEl.addEventListener('dblclick', function(e) {
            if (e.target.tagName === 'INPUT') { return; }
            var label = e.target.closest('.slide-thumb-label');
            if (!label) { return; }
            var thumb = label.closest('.slide-thumb');
            if (!thumb) { return; }
            var idx = parseInt(thumb.dataset.idx, 10);
            startRename(idx);
        });

        // ---- Delegated context menu ----
        listEl.addEventListener('contextmenu', function(e) {
            if (e.target.tagName === 'INPUT') { return; }
            var thumb = e.target.closest('.slide-thumb');
            if (!thumb) { return; }
            e.preventDefault();
            var idx = parseInt(thumb.dataset.idx, 10);
            showContextMenu(e.clientX, e.clientY, idx);
        });

        // ---- Delegated drag & drop ----
        listEl.addEventListener('dragstart', function(e) {
            if (renamingIdx >= 0) { e.preventDefault(); return; }
            var thumb = e.target.closest('.slide-thumb');
            if (!thumb) { return; }
            dragFromIdx = parseInt(thumb.dataset.idx, 10);
            thumb.classList.add('is-dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', dragFromIdx.toString());
        });

        listEl.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            clearDropIndicators();
            var thumb = e.target.closest('.slide-thumb');
            if (!thumb) { return; }
            var rect = thumb.getBoundingClientRect();
            var midY = rect.top + rect.height / 2;
            dragOverThumb = thumb;
            dragPosition = (e.clientY < midY) ? 'above' : 'below';
            thumb.classList.add(dragPosition === 'above' ? 'drop-above' : 'drop-below');
        });

        // Only clear when leaving the listEl entirely (not between children)
        listEl.addEventListener('dragleave', function(e) {
            if (e.relatedTarget && listEl.contains(e.relatedTarget)) { return; }
            clearDropIndicators();
        });

        listEl.addEventListener('drop', function(e) {
            e.preventDefault();
            clearDropIndicators();
            if (dragFromIdx < 0) { return; }
            var insertIdx = computeInsertIndex(e.clientY);
            // No-op: already in correct position
            if (insertIdx === dragFromIdx || insertIdx === dragFromIdx + 1) { return; }
            state.moveSlide(dragFromIdx, insertIdx > dragFromIdx ? insertIdx - 1 : insertIdx);
        });

        listEl.addEventListener('dragend', function(e) {
            clearDropIndicators();
            var dragging = listEl.querySelector('.is-dragging');
            if (dragging) { dragging.classList.remove('is-dragging'); }
            dragFromIdx = -1;
        });

        state.subscribe(render);
        render();
    }

    function clearDropIndicators() {
        var old = listEl.querySelectorAll('.drop-above, .drop-below');
        for (var i = 0; i < old.length; i++) {
            old[i].classList.remove('drop-above', 'drop-below');
        }
        dragOverThumb = null;
        dragPosition = null;
    }

    function computeInsertIndex(clientY) {
        var thumbs = listEl.querySelectorAll('.slide-thumb');
        for (var i = 0; i < thumbs.length; i++) {
            var rect = thumbs[i].getBoundingClientRect();
            if (clientY < rect.top + rect.height / 2) { return i; }
        }
        return thumbs.length;
    }

    function render() {
        var s = state.get();
        listEl.innerHTML = '';

        s.slides.forEach(function(slide, idx) {
            var thumb = document.createElement('div');
            thumb.className = 'slide-thumb' + (idx === s.current ? ' is-active' : '');
            thumb.dataset.idx = idx;
            // Enable drag except during rename
            if (renamingIdx < 0) { thumb.draggable = true; }

            var inner = document.createElement('div');
            inner.className = 'slide-thumb-canvas';
            inner.style.cssText = 'width:100%;aspect-ratio:' + CANVAS_W + '/' + canvasHeight +
                ';position:relative;overflow:hidden;background:' +
                background.toCss(slide.background) + ';border-radius:3px;';

            (slide.elements || []).forEach(function(el) {
                if (el._visible === false) { return; }
                renderThumbElement(inner, el);
            });

            thumb.appendChild(inner);

            var label = document.createElement('div');
            label.className = 'slide-thumb-label';
            label.textContent = (idx + 1) + '. ' + (slide.title || '');
            thumb.appendChild(label);

            var moreBtn = document.createElement('button');
            moreBtn.type = 'button';
            moreBtn.className = 'slide-thumb-more';
            try {
                moreBtn.title = M.util.get_string('slidemenu', 'mod_slides');
                moreBtn.setAttribute('aria-label', M.util.get_string('slidemenu', 'mod_slides'));
            } catch (e) { /* ignore */ }
            moreBtn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true" focusable="false"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>';
            moreBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                var rect = moreBtn.getBoundingClientRect();
                var menuY = Math.min(rect.bottom + 4, window.innerHeight - 200);
                showContextMenu(rect.left, Math.max(8, menuY), idx);
            });
            thumb.appendChild(moreBtn);

            listEl.appendChild(thumb);
        });
    }

    function pct(v, total) {
        return (v / total * 100) + '%';
    }

    function renderThumbElement(parent, el) {
        var div = document.createElement('div');
        div.className = 'slide-element slide-element--' + (el.type || 'text');
        div.style.cssText = 'position:absolute;left:' + pct(el.x, CANVAS_W) +
            ';top:' + pct(el.y, canvasHeight) +
            ';width:' + pct(el.w, CANVAS_W) +
            ';height:' + pct(el.h, canvasHeight) + ';';

        var opacity = (el.opacity !== undefined) ? el.opacity / 100 : 1;
        var thumbScale = THUMB_W / CANVAS_W;

        if (el.type === 'image') {
            div.style.overflow = 'hidden';
            if (el.src) {
                var img = document.createElement('img');
                img.src = el.src;
                img.alt = '';
                if (imageMod && imageMod.hasCrop(el)) {
                    div.style.borderRadius = (el.borderRadius || 0) + 'px';
                    img.style.cssText = imageMod.croppedImgStyle(el) + 'pointer-events:none;';
                } else {
                    img.style.cssText = 'width:100%;height:100%;object-fit:contain;display:block;opacity:' + opacity + ';pointer-events:none;';
                }
                div.appendChild(img);
            } else {
                div.style.background = '#f8f9fa';
                div.style.border = '1px dashed #adb5bd';
            }

        } else if (el.type === 'video') {
            div.style.cssText += 'background:#1a1a2e;border-radius:3px;display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var play = document.createElement('div');
            play.style.cssText = 'width:36%;height:36%;color:rgba(255,255,255,0.9);';
            play.innerHTML = icons.get('play', {size: '100%'});
            div.appendChild(play);

        } else if (el.type === 'pdf') {
            div.style.cssText += 'background:#f8f9fa;border:1px dashed #dee2e6;border-radius:3px;' +
                'display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var pdfIcon = document.createElement('div');
            pdfIcon.style.cssText = 'width:40%;height:40%;color:#dc3545;pointer-events:none;';
            pdfIcon.innerHTML = icons.get('pdf', {size: '100%'});
            div.appendChild(pdfIcon);

        } else if (el.type === 'html') {
            // Thumbnails never load the embed itself (iframes would be far too
            // heavy here): a light code card stands in for the element.
            div.style.cssText += 'background:#f8f9fa;border:1px dashed #dee2e6;border-radius:3px;' +
                'display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var htmlIcon = document.createElement('div');
            htmlIcon.style.cssText = 'width:40%;height:40%;color:#6f42c1;pointer-events:none;';
            htmlIcon.innerHTML = icons.get('code', {size: '100%'});
            div.appendChild(htmlIcon);

        } else if (el.type === 'audio') {
            // Thumbnail for a recorded clip: a light mic card (never load
            // the player here — it would autoplay on every re-render).
            div.style.cssText += 'background:#eef5ff;border:1px dashed #b6d4fe;border-radius:3px;' +
                'display:flex;align-items:center;justify-content:center;overflow:hidden;opacity:' + opacity + ';';
            var micIcon = document.createElement('div');
            micIcon.style.cssText = 'width:40%;height:40%;color:#0d6efd;pointer-events:none;';
            micIcon.innerHTML = icons.get('mic', {size: '100%'});
            div.appendChild(micIcon);

        } else if (el.type === 'pencil' && pencil && pencil.renderSvg) {
            div.style.overflow = 'visible';
            var miniSvg = pencil.renderSvg(el);
            miniSvg.setAttribute('viewBox', '0 0 ' + el.w + ' ' + el.h);
            miniSvg.style.cssText = 'width:100%;height:100%;display:block;pointer-events:none;';
            div.appendChild(miniSvg);

        } else if (el.type === 'shape' && shapes && shapes.innerStyle) {
            div.style.overflow = 'visible';
            var innerDiv = document.createElement('div');
            innerDiv.className = 'shape-inner';
            innerDiv.style.cssText = shapes.innerStyle(el);
            div.appendChild(innerDiv);

        } else if (el.type === 'equation') {
            var eqJustify = el.align === 'left' ? 'flex-start' : (el.align === 'right' ? 'flex-end' : 'center');
            div.style.cssText += 'display:flex;align-items:center;justify-content:' + eqJustify + ';overflow:hidden;' +
                'font-size:' + Math.max(3, (el.fontSize || 32) * thumbScale) + 'px;' +
                'color:' + (el.color || '#000') + ';line-height:1.2;box-sizing:border-box;opacity:' + opacity + ';';
            div.innerHTML = equation.renderHtml(el.text || '');

        } else {
            div.style.cssText += 'font-size:' + Math.max(3, (el.fontSize || 24) * thumbScale) +
                'px;color:' + (el.color || '#000') +
                ';text-align:' + (el.align || 'left') +
                ';font-family:' + (el.fontfamily || 'sans-serif') + ';' +
                (el.bold ? 'font-weight:bold;' : '') +
                (el.italic ? 'font-style:italic;' : '') +
                'overflow:hidden;line-height:1.3;white-space:pre-wrap;box-sizing:border-box;opacity:' + opacity + ';';
            div.textContent = el.text || '';
        }

        parent.appendChild(div);
    }

    /* ---- Rename ---------------------------------------------------------- */
    function startRename(idx) {
        if (renamingIdx >= 0) { commitRename(renamingIdx); }
        renamingIdx = idx;

        state.setCurrent(idx);

        var thumb = listEl.querySelector('.slide-thumb[data-idx="' + idx + '"]');
        if (!thumb) { return; }
        var label = thumb.querySelector('.slide-thumb-label');
        if (!label) { return; }

        var s = state.get();
        var currentTitle = s.slides[idx].title || '';

        var input = document.createElement('input');
        input.className = 'slide-rename-input';
        input.type = 'text';
        input.value = currentTitle;
        input.style.cssText = 'width:140px;padding:2px 4px;border:1px solid #0d6efd;border-radius:3px;font-size:11px;outline:none;';

        input.addEventListener('mousedown', function(e) { e.stopPropagation(); });
        input.addEventListener('click', function(e) { e.stopPropagation(); });
        input.addEventListener('dblclick', function(e) { e.stopPropagation(); });

        label.textContent = '';
        label.appendChild(input);
        input.focus();
        input.select();

        var committed = false;

        input.addEventListener('blur', function() {
            if (!committed) {
                committed = true;
                var newTitle = input.value.trim() || currentTitle;
                renamingIdx = -1;
                if (newTitle !== currentTitle) {
                    state.renameSlide(idx, newTitle);
                }
            }
        });

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                committed = true;
                var newTitle = input.value.trim() || currentTitle;
                renamingIdx = -1;
                if (newTitle !== currentTitle) {
                    state.renameSlide(idx, newTitle);
                }
            }
            if (e.key === 'Escape') {
                committed = true;
                renamingIdx = -1;
                state.notify();
            }
        });
    }

    /* ---- Context menu ---------------------------------------------------- */
    function showContextMenu(x, y, idx) {
        removeContextMenu();
        var menu = document.createElement('div');
        menu.className = 'slide-context-menu';
        menu.style.cssText = 'position:fixed;left:' + x + 'px;top:' + y + 'px;z-index:1000;background:#fff;border:1px solid #ccc;border-radius:4px;box-shadow:0 2px 8px rgba(0,0,0,0.15);padding:4px 0;min-width:150px;';

        var str = M.util.get_string;
        var items = [
            { label: str('rename', 'mod_slides'), action: function() { startRename(idx); } },
            { label: str('duplicateslide', 'mod_slides'), action: function() { state.duplicateSlide(idx); } },
            { label: str('moveup', 'mod_slides') || 'Subir', action: function() { state.moveSlide(idx, idx - 1); } },
            { label: str('movedown', 'mod_slides') || 'Bajar', action: function() { state.moveSlide(idx, idx + 1); } },
            { label: str('deleteslide', 'mod_slides'), action: function() { state.deleteSlide(idx); }, cls: 'text-danger' },
        ];

        items.forEach(function(item) {
            var btn = document.createElement('button');
            btn.className = 'dropdown-item' + (item.cls ? ' ' + item.cls : '');
            btn.textContent = item.label;
            btn.style.cssText = 'display:block;width:100%;padding:6px 16px;border:none;background:none;text-align:left;cursor:pointer;font-size:13px;';
            btn.addEventListener('click', function() { removeContextMenu(); item.action(); });
            menu.appendChild(btn);
        });

        document.body.appendChild(menu);
        var mw = menu.offsetWidth;
        var mh = menu.offsetHeight;
        var menuLeft = x;
        var menuTop = y;
        if (menuLeft + mw > window.innerWidth - 8) {
            menuLeft = Math.max(8, window.innerWidth - mw - 8);
        }
        if (menuTop + mh > window.innerHeight - 8) {
            menuTop = Math.max(8, window.innerHeight - mh - 8);
        }
        menu.style.left = menuLeft + 'px';
        menu.style.top = menuTop + 'px';
        document.addEventListener('click', removeContextMenu, { once: true });
    }

    function removeContextMenu() {
        var old = document.querySelector('.slide-context-menu');
        if (old) { old.remove(); }
    }

    return { init: init };
});
