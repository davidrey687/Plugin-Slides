/**
 * Save/load module for the slides editor.
 *
 * @module     mod_slides/editorSave
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['core/ajax', 'core/notification'], function(Ajax, Notification) {
    'use strict';

    return {
        load: function(cmid) {
            return Ajax.call([{
                methodname: 'mod_slides_get_deck',
                args: { cmid: cmid },
            }])[0];
        },

        save: function(cmid, deck, sesskey, opts) {
            var serialised = deck.map(function(s, i) {
                var bg = s.background || { color: '#ffffff' };
                if (typeof bg === 'string') {
                    try { bg = JSON.parse(bg); } catch (e) { bg = { color: '#ffffff' }; }
                }

                return {
                    title: s.title || '',
                    sortorder: i,
                    elements: (s.elements || []).map(function(el) {
                        // Only send fields that are defined in the PHP parameters
                        var clean = {
                            type: el.type || 'text',
                            x: Math.round(el.x || 0),
                            y: Math.round(el.y || 0),
                            w: Math.round(el.w || 200),
                            h: Math.round(el.h || 40),
                        };

                        if (el.type === 'text') {
                            clean.text = el.text || '';
                            clean.fontfamily = el.fontfamily || 'sans-serif';
                            clean.fontSize = el.fontSize || 24;
                            clean.color = el.color || '#000000';
                            clean.highlight = el.highlight || '';
                            clean.align = el.align || 'left';
                            clean.bold = !!el.bold;
                            clean.italic = !!el.italic;
                            clean.underline = !!el.underline;
                            clean.strikethrough = !!el.strikethrough;
                            clean.listType = el.listType || 'none';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'shape') {
                            clean.shape = el.shape || 'rect';
                            // Preserve an empty fill (transparent): '' must not
                            // fall back to the default colour.
                            clean.fill = (el.fill === undefined || el.fill === null) ? '#0d6efd' : el.fill;
                            clean.stroke = el.stroke || '#1a1a2e';
                            clean.strokeWidth = el.strokeWidth || 0;
                            clean.angle = el.angle || 0;
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'pencil') {
                            clean.stroke = el.stroke || '#1a1a2e';
                            clean.strokeWidth = el.strokeWidth || 2;
                            clean.points = el.points || [];
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'image') {
                            clean.src = el.src || '';
                            clean.alt = el.alt || '';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.borderRadius = el.borderRadius || 0;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                            if (el.crop && el.crop.w > 0 && el.crop.w <= 1 && el.crop.h > 0 && el.crop.h <= 1) {
                                clean.crop = {
                                    x: el.crop.x || 0,
                                    y: el.crop.y || 0,
                                    w: el.crop.w,
                                    h: el.crop.h,
                                };
                            }
                        }

                        if (el.type === 'video') {
                            clean.src = el.src || '';
                            clean.alt = el.alt || '';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'pdf') {
                            clean.src = el.src || '';
                            clean.pdftitle = el.pdftitle || '';
                            clean.alt = el.alt || '';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.borderRadius = el.borderRadius || 0;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'link') {
                            clean.text = el.text || '';
                            clean.url = el.url || '';
                            clean.target = el.target || '_blank';
                            clean.fontfamily = el.fontfamily || 'sans-serif';
                            clean.fontSize = el.fontSize || 20;
                            clean.color = el.color || '#0d6efd';
                            clean.background = el.background || '#e7f1ff';
                            clean.align = el.align || 'center';
                            clean.bold = !!el.bold;
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'footer') {
                            clean.text = el.text || '';
                            clean.fontfamily = el.fontfamily || 'sans-serif';
                            clean.fontSize = el.fontSize || 14;
                            clean.color = el.color || '#888888';
                            clean.align = el.align || 'center';
                            clean.bold = !!el.bold;
                            clean.italic = !!el.italic;
                            clean.background = el.background || '#f8f9fa';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'chart') {
                            clean.charttype = el.charttype || 'bar';
                            clean.title = el.title || '';
                            clean.labels = el.labels || '';
                            clean.values = el.values || '';
                            clean.titleColor = el.titleColor || '#1a1a2e';
                            clean.valueColor = el.valueColor || '#333333';
                            clean.bgColor = el.bgColor || '#ffffff';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'equation') {
                            // TeX source lives in the standard `text` field so the
                            // webservice/sanitiser schema needs no new keys; the
                            // formula is re-rendered from it on every view.
                            clean.text = el.text || '';
                            clean.fontSize = el.fontSize || 32;
                            clean.color = el.color || '#000000';
                            clean.align = el.align || 'center';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'html') {
                            // Same convention as equations: the markup lives in the
                            // standard `text` field (cleaned server-side on save).
                            clean.text = el.text || '';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.borderRadius = el.borderRadius || 0;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        if (el.type === 'audio') {
                            // Recording stored in the slides_media file area:
                            // only the pluginfile reference travels in the deck.
                            clean.src = el.src || '';
                            clean.alt = el.alt || '';
                            clean.opacity = el.opacity !== undefined ? el.opacity : 100;
                            clean.shadowEnabled = !!el.shadowEnabled;
                            clean.shadowColor = el.shadowColor || '#00000080';
                            clean.shadowBlur = el.shadowBlur || 0;
                            clean.shadowX = el.shadowX || 0;
                            clean.shadowY = el.shadowY || 0;
                        }

                        // Interactive link attached to any element type
                        // (image / shape / text / link): only send it when the
                        // element actually carries one; the server re-validates
                        // the scheme and whitelists the target window.
                        if (el.url) {
                            clean.url = el.url;
                            clean.target = el.target === '_self' ? '_self' : '_blank';
                        }

                        // Click-to-reveal animation (cross-type, like opacity):
                        // order 0 = not animated, 1..N = appearance sequence.
                        // Interactive action buttons (Genially-style).
                        if (el.type === 'action') {
                            clean.actionId = el.actionId || '';
                            clean.slideIdx = (typeof el.slideIdx === 'number') ? el.slideIdx : 0;
                            clean.label = el.label || '';
                            clean.bg = el.bg || '#0d6efd';
                            clean.shape = el.shape || '';
                            clean.behavior = (el.behavior && typeof el.behavior === 'object') ? el.behavior : { kind: 'label', text: '' };
                        }

                        clean.animOrder = el.animOrder || 0;
                        clean.animType = el.animType || '';

                        return clean;
                    }),
                    background: JSON.stringify(bg),
                    transition: s.transition || 'none',
                };
            });

            return Ajax.call([{
                methodname: 'mod_slides_save_deck',
                args: { cmid: cmid, deck: serialised, sesskey: sesskey },
            }])[0].catch(function(ex) {
                // Autosave runs in the background: report failures through the
                // status indicator instead of popping a modal on every retry.
                if (!(opts && opts.quiet)) {
                    Notification.exception(ex);
                }
                throw ex;
            });
        },
    };
});
