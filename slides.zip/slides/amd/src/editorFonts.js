/**
 * Bundled web font preloading for the editor.
 *
 * The font files ship with the plugin (mod/slides/fonts/fonts.css); this module
 * only forces the browser to fetch them up-front so the dropdown previews render
 * with the real typeface immediately instead of falling back.
 *
 * @module     mod_slides/editorFonts
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(function() {
    'use strict';

    var preloaded = false;

    function familyNameOf(value) {
        var match = /^"([^"]+)"/.exec(value || '');
        if (match) {
            return match[1];
        }
        var first = String(value || '').split(',')[0].trim();
        return /^[A-Za-z0-9 ]+$/.test(first) ? first : null;
    }

    return {
        /**
         * Warm up every bundled web font (weights 400/700) used by the bank.
         * Safe to call once; repeated calls are no-ops.
         *
         * @param {Array} options Entries from getFontFamilyOptions() ({value, label, cat}).
         * @return {Promise}
         */
        preload: function(options) {
            if (preloaded || !document.fonts || !document.fonts.load) {
                return Promise.resolve();
            }
            preloaded = true;

            var promises = [];
            (options || []).forEach(function(opt) {
                if (opt.cat !== 'web') {
                    return;
                }
                var family = familyNameOf(opt.value);
                if (!family) {
                    return;
                }
                [400, 700].forEach(function(weight) {
                    try {
                        promises.push(document.fonts.load(weight + ' 16px "' + family + '"'));
                    } catch (e) {
                        // Older browsers: previews still work, just after first paint.
                    }
                });
            });
            return Promise.all(promises).catch(function() { /* never break init */ });
        },
    };
});
