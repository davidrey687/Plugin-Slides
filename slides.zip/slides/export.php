<?php
/**
 * SCORM 1.2 package download endpoint for mod_slides.
 *
 * Generates the package with the plugin's exporter and streams it back as an
 * attachment. Every step happens inside mod/slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');

use mod_slides\local\scorm\exporter;

$id       = required_param('id', PARAM_INT);
$sesskey  = optional_param('sesskey', '', PARAM_RAW);
$backto   = optional_param('backto', 'view', PARAM_ALPHA);

[$course, $cm] = get_course_and_cm_from_cmid($id, 'slides');
$instance = $DB->get_record('slides', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, false, $cm);

$context = context_module::instance($cm->id);
require_capability('mod/slides:edit', $context);

$PAGE->set_url(new moodle_url('/mod/slides/export.php', ['id' => $id]));
$PAGE->set_context($context);

$backurl = new moodle_url($backto === 'edit' ? '/mod/slides/edit.php' : '/mod/slides/view.php', ['id' => $id]);

if ($sesskey !== '') {
    require_sesskey();
} else {
    // Direct hits without a session key are rejected: exporting is a write
    // level action for editors only.
    redirect($backurl, get_string('invalidsesskey', 'error'));
}

try {
    $result = exporter::run($instance, $cm, $context);
} catch (\Throwable $e) {
    redirect($backurl, $e->getMessage(), null, \core\output\notification::NOTIFY_ERROR);
}

// Stream the archive and clean the temporary file up afterwards.
send_file(
    $result['zip'],
    $result['filename'],
    0,
    0,
    false,
    true,          // forcedownload
    'application/zip',
    true           // dontdie, so we can unlink the temporary file
);

@unlink($result['zip']);
exit;
