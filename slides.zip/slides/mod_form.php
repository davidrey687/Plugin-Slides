<?php
/**
 * Activity creation/editing form for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once($CFG->dirroot . '/course/moodleform_mod.php');

class mod_slides_mod_form extends moodleform_mod {

    function definition() {
        global $CFG;

        $mform = $this->_form;

        $mform->addElement('header', 'general', get_string('general'));

        $mform->addElement('text', 'name', get_string('name', 'mod_slides'), ['size' => '64']);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');

        $this->standard_intro_elements(get_string('intro', 'mod_slides'));

        $aspectoptions = [
            '16:9' => '16:9 (' . get_string('widescreen', 'mod_slides') . ')',
            '4:3'  => '4:3 (' . get_string('standard', 'mod_slides') . ')',
        ];
        $mform->addElement('select', 'aspectratio', get_string('aspectratio', 'mod_slides'), $aspectoptions);
        $mform->setDefault('aspectratio', '16:9');

        // File manager for images
        $filemanageroptions = [
            'accepted_types' => ['web_image'],
            'maxbytes' => $CFG->maxbytes,
            'maxfiles' => 50,
        ];
        $mform->addElement('filemanager', 'files', get_string('files', 'mod_slides'), null, $filemanageroptions);

        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }

    function data_preprocessing(&$default_values) {
        parent::data_preprocessing($default_values);

        if ($this->current->instance) {
            $draftitemid = file_get_submitted_draft_itemid('files');
            file_prepare_draft_area($draftitemid, $this->context->id, 'mod_slides', 'slides_files', 0, ['subdirs' => true]);
            $default_values['files'] = $draftitemid;
        }
    }

    function validation($data, $files) {
        $errors = parent::validation($data, $files);
        return $errors;
    }
}
