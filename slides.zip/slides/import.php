<?php
/**
 * SCORM 1.2 package import page for mod_slides.
 *
 * Uploads a .zip with the File API, hands it to the plugin's importer and
 * replaces the slides of this activity.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');

use mod_slides\event\slides_updated;
use mod_slides\local\deck;
use mod_slides\local\scorm\importer;

require_once($CFG->libdir . '/formslib.php');
require_once(__DIR__ . '/import_form.php');

$id = required_param('id', PARAM_INT);

[$course, $cm] = get_course_and_cm_from_cmid($id, 'slides');
$instance = $DB->get_record('slides', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, false, $cm);

$context = context_module::instance($cm->id);
require_capability('mod/slides:edit', $context);

$viewurl = new moodle_url('/mod/slides/view.php', ['id' => $id]);

$PAGE->set_url(new moodle_url('/mod/slides/import.php', ['id' => $id]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('importscorm', 'mod_slides') . ': ' . $instance->name);
$PAGE->set_heading($instance->name);

$form = new mod_slides_import_form(new moodle_url('/mod/slides/import.php', ['id' => $id]));

if ($form->is_cancelled()) {
    redirect($viewurl);
}

$error = '';
$result = null;

if ($form->is_submitted() && $form->is_validated()) {
    $file = $form->save_stored_file('package', $context->id, 'mod_slides', 'scormimport', 0, '/', null, true);

    if (!$file) {
        $error = get_string('importfailed', 'mod_slides');
    } else {
        try {
            if (strtolower(pathinfo($file->get_filename(), PATHINFO_EXTENSION)) !== 'zip') {
                throw new moodle_exception('invalidpackage', 'mod_slides');
            }
            $result = importer::import($file, $instance);
        } catch (\Throwable $e) {
            $error = $e->getMessage();
        } finally {
            // The package itself is never kept: the deck is now self contained.
            $file->delete();
        }
    }
}

if ($result !== null) {
    slides_updated::create_from_instance($instance, $context)->trigger();

    $notice = $result['format'] === 'native'
        ? get_string('importsuccess', 'mod_slides', $result['slides'])
        : get_string('importsuccessgeneric', 'mod_slides', $result['slides']);

    redirect($viewurl, $notice, null, \core\output\notification::NOTIFY_SUCCESS);
}

$existing = deck::get_deck($instance->id);
$slidecount = count($existing);

$warning = $slidecount > 0
    ? get_string('importwarning', 'mod_slides', $slidecount)
    : get_string('importwarningempty', 'mod_slides');

echo $OUTPUT->header();

if ($error !== '') {
    echo $OUTPUT->notification($error, 'error');
}

echo $OUTPUT->render_from_template('mod_slides/import', [
    'warning'    => $warning,
    'slidecount' => $slidecount,
    'form'       => $form->render(),
]);

echo $OUTPUT->footer();
