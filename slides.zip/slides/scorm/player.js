/**
 * mod_slides — standalone SCORM 1.2 player.
 *
 * Renders the statically generated markup of templates/viewer.mustache:
 * scales the canvas, navigates between slides, replays the CSS transitions and
 * reports progress to the LMS through SlidesScorm (APIWrapper.js).
 *
 * Works with or without an LMS API: opened directly in a browser it is just a
 * regular presentation.
 *
 * @package   mod_slides
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
(function() {
    'use strict';

    var root, viewportEl, canvasEl;
    var slides = [];
    var transitions = [];
    var current = 0;
    var total = 0;
    var CANVAS_W = 960;
    var isFullscreen = false;

    /* ------------------------------------------------------------------ */
    /* SCORM state                                                         */
    /* ------------------------------------------------------------------ */
    var scorm = {
        active: false,
        startedAt: 0,
        visited: {},
        total: 0,
        bestScore: 0,
        completed: false,
        commitTimer: null
    };

    var TRANSITION_ANIM = {
        'fade': 'slideFadeIn',
        'push': 'slidePushIn',
        'transform': 'slideTransformIn',
        'slide-left': 'slideSlideLeftIn',
        'slide-up': 'slideSlideUpIn',
        'slide-down': 'slideSlideDownIn',
        'zoom': 'slideZoomIn',
        'flip': 'slideFlipIn',
        'reveal': 'slideRevealIn',
        'cube': 'slideCubeIn'
        // 'none' and 'cut' are handled as instant switches.
    };

    /* ------------------------------------------------------------------ */
    /* Canvas scaling                                                      */
    /* ------------------------------------------------------------------ */
    function scaleCanvas() {
        if (!viewportEl || !canvasEl) {
            return;
        }
        var vw = viewportEl.clientWidth;
        if (!vw) {
            return;
        }
        canvasEl.style.transform = 'scale(' + (vw / CANVAS_W) + ')';
    }

    /* ------------------------------------------------------------------ */
    /* Navigation                                                          */
    /* ------------------------------------------------------------------ */
    function applyTransition(nextEl, animate) {
        if (!animate || !nextEl) {
            return;
        }
        var type = transitions[current] || 'none';
        var key = TRANSITION_ANIM[type];
        if (!key) {
            return;
        }
        nextEl.style.animation = 'none';
        // Force a reflow so the animation restarts even when revisiting.
        void nextEl.offsetWidth;
        nextEl.style.animation = key + ' 0.5s ease';
    }

    function render(animate) {
        if (!canvasEl || !slides.length) {
            return;
        }
        current = Math.max(0, Math.min(current, slides.length - 1));

        var previous = canvasEl.querySelector('.slide.is-active');
        var next = slides[current];
        if (!next) {
            return;
        }

        if (previous && previous !== next) {
            previous.classList.remove('is-active');
            previous.style.animation = '';
        }
        next.classList.add('is-active');
        applyTransition(next, animate && previous !== next);

        updateCounter();
        updateProgress();
        onSlideShown();
    }

    function goTo(index, animate) {
        if (index < 0 || index >= slides.length || index === current) {
            if (index === current) {
                render(false);
            }
            return;
        }
        current = index;
        render(animate !== false);
    }

    function next() {
        if (current < slides.length - 1) {
            current++;
            render(true);
        }
    }

    function prev() {
        if (current > 0) {
            current--;
            render(true);
        }
    }

    function updateCounter() {
        var counter = root.querySelector('.slides-counter');
        if (counter) {
            counter.textContent = (current + 1) + ' / ' + slides.length;
        }
    }

    function updateProgress() {
        var bar = root.querySelector('.slides-progress-bar');
        if (bar && slides.length > 0) {
            bar.style.width = (((current + 1) / slides.length) * 100) + '%';
        }
    }

    /* ------------------------------------------------------------------ */
    /* Fullscreen                                                          */
    /* ------------------------------------------------------------------ */
    function toggleFullscreen() {
        if (!document.fullscreenElement && !document.webkitFullscreenElement) {
            var request = root.requestFullscreen || root.webkitRequestFullscreen;
            if (!request) {
                return;
            }
            var result = request.call(root);
            if (result && result.then) {
                result.then(function() {
                    isFullscreen = true;
                    root.classList.add('is-fullscreen');
                    scaleCanvas();
                });
            } else {
                isFullscreen = true;
                root.classList.add('is-fullscreen');
                scaleCanvas();
            }
        } else {
            var exit = document.exitFullscreen || document.webkitExitFullscreen;
            if (exit) {
                exit.call(document);
            }
            isFullscreen = false;
            root.classList.remove('is-fullscreen');
            scaleCanvas();
        }
    }

    function exitFullscreen() {
        if (document.fullscreenElement || document.webkitFullscreenElement) {
            var exit = document.exitFullscreen || document.webkitExitFullscreen;
            if (exit) {
                exit.call(document);
            }
        }
        isFullscreen = false;
        root.classList.remove('is-fullscreen');
        scaleCanvas();
    }

    /* ------------------------------------------------------------------ */
    /* SCORM                                                               */
    /* ------------------------------------------------------------------ */
    function onSlideShown() {
        if (!scorm.active) {
            return;
        }

        var onebased = current + 1;
        scorm.visited[onebased] = true;

        SlidesScorm.set('cmi.core.lesson_location', String(onebased));

        var score = Math.round((Object.keys(scorm.visited).length / scorm.total) * 100);
        if (score > scorm.bestScore) {
            scorm.bestScore = score;
            SlidesScorm.set('cmi.core.score.raw', String(scorm.bestScore));
        }

        // Reaching the last slide completes the SCO.
        if (current === scorm.total - 1 && !scorm.completed) {
            scorm.completed = true;
            SlidesScorm.set('cmi.core.lesson_status', 'completed');
        }

        SlidesScorm.commit();
    }

    function scormInit() {
        scorm.total = slides.length;
        if (!scorm.total || typeof SlidesScorm === 'undefined') {
            return;
        }

        scorm.active = SlidesScorm.init();
        if (!scorm.active) {
            return;
        }

        scorm.startedAt = Date.now();

        var status = SlidesScorm.get('cmi.core.lesson_status');
        if (!status || status === 'not attempted') {
            SlidesScorm.set('cmi.core.lesson_status', 'incomplete');
        } else if (status === 'completed' || status === 'passed' || status === 'failed') {
            scorm.completed = true;
        }

        // Restore the previous score so revisiting never lowers it.
        var stored = parseInt(SlidesScorm.get('cmi.core.score.raw'), 10);
        if (!isNaN(stored) && stored > 0) {
            scorm.bestScore = stored;
        }

        SlidesScorm.set('cmi.core.session_time', '00:00:00.00');
        SlidesScorm.commit();

        // Resume where the learner left off.
        var location = parseInt(SlidesScorm.get('cmi.core.lesson_location'), 10);
        if (!isNaN(location) && location >= 1 && location <= slides.length) {
            current = location - 1;
            render(false);
        }

        scorm.commitTimer = setInterval(function() {
            if (scorm.active) {
                SlidesScorm.commit();
            }
        }, 30000);

        // The slide shown during boot counts as visited.
        onSlideShown();
    }

    function scormTerminate() {
        if (!scorm.active || typeof SlidesScorm === 'undefined') {
            return;
        }
        if (scorm.commitTimer) {
            clearInterval(scorm.commitTimer);
            scorm.commitTimer = null;
        }

        var elapsed = scorm.startedAt ? (Date.now() - scorm.startedAt) / 1000 : 0;
        SlidesScorm.set('cmi.core.session_time', SlidesScorm.formatTime(elapsed));
        SlidesScorm.set('cmi.core.exit', scorm.completed ? 'normal' : 'suspend');
        SlidesScorm.terminate();
        scorm.active = false;
    }

    /* ------------------------------------------------------------------ */
    /* Events                                                              */
    /* ------------------------------------------------------------------ */
    function isInteractive(target) {
        var sel = 'a, button, video, iframe, input, textarea, select, .slides-progress, [data-no-nav]';
        return !!(target && target.closest && target.closest(sel));
    }

    var NAV_ZONE = 0.15;

    function navZoneAt(clientX) {
        if (!viewportEl) {
            return null;
        }
        var rect = viewportEl.getBoundingClientRect();
        if (!rect.width) {
            return null;
        }
        var ratio = (clientX - rect.left) / rect.width;
        if (ratio <= NAV_ZONE) {
            return 'prev';
        }
        if (ratio >= 1 - NAV_ZONE) {
            return 'next';
        }
        return null;
    }

    function setHotZone(zone) {
        var navPrev = root.querySelector('.slides-nav-zone--prev');
        var navNext = root.querySelector('.slides-nav-zone--next');
        if (navPrev) {
            navPrev.classList.toggle('is-hot', zone === 'prev');
        }
        if (navNext) {
            navNext.classList.toggle('is-hot', zone === 'next');
        }
        if (viewportEl) {
            viewportEl.style.cursor = zone ? 'pointer' : '';
        }
    }

    function bindEvents() {
        var btnPrev = root.querySelector('.slides-btn-arrow--prev');
        var btnNext = root.querySelector('.slides-btn-arrow--next');
        if (btnPrev) {
            btnPrev.addEventListener('click', prev);
        }
        if (btnNext) {
            btnNext.addEventListener('click', next);
        }

        var btnFS = root.querySelector('.slides-btn-fullscreen');
        if (btnFS) {
            btnFS.addEventListener('click', toggleFullscreen);
        }

        if (viewportEl) {
            viewportEl.addEventListener('click', function(e) {
                if (e.defaultPrevented || isInteractive(e.target)) {
                    return;
                }
                var zone = navZoneAt(e.clientX);
                if (zone === 'prev') {
                    prev();
                } else if (zone === 'next') {
                    next();
                }
            });

            viewportEl.addEventListener('mousemove', function(e) {
                setHotZone(isInteractive(e.target) ? null : navZoneAt(e.clientX));
            });

            viewportEl.addEventListener('mouseleave', function() {
                setHotZone(null);
            });
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && isFullscreen) {
                exitFullscreen();
                return;
            }
            var t = e.target;
            if (t && t.closest && t.closest('input, select, textarea, button, [contenteditable]:not([contenteditable="false"])')) {
                return;
            }
            if (e.key === 'ArrowRight' || e.key === ' ') {
                e.preventDefault();
                next();
            } else if (e.key === 'ArrowLeft') {
                e.preventDefault();
                prev();
            } else if (e.key === 'Home') {
                e.preventDefault();
                goTo(0, true);
            } else if (e.key === 'End') {
                e.preventDefault();
                goTo(slides.length - 1, true);
            }
        });

        document.addEventListener('fullscreenchange', function() {
            if (!document.fullscreenElement) {
                isFullscreen = false;
                root.classList.remove('is-fullscreen');
            }
            setTimeout(scaleCanvas, 60);
        });

        window.addEventListener('resize', scaleCanvas);

        window.addEventListener('pagehide', scormTerminate);
        window.addEventListener('beforeunload', scormTerminate);
        window.addEventListener('unload', scormTerminate);
    }

    /* ------------------------------------------------------------------ */
    /* Boot                                                                */
    /* ------------------------------------------------------------------ */
    function init() {
        root = document.getElementById('slides-viewer');
        if (!root) {
            return;
        }

        viewportEl = root.querySelector('.slides-viewport');
        canvasEl = root.querySelector('.slides-canvas');
        if (!canvasEl) {
            return;
        }

        var nodeSlides = canvasEl.querySelectorAll('.slide');
        for (var i = 0; i < nodeSlides.length; i++) {
            slides.push(nodeSlides[i]);
        }
        total = slides.length;

        // Transitions come from the JSON payload embedded by the template.
        var dataEl = root.querySelector('.slides-data');
        if (dataEl) {
            try {
                var parsed = JSON.parse(dataEl.textContent);
                for (var j = 0; j < parsed.length; j++) {
                    transitions[j] = parsed[j].transition || 'none';
                }
            } catch (e) {
                transitions = [];
            }
        }

        var hint = root.querySelector('.slides-hint');
        if (hint) {
            setTimeout(function() {
                hint.classList.add('is-hidden');
            }, 3000);
        }

        bindEvents();

        var urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('present') === '1') {
            current = 0;
        }

        render(false);

        if (typeof ResizeObserver !== 'undefined' && viewportEl) {
            new ResizeObserver(scaleCanvas).observe(viewportEl);
        }
        scaleCanvas();
        setTimeout(scaleCanvas, 100);

        scormInit();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
