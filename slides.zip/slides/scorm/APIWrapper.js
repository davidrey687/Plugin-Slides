/**
 * mod_slides — SCORM 1.2 API wrapper.
 *
 * Locates the LMS LMS API adapter (window.API in this window, an ancestor, a
 * frameset parent or the opener) and exposes a small, safe interface used by
 * player.js. Every call is guarded so the package also works when it is opened
 * outside an LMS (double click, preview, ...).
 *
 * SCORM 1.2 elements handled by player.js:
 *   cmi.core.lesson_status, cmi.core.score.raw, cmi.core.lesson_location,
 *   cmi.core.session_time, cmi.core.exit, cmi.core.student_id, cmi.core.mode
 *
 * @package   mod_slides
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
var SlidesScorm = (function() {
    'use strict';

    var API = null;
    var initialized = false;
    var terminated = false;
    var lastError = 0;

    var MAX_PARENT_DEPTH = 12;

    /**
     * Walk a window hierarchy looking for the SCORM 1.2 API adapter.
     *
     * @param {Window} win
     * @returns {Object|null}
     */
    function findAPI(win) {
        var depth = 0;
        while (win && depth < MAX_PARENT_DEPTH) {
            try {
                if (win.API && typeof win.API.LMSInitialize === 'function') {
                    return win.API;
                }
            } catch (e) {
                // Cross origin access: keep walking.
            }
            if (win === win.parent) {
                break;
            }
            win = win.parent;
            depth++;
        }
        return null;
    }

    /**
     * Resolve the LMS API adapter from the current browsing context.
     *
     * @returns {Object|null}
     */
    function getAPI() {
        try {
            if (window.API && typeof window.API.LMSInitialize === 'function') {
                return window.API;
            }
        } catch (e) {
            // Ignore.
        }

        var found = null;

        try {
            found = findAPI(window);
        } catch (e) {
            found = null;
        }

        if (!found) {
            try {
                if (window.opener && window.opener !== window) {
                    found = findAPI(window.opener);
                }
            } catch (e) {
                found = null;
            }
        }

        if (!found) {
            try {
                if (window.top && window.top !== window) {
                    found = findAPI(window.top);
                }
            } catch (e) {
                found = null;
            }
        }

        return found;
    }

    /**
     * Invoke an API method, tracking the SCORM error code.
     *
     * @param {string} method
     * @param {*} [arg]
     * @returns {*}
     */
    function call(method, arg) {
        if (!API || terminated) {
            return null;
        }
        try {
            if (typeof arg === 'undefined') {
                return API[method]('');
            }
            return API[method](arg);
        } catch (e) {
            lastError = 101;
            return null;
        }
    }

    /**
     * Start a SCORM session.
     *
     * @returns {boolean} True when the LMS API was found and initialised.
     */
    function init() {
        if (initialized) {
            return true;
        }
        API = getAPI();
        if (!API) {
            return false;
        }
        var result = call('LMSInitialize', '');
        initialized = (result === 'true' || result === true);
        if (!initialized) {
            API = null;
            return false;
        }
        terminated = false;
        return true;
    }

    /**
     * Read a CMI element.
     *
     * @param {string} element
     * @returns {string} Empty string when unavailable.
     */
    function get(element) {
        if (!initialized) {
            return '';
        }
        var value = call('LMSGetValue', element);
        if (typeof value !== 'string') {
            value = (value === null || typeof value === 'undefined') ? '' : String(value);
        }
        return value;
    }

    /**
     * Write a CMI element.
     *
     * @param {string} element
     * @param {string} value
     * @returns {boolean}
     */
    function set(element, value) {
        if (!initialized) {
            return false;
        }
        var result = call('LMSSetValue', element, String(value));
        if (result === 'false' || result === false) {
            lastError = Number(call('LMSGetLastError')) || 351;
            return false;
        }
        return true;
    }

    /**
     * Commit pending data to the LMS.
     *
     * @returns {boolean}
     */
    function commit() {
        if (!initialized) {
            return false;
        }
        return call('LMSCommit', '') !== 'false';
    }

    /**
     * Close the SCORM session. Safe to call more than once.
     *
     * @returns {boolean}
     */
    function terminate() {
        if (!initialized || terminated) {
            return false;
        }
        commit();
        call('LMSFinish', '');
        terminated = true;
        return true;
    }

    /**
     * @returns {number} Last SCORM error code.
     */
    function getLastError() {
        if (!initialized) {
            return lastError;
        }
        var code = Number(call('LMSGetLastError'));
        return isNaN(code) ? lastError : code;
    }

    /**
     * @returns {boolean} True when the last call failed.
     */
    function isError() {
        var code = getLastError();
        return code !== 0 && code !== 401; // 401 = general warning, not fatal.
    }

    /**
     * Format a number of seconds as SCORM 1.2 CMITimespan (HH:MM:SS.ss).
     *
     * @param {number} seconds
     * @returns {string}
     */
    function formatTime(seconds) {
        seconds = Math.max(0, Number(seconds) || 0);
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = Math.floor(seconds % 60);
        var cs = Math.round((seconds - Math.floor(seconds)) * 100);
        if (cs === 100) {
            cs = 0;
            s += 1;
        }
        var pad = function(n) { return (n < 10 ? '0' : '') + n; };
        return pad(h) + ':' + pad(m) + ':' + pad(s) + '.' + pad(cs);
    }

    return {
        init: init,
        get: get,
        set: set,
        commit: commit,
        terminate: terminate,
        getLastError: getLastError,
        isError: isError,
        formatTime: formatTime,
        isInitialized: function() { return initialized; },
        isTerminated: function() { return terminated; },
        // Exposed for debugging / third party tooling.
        getApi: function() { return API; }
    };
})();

// Backwards friendly global: some LMS debuggers look for window.API being
// reachable from the SCO. We never define it, only read it.
if (typeof window !== 'undefined') {
    window.SlidesScorm = SlidesScorm;
}
