<?php
/**
 * Slides index page — list all presentations in a course.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');

$courseid = required_param('id', PARAM_INT);

$course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);

require_login($course);
$context = context_course::instance($course->id);
require_capability('mod/slides:view', $context);

$PAGE->set_url(new moodle_url('/mod/slides/index.php', ['id' => $courseid]));
$PAGE->set_title($course->fullname);
$PAGE->set_heading($course->fullname);

    $instances = $DB->get_records('slides', ['course' => $courseid], 'name ASC');
    $modinfo = get_fast_modinfo($courseid);

    echo $OUTPUT->header();

    if (empty($instances)) {
        echo $OUTPUT->box(get_string('modulenameplural', 'mod_slides') . ': ' .
            get_string('nothing', 'moodle'), 'generalbox');
    } else {
        echo '<table class="generaltable">';
        echo '<tr><th>' . get_string('name', 'mod_slides') . '</th></tr>';
        foreach ($instances as $inst) {
            $cm = $modinfo->instances['slides'][$inst->id] ?? null;
            if (!$cm) {
                continue;
            }
            $link = new moodle_url('/mod/slides/view.php', ['id' => $cm->id]);
            echo '<tr><td>' . $OUTPUT->action_link($link, s($inst->name)) . '</td></tr>';
        }
        echo '</table>';
    }

echo $OUTPUT->footer();
