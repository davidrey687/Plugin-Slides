<?php
/**
 * Editor page for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');

use mod_slides\local\deck;

$id = required_param('id', PARAM_INT);

[$course, $cm] = get_course_and_cm_from_cmid($id, 'slides');
$instance = $DB->get_record('slides', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, false, $cm);

$context = context_module::instance($cm->id);
require_capability('mod/slides:edit', $context);

$PAGE->set_url(new moodle_url('/mod/slides/edit.php', ['id' => $id]));
$PAGE->set_title(get_string('editor', 'mod_slides') . ': ' . $instance->name);
$PAGE->set_heading($instance->name);

$PAGE->requires->js_call_amd('mod_slides/editorApp', 'init');
// Start fetching the local KaTeX build right away so the equation dialog
// already has rendered symbols when the first teacher opens it.
$PAGE->requires->js_call_amd('mod_slides/editorEquation', 'preload');

$PAGE->requires->strings_for_js([
    'editor', 'addtext', 'save', 'saved', 'unsaved', 'addslide',
    'duplicateslide', 'deleteslide', 'deselect', 'undo', 'redo', 'slidemenu',
    'font-size', 'font-family', 'color', 'alignment', 'bold', 'italic',
    'underline', 'strikethrough', 'left', 'center', 'right', 'properties',
    'confirmdelete', 'slides', 'loading', 'saving', 'errorloading', 'emptystate',
    'errorsaving', 'moveup', 'movedown', 'newslide', 'selectelement',
    'deleteelement', 'addshape', 'addpencil', 'addrline', 'shape',
    'fill', 'stroke', 'strokewidth', 'angle', 'width', 'height',
    'type-text', 'type-shape', 'type-pencil', 'type-image', 'type-video',
    'grpinsert', 'grpslide', 'grphistory', 'grpdoc', 'grpelement',
    'grpbackground', 'grpclipboard', 'grpfont', 'grpparagraph',
    'grptransitions', 'grppresent',
    'rename', 'templates', 'template-new', 'template-replace',
    'addimage', 'addbackground', 'bringfront', 'sendback', 'copy', 'paste',
    'cut', 'alt', 'opacity', 'borderradius',
    'highlight', 'highlight-none', 'list-bullet', 'list-number', 'justify',
    'addvideo', 'addfooter', 'addchart', 'videourl', 'footertext',
    'presentfromstart', 'exportpdf',
    'transition', 'transition-none', 'transition-fade', 'transition-push',
    'transition-cut', 'transition-transform', 'applytoall',
    'transition-slide-left', 'transition-slide-up', 'transition-slide-down',
    'transition-zoom', 'transition-flip', 'transition-reveal', 'transition-cube',
    'bg-solid', 'bg-image', 'bg-linear', 'bg-radial', 'bg-apply', 'bg-remove',
    'gradient-angle', 'add-stop',
    'image-fit', 'image-fit-cover', 'image-fit-contain', 'image-fit-stretch',
    'layers', 'bringforward', 'sendbackward', 'layer-visibility', 'layer-lock',
    'shadow-enabled', 'shadow-color', 'shadow-blur', 'shadow-x', 'shadow-y',
    'layout-title', 'layout-titlecontent', 'layout-titleimage', 'layout-text',
    'chartbar', 'chartline', 'chartpie',
    'font-sans-serif', 'list-none',
    'shape-rect', 'shape-roundedrect', 'shape-circle', 'shape-ellipse',
    'shape-line', 'shape-triangle', 'shape-triangledown', 'shape-diamond',
    'shape-pentagon', 'shape-hexagon', 'shape-star5', 'shape-star6',
    'shape-arrowright', 'shape-arrowleft', 'shape-arrowup', 'shape-arrowdown',
    'shape-octagon', 'shape-cross', 'shape-heart', 'shape-cloud',
    'shape-parallelogram', 'shape-trapezoid', 'shape-arrowrightwide',
    'shape-speechbubble', 'shape-star4', 'shape-star8', 'shape-star12', 'shape-bolt',
    'shape-shield', 'shape-droplet', 'shape-ribbon', 'shape-pennant', 'shape-hourglass', 'shape-flower',
    'shape-eqplus', 'shape-eqminus', 'shape-eqmultiply', 'shape-eqdivide', 'shape-eqequals',
    'shape-flowprocess', 'shape-flowdecision', 'shape-flowterminator',
    'shapecat-basic', 'shapecat-arrows', 'shapecat-equations', 'shapecat-flowchart', 'shapecat-stars',
    'fillnone',
    'preset-blank', 'preset-titleonly', 'preset-titlecontent',
    'preset-titleimage', 'preset-textonly', 'preset-twocolumns', 'preset-closing',
    'preset-sectionheader', 'preset-titlebullets', 'preset-bigquote',
    'preset-comparison', 'preset-imagefull', 'preset-title3columns',
    'preset-twocolumnstitle', 'preset-blankdark', 'preset-titlecenterdark',
    'preset-iconlist',
    'theme-colors', 'standard-colors', 'more-colors', 'eyedropper',
    'addlink', 'type-link', 'linkname', 'linkurl', 'linktarget',
    'linknewtab', 'linksametab', 'linkmodaltitle', 'linkinvalidurl', 'cancel',
    'editlink', 'removelink', 'linktabtext', 'linkpickimage', 'linkpickshape',
    'linkimagerequired', 'linkshaperequired',
    'addinteractive', 'ibmodaltitle', 'ibkind', 'ibkind-slide', 'ibkind-url', 'ibkind-label',
    'ibtarget', 'iburl', 'ibtext', 'lbltext', 'ibaction', 'ibconfig', 'ibshape',
    'ibimg', 'ibimgselect', 'ibimgrm', 'ibpopupclose',
    'ibvideo', 'ibvideourl', 'ibuploadvideo', 'ibvideorm',
    'ibsearch', 'ibcat-all', 'ibcat-nav', 'ibcat-info', 'ibcat-media', 'ibcat-actions', 'ibcat-social', 'ibnoresults',
    'addpdf', 'type-pdf', 'pdfmodaltitle', 'pdfdropzone', 'pdfdropzonehint',
    'pdfupload', 'pdfuploading', 'pdfprocessing', 'pdfuploadsuccess',
    'pdfuploaderror', 'pdfuploadtimeout', 'pdfinvalidtype', 'pdftitle', 'pdfalt', 'remove',
    'importpdf', 'importpdftitle', 'importpdfdrop', 'importpdfdropsub', 'importpdfhint',
    'importpdfmodelabel', 'importpdfadd', 'importpdfreplace', 'importpdfprogress',
    'importpdfpage', 'importpdfdone', 'importpdferror', 'importpdfbadtype',
    'importpdflocked', 'importpdfnolib', 'importpdfcancelling',
    'importslides', 'importpdfpassword',
    'importpptxprogress', 'importpptxpage', 'importpptxerror', 'importpptxbadtype',
    'importpptxnolib',
    'applyfonttoall', 'applyfonttoallhelp', 'applyfonttoallconfirm',
    'fontgroup-sans', 'fontgroup-serif', 'fontgroup-mono',
    'fontgroup-decorative', 'fontgroup-web', 'fontgroup-other',
    'imagebank', 'imagebankall', 'imagebankupload', 'imagebankurl',
    'imagebankurlbtn', 'imagebanksearch', 'imagebankempty',
    'imagebankloading', 'imagebankurlerr', 'imagebankdrop',
    'imagebankhint', 'imagebankclose', 'imagebankapplyerr',
    'crop', 'cropreset', 'cropapply', 'cropcancel', 'crophint',
    'moretools', 'grpmore', 'addequation', 'type-equation', 'editequation',
    'eqmodaltitle', 'eqtaboperators', 'eqtabarrows', 'eqtabgreek', 'eqtabadvanced',
    'eqinputlabel', 'eqpreviewlabel', 'eqpreviewempty', 'eqinsert', 'equpdate',
    'eqempty', 'eqedittex', 'eqloading', 'eqloaderror',
    'addhtml', 'type-html', 'edithtml', 'htmlmodaltitle', 'htmlcodelabel',
    'htmlpreviewlabel', 'htmlpreviewempty', 'htmlinsert', 'htmlupdate',
    'htmlempty', 'htmlhint',
    'recordaudio', 'recordvideo', 'type-audio',
    'recorderrecord', 'recorderstop', 'recorderplay', 'recorderupload',
    'recorderinsert', 'recorderuploading', 'recorderuploaded', 'recordererror',
    'recorderdenied', 'recorderunsupported', 'recorderinsecure',
    'recorderlimit', 'recorderhint', 'recorderloading',
    'adddrawing', 'drawingtitle', 'drawinghint', 'drawingcolor', 'drawingwidth',
    'drawingbrush', 'drawingeraser', 'drawingundo', 'drawingredo', 'drawingclear',
    'drawingsave', 'drawinginsert', 'drawingsaving', 'drawingsaved',
    'drawingerror', 'drawingempty',
    'addanimations', 'animmodaltitle', 'animselected', 'animselecthint',
    'animnone', 'animappear', 'animfade', 'animup', 'animsequence', 'animempty',
    'animmoveup', 'animmovedown', 'animremove', 'animclearall', 'animorder',
    'animhint',
    'zoomlevel', 'zoomin', 'zoomout', 'zoomfit', 'zoomlabel',
    'autosaved', 'draftfound', 'draftrestore', 'draftdiscard',
], 'mod_slides');

$PAGE->requires->css(new moodle_url('/mod/slides/fonts/fonts.css'));
// KaTeX stylesheet up front: it hides the MathML annotation holding the TeX
// source, so formulas must never paint before it is applied.
$PAGE->requires->css(new moodle_url('/mod/slides/vendor/katex/katex.min.css'));

[$canvasw, $canvash] = deck::canvas_dimensions($instance->aspectratio);

echo $OUTPUT->header();

echo $OUTPUT->render_from_template('mod_slides/editor', [
    'cmid'         => $cm->id,
    'sesskey'      => sesskey(),
    'aspectratio'  => $instance->aspectratio,
    'canvasheight' => $canvash,
    'canvaswidth'  => $canvasw,
]);

echo $OUTPUT->footer();
