<?php
/**
 * Import form: uploads a SCORM 1.2 .zip package.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class mod_slides_import_form extends moodleform {

    /**
     * Form definition.
     *
     * @return void
     */
    protected function definition() {
        global $CFG;

        $mform = $this->_form;

        $mform->addElement('filepicker', 'package', get_string('scormpackage', 'mod_slides'), null, [
            'accepted_types' => '.zip',
            'maxbytes'       => empty($CFG->maxbytes) ? 0 : $CFG->maxbytes,
        ]);
        $mform->addRule('package', get_string('required'), 'required', null, 'client');
        $mform->setType('package', PARAM_RAW);

        $this->add_action_buttons(true, get_string('importaction', 'mod_slides'));
    }
}
