<?php
/**
 * Version information for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component    = 'mod_slides';
$plugin->version      = 2026110601;
$plugin->requires     = 2022112800; // Moodle 4.1
$plugin->maturity     = MATURITY_ALPHA;
$plugin->release      = 'v1.32-import-icon';
$plugin->dependencies = [];
