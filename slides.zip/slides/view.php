<?php
/**
 * Activity view page for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');

use mod_slides\local\deck;
use mod_slides\local\slide_renderer;
use mod_slides\event\course_module_viewed;

$id = required_param('id', PARAM_INT);

[$course, $cm] = get_course_and_cm_from_cmid($id, 'slides');
$instance = $DB->get_record('slides', ['id' => $cm->instance], '*', MUST_EXIST);

require_login($course, false, $cm);

$context = context_module::instance($cm->id);
$iseditor = has_capability('mod/slides:edit', $context) && $PAGE->user_is_editing();

$PAGE->set_url(new moodle_url('/mod/slides/view.php', ['id' => $id]));
$PAGE->set_title($instance->name);
$PAGE->set_heading($instance->name);
$PAGE->requires->js_call_amd('mod_slides/viewer', 'init');
$PAGE->requires->strings_for_js(['pdfopennewtab', 'ibpopupclose', 'slidethumb'], 'mod_slides');

// --- Handle demo seed action (POST only) -----------------------------------
if ($iseditor && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sesskey'])) {
    require_sesskey();
    deck::create_demo_deck($instance->id);
    redirect(new moodle_url('/mod/slides/view.php', ['id' => $id]));
}

// --- Log viewed event -------------------------------------------------------
course_module_viewed::create_from_cm($cm->id, $instance)->trigger();

// --- Load deck --------------------------------------------------------------
$deck = deck::get_deck($instance->id);
$slidecount = count($deck);
[$canvasw, $canvash] = deck::canvas_dimensions($instance->aspectratio);

// --- Build template data for each slide (shared renderer) --------------------
$slidetpldata = slide_renderer::template_slides($deck);
$slidesjson   = slide_renderer::viewer_json($deck);

// --- Final template context -------------------------------------------------
$tpldata = [
    'cmid'         => $cm->id,
    'slidecount'   => $slidecount,
    'aspectratio'  => $instance->aspectratio,
    'aspectwidth'  => $canvasw,
    'canvasheight' => $canvash,
    'initialslide' => 1,
    'iseditor'     => $iseditor,
    'empty'        => ($slidecount === 0),
    'seedurl'      => (new moodle_url('/mod/slides/view.php', ['id' => $id]))->out(false),
    'sesskey'      => sesskey(),
    'slides'       => $slidetpldata,
    'slidesjson'   => $slidesjson,
    'pageheading'  => $instance->name,
    'intro'        => '',
    'progressbar'  => slide_renderer::progressbar($slidecount),
];

$PAGE->requires->css(new moodle_url('/mod/slides/fonts/fonts.css'));
// KaTeX stylesheet up front (see edit.php): keeps the TeX annotation hidden.
$PAGE->requires->css(new moodle_url('/mod/slides/vendor/katex/katex.min.css'));

echo $OUTPUT->header();

if ($instance->intro) {
    echo $OUTPUT->box(format_module_intro('slides', $instance, $cm->id), 'generalbox intro');
}

if ($iseditor) {
    $editurl   = new moodle_url('/mod/slides/edit.php', ['id' => $id]);
    $exporturl = new moodle_url('/mod/slides/export.php', ['id' => $id, 'sesskey' => sesskey()]);
    $importurl = new moodle_url('/mod/slides/import.php', ['id' => $id]);

    echo '<div class="slides-authoring-buttons">';
    echo $OUTPUT->action_link($editurl, get_string('editor', 'mod_slides'), null, ['class' => 'btn btn-primary']);

    // SCORM dropdown
    echo '<div class="slides-scorm-dropdown">';
    echo '<button type="button" class="btn btn-secondary slides-scorm-toggle" aria-haspopup="true" aria-expanded="false" aria-label="' . get_string('scorm', 'mod_slides') . '">';
    echo '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v3"/><path d="M21 16V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3"/><path d="M4 12H2"/><path d="M22 12h-2"/></svg>';
    echo '<span>' . get_string('scorm', 'mod_slides') . '</span>';
    echo '<svg class="slides-caret" viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
    echo '</button>';
    echo '<div class="slides-scorm-panel" role="menu">';
    echo '<a class="slides-scorm-item" href="' . $exporturl . '" role="menuitem">' . get_string('exportscorm', 'mod_slides') . '</a>';
    echo '<a class="slides-scorm-item" href="' . $importurl . '" role="menuitem">' . get_string('importscorm', 'mod_slides') . '</a>';
    echo '</div>';
    echo '</div>';

    echo '</div>';
}

echo $OUTPUT->render_from_template('mod_slides/viewer', $tpldata);

echo $OUTPUT->footer();
