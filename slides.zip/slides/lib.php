<?php
/**
 * Library functions for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use mod_slides\event\slides_created;
use mod_slides\event\slides_updated;
use mod_slides\event\slides_deleted;

/**
 * Return feature flags for this module.
 */
function slides_supports(string $feature): bool|string|null {
    switch ($feature) {
        case FEATURE_IDNUMBER:
            return true;
        case FEATURE_GROUPS:
        case FEATURE_GROUPINGS:
            return true;
        case FEATURE_MOD_INTRO:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        case FEATURE_BACKUP_MOODLE2:
            return false;
        case FEATURE_COMPLETION_HAS_RULES:
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return false;

        default:
            return null;
    }
}

/**
 * Add a new slides presentation instance.
 */
function slides_add_instance(object $data, object $mform = null): int {
    global $DB;

    $data->timecreated  = time();
    $data->timemodified = $data->timecreated;

    $id = $DB->insert_record('slides', $data);

    // Create one blank slide by default
    $blank = new \stdClass();
    $blank->slidesid   = $id;
    $blank->sortorder  = 0;
    $blank->title      = get_string('slide1', 'mod_slides');
    $blank->elements   = json_encode([], JSON_UNESCAPED_UNICODE);
    $blank->background = json_encode(['color' => '#ffffff'], JSON_UNESCAPED_UNICODE);
    $DB->insert_record('slides_slides', $blank);

    // Handle file uploads.
    $cmid = (int) ($data->coursemodule ?? 0);
    if ($cmid && !empty($data->files)) {
        $context = context_module::instance($cmid);
        file_save_draft_area_files(
            $data->files,
            $context->id,
            'mod_slides',
            'slides_files',
            0
        );
    }

    // Fire created event.
    $cm = $cmid ? $DB->get_record('course_modules', ['id' => $cmid]) : false;
    if ($cm) {
        $context = context_module::instance($cm->id);
        $instance = $DB->get_record('slides', ['id' => $id]);
        slides_created::create_from_instance($instance, $context)->trigger();
    }

    return $id;
}

/**
 * Update an existing slides presentation instance.
 */
function slides_update_instance(object $data, object $mform = null): bool {
    global $DB;

    $data->timemodified = time();

    // Handle file uploads.
    $cmid = (int) ($data->coursemodule ?? 0);
    if ($cmid && !empty($data->files)) {
        $context = context_module::instance($cmid);
        file_save_draft_area_files(
            $data->files,
            $context->id,
            'mod_slides',
            'slides_files',
            0
        );
    }

    $result = $DB->update_record('slides', $data);

    // Fire updated event.
    $cm = get_coursemodule_from_instance('slides', $data->id);
    if ($cm) {
        $context = context_module::instance($cm->id);
        $instance = $DB->get_record('slides', ['id' => $data->id]);
        slides_updated::create_from_instance($instance, $context)->trigger();
    }

    return $result;
}

/**
 * Delete a slides presentation instance and its related slides.
 */
function slides_delete_instance(int $id): bool {
    global $DB;

    $DB->delete_records('slides_slides', ['slidesid' => $id]);

    // Delete associated files.
    $cm = get_coursemodule_from_instance('slides', $id);
    if ($cm) {
        $context = context_module::instance($cm->id);
        $fs = get_file_storage();
        $fs->delete_area_files($context->id, 'mod_slides', 'slides_files');
        $fs->delete_area_files($context->id, 'mod_slides', 'slides_pdf');

        // Fire deleted event.
        $instance = $DB->get_record('slides', ['id' => $id]);
        if ($instance) {
            slides_deleted::create_from_instance($instance, $context)->trigger();
        }
    }

    return $DB->delete_records('slides', ['id' => $id]);
}

/**
 * Get file URLs for a slides instance.
 */
function slides_get_files_info(int $cmid): array {
    $context = context_module::instance($cmid);

    $fs = get_file_storage();
    $files = $fs->get_area_files($context->id, 'mod_slides', 'slides_files', 0, 'sortorder ASC');

    $result = [];
    foreach ($files as $file) {
        if ($file->is_directory()) {
            continue;
        }
        $result[] = [
            'filename' => $file->get_filename(),
            'url'      => moodle_url::make_pluginfile_url(
                $context->id,
                'mod_slides',
                'slides_files',
                0,
                $file->get_filepath(),
                $file->get_filename()
            )->out(false),
        ];
    }

    // PDF resources attached from the editor live in their own file area.
    $pdfs = $fs->get_area_files($context->id, 'mod_slides', 'slides_pdf', 0, 'sortorder ASC');
    foreach ($pdfs as $file) {
        if ($file->is_directory()) {
            continue;
        }
        $result[] = [
            'filename' => $file->get_filename(),
            'url'      => moodle_url::make_pluginfile_url(
                $context->id,
                'mod_slides',
                'slides_pdf',
                0,
                $file->get_filepath(),
                $file->get_filename()
            )->out(false),
        ];
    }

    return $result;
}

/**
 * Serves the slides files.
 */
function slides_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    if ($context->contextlevel != CONTEXT_MODULE) {
        return false;
    }

    require_course_login($course, true, $cm);
    if (!has_capability('mod/slides:view', $context)) {
        return false;
    }

    $fileareas = ['slides_files', 'slides_pdf', 'slides_media'];
    if (!in_array($filearea, $fileareas)) {
        return false;
    }

    $itemid = (int) array_shift($args);
    $filename = array_pop($args);
    if (empty($filename)) {
        return false;
    }
    $filepath = $args ? '/' . implode('/', $args) . '/' : '/';

    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'mod_slides', $filearea, $itemid, $filepath, $filename);
    if (!$file) {
        return false;
    }

    send_stored_file($file, 0, 0, $forcedownload, $options);
}
