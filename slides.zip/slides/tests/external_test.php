<?php
/**
 * Unit tests for mod_slides external API.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Tests for the external API.
 *
 * @package   mod_slides
 */
class mod_slides_external_test extends advanced_testcase {

    /**
     * Test get_deck_parameters().
     */
    public function test_get_deck_parameters() {
        $params = \mod_slides\external::get_deck_parameters();
        $this->assertInstanceOf('core_external\external_function_parameters', $params);
        $keys = $params->keys;
        $this->assertArrayHasKey('cmid', $keys);
    }

    /**
     * Test get_deck_returns().
     */
    public function test_get_deck_returns() {
        $returns = \mod_slides\external::get_deck_returns();
        $this->assertInstanceOf('core_external\external_single_structure', $returns);

        $slides = $returns->keys['slides'];
        $this->assertInstanceOf('core_external\external_multiple_structure', $slides);
    }

    /**
     * Test get_deck() with valid cmid.
     */
    public function test_get_deck_valid() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->setAdminUser();
        $result = \mod_slides\external::get_deck($cm->id);

        $this->assertArrayHasKey('slides', $result);
        $this->assertCount(1, $result['slides']);
        $this->assertEquals('Slide 1', $result['slides'][0]['title']);
        $this->assertArrayHasKey('elements', $result['slides'][0]);
        $this->assertArrayHasKey('background', $result['slides'][0]);
    }

    /**
     * Test get_deck() with invalid cmid throws exception.
     */
    public function test_get_deck_invalid_cmid() {
        $this->resetAfterTest(true);

        $this->setAdminUser();

        $this->expectException('moodle_exception');
        \mod_slides\external::get_deck(999999);
    }

    /**
     * Test save_deck_parameters().
     */
    public function test_save_deck_parameters() {
        $params = \mod_slides\external::save_deck_parameters();
        $this->assertInstanceOf('core_external\external_function_parameters', $params);
        $keys = $params->keys;
        $this->assertArrayHasKey('cmid', $keys);
        $this->assertArrayHasKey('deck', $keys);
        $this->assertArrayHasKey('sesskey', $keys);
    }

    /**
     * Test save_deck_returns().
     */
    public function test_save_deck_returns() {
        $returns = \mod_slides\external::save_deck_returns();
        $this->assertInstanceOf('core_external\external_single_structure', $returns);
        $this->assertArrayHasKey('status', $returns->keys);
    }

    /**
     * Test save_deck() with valid data.
     */
    public function test_save_deck_valid() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->setAdminUser();
        $sesskey = sesskey();

        $deck = [
            [
                'title'       => 'Slide A',
                'sortorder'   => 0,
                'elements'    => [
                    [
                        'type'     => 'text',
                        'x'        => 100,
                        'y'        => 100,
                        'w'        => 400,
                        'h'        => 50,
                        'text'     => 'Hello World',
                        'fontSize' => 28,
                        'color'    => '#000000',
                    ],
                ],
                'background'  => json_encode(['color' => '#ffffff']),
                'transition'  => 'none',
            ],
        ];

        $result = \mod_slides\external::save_deck($cm->id, $deck, $sesskey);

        $this->assertTrue($result['status']);

        // Verify the deck was saved.
        $slides = $DB->get_records('slides_slides', ['slidesid' => $instance->id]);
        $this->assertCount(1, $slides);

        $slide = reset($slides);
        $this->assertEquals('Slide A', $slide->title);

        $elements = json_decode($slide->elements, true);
        $this->assertCount(1, $elements);
        $this->assertEquals('Hello World', $elements[0]['text']);
    }

    /**
     * Animation fields travel through save_deck and come back via get_deck.
     */
    public function test_save_deck_animation_fields_roundtrip() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->setAdminUser();
        $sesskey = sesskey();

        $deck = [
            [
                'title'      => 'Animated',
                'sortorder'  => 0,
                'elements'   => [
                    [
                        'type'      => 'text',
                        'x'         => 100,
                        'y'         => 100,
                        'w'         => 400,
                        'h'         => 50,
                        'text'      => 'Step one',
                        'animOrder' => 1,
                        'animType'  => 'appear',
                    ],
                    [
                        'type'      => 'image',
                        'x'         => 200,
                        'y'         => 200,
                        'w'         => 300,
                        'h'         => 200,
                        'src'       => '',
                        'animOrder' => 2,
                        'animType'  => 'up',
                    ],
                    [
                        'type' => 'shape',
                        'x'    => 50,
                        'y'    => 50,
                        'w'    => 100,
                        'h'    => 100,
                    ],
                ],
                'background' => json_encode(['color' => '#ffffff']),
                'transition' => 'none',
            ],
        ];

        $result = \mod_slides\external::save_deck($cm->id, $deck, $sesskey);
        $this->assertTrue($result['status']);

        $slides = $DB->get_records('slides_slides', ['slidesid' => $instance->id]);
        $slide = reset($slides);
        $stored = json_decode($slide->elements, true);
        $this->assertEquals(1, $stored[0]['animOrder']);
        $this->assertEquals('appear', $stored[0]['animType']);
        $this->assertEquals(2, $stored[1]['animOrder']);
        $this->assertEquals('up', $stored[1]['animType']);
        $this->assertEquals(0, $stored[2]['animOrder']);
        $this->assertEquals('', $stored[2]['animType']);

        // The webservice return keeps them as well.
        $read = \mod_slides\external::get_deck($cm->id);
        $els = $read['slides'][0]['elements'];
        $this->assertEquals(1, $els[0]['animOrder']);
        $this->assertEquals('appear', $els[0]['animType']);
        $this->assertEquals(2, $els[1]['animOrder']);
        $this->assertEquals('up', $els[1]['animType']);
    }

    /**
     * The save_deck element structure exposes the animation keys.
     */
    public function test_save_deck_structure_has_animation_keys() {
        $params = \mod_slides\external::save_deck_parameters();
        $elementfields = $params->keys['deck']->content->keys['elements']->content->keys;
        $this->assertArrayHasKey('animOrder', $elementfields);
        $this->assertArrayHasKey('animType', $elementfields);

        $returns = \mod_slides\external::get_deck_returns();
        $elementfields = $returns->keys['slides']->content->keys['elements']->content->keys;
        $this->assertArrayHasKey('animOrder', $elementfields);
        $this->assertArrayHasKey('animType', $elementfields);
    }

    /**
     * Test save_deck() with invalid sesskey throws exception.
     */
    public function test_save_deck_invalid_sesskey() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->setAdminUser();

        $this->expectException('moodle_exception');
        \mod_slides\external::save_deck($cm->id, [], 'invalid_sesskey');
    }

    /**
     * Test save_deck() replaces all slides.
     */
    public function test_save_deck_replaces() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->setAdminUser();
        $sesskey = sesskey();

        // Save a deck with 3 slides.
        $deck = [];
        for ($i = 0; $i < 3; $i++) {
            $deck[] = [
                'title'       => "Slide $i",
                'sortorder'   => $i,
                'elements'    => [],
                'background'  => json_encode(['color' => '#ffffff']),
                'transition'  => 'none',
            ];
        }

        \mod_slides\external::save_deck($cm->id, $deck, $sesskey);

        $slides = $DB->get_records('slides_slides', ['slidesid' => $instance->id]);
        $this->assertCount(3, $slides);

        // Now save with only 1 slide.
        $deck2 = [
            [
                'title'       => 'Single slide',
                'sortorder'   => 0,
                'elements'    => [],
                'background'  => json_encode(['color' => '#ffffff']),
                'transition'  => 'none',
            ],
        ];

        \mod_slides\external::save_deck($cm->id, $deck2, $sesskey);

        $slides2 = $DB->get_records('slides_slides', ['slidesid' => $instance->id]);
        $this->assertCount(1, $slides2);
    }

    /**
     * Test font family sanitization.
     */
    public function test_get_deck_sanitizes_fontfamily() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        // Inject a slide with invalid font family.
        global $DB;
        $row = new stdClass();
        $row->slidesid = $instance->id;
        $row->sortorder = 0;
        $row->title = 'Test';
        $row->elements = json_encode([
            ['type' => 'text', 'fontfamily' => 'Evil<script>alert(1)</script>', 'text' => 'test'],
        ]);
        $row->background = json_encode(['color' => '#ffffff']);
        $DB->insert_record('slides_slides', $row);

        $this->setAdminUser();
        $result = \mod_slides\external::get_deck($cm->id);

        $element = $result['slides'][0]['elements'][0];
        $this->assertEquals('sans-serif', $element['fontfamily']);
    }

    /**
     * Test that get_deck keeps every font-bank family untouched.
     */
    public function test_get_deck_accepts_font_bank_families() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $samples = [
            '"Montserrat", sans-serif',
            '"Playfair Display", serif',
            'Anton, sans-serif',
            '"Dancing Script", cursive',
            '"Book Antiqua", serif',
            'Copperplate, fantasy',
            'sans-serif',
        ];

        global $DB;
        $elements = [];
        foreach ($samples as $family) {
            $elements[] = ['type' => 'text', 'fontfamily' => $family, 'text' => 'test'];
        }
        $row = new stdClass();
        $row->slidesid = $instance->id;
        $row->sortorder = 0;
        $row->title = 'Test';
        $row->elements = json_encode($elements);
        $row->background = json_encode(['color' => '#ffffff']);
        $DB->insert_record('slides_slides', $row);

        $this->setAdminUser();
        $result = \mod_slides\external::get_deck($cm->id);

        foreach ($samples as $i => $family) {
            $this->assertEquals($family, $result['slides'][0]['elements'][$i]['fontfamily']);
        }
    }

    /**
     * Injection attempts in fontfamily must fall back to sans-serif.
     */
    public function test_get_deck_blocks_css_injection_fontfamily() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $evil = [
            'red; font-family: x',
            'url(javascript:alert(1))',
            'expression(alert(1))',
            '"A"; } body { background: red',
            '<script>alert(1)</script>',
            '',
        ];

        global $DB;
        $elements = [];
        foreach ($evil as $family) {
            $elements[] = ['type' => 'text', 'fontfamily' => $family, 'text' => 'test'];
        }
        $row = new stdClass();
        $row->slidesid = $instance->id;
        $row->sortorder = 0;
        $row->title = 'Test';
        $row->elements = json_encode($elements);
        $row->background = json_encode(['color' => '#ffffff']);
        $DB->insert_record('slides_slides', $row);

        $this->setAdminUser();
        $result = \mod_slides\external::get_deck($cm->id);

        foreach ($evil as $i => $family) {
            $this->assertEquals('sans-serif', $result['slides'][0]['elements'][$i]['fontfamily']);
        }
    }

    /**
     * HTML/Embed elements keep useful markup (iframes, images) but lose
     * scripts, inline handlers and javascript: URLs on the way out.
     */
    public function test_html_element_sanitization() {
        $this->resetAfterTest(true);

        $evil = '<iframe src="https://www.youtube.com/embed/abc" width="560" height="315"></iframe>' .
            '<script>alert(1)</script>' .
            '<img src="https://example.com/a.png" onerror="alert(2)">' .
            '<a href="javascript:alert(3)">click</a>' .
            '<div style="color:red" onclick="alert(4)">ok</div>';

        $clean = \mod_slides\local\deck_sanitizer::sanitize_html_code($evil);

        $this->assertStringContainsString('youtube.com/embed/abc', $clean);
        $this->assertStringContainsString('example.com/a.png', $clean);
        $this->assertStringContainsString('style="color:red"', $clean);
        $this->assertStringNotContainsString('<script', $clean);
        $this->assertStringNotContainsString('onerror', $clean);
        $this->assertStringNotContainsString('onclick', $clean);
        $this->assertStringNotContainsString('javascript:', $clean);
    }

    /**
     * Saving a deck with an html element scrubs the markup stored in `text`.
     */
    public function test_save_deck_sanitizes_html_element() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->setAdminUser();
        $sesskey = sesskey();

        $deck = [[
            'title' => 'HTML slide',
            'sortorder' => 0,
            'elements' => [[
                'type' => 'html',
                'x' => 100,
                'y' => 100,
                'w' => 560,
                'h' => 315,
                'text' => '<iframe src="https://player.vimeo.com/video/123"></iframe><script>evil()</script>',
            ]],
            'background' => json_encode(['color' => '#ffffff']),
            'transition' => 'none',
        ]];

        $result = \mod_slides\external::save_deck($cm->id, $deck, $sesskey);
        $this->assertTrue($result['status']);

        $got = \mod_slides\external::get_deck($cm->id);

        $text = $got['slides'][0]['elements'][0]['text'];
        $this->assertStringContainsString('player.vimeo.com/video/123', $text);
        $this->assertStringNotContainsString('evil()', $text);
    }
}
