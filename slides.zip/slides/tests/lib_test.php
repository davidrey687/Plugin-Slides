<?php
/**
 * Unit tests for mod_slides lib functions.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->dirroot . '/mod/slides/lib.php');

/**
 * Tests for mod_slides lib functions.
 *
 * @package   mod_slides
 */
class mod_slides_lib_test extends advanced_testcase {

    /**
     * Test slides_supports() with various features.
     */
    public function test_slides_supports() {
        $this->assertTrue(slides_supports(FEATURE_IDNUMBER));
        $this->assertTrue(slides_supports(FEATURE_GROUPS));
        $this->assertTrue(slides_supports(FEATURE_GROUPINGS));
        $this->assertTrue(slides_supports(FEATURE_MOD_INTRO));
        $this->assertTrue(slides_supports(FEATURE_SHOW_DESCRIPTION));
        $this->assertFalse(slides_supports(FEATURE_BACKUP_MOODLE2));
        $this->assertFalse(slides_supports(FEATURE_COMPLETION_HAS_RULES));
        $this->assertFalse(slides_supports(FEATURE_COMPLETION_TRACKS_VIEWS));
        $this->assertNull(slides_supports('nonexistentfeature'));
    }

    /**
     * Test slides_add_instance().
     */
    public function test_slides_add_instance() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        // Verify the instance was created.
        $record = $DB->get_record('slides', ['id' => $instance->id]);
        $this->assertNotEmpty($record);
        $this->assertEquals($course->id, $record->course);
        $this->assertEquals('Test slides presentation', $record->name);
        $this->assertEquals('16:9', $record->aspectratio);

        // Verify a blank slide was created.
        $slides = $DB->get_records('slides_slides', ['slidesid' => $instance->id]);
        $this->assertCount(1, $slides);

        $slide = reset($slides);
        $this->assertEquals(0, $slide->sortorder);
        $this->assertNotEmpty($slide->elements);
        $this->assertNotEmpty($slide->background);
    }

    /**
     * Test slides_update_instance().
     */
    public function test_slides_update_instance() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        // Update the instance.
        $update = new stdClass();
        $update->id = $instance->id;
        $update->name = 'Updated presentation name';
        $update->intro = 'Updated introduction';
        $update->introformat = FORMAT_HTML;
        $update->aspectratio = '4:3';
        $update->timemodified = time();

        $result = slides_update_instance($update);
        $this->assertTrue($result);

        // Verify the update.
        $record = $DB->get_record('slides', ['id' => $instance->id]);
        $this->assertEquals('Updated presentation name', $record->name);
        $this->assertEquals('4:3', $record->aspectratio);
    }

    /**
     * Test slides_delete_instance().
     */
    public function test_slides_delete_instance() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        // Verify the instance exists.
        $this->assertRecordExists('slides', $instance->id);
        $this->assertGreaterThanOrEqual(1, $DB->count_records('slides_slides', ['slidesid' => $instance->id]));

        // Delete the instance.
        $result = slides_delete_instance($instance->id);
        $this->assertTrue($result);

        // Verify the instance and slides are deleted.
        $this->assertRecordNotExists('slides', $instance->id);
        $this->assertEquals(0, $DB->count_records('slides_slides', ['slidesid' => $instance->id]));
    }

    /**
     * Test slides_get_files_info() when no files exist.
     */
    public function test_slides_get_files_info_empty() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);
        $files = slides_get_files_info($cm->id);

        $this->assertIsArray($files);
        $this->assertCount(0, $files);
    }

    /**
     * Test slides_pluginfile() with invalid context level.
     */
    public function test_slides_pluginfile_invalid_context() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();

        $context = context_course::instance($course->id);
        $result = slides_pluginfile($course, null, $context, 'slides_files', ['test.png'], false);

        $this->assertFalse($result);
    }

    /**
     * Test slides_pluginfile() with invalid filearea.
     */
    public function test_slides_pluginfile_invalid_filearea() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);
        $context = context_module::instance($cm->id);

        $result = slides_pluginfile($course, $cm, $context, 'invalid_area', ['test.png'], false);

        $this->assertFalse($result);
    }

    /**
     * Test that events are triggered on add.
     */
    public function test_slides_add_instance_fires_event() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();

        $sink = $this->redirectEvents();

        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $events = $sink->get_events();
        $createdevents = array_filter($events, function($e) {
            return $e instanceof \mod_slides\event\slides_created;
        });

        $this->assertCount(1, $createdevents);
    }

    /**
     * Test that events are triggered on delete.
     */
    public function test_slides_delete_instance_fires_event() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $sink = $this->redirectEvents();

        slides_delete_instance($instance->id);

        $events = $sink->get_events();
        $deletedevents = array_filter($events, function($e) {
            return $e instanceof \mod_slides\event\slides_deleted;
        });

        $this->assertCount(1, $deletedevents);
    }
}
