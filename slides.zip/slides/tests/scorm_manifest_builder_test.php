<?php
/**
 * Unit tests for the SCORM 1.2 manifest builder.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use mod_slides\local\scorm\manifest_builder;

global $CFG;
require_once($CFG->dirroot . '/mod/slides/classes/local/scorm/manifest_builder.php');

/**
 * Tests for manifest_builder.
 *
 * @package   mod_slides
 */
class mod_slides_scorm_manifest_builder_test extends advanced_testcase {

    /**
     * The entry point must be the first file listed, everything else sorted.
     */
    public function test_normalise_files_puts_entry_point_first() {
        $files = manifest_builder::normalise_files(['assets/b.js', 'index.html', 'assets/a.css']);
        $hrefs = array_column($files, 'href');

        $this->assertSame(['index.html', 'assets/a.css', 'assets/b.js'], $hrefs);
    }

    /**
     * Paths that could escape the package are dropped.
     */
    public function test_normalise_files_drops_unsafe_paths() {
        $files = manifest_builder::normalise_files(['../evil.txt', 'a/../../b.txt', '', '/abs.png']);
        $hrefs = array_column($files, 'href');

        $this->assertSame(['abs.png'], $hrefs);
    }

    /**
     * The manifest must be a valid SCORM 1.2 document.
     */
    public function test_build_is_valid_scorm_1_2_manifest() {
        $paths = ['index.html', 'assets/deck.json', 'assets/styles.css'];
        $xml = manifest_builder::build('My presentation', 42, $paths, 1700000000);

        $this->assertStringStartsWith('<?xml', $xml);

        $previous = libxml_use_internal_errors(true);
        $sxe = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET);
        $errors = libxml_get_errors();
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        $this->assertInstanceOf(SimpleXMLElement::class, $sxe);
        $this->assertEmpty($errors, 'Manifest has XML errors.');
        $this->assertSame('1.2', (string) $sxe->metadata->schemaversion);
        $this->assertSame('ADL SCORM', (string) $sxe->metadata->schema);
        $this->assertStringContainsString('adlcp:scormtype="sco"', $xml);
        $this->assertStringContainsString('type="webcontent"', $xml);

        // The organisation and the resource point at the entry point.
        $resource = $sxe->resources->resource;
        $this->assertSame(manifest_builder::ENTRYHREF, (string) $resource['href']);
        $this->assertSame((string) $sxe->organizations['default'],
            (string) $sxe->organizations->organization['identifier']);

        // Every declared file is listed, index.html first.
        $listed = [];
        foreach ($resource->file as $file) {
            $listed[] = (string) $file['href'];
        }
        $this->assertSame(['index.html', 'assets/deck.json', 'assets/styles.css'], $listed);
    }

    /**
     * Titles are escaped so a malicious name cannot break the XML.
     */
    public function test_build_escapes_markup_in_title() {
        $xml = manifest_builder::build('<script>"x" & \'y\'</script>', 7, ['index.html'], 1700000000);

        $this->assertStringContainsString('&lt;script&gt;', $xml);
        $this->assertStringNotContainsString('<script>', $xml);
        $this->assertStringContainsString('&amp;', $xml);
        $this->assertNotFalse(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET));
    }

    /**
     * Identifiers must be unique per course module and free of spaces.
     */
    public function test_identifiers_are_valid_xml_names() {
        $ids = manifest_builder::identifiers(1234, 1700000000);

        foreach ($ids as $id) {
            $this->assertMatchesRegularExpression('/^[A-Za-z_][A-Za-z0-9_]*$/', $id);
        }
        $this->assertCount(4, array_unique($ids));

        $other = manifest_builder::identifiers(4321, 1700000000);
        $this->assertNotSame($ids['manifestid'], $other['manifestid']);
    }

    /**
     * Identifiers change when the timestamp changes so two exports differ.
     */
    public function test_identifiers_depend_on_timestamp() {
        $a = manifest_builder::identifiers(10, 1700000000);
        $b = manifest_builder::identifiers(10, 1700000001);

        $this->assertNotSame($a['manifestid'], $b['manifestid']);
    }
}
