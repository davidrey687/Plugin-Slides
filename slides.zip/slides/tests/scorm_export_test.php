<?php
/**
 * Integration tests for the SCORM 1.2 package exporter.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use mod_slides\local\deck;
use mod_slides\local\scorm\exporter;

global $CFG;
require_once($CFG->dirroot . '/mod/slides/classes/local/scorm/exporter.php');

/**
 * Tests for exporter::run().
 *
 * @package   mod_slides
 */
class mod_slides_scorm_export_test extends advanced_testcase {

    /**
     * Artefacts produced by a test, removed in tearDown().
     *
     * @var array
     */
    private $artifacts = [];

    /**
     * Clean up temporary packages even when an assertion fails.
     */
    protected function tearDown(): void {
        foreach ($this->artifacts as $path) {
            if (is_dir($path)) {
                remove_dir($path);
            } else if ($path !== null && file_exists($path)) {
                @unlink($path);
            }
        }
        $this->artifacts = [];
        parent::tearDown();
    }

    /**
     * Create a slides instance with a populated deck.
     *
     * @param array $slides Optional slides to install instead of the demo deck.
     * @return array{instance:stdClass,cm:stdClass,context:\context_module}
     */
    private function prepare_deck(array $slides = []): array {
        global $DB;

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        if (empty($slides)) {
            deck::create_demo_deck((int) $instance->id);
        } else {
            deck::replace_deck((int) $instance->id, $slides);
        }

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        return ['instance' => $DB->get_record('slides', ['id' => $instance->id]),
                'cm' => $cm, 'context' => context_module::instance($cm->id)];
    }

    /**
     * Extract a generated package into a temporary directory.
     *
     * @param string $zip Path to the archive.
     * @return string Directory holding the extracted package.
     */
    private function extract(string $zip): string {
        $packer = get_file_packer('application/zip');
        $dir = make_temp_directory('mod_slides/phpunit_export_' . uniqid('', true));
        $this->artifacts[] = $dir;
        $this->assertTrue($packer->extract_to_pathname($zip, $dir));

        return $dir;
    }

    /**
     * A demo deck must produce a self contained, valid SCORM 1.2 package.
     */
    public function test_export_creates_valid_package() {
        $prepared = $this->prepare_deck();
        $result = exporter::run($prepared['instance'], $prepared['cm'], $prepared['context']);
        $this->artifacts[] = $result['zip'];

        $this->assertFileExists($result['zip']);
        $this->assertStringStartsWith('slides-', $result['filename']);
        $this->assertMatchesRegularExpression('/^slides-[a-z0-9\-]+-\d+-\d{8}-\d{6}\.zip$/', $result['filename']);
        $this->assertGreaterThan(0, $result['files']);

        $packer = get_file_packer('application/zip');
        $entries = $packer->list_files($result['zip']);
        $names = array_map(fn($entry) => str_replace('\\', '/', $entry->pathname), $entries);
        sort($names);

        foreach (['assets/deck.json', 'assets/APIWrapper.js', 'assets/player.js',
                  'assets/player.css', 'assets/styles.css', 'fonts/fonts.css'] as $required) {
            $this->assertContains($required, $names, "Missing $required");
        }
        $this->assertContains('imsmanifest.xml', $names);
        $this->assertContains('index.html', $names);
        $this->assertNotEmpty(array_filter($names, fn($n) => str_ends_with($n, '.woff2')));

        $dir = $this->extract($result['zip']);
        $this->assertManifestMatchesPackage($dir, $names);

        $index = (string) file_get_contents($dir . '/index.html');
        $this->assertStringContainsString('assets/player.js', $index);
        $this->assertStringContainsString('slides-viewer', $index);
        $this->assertStringNotContainsString('slides-topbar', $index, 'Moodle chrome must not leak.');
        $this->assertStringNotContainsString('pluginfile.php', $index);
        $this->assertStringNotContainsString('data:image', $index);
        $this->assertSame(5, substr_count($index, '<section class="slide'));

        $deckjson = (string) file_get_contents($dir . '/assets/deck.json');
        $deck = json_decode($deckjson, true);
        $this->assertIsArray($deck);
        $this->assertCount(5, $deck);
        $this->assertSame('Portada', $deck[0]['title']);
        $this->assertSame('#1a1a2e', $deck[0]['background']['color']);
        $this->assertStringNotContainsString('data:image', $deckjson);
    }

    /**
     * Media embedded as data URIs must be extracted to real files.
     */
    public function test_export_extracts_media_to_files() {
        $png = base64_decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
        );
        $datauri = 'data:image/png;base64,' . base64_encode($png);

        $prepared = $this->prepare_deck([[
            'title' => 'With media',
            'elements' => [['type' => 'image', 'x' => 10, 'y' => 10, 'w' => 200, 'h' => 100,
                'src' => $datauri, 'opacity' => 100]],
            'background' => ['color' => '#ffffff', 'image' => $datauri],
            'transition' => 'none',
        ]]);

        $result = exporter::run($prepared['instance'], $prepared['cm'], $prepared['context']);
        $this->artifacts[] = $result['zip'];
        $this->assertSame(2, $result['media']);

        $dir = $this->extract($result['zip']);
        $media = array_values(array_filter(scandir($dir . '/assets/media') ?: [],
            fn($entry) => !in_array($entry, ['.', '..'], true)));
        $this->assertNotEmpty($media, 'No media file was written.');

        $deckjson = (string) file_get_contents($dir . '/assets/deck.json');
        $index = (string) file_get_contents($dir . '/index.html');
        $this->assertStringNotContainsString('data:image', $deckjson);
        $this->assertStringNotContainsString('data:image', $index);

        $decoded = json_decode($deckjson, true);
        $this->assertStringStartsWith('assets/media/', $decoded[0]['elements'][0]['src']);
        $this->assertStringStartsWith('assets/media/', $decoded[0]['background']['image']);
        $this->assertFileExists($dir . '/' . $decoded[0]['elements'][0]['src']);
    }

    /**
     * Exporting an empty deck must be refused with a readable message.
     */
    public function test_export_rejects_empty_deck() {
        global $DB;

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);
        $DB->delete_records('slides_slides', ['slidesid' => $instance->id]);

        $cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->expectException(moodle_exception::class);
        $this->expectExceptionMessage(get_string('nothingtoexport', 'mod_slides'));
        exporter::run($instance, $cm, context_module::instance($cm->id));
    }

    /**
     * The download name must be safe for a Content-Disposition header.
     */
    public function test_package_filename_is_safe() {
        $instance = (object) ['name' => 'My Great Deck! ¿Vale?'];
        $cm = (object) ['id' => 77];

        $filename = exporter::package_filename($instance, $cm);

        $this->assertMatchesRegularExpression('/^slides-[a-z0-9\-]+-77-\d{8}-\d{6}\.zip$/', $filename);
        $this->assertStringNotContainsString('!', $filename);
        $this->assertStringNotContainsString('?', $filename);
        $this->assertStringNotContainsString(' ', $filename);
    }

    /**
     * Assert that imsmanifest.xml lists exactly the files present in the package.
     *
     * @param string $dir Extracted package directory.
     * @param array $names Zip entry names (including imsmanifest.xml).
     * @return void
     */
    private function assertManifestMatchesPackage(string $dir, array $names): void {
        $xml = (string) file_get_contents($dir . '/imsmanifest.xml');
        $previous = libxml_use_internal_errors(true);
        $manifest = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET);
        $errors = libxml_get_errors();
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        $this->assertInstanceOf(SimpleXMLElement::class, $manifest, 'Manifest is not valid XML.');
        $this->assertEmpty($errors);
        $this->assertSame('1.2', (string) $manifest->metadata->schemaversion);

        $listed = [];
        foreach ($manifest->resources->resource->file as $file) {
            $listed[] = (string) $file['href'];
        }
        sort($listed);

        $ondisk = array_values(array_diff($names, ['imsmanifest.xml']));
        sort($ondisk);

        $this->assertSame($ondisk, $listed, 'Manifest file list does not match the package.');
        foreach ($listed as $href) {
            $this->assertStringNotContainsString('..', $href);
            $this->assertFileExists($dir . '/' . $href);
        }
    }
}
