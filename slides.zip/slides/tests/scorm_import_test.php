<?php
/**
 * Integration tests for the SCORM 1.2 package importer.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use mod_slides\local\deck;
use mod_slides\local\deck_sanitizer;
use mod_slides\local\scorm\exporter;
use mod_slides\local\scorm\importer;
use mod_slides\local\scorm\manifest_builder;

global $CFG;
require_once($CFG->dirroot . '/mod/slides/classes/local/scorm/importer.php');

/**
 * Tests for importer::import().
 *
 * @package   mod_slides
 */
class mod_slides_scorm_import_test extends advanced_testcase {

    /** @var array Temporary files/directories created by a test. */
    private $artifacts = [];

    /** @var stored_file[] Packages stored during a test. */
    private $files = [];

    /** @var array Context of the presentation being imported into. */
    private $context;

    /** @var stdClass Slides instance being imported into. */
    private $instance;

    /**
     * Prepare an instance and a signed in user.
     */
    protected function setUp(): void {
        parent::setUp();
        $this->resetAfterTest(true);

        $user = $this->getDataGenerator()->create_user();
        $this->setUser($user);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $this->instance = $generator->create_instance(['course' => $course->id]);

        $cm = get_coursemodule_from_instance('slides', $this->instance->id);
        $this->context = context_module::instance($cm->id);
    }

    /**
     * Remove temporary artefacts even when a test fails.
     */
    protected function tearDown(): void {
        foreach ($this->files as $file) {
            try {
                $file->delete();
            } catch (\Throwable $e) {
                // The file may already be gone; nothing to do.
            }
        }
        $this->files = [];

        foreach ($this->artifacts as $path) {
            if (is_dir($path)) {
                remove_dir($path);
            } else if ($path !== null && file_exists($path)) {
                @unlink($path);
            }
        }
        $this->artifacts = [];
        parent::tearDown();
    }

    /* ---------------------------------------------------------------- *
     * Helpers
     * ---------------------------------------------------------------- */

    /**
     * Build a .zip on disk out of in-memory entries.
     *
     * @param array $entries Relative path => content.
     * @param bool $hostile Use ZipArchive directly (keeps hostile paths).
     * @return string Path of the archive.
     */
    private function build_package(array $entries, bool $hostile = false): string {
        $dir = make_temp_directory('mod_slides/phpunit_pkg_' . uniqid('', true));
        $this->artifacts[] = $dir;
        $zip = $dir . '/package.zip';

        if ($hostile) {
            $archive = new ZipArchive();
            $archive->open($zip, ZipArchive::CREATE | ZipArchive::OVERWRITE);
            foreach ($entries as $path => $content) {
                $archive->addFromString($path, $content);
            }
            $archive->close();
        } else {
            $packer = get_file_packer('application/zip');
            $files = [];
            foreach ($entries as $path => $content) {
                $files[$path] = ['content_as_string' => $content];
            }
            $this->assertTrue($packer->archive_to_pathname($files, $zip, false));
        }

        return $zip;
    }

    /**
     * Store an archive in the scormimport area of the presentation.
     *
     * @param string $zip Path to the archive on disk.
     * @param int $itemid Draft item id.
     * @return stored_file
     */
    private function stored_package(string $zip, int $itemid = 0): stored_file {
        global $USER;

        $fs = get_file_storage();
        $fs->delete_area_files($this->context->id, 'mod_slides', 'scormimport', $itemid);

        $file = $fs->create_file_from_pathname((object) [
            'contextid' => $this->context->id,
            'component' => 'mod_slides',
            'filearea'  => 'scormimport',
            'itemid'    => $itemid,
            'filepath'  => '/',
            'filename'  => 'package.zip',
            'userid'    => $USER->id,
            'mimetype'  => 'application/zip',
        ], $zip);

        $this->files[] = $file;

        return $file;
    }

    /**
     * Install a two slide deck with transitions on an instance.
     *
     * @param int $slidesid
     * @return array Slides in the exact shape used when saving from the editor.
     */
    private function install_deck(int $slidesid): array {
        $slides = deck_sanitizer::sanitize_slides([
            [
                'title'      => 'Portada',
                'background' => ['color' => '#1a1a2e'],
                'transition' => 'fade',
                'elements'   => [
                    ['type' => 'text', 'x' => 120, 'y' => 160, 'w' => 720, 'h' => 90,
                     'text' => 'Presentación', 'fontSize' => 52, 'color' => '#ffffff',
                     'align' => 'center', 'bold' => true],
                ],
            ],
            [
                'title'      => 'Contenido',
                'background' => ['color' => '#ffffff'],
                'transition' => 'push',
                'elements'   => [
                    ['type' => 'text', 'x' => 80, 'y' => 60, 'w' => 800, 'h' => 320,
                     'text' => "• Uno\n• Dos", 'fontSize' => 28, 'color' => '#333333',
                     'align' => 'left', 'bold' => false],
                    ['type' => 'shape', 'shape' => 'rectangle', 'x' => 100, 'y' => 400,
                     'w' => 200, 'h' => 80, 'color' => '#0d6efd'],
                ],
            ],
        ]);

        deck::replace_deck($slidesid, $slides);

        return $slides;
    }

    /**
     * Export a deck and return the archive path.
     *
     * @return string
     */
    private function export_package(): string {
        $cm = get_coursemodule_from_instance('slides', $this->instance->id);
        $result = exporter::run($this->instance, $cm, $this->context);
        $this->artifacts[] = $result['zip'];

        return $result['zip'];
    }

    /**
     * Build a minimal third party package that only has HTML content.
     *
     * @return string
     */
    private function build_generic_package(): string {
        $html = '<html><head><title>Ignored</title></head><body>'
            . '<h1>Welcome aboard</h1>'
            . '<p>First paragraph with enough text to occupy a line of the slide.</p>'
            . '<ul><li>Item one</li><li>Item two</li></ul>'
            . '<h2>Second part</h2><p>Closing thoughts.</p>'
            . '</body></html>';

        return $this->build_package([
            'index.html'     => $html,
            'imsmanifest.xml' => manifest_builder::build('Generic package', 77, ['index.html'], 1700000000),
        ]);
    }

    /* ---------------------------------------------------------------- *
     * Tests
     * ---------------------------------------------------------------- */

    /**
     * A package exported by the plugin must restore the deck with full fidelity.
     */
    public function test_roundtrip_preserves_the_deck() {
        $expected = $this->install_deck((int) $this->instance->id);
        $zip = $this->export_package();

        // Import the archive into a different presentation.
        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $target = $generator->create_instance(['course' => $course->id]);
        $cm = get_coursemodule_from_instance('slides', $target->id);

        $result = importer::import($this->stored_package($zip), $target);

        $this->assertSame('native', $result['format']);
        $this->assertSame(2, $result['slides']);

        global $DB;
        $rows = $DB->get_records('slides_slides', ['slidesid' => $target->id], 'sortorder ASC');
        $this->assertCount(2, $rows);

        $rows = array_values($rows);
        foreach ($expected as $i => $slide) {
            $this->assertSame($slide['title'], $rows[$i]->title);
            $this->assertEquals(json_decode($slide['background'], true),
                json_decode($rows[$i]->background, true), "Slide $i background differs.");
            $this->assertEquals(json_decode($slide['elements'], true),
                json_decode($rows[$i]->elements, true), "Slide $i elements differ.");
        }

        // The transition survives the round trip inside the background.
        $first = json_decode($rows[0]->background, true);
        $this->assertSame('fade', $first['transition']);
        $second = json_decode($rows[1]->background, true);
        $this->assertSame('push', $second['transition']);
    }

    /**
     * Importing must replace whatever deck the presentation had.
     */
    public function test_import_replaces_existing_slides() {
        global $DB;

        $this->install_deck((int) $this->instance->id);
        $zip = $this->build_generic_package();

        $result = importer::import($this->stored_package($zip), $this->instance);

        $this->assertSame('generic', $result['format']);
        $rows = $DB->get_records('slides_slides', ['slidesid' => $this->instance->id], 'sortorder ASC');
        $this->assertGreaterThan(0, count($rows));
        $this->assertStringNotContainsString('Portada', json_encode(array_map(fn($r) => $r->title, $rows)));
    }

    /**
     * A foreign package must be converted from its HTML into plain slides.
     */
    public function test_generic_package_is_converted_from_html() {
        global $DB;

        $result = importer::import($this->stored_package($this->build_generic_package()), $this->instance);

        $this->assertSame('generic', $result['format']);
        $this->assertGreaterThanOrEqual(2, $result['slides']);

        $rows = $DB->get_records('slides_slides', ['slidesid' => $this->instance->id], 'sortorder ASC');
        $all = json_encode(array_values(array_map(fn($r) => $r->elements, $rows)));

        $this->assertStringContainsString('Welcome aboard', $all);
        $this->assertStringContainsString('Item one', $all);
        $this->assertStringContainsString('Second part', $all);
    }

    /**
     * The heading of the first page becomes the title of the first slide.
     */
    public function test_generic_package_uses_html_heading_as_title() {
        global $DB;

        importer::import($this->stored_package($this->build_generic_package()), $this->instance);

        $rows = $DB->get_records('slides_slides', ['slidesid' => $this->instance->id], 'sortorder ASC');
        $first = reset($rows);

        $this->assertStringContainsString('Welcome aboard', $first->title . ' ' . $first->elements);
    }

    /**
     * Packages without a manifest are rejected.
     */
    public function test_import_rejects_package_without_manifest() {
        $zip = $this->build_package(['readme.txt' => 'hello']);

        $this->expectException(moodle_exception::class);
        $this->expectExceptionMessage(get_string('invalidmanifest', 'mod_slides'));
        importer::import($this->stored_package($zip), $this->instance);
    }

    /**
     * Files with an unsupported extension are rejected before extraction.
     */
    public function test_import_rejects_forbidden_file_types() {
        $zip = $this->build_package([
            'evil.php'       => '<?php echo 1;',
            'imsmanifest.xml' => manifest_builder::build('Bad', 77, ['index.html'], 1700000001),
        ]);

        $this->expectException(moodle_exception::class);
        $this->expectExceptionMessage(get_string('forbiddenfiletype', 'mod_slides', 'php'));
        importer::import($this->stored_package($zip), $this->instance);
    }

    /**
     * Hostile entry names must never be written outside the extraction folder.
     */
    public function test_import_never_writes_outside_the_temporary_folder() {
        global $CFG;

        $zip = $this->build_package([
            '../evil.txt'   => 'boom',
            'notes.txt'     => 'ok',
            'index.html'    => '<html><body><h1>Escaped?</h1></body></html>',
            'imsmanifest.xml' => manifest_builder::build('Hostile', 77, ['index.html'], 1700000002),
        ], true);

        $result = importer::import($this->stored_package($zip), $this->instance);

        $this->assertIsArray($result);
        $this->assertFileDoesNotExist($CFG->tempdir . '/evil.txt');
        $this->assertFileDoesNotExist($CFG->tempdir . '/mod_slides/evil.txt');
        $this->assertFileDoesNotExist($CFG->tempdir . '/../evil.txt');
    }

    /**
     * A package whose deck.json is corrupt must not wipe the presentation.
     */
    public function test_import_rejects_corrupt_deck_json() {
        global $DB;

        $expected = $this->install_deck((int) $this->instance->id);
        $before = $DB->count_records('slides_slides', ['slidesid' => $this->instance->id]);

        $zip = $this->build_package([
            'index.html'      => '<html><body><h1>Hi</h1></body></html>',
            'assets/deck.json' => '{ this is not json }',
            'imsmanifest.xml'  => manifest_builder::build('Broken', 77,
                ['index.html', 'assets/deck.json'], 1700000003),
        ]);

        try {
            importer::import($this->stored_package($zip), $this->instance);
            $this->fail('Corrupt deck.json was accepted.');
        } catch (moodle_exception $e) {
            $this->assertSame('importfailed', $e->errorcode);
        }

        $this->assertSame($before, $DB->count_records('slides_slides', ['slidesid' => $this->instance->id]));
        $rows = $DB->get_records('slides_slides', ['slidesid' => $this->instance->id], 'sortorder ASC');
        $this->assertSame($expected[0]['title'], reset($rows)->title);
    }
}
