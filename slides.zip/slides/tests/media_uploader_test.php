<?php
/**
 * Unit tests for the audio/video recording uploader.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use mod_slides\local\media_uploader;

/**
 * Tests for media_uploader (slides_media file area).
 *
 * @package   mod_slides
 */
class mod_slides_media_uploader_test extends advanced_testcase {

    /** @var stdClass Course module context. */
    private $cm;

    /** @var string Absolute path of the temp file used as tmp_name. */
    private $tmpfile;

    protected function setUp(): void {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);
        $this->cm = get_coursemodule_from_instance('slides', $instance->id);

        $this->setAdminUser();

        // Minimal but real RIFF/WAVE file so libmagic reports audio/*.
        $header = 'RIFF' . pack('V', 36 + 800) . 'WAVE'
            . 'fmt ' . pack('V', 16) . pack('v', 1) . pack('v', 1)
            . pack('V', 8000) . pack('V', 8000) . pack('v', 1) . pack('v', 8)
            . 'data' . pack('V', 800) . str_repeat("\x80", 800);
        $this->tmpfile = tempnam(sys_get_temp_dir(), 'slides_media_test_');
        file_put_contents($this->tmpfile, $header);
    }

    protected function tearDown(): void {
        if ($this->tmpfile !== null && file_exists($this->tmpfile)) {
            unlink($this->tmpfile);
        }
    }

    /**
     * A valid recording is stored in slides_media and returns a pluginfile URL.
     */
    public function test_upload_accepts_recording() {
        $result = media_uploader::upload($this->cm->id, [
            'tmp_name' => $this->tmpfile,
            'name'     => 'grabacion.webm',
            'size'     => filesize($this->tmpfile),
            'type'     => 'audio/wav',
            'error'    => 0,
        ]);

        $this->assertArrayHasKey('url', $result);
        $this->assertArrayHasKey('filename', $result);
        $this->assertArrayHasKey('filesize', $result);
        $this->assertStringContainsString('pluginfile.php', $result['url']);
        $this->assertStringEndsWith('.webm', $result['filename']);
        $this->assertEquals(filesize($this->tmpfile), $result['filesize']);

        $fs = get_file_storage();
        $files = $fs->get_area_files(context_module::instance($this->cm->id)->id,
            'mod_slides', media_uploader::FILEAREA, 0, 'filename', false);
        $this->assertCount(1, $files);
        $this->assertEquals(reset($files)->get_filename(), $result['filename']);
    }

    /**
     * A plain text file is rejected before anything is stored.
     */
    public function test_upload_rejects_non_media() {
        $txt = tempnam(sys_get_temp_dir(), 'slides_media_txt_');
        file_put_contents($txt, 'esto no es una grabacion, solo texto plano.');
        try {
            $this->expectException('moodle_exception');
            media_uploader::upload($this->cm->id, [
                'tmp_name' => $txt,
                'name'     => 'notas.txt',
                'size'     => filesize($txt),
                'type'     => 'text/plain',
                'error'    => 0,
            ]);
        } finally {
            if (file_exists($txt)) {
                unlink($txt);
            }
        }

        $fs = get_file_storage();
        $files = $fs->get_area_files(context_module::instance($this->cm->id)->id,
            'mod_slides', media_uploader::FILEAREA, 0, 'filename', false);
        $this->assertEmpty($files);
    }

    /**
     * Oversized uploads are rejected with the size message (50 MB cap).
     */
    public function test_upload_rejects_file_too_large() {
        $this->expectException('moodle_exception');
        media_uploader::upload($this->cm->id, [
            'tmp_name' => $this->tmpfile,
            'name'     => 'gigante.webm',
            'size'     => media_uploader::MAX_FILESIZE + 1,
            'type'     => 'video/webm',
            'error'    => 0,
        ]);
    }

    /**
     * Uploads without a tmp file (upload error / forged request) are rejected.
     */
    public function test_upload_rejects_missing_tmp_name() {
        $this->expectException('moodle_exception');
        media_uploader::upload($this->cm->id, [
            'tmp_name' => '',
            'name'     => 'vacio.webm',
            'size'     => 0,
            'type'     => '',
            'error'    => 4,
        ]);
    }

    /**
     * A drawing PNG exported from the editor canvas is accepted.
     *
     * Builds a minimal valid 1x1 RGBA PNG byte-by-byte (signature + IHDR +
     * zlib IDAT + IEND) so no GD/ImageMagick extension is needed.
     */
    public function test_upload_accepts_png_drawing() {
        $chunk = function(string $type, string $data): string {
            return $type . $data . pack('N', crc32($type . $data));
        };
        $png = "\x89PNG\r\n\x1a\n"
            . $chunk('IHDR', pack('NNCCCCC', 1, 1, 8, 6, 0, 0, 0))
            . $chunk('IDAT', gzcompress("\x00\x00\x00\x00\x00"))
            . $chunk('IEND', '');

        $tmp = tempnam(sys_get_temp_dir(), 'slides_media_png_');
        file_put_contents($tmp, $png);
        try {
            $result = media_uploader::upload($this->cm->id, [
                'tmp_name' => $tmp,
                'name'     => 'dibujo_1760000000000.png',
                'size'     => strlen($png),
                'type'     => 'image/png',
                'error'    => 0,
            ]);
            $this->assertStringContainsString('pluginfile.php', $result['url']);
            $this->assertStringEndsWith('.png', $result['filename']);
            $this->assertEquals(strlen($png), $result['filesize']);

            $fs = get_file_storage();
            $files = $fs->get_area_files(context_module::instance($this->cm->id)->id,
                'mod_slides', media_uploader::FILEAREA, 0, 'filename', false);
            $this->assertCount(1, $files);
        } finally {
            if (file_exists($tmp)) {
                unlink($tmp);
            }
        }
    }

    /**
     * A JPEG renamed to .png is still rejected (MIME comes from content).
     */
    public function test_upload_rejects_non_png_image() {
        $jpeg = "\xFF\xD8\xFF\xE0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00"
            . "\xFF\xD9"; // Minimal JPEG signature; finfo reports image/jpeg.
        $tmp = tempnam(sys_get_temp_dir(), 'slides_media_jpg_');
        file_put_contents($tmp, $jpeg);
        try {
            $this->expectException('moodle_exception');
            media_uploader::upload($this->cm->id, [
                'tmp_name' => $tmp,
                'name'     => 'falso.png',
                'size'     => strlen($jpeg),
                'type'     => 'image/png',
                'error'    => 0,
            ]);
        } finally {
            if (file_exists($tmp)) {
                unlink($tmp);
            }
        }
    }
}
