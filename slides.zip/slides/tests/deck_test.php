<?php
/**
 * Unit tests for mod_slides\local\deck class.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use mod_slides\local\deck;
use mod_slides\local\deck_sanitizer;

global $CFG;
require_once($CFG->dirroot . '/mod/slides/classes/local/deck.php');
require_once($CFG->dirroot . '/mod/slides/classes/local/deck_sanitizer.php');

/**
 * Tests for the deck helper class.
 *
 * @package   mod_slides
 */
class mod_slides_deck_test extends advanced_testcase {

    /**
     * Test canvas_dimensions() for 16:9 ratio.
     */
    public function test_canvas_dimensions_16_9() {
        [$w, $h] = deck::canvas_dimensions('16:9');
        $this->assertEquals(960, $w);
        $this->assertEquals(540, $h);
    }

    /**
     * Test canvas_dimensions() for 4:3 ratio.
     */
    public function test_canvas_dimensions_4_3() {
        [$w, $h] = deck::canvas_dimensions('4:3');
        $this->assertEquals(960, $w);
        $this->assertEquals(720, $h);
    }

    /**
     * Test canvas_dimensions() defaults to 16:9 for unknown ratios.
     */
    public function test_canvas_dimensions_unknown_defaults() {
        [$w, $h] = deck::canvas_dimensions('unknown');
        $this->assertEquals(960, $w);
        $this->assertEquals(540, $h);
    }

    /**
     * Test sanitize_color() with valid hex colors.
     */
    public function test_sanitize_color_valid_hex() {
        $this->assertEquals('#ffffff', deck::sanitize_color('#FFFFFF'));
        $this->assertEquals('#000000', deck::sanitize_color('#000000'));
        $this->assertEquals('#abc123', deck::sanitize_color('#ABC123'));
        $this->assertEquals('#fff', deck::sanitize_color('#FFF'));
    }

    /**
     * Test sanitize_color() with invalid colors returns fallback.
     */
    public function test_sanitize_color_invalid_returns_fallback() {
        $this->assertEquals('#ffffff', deck::sanitize_color('red'));
        $this->assertEquals('#ffffff', deck::sanitize_color('rgb(255,0,0)'));
        $this->assertEquals('#ffffff', deck::sanitize_color(''));
        $this->assertEquals('#ffffff', deck::sanitize_color('not-a-color'));
    }

    /**
     * Test get_deck() with empty slides.
     */
    public function test_get_deck_empty() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        // Delete the default slide.
        $DB = $this->getDb();
        $DB->delete_records('slides_slides', ['slidesid' => $instance->id]);

        $slides = deck::get_deck($instance->id);
        $this->assertCount(0, $slides);
    }

    /**
     * Test get_deck() with slides returns decoded data.
     */
    public function test_get_deck_with_slides() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $slides = deck::get_deck($instance->id);

        $this->assertCount(1, $slides);
        $this->assertEquals('Slide 1', $slides[0]->title);
        $this->assertIsArray($slides[0]->elements);
        $this->assertIsArray($slides[0]->background);
        $this->assertEquals('#ffffff', $slides[0]->background['color']);
    }

    /**
     * Test is_empty() when no slides exist.
     */
    public function test_is_empty_true() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        // Delete default slide.
        $DB = $this->getDb();
        $DB->delete_records('slides_slides', ['slidesid' => $instance->id]);

        $this->assertTrue(deck::is_empty($instance->id));
    }

    /**
     * Test is_empty() when slides exist.
     */
    public function test_is_empty_false() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        $this->assertFalse(deck::is_empty($instance->id));
    }

    /**
     * Test create_demo_deck() creates slides.
     */
    public function test_create_demo_deck() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        deck::create_demo_deck($instance->id);

        $slides = $DB->get_records('slides_slides', ['slidesid' => $instance->id], 'sortorder ASC');
        $this->assertCount(5, $slides);

        // Verify the first slide.
        $first = reset($slides);
        $this->assertEquals('Portada', $first->title);
        $this->assertEquals(0, $first->sortorder);

        // Verify JSON fields decode correctly.
        $elements = json_decode($first->elements, true);
        $this->assertIsArray($elements);
        $this->assertGreaterThanOrEqual(1, count($elements));

        $background = json_decode($first->background, true);
        $this->assertIsArray($background);
        $this->assertEquals('#1a1a2e', $background['color']);
    }

    /**
     * Test create_demo_deck() replaces existing slides.
     */
    public function test_create_demo_deck_replaces() {
        global $DB;

        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);

        // Create demo twice.
        deck::create_demo_deck($instance->id);
        deck::create_demo_deck($instance->id);

        $slides = $DB->get_records('slides_slides', ['slidesid' => $instance->id]);
        $this->assertCount(5, $slides);
    }

    /**
     * The sanitizer preserves valid animation fields and clamps bad input.
     */
    public function test_sanitize_element_animation_fields() {
        // Valid values pass through untouched.
        $clean = deck_sanitizer::sanitize_element([
            'type' => 'text',
            'animOrder' => 3,
            'animType' => 'fade',
        ]);
        $this->assertEquals(3, $clean['animOrder']);
        $this->assertEquals('fade', $clean['animType']);

        // Negative order collapses to 0 (not animated).
        $clean = deck_sanitizer::sanitize_element([
            'type' => 'image',
            'animOrder' => -2,
            'animType' => 'up',
        ]);
        $this->assertEquals(0, $clean['animOrder']);
        $this->assertEquals('up', $clean['animType']);

        // Unknown effect is wiped; defaults are zeroed.
        $clean = deck_sanitizer::sanitize_element([
            'type' => 'shape',
            'animOrder' => 'x',
            'animType' => 'explode',
        ]);
        $this->assertEquals(0, $clean['animOrder']);
        $this->assertEquals('', $clean['animType']);

        $clean = deck_sanitizer::sanitize_element(['type' => 'text']);
        $this->assertEquals(0, $clean['animOrder']);
        $this->assertEquals('', $clean['animType']);
    }
}
