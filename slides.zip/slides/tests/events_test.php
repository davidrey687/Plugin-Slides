<?php
/**
 * Unit tests for mod_slides events.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

use mod_slides\event\course_module_viewed;
use mod_slides\event\slides_created;
use mod_slides\event\slides_updated;
use mod_slides\event\slides_deleted;

/**
 * Tests for mod_slides events.
 *
 * @package   mod_slides
 */
class mod_slides_events_test extends advanced_testcase {

    /**
     * Test course_module_viewed event.
     */
    public function test_course_module_viewed() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);
        $cm = get_coursemodule_from_instance('slides', $instance->id);
        $context = context_module::instance($cm->id);

        $sink = $this->redirectEvents();

        $event = course_module_viewed::create_from_cm($cm->id, $instance);
        $event->trigger();

        $events = $sink->get_events();
        $this->assertCount(1, $events);

        $event = reset($events);
        $this->assertInstanceOf('mod_slides\event\course_module_viewed', $event);
        $this->assertEquals($instance->id, $event->objectid);
        $this->assertEquals($instance->name, $event->other['slidesname']);
        $this->assertEquals('r', $event->crud);
        $this->assertNotEmpty($event->get_description());
    }

    /**
     * Test slides_created event.
     */
    public function test_slides_created() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);
        $cm = get_coursemodule_from_instance('slides', $instance->id);
        $context = context_module::instance($cm->id);

        $sink = $this->redirectEvents();

        $event = slides_created::create_from_instance($instance, $context);
        $event->trigger();

        $events = $sink->get_events();
        $this->assertCount(1, $events);

        $event = reset($events);
        $this->assertInstanceOf('mod_slides\event\slides_created', $event);
        $this->assertEquals($instance->id, $event->objectid);
        $this->assertEquals('c', $event->crud);
        $this->assertStringContainsString('created', $event->get_description());
    }

    /**
     * Test slides_updated event.
     */
    public function test_slides_updated() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);
        $cm = get_coursemodule_from_instance('slides', $instance->id);
        $context = context_module::instance($cm->id);

        $sink = $this->redirectEvents();

        $event = slides_updated::create_from_instance($instance, $context);
        $event->trigger();

        $events = $sink->get_events();
        $this->assertCount(1, $events);

        $event = reset($events);
        $this->assertInstanceOf('mod_slides\event\slides_updated', $event);
        $this->assertEquals($instance->id, $event->objectid);
        $this->assertEquals('u', $event->crud);
        $this->assertStringContainsString('updated', $event->get_description());
    }

    /**
     * Test slides_deleted event.
     */
    public function test_slides_deleted() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);
        $cm = get_coursemodule_from_instance('slides', $instance->id);
        $context = context_module::instance($cm->id);

        $sink = $this->redirectEvents();

        $event = slides_deleted::create_from_instance($instance, $context);
        $event->trigger();

        $events = $sink->get_events();
        $this->assertCount(1, $events);

        $event = reset($events);
        $this->assertInstanceOf('mod_slides\event\slides_deleted', $event);
        $this->assertEquals($instance->id, $event->objectid);
        $this->assertEquals('d', $event->crud);
        $this->assertStringContainsString('deleted', $event->get_description());
    }

    /**
     * Test event get_name() returns correct values.
     */
    public function test_event_get_name() {
        $this->assertNotEmpty(course_module_viewed::get_name());
        $this->assertNotEmpty(slides_created::get_name());
        $this->assertNotEmpty(slides_updated::get_name());
        $this->assertNotEmpty(slides_deleted::get_name());
    }

    /**
     * Test event get_url() returns valid URLs.
     */
    public function test_event_get_url() {
        $this->resetAfterTest(true);

        $course = $this->getDataGenerator()->create_course();
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_slides');
        $instance = $generator->create_instance(['course' => $course->id]);
        $cm = get_coursemodule_from_instance('slides', $instance->id);
        $context = context_module::instance($cm->id);

        $event = slides_created::create_from_instance($instance, $context);
        $url = $event->get_url();

        $this->assertInstanceOf('moodle_url', $url);
        $this->assertStringContainsString('/mod/slides/view.php', $url->out());
    }
}
