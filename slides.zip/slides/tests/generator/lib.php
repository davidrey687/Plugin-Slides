<?php
/**
 * Test data generator for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Slides test data generator.
 *
 * @package   mod_slides
 */
class mod_slides_generator extends testing_module_generator {

    /**
     * Create a slides instance in a course.
     *
     * @param array|stdClass $record
     * @param array $options
     * @return stdClass
     */
    public function create_instance($record = null, array $options = null): stdClass {
        $record = (array) $record;

        // Set default values.
        $defaults = [
            'name'          => 'Test slides presentation',
            'intro'         => 'Test introduction text',
            'introformat'   => FORMAT_HTML,
            'aspectratio'   => '16:9',
            'theme'         => 'default',
            'timecreated'   => time(),
            'timemodified'  => time(),
        ];

        foreach ($defaults as $key => $value) {
            if (!isset($record[$key])) {
                $record[$key] = $value;
            }
        }

        $record['timecreated'] = time();
        $record['timemodified'] = time();

        return parent::create_instance($record, $options);
    }
}
