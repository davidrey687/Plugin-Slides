<?php
/**
 * Privacy API implementation for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;

defined('MOODLE_INTERNAL') || die();

/**
 * Privacy provider for mod_slides.
 *
 * The plugin stores presentation content created by teachers/editors.
 * Slide content is not personal user data by itself, but editors may
 * embed images or videos (base64 data URIs) in slides. No user-specific
 * records are stored per user.
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider {

    /**
     * Return the fields managed by this plugin.
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_database_table('slides', [
            'name'         => 'privacy:metadata:slides:name',
            'intro'        => 'privacy:metadata:slides:intro',
            'aspectratio'  => 'privacy:metadata:slides:aspectratio',
            'timecreated'  => 'privacy:metadata:slides:timecreated',
            'timemodified' => 'privacy:metadata:slides:timemodified',
        ], 'privacy:metadata:slides');

        $collection->add_database_table('slides_slides', [
            'title'      => 'privacy:metadata:slides_slides:title',
            'elements'   => 'privacy:metadata:slides_slides:elements',
            'background' => 'privacy:metadata:slides_slides:background',
        ], 'privacy:metadata:slides_slides');

        $collection->link_subsystem(
            'core_files',
            'privacy:metadata:core_files'
        );

        return $collection;
    }

    /**
     * Get the list of contexts that contain user information for the specified user.
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $contextlist = new contextlist();

        // Editors who modified a presentation have data in its context.
        $sql = "SELECT ctx.id
                  FROM {slides} s
                  JOIN {course_modules} cm ON cm.instance = s.id
                  JOIN {modules} m ON m.id = cm.module AND m.name = :modname
                  JOIN {context} ctx ON ctx.instanceid = cm.id AND ctx.contextlevel = :contextlevel
                 WHERE s.timemodified > 0 AND EXISTS (
                       SELECT 1 FROM {user} u WHERE u.id = :userid
                 )";

        $params = [
            'userid'       => $userid,
            'contextlevel' => CONTEXT_MODULE,
        ];

        // Only include module contexts of presentations the user can access as editor.
        $sql = "SELECT ctx.id
                  FROM {context} ctx
                  JOIN {course_modules} cm ON cm.id = ctx.instanceid
                  JOIN {modules} m ON m.id = cm.module AND m.name = 'slides'
                  JOIN {slides} s ON s.id = cm.instance
                 WHERE ctx.contextlevel = :contextlevel
                   AND EXISTS (
                       SELECT 1
                         FROM {role_assignments} ra
                         JOIN {role_capabilities} rc ON rc.roleid = ra.roleid
                        WHERE ra.userid = :userid
                          AND ra.contextid = ctx.id
                          AND rc.capability = 'mod/slides:edit'
                   )";

        $contextlist->add_from_sql($sql, $params);

        return $contextlist;
    }

    /**
     * Get the list of users who have data within a context.
     */
    public static function get_users_in_context(userlist $userlist): void {
        $context = $userlist->get_context();

        if (!$context instanceof \context_module) {
            return;
        }

        $sql = "SELECT ra.userid
                  FROM {role_assignments} ra
                  JOIN {role_capabilities} rc ON rc.roleid = ra.roleid
                 WHERE ra.contextid = :contextid
                   AND rc.capability = 'mod/slides:edit'";

        $params = ['contextid' => $context->id];

        $userlist->add_from_sql('userid', $sql, $params);
    }

    /**
     * Export all user data for the specified user in the specified contexts.
     */
    public static function export_user_data(approved_contextlist $contextlist): void {
        global $DB;

        if (empty($contextlist->count())) {
            return;
        }

        $userid = $contextlist->get_user()->id;

        foreach ($contextlist->get_contexts() as $context) {
            if ($context->contextlevel !== CONTEXT_MODULE) {
                continue;
            }

            $instance = $DB->get_record('slides', ['id' => $context->instanceid]);
            if (!$instance) {
                continue;
            }

            $slides = $DB->get_records('slides_slides', ['slidesid' => $instance->id], 'sortorder ASC');

            $data = (object) [
                'name'         => $instance->name,
                'description'  => $instance->intro,
                'aspectratio'  => $instance->aspectratio,
                'slide_count'  => count($slides),
            ];

            writer::with_context($context)->export_data(
                [get_string('privacy:path:presentations', 'mod_slides')],
                $data
            );

            // Export stored files in the slides_files, slides_pdf and
            // slides_media areas (recorded audio/video lives in the last one).
            $fs = get_file_storage();
            foreach (['slides_files', 'slides_pdf', 'slides_media'] as $filearea) {
                $files = $fs->get_area_files($context->id, 'mod_slides', $filearea, 0, 'sortorder ASC', false);
                foreach ($files as $file) {
                    writer::with_context($context)->export_file(
                        [get_string('privacy:path:presentations', 'mod_slides')],
                        $file
                    );
                }
            }
        }
    }

    /**
     * Delete all data for all users in the specified context.
     */
    public static function delete_data_for_all_users_in_context(\context $context): void {
        // Presentation content is shared (not user-owned), so nothing
        // per-user to delete here. Files are removed with the module.
    }

    /**
     * Delete all user data for the specified user.
     */
    public static function delete_data_for_user(approved_contextlist $contextlist): void {
        // Presentation content is shared (not user-owned), so nothing
        // per-user to delete here.
    }

    /**
     * Delete multiple users within a single context.
     */
    public static function delete_data_for_users(approved_userlist $userlist): void {
        // Presentation content is shared (not user-owned), so nothing
        // per-user to delete here.
    }
}
