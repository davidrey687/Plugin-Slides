<?php
/**
 * External API for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides;

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use mod_slides\local\deck;
use mod_slides\local\deck_sanitizer;

defined('MOODLE_INTERNAL') || die();

class external extends external_api {

    /* ------------------------------------------------------------------
     *  get_deck
     * ----------------------------------------------------------------*/

    public static function get_deck_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'Course module ID'),
        ]);
    }

    public static function get_deck(int $cmid): array {
        global $DB;

        [$course, $cm] = get_course_and_cm_from_cmid($cmid, 'slides');
        require_capability('mod/slides:view', \context_module::instance($cm->id));

        $instance = $DB->get_record('slides', ['id' => $cm->instance], '*', MUST_EXIST);
        $rawdeck  = deck::get_deck($instance->id);

        $slides = [];
        foreach ($rawdeck as $s) {
            $elements = [];
            foreach ($s->elements as $el) {
                $elements[] = deck_sanitizer::sanitize_element($el);
            }

            // Background JSON may contain transition stored inside it
            $bgRaw = is_string($s->background) ? $s->background : json_encode($s->background ?? [], JSON_UNESCAPED_UNICODE);
            $bgData = json_decode($bgRaw, true) ?? ['color' => '#ffffff'];
            $transition = $bgData['transition'] ?? 'none';
            // Remove transition from background data before returning
            unset($bgData['transition']);
            $bgClean = json_encode($bgData, JSON_UNESCAPED_UNICODE);

            $slides[] = [
                'id'           => (int) $s->id,
                'title'        => $s->title,
                'sortorder'    => (int) $s->sortorder,
                'elements'     => $elements,
                'background'   => $bgClean,
                'transition'   => $transition,
            ];
        }

        return ['slides' => $slides];
    }

    public static function get_deck_returns(): external_single_structure {
        $elementfields = [
            'type'          => new external_value(PARAM_RAW, 'Element type'),
            'x'             => new external_value(PARAM_INT, 'X position'),
            'y'             => new external_value(PARAM_INT, 'Y position'),
            'w'             => new external_value(PARAM_INT, 'Width'),
            'h'             => new external_value(PARAM_INT, 'Height'),
            'text'          => new external_value(PARAM_RAW, 'Text content', VALUE_OPTIONAL),
            'fontfamily'    => new external_value(PARAM_RAW, 'Font family', VALUE_OPTIONAL),
            'fontSize'      => new external_value(PARAM_INT, 'Font size', VALUE_OPTIONAL),
            'color'         => new external_value(PARAM_RAW, 'Color', VALUE_OPTIONAL),
            'highlight'     => new external_value(PARAM_RAW, 'Highlight color', VALUE_OPTIONAL),
            'align'         => new external_value(PARAM_RAW, 'Alignment', VALUE_OPTIONAL),
            'bold'          => new external_value(PARAM_BOOL, 'Bold', VALUE_OPTIONAL),
            'italic'        => new external_value(PARAM_BOOL, 'Italic', VALUE_OPTIONAL),
            'underline'     => new external_value(PARAM_BOOL, 'Underline', VALUE_OPTIONAL),
            'strikethrough' => new external_value(PARAM_BOOL, 'Strikethrough', VALUE_OPTIONAL),
            'listType'      => new external_value(PARAM_RAW, 'List type', VALUE_OPTIONAL),
            'shape'         => new external_value(PARAM_RAW, 'Shape key', VALUE_OPTIONAL),
            'fill'          => new external_value(PARAM_RAW, 'Fill color', VALUE_OPTIONAL),
            'stroke'        => new external_value(PARAM_RAW, 'Stroke color', VALUE_OPTIONAL),
            'strokeWidth'   => new external_value(PARAM_INT, 'Stroke width', VALUE_OPTIONAL),
            'angle'         => new external_value(PARAM_INT, 'Angle', VALUE_OPTIONAL),
            'src'           => new external_value(PARAM_RAW, 'Source URL', VALUE_OPTIONAL),
            'alt'           => new external_value(PARAM_RAW, 'Alt text', VALUE_OPTIONAL),
            'crop'          => new external_single_structure([
                'x' => new external_value(PARAM_FLOAT, 'Crop left (source fraction)'),
                'y' => new external_value(PARAM_FLOAT, 'Crop top (source fraction)'),
                'w' => new external_value(PARAM_FLOAT, 'Crop width (source fraction)'),
                'h' => new external_value(PARAM_FLOAT, 'Crop height (source fraction)'),
            ], 'Source crop rect', VALUE_OPTIONAL, null, NULL_ALLOWED),
            'url'           => new external_value(PARAM_RAW, 'Link URL', VALUE_OPTIONAL),
            'target'        => new external_value(PARAM_RAW, 'Link target', VALUE_OPTIONAL),
            'opacity'       => new external_value(PARAM_INT, 'Opacity', VALUE_OPTIONAL),
            'borderRadius'  => new external_value(PARAM_INT, 'Border radius', VALUE_OPTIONAL),
            'points'        => new external_multiple_structure(
                new external_single_structure([
                    'x' => new external_value(PARAM_INT, 'Point X'),
                    'y' => new external_value(PARAM_INT, 'Point Y'),
                ]),
                'Pencil points',
                VALUE_OPTIONAL
            ),
            'pdftitle'      => new external_value(PARAM_RAW, 'PDF title', VALUE_OPTIONAL),
            'background'    => new external_value(PARAM_RAW, 'Footer background', VALUE_OPTIONAL),
            'charttype'     => new external_value(PARAM_RAW, 'Chart type', VALUE_OPTIONAL),
            'title'         => new external_value(PARAM_RAW, 'Chart title', VALUE_OPTIONAL),
            'labels'        => new external_value(PARAM_RAW, 'Chart labels', VALUE_OPTIONAL),
            'values'        => new external_value(PARAM_RAW, 'Chart values', VALUE_OPTIONAL),
            'titleColor'    => new external_value(PARAM_RAW, 'Chart title color', VALUE_OPTIONAL),
            'valueColor'    => new external_value(PARAM_RAW, 'Chart value color', VALUE_OPTIONAL),
            'bgColor'       => new external_value(PARAM_RAW, 'Chart background color', VALUE_OPTIONAL),
            'shadowEnabled' => new external_value(PARAM_BOOL, 'Shadow enabled', VALUE_OPTIONAL),
            'shadowColor'   => new external_value(PARAM_RAW, 'Shadow color', VALUE_OPTIONAL),
            'shadowBlur'    => new external_value(PARAM_INT, 'Shadow blur', VALUE_OPTIONAL),
            'shadowX'       => new external_value(PARAM_INT, 'Shadow X offset', VALUE_OPTIONAL),
            'shadowY'       => new external_value(PARAM_INT, 'Shadow Y offset', VALUE_OPTIONAL),
            'animOrder'     => new external_value(PARAM_INT, 'Animation order (0 = none)', VALUE_OPTIONAL),
            'animType'      => new external_value(PARAM_RAW, 'Animation type (appear|fade|up)', VALUE_OPTIONAL),
            'actionId'      => new external_value(PARAM_RAW, 'Interactive action button id', VALUE_OPTIONAL),
            'slideIdx'      => new external_value(PARAM_INT, 'Interactive action target slide', VALUE_OPTIONAL),
            'label'         => new external_value(PARAM_RAW, 'Interactive action label', VALUE_OPTIONAL),
            'bg'            => new external_value(PARAM_RAW, 'Interactive action background color', VALUE_OPTIONAL),
            'behavior'      => new external_single_structure([
                'kind'  => new external_value(PARAM_RAW, 'Action behavior kind (slide|url|label)', VALUE_OPTIONAL),
                'slide' => new external_value(PARAM_INT, 'Action target slide', VALUE_OPTIONAL),
                'url'   => new external_value(PARAM_RAW, 'Action external URL', VALUE_OPTIONAL),
                'text'  => new external_value(PARAM_RAW, 'Action label text', VALUE_OPTIONAL),
                'img'   => new external_value(PARAM_RAW, 'Action label image URL', VALUE_OPTIONAL),
                'video' => new external_value(PARAM_RAW, 'Action label video URL', VALUE_OPTIONAL),
            ], 'Interactive action behavior', VALUE_OPTIONAL, null, NULL_ALLOWED),
        ];

        $slidestruct = new external_single_structure([
            'id'           => new external_value(PARAM_INT, 'Slide ID'),
            'title'        => new external_value(PARAM_TEXT, 'Slide title'),
            'sortorder'    => new external_value(PARAM_INT, 'Sort order'),
            'elements'     => new external_multiple_structure(
                new external_single_structure($elementfields)
            ),
            'background'   => new external_value(PARAM_RAW, 'Background JSON'),
            'transition'   => new external_value(PARAM_RAW, 'Transition type', VALUE_OPTIONAL),
        ]);

        return new external_single_structure([
            'slides' => new external_multiple_structure($slidestruct),
        ]);
    }

    /* ------------------------------------------------------------------
     *  save_deck
     * ----------------------------------------------------------------*/

    public static function save_deck_parameters(): external_function_parameters {
        $elementfields = [
            'type'          => new external_value(PARAM_RAW, 'Element type'),
            'x'             => new external_value(PARAM_INT, 'X position'),
            'y'             => new external_value(PARAM_INT, 'Y position'),
            'w'             => new external_value(PARAM_INT, 'Width'),
            'h'             => new external_value(PARAM_INT, 'Height'),
            'text'          => new external_value(PARAM_RAW, 'Text content', VALUE_OPTIONAL),
            'fontfamily'    => new external_value(PARAM_RAW, 'Font family', VALUE_OPTIONAL),
            'fontSize'      => new external_value(PARAM_INT, 'Font size', VALUE_OPTIONAL),
            'color'         => new external_value(PARAM_RAW, 'Color', VALUE_OPTIONAL),
            'highlight'     => new external_value(PARAM_RAW, 'Highlight color', VALUE_OPTIONAL),
            'align'         => new external_value(PARAM_RAW, 'Alignment', VALUE_OPTIONAL),
            'bold'          => new external_value(PARAM_BOOL, 'Bold', VALUE_OPTIONAL),
            'italic'        => new external_value(PARAM_BOOL, 'Italic', VALUE_OPTIONAL),
            'underline'     => new external_value(PARAM_BOOL, 'Underline', VALUE_OPTIONAL),
            'strikethrough' => new external_value(PARAM_BOOL, 'Strikethrough', VALUE_OPTIONAL),
            'listType'      => new external_value(PARAM_RAW, 'List type', VALUE_OPTIONAL),
            'shape'         => new external_value(PARAM_RAW, 'Shape key', VALUE_OPTIONAL),
            'fill'          => new external_value(PARAM_RAW, 'Fill color', VALUE_OPTIONAL),
            'stroke'        => new external_value(PARAM_RAW, 'Stroke color', VALUE_OPTIONAL),
            'strokeWidth'   => new external_value(PARAM_INT, 'Stroke width', VALUE_OPTIONAL),
            'angle'         => new external_value(PARAM_INT, 'Angle', VALUE_OPTIONAL),
            'src'           => new external_value(PARAM_RAW, 'Source URL', VALUE_OPTIONAL),
            'alt'           => new external_value(PARAM_RAW, 'Alt text', VALUE_OPTIONAL),
            'crop'          => new external_single_structure([
                'x' => new external_value(PARAM_FLOAT, 'Crop left (source fraction)'),
                'y' => new external_value(PARAM_FLOAT, 'Crop top (source fraction)'),
                'w' => new external_value(PARAM_FLOAT, 'Crop width (source fraction)'),
                'h' => new external_value(PARAM_FLOAT, 'Crop height (source fraction)'),
            ], 'Source crop rect', VALUE_OPTIONAL, null, NULL_ALLOWED),
            'url'           => new external_value(PARAM_RAW, 'Link URL', VALUE_OPTIONAL),
            'target'        => new external_value(PARAM_RAW, 'Link target', VALUE_OPTIONAL),
            'opacity'       => new external_value(PARAM_INT, 'Opacity', VALUE_OPTIONAL),
            'borderRadius'  => new external_value(PARAM_INT, 'Border radius', VALUE_OPTIONAL),
            'points'        => new external_multiple_structure(
                new external_single_structure([
                    'x' => new external_value(PARAM_INT, 'Point X'),
                    'y' => new external_value(PARAM_INT, 'Point Y'),
                ]),
                'Pencil points',
                VALUE_OPTIONAL
            ),
            'pdftitle'      => new external_value(PARAM_RAW, 'PDF title', VALUE_OPTIONAL),
            'background'    => new external_value(PARAM_RAW, 'Footer background', VALUE_OPTIONAL),
            'charttype'     => new external_value(PARAM_RAW, 'Chart type', VALUE_OPTIONAL),
            'title'         => new external_value(PARAM_RAW, 'Chart title', VALUE_OPTIONAL),
            'labels'        => new external_value(PARAM_RAW, 'Chart labels', VALUE_OPTIONAL),
            'values'        => new external_value(PARAM_RAW, 'Chart values', VALUE_OPTIONAL),
            'titleColor'    => new external_value(PARAM_RAW, 'Chart title color', VALUE_OPTIONAL),
            'valueColor'    => new external_value(PARAM_RAW, 'Chart value color', VALUE_OPTIONAL),
            'bgColor'       => new external_value(PARAM_RAW, 'Chart background color', VALUE_OPTIONAL),
            'shadowEnabled' => new external_value(PARAM_BOOL, 'Shadow enabled', VALUE_OPTIONAL),
            'shadowColor'   => new external_value(PARAM_RAW, 'Shadow color', VALUE_OPTIONAL),
            'shadowBlur'    => new external_value(PARAM_INT, 'Shadow blur', VALUE_OPTIONAL),
            'shadowX'       => new external_value(PARAM_INT, 'Shadow X offset', VALUE_OPTIONAL),
            'shadowY'       => new external_value(PARAM_INT, 'Shadow Y offset', VALUE_OPTIONAL),
            // Interactive action buttons (Genially-style).
            'actionId'      => new external_value(PARAM_RAW, 'Interactive action button id', VALUE_OPTIONAL),
            'slideIdx'      => new external_value(PARAM_INT, 'Interactive action target slide', VALUE_OPTIONAL),
            'label'         => new external_value(PARAM_RAW, 'Interactive action label', VALUE_OPTIONAL),
            'bg'            => new external_value(PARAM_RAW, 'Interactive action background color', VALUE_OPTIONAL),
            'behavior'      => new external_single_structure([
                'kind'  => new external_value(PARAM_RAW, 'Action behavior kind (slide|url|label)', VALUE_OPTIONAL),
                'slide' => new external_value(PARAM_INT, 'Action target slide', VALUE_OPTIONAL),
                'url'   => new external_value(PARAM_RAW, 'Action external URL', VALUE_OPTIONAL),
                'text'  => new external_value(PARAM_RAW, 'Action label text', VALUE_OPTIONAL),
                'img'   => new external_value(PARAM_RAW, 'Action label image URL', VALUE_OPTIONAL),
                'video' => new external_value(PARAM_RAW, 'Action label video URL', VALUE_OPTIONAL),
            ], 'Interactive action behavior', VALUE_OPTIONAL, null, NULL_ALLOWED),
            'animOrder'     => new external_value(PARAM_INT, 'Animation order (0 = none)', VALUE_OPTIONAL),
            'animType'      => new external_value(PARAM_RAW, 'Animation type (appear|fade|up)', VALUE_OPTIONAL),
        ];

        $slidestruct = new external_single_structure([
            'title'        => new external_value(PARAM_TEXT, 'Slide title'),
            'sortorder'    => new external_value(PARAM_INT, 'Sort order'),
            'elements'     => new external_multiple_structure(
                new external_single_structure($elementfields)
            ),
            'background'   => new external_value(PARAM_RAW, 'Background JSON'),
            'transition'   => new external_value(PARAM_RAW, 'Transition type', VALUE_OPTIONAL),
        ]);

        return new external_function_parameters([
            'cmid'    => new external_value(PARAM_INT, 'Course module ID'),
            'deck'    => new external_multiple_structure($slidestruct),
            'sesskey' => new external_value(PARAM_RAW, 'Session key'),
        ]);
    }

    public static function save_deck(int $cmid, array $deck, string $sesskey): array {
        global $DB;

        [$course, $cm] = get_course_and_cm_from_cmid($cmid, 'slides');
        require_capability('mod/slides:edit', \context_module::instance($cm->id));

        if (!confirm_sesskey($sesskey)) {
            throw new \moodle_exception('invalidsesskey', 'error');
        }

        $instance = $DB->get_record('slides', ['id' => $cm->instance], '*', MUST_EXIST);

        $slides = deck_sanitizer::sanitize_slides($deck);
        deck::replace_deck((int) $instance->id, $slides);

        return ['status' => true];
    }

    public static function save_deck_returns(): external_single_structure {
        return new external_single_structure([
            'status' => new external_value(PARAM_BOOL, 'Success'),
        ]);
    }

}
