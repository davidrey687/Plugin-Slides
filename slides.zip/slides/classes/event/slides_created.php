<?php
/**
 * Event: slides instance created.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\event;

defined('MOODLE_INTERNAL') || die();

/**
 * Event triggered when a new slides presentation instance is created.
 *
 * @property-read array $other {
 *     @type string $slidesname  The presentation name.
 * }
 */
class slides_created extends \core\event\base {

    /**
     * Create event from data.
     */
    public static function create_from_instance(object $instance, \context_module $context): self {
        $data = [
            'context'  => $context,
            'objectid' => $instance->id,
            'other'    => ['slidesname' => $instance->name],
        ];
        return self::create($data);
    }

    /**
     * Get the description of the event.
     */
    protected function init(): void {
        $this->data['crud'] = 'c';
        $this->data['edulevel'] = self::LEVEL_TEACHING;
        $this->data['objecttable'] = 'slides';
    }

    /**
     * Get the name of the event.
     */
    public static function get_name(): string {
        return get_string('event:created', 'mod_slides');
    }

    /**
     * Get the description of the event.
     */
    public function get_description(): string {
        return "The user with id '{$this->userid}' created the slides presentation with id '{$this->objectid}'.";
    }

    /**
     * Get the URL for the event.
     */
    public function get_url(): \moodle_url {
        return new \moodle_url('/mod/slides/view.php', ['id' => $this->contextinstanceid]);
    }
}
