<?php
/**
 * Event: course module viewed for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\event;

defined('MOODLE_INTERNAL') || die();

/**
 * Event triggered when a user views a slides presentation.
 *
 * @property-read array $other {
 *     @type string $slidesname  The presentation name.
 * }
 */
class course_module_viewed extends \core\event\course_module_viewed {

    /**
     * Create event from cm id.
     */
    public static function create_from_cm(int $cmid, object $instance): self {
        $data = [
            'context'  => \context_module::instance($cmid),
            'objectid' => $instance->id,
            'other'    => ['slidesname' => $instance->name],
        ];
        return self::create($data);
    }

    /**
     * Get the description of the event.
     */
    protected function init(): void {
        $this->data['crud'] = 'r';
        $this->data['edulevel'] = self::LEVEL_PARTICIPATING;
        $this->data['objecttable'] = 'slides';
    }

    /**
     * Get the name of the event.
     */
    public static function get_name(): string {
        return get_string('event:moduleviewed', 'mod_slides');
    }

    /**
     * Get the description of the event.
     */
    public function get_description(): string {
        return "The user with id '{$this->userid}' viewed the slides presentation with id '{$this->objectid}'.";
    }

    /**
     * Get the URL for the event.
     */
    public function get_url(): \moodle_url {
        return new \moodle_url('/mod/slides/view.php', ['id' => $this->contextinstanceid]);
    }
}
