<?php
/**
 * Media upload helper — stores an audio/video recording or a drawing PNG
 * from the editor in the plugin's `slides_media` file area (Moodle File API)
 * and returns its pluginfile.php URL.
 *
 * MediaRecorder output (webm/ogg/mp4) and canvas exports (image/png) are
 * capped at 50 MB: the editor limits recordings to 2 minutes at 1 Mbps
 * video / 64 kbps audio (~20 MB), so the server cap only has to stop
 * oversized or forged uploads.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local;

defined('MOODLE_INTERNAL') || die();

use moodle_url;
use context_module;

class media_uploader {

    /** File area used exclusively for recorded audio/video and drawings. */
    const FILEAREA = 'slides_media';

    /** Maximum file size in bytes (50 MB — see Option A). */
    const MAX_FILESIZE = 52428800;

    /** Extensions produced by MediaRecorder, image uploads and drawings. */
    const ALLOWED_EXT = ['webm', 'mp4', 'ogg', 'oga', 'm4a', 'wav', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'];

    /**
     * Upload a recorded media file ($_FILES entry) to slides_media.
     *
     * @param int    $cmid Course module ID.
     * @param array  $file $_FILES entry: tmp_name, name, size, type, error.
     * @return array ['url' => string, 'filename' => string, 'filesize' => int]
     * @throws \moodle_exception
     */
    public static function upload(int $cmid, array $file): array {
        global $USER;

        if (empty($file['tmp_name'])) {
            throw new \moodle_exception('mediainvalidtype', 'mod_slides');
        }
        if (!empty($file['error'])) {
            throw new \moodle_exception('mediauploaderror', 'mod_slides', '', $file['error']);
        }

        // Validate the real MIME type from content (never trust the client):
        // libmagic reports audio/* or video/* for webm/ogg/mp4 containers,
        // application/ogg for raw Ogg files on older magic databases, and
        // image/png for canvas exports (drawings).
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        $okmime = (is_string($mime) && (
                strpos($mime, 'audio/') === 0 ||
                strpos($mime, 'video/') === 0 ||
                $mime === 'application/ogg' ||
                strpos($mime, 'image/') === 0
        ));
        if (!$okmime) {
            throw new \moodle_exception('mediainvalidtype', 'mod_slides');
        }

        // Validate size.
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > self::MAX_FILESIZE) {
            throw new \moodle_exception('mediafiletoolarge', 'mod_slides', '',
                self::format_size(self::MAX_FILESIZE));
        }

        // Capability check — only editors may attach recordings.
        $context = context_module::instance($cmid);
        require_capability('mod/slides:edit', $context);

        // Safe filename: original basename + timestamp + random suffix.
        $original = (string) ($file['name'] ?? 'grabacion.webm');
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        if (!in_array($ext, self::ALLOWED_EXT, true)) {
            $ext = 'webm';
        }
        $basename = clean_param(pathinfo($original, PATHINFO_FILENAME), PARAM_FILE);
        if ($basename === '') {
            $basename = 'grabacion';
        }
        $filename = $basename . '_' . time() . '_' . random_string(8) . '.' . $ext;

        // Store in the Moodle File API (plugin file area).
        $fs = get_file_storage();
        $fileRecord = [
            'contextid'   => $context->id,
            'component'   => 'mod_slides',
            'filearea'    => self::FILEAREA,
            'itemid'      => 0,
            'filepath'    => '/',
            'filename'    => $filename,
            'userid'      => $USER->id,
            'author'      => $USER->username,
            'license'     => 'allrightsreserved',
            'timecreated' => time(),
            'timemodified' => time(),
        ];

        $storedFile = $fs->create_file_from_pathname($fileRecord, $file['tmp_name']);
        if (!$storedFile) {
            throw new \moodle_exception('mediastorefailed', 'mod_slides');
        }

        $url = moodle_url::make_pluginfile_url(
            $context->id,
            'mod_slides',
            self::FILEAREA,
            0,
            '/',
            $filename
        )->out(false);

        return [
            'url'      => $url,
            'filename' => $storedFile->get_filename(),
            'filesize' => $storedFile->get_filesize(),
        ];
    }

    /**
     * Format bytes as human-readable string.
     */
    private static function format_size(int $bytes): string {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 1) . ' GB';
        }
        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 1) . ' MB';
        }
        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 1) . ' KB';
        }
        return $bytes . ' bytes';
    }
}
