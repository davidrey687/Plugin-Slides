<?php
/**
 * Builds the SCORM 1.2 imsmanifest.xml from the plugin's mustache template.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local\scorm;

defined('MOODLE_INTERNAL') || die();

class manifest_builder {

    /** Manifest schema values for SCORM 1.2. */
    public const SCHEMA = 'ADL SCORM';
    public const SCHEMAVERSION = '1.2';
    public const MANIFESTVERSION = '1.0';
    public const RESOURCETYPE = 'webcontent';
    public const ENTRYHREF = 'index.html';

    /**
     * Identifier set used by the manifest. Identifiers must be unique inside
     * the package and valid XML names (NCName-ish).
     *
     * @param int $cmid Course module id.
     * @param int|null $now Timestamp used to avoid collisions (defaults to time()).
     * @return array{manifestid:string,orgid:string,itemidentifier:string,resourceid:string}
     */
    public static function identifiers(int $cmid, ?int $now = null): array {
        $now = $now ?? time();
        $suffix = sprintf('%x_%x', $cmid, $now);

        return [
            'manifestid'     => 'MANIF_SLIDES_' . $suffix,
            'orgid'          => 'ORG_SLIDES_' . $suffix,
            'itemidentifier' => 'ITEM_SLIDES_' . $suffix,
            'resourceid'     => 'RES_SLIDES_' . $suffix,
        ];
    }

    /**
     * Normalise a list of package-relative file paths for the manifest.
     *
     * @param array $filepaths Relative paths (forward slashes, no leading slash).
     * @return array List of ['href' => string].
     */
    public static function normalise_files(array $filepaths): array {
        $files = [];

        foreach ($filepaths as $path) {
            $path = str_replace('\\', '/', (string) $path);
            $path = ltrim($path, '/');
            if ($path === '' || strpos($path, '..') !== false || strpos($path, "\0") !== false) {
                continue;
            }
            $files[] = ['href' => $path];
        }

        // The entry point must always be listed first, and listed only once.
        usort($files, static function ($a, $b) {
            if ($a['href'] === self::ENTRYHREF) {
                return -1;
            }
            if ($b['href'] === self::ENTRYHREF) {
                return 1;
            }
            return strcmp($a['href'], $b['href']);
        });

        return $files;
    }

    /**
     * Build the template context for templates/imsmanifest.xml.mustache.
     *
     * @param string $title Human readable package title.
     * @param int $cmid Course module id.
     * @param array $filepaths Package-relative paths of every file in the zip.
     * @param int|null $now Optional timestamp for identifier generation.
     * @return array
     */
    public static function build_data(string $title, int $cmid, array $filepaths, ?int $now = null): array {
        $ids = self::identifiers($cmid, $now);

        return array_merge($ids, [
            'manifestversion' => self::MANIFESTVERSION,
            'schema'          => self::SCHEMA,
            'schemaversion'   => self::SCHEMAVERSION,
            'resourcetype'    => self::RESOURCETYPE,
            'title'           => $title,
            'href'            => self::ENTRYHREF,
            'files'           => self::normalise_files($filepaths),
        ]);
    }

    /**
     * Render the manifest XML.
     *
     * @param array $data Template context from build_data().
     * @return string Trimmed XML document ending with a newline.
     */
    public static function render(array $data): string {
        global $OUTPUT;

        // The file on disk is templates/imsmanifest.xml.mustache, so the
        // template name keeps its .xml suffix.
        $xml = $OUTPUT->render_from_template('mod_slides/imsmanifest.xml', $data);

        // The XML declaration must be the very first thing in the file.
        return trim($xml) . "\n";
    }

    /**
     * Convenience wrapper: build + render.
     *
     * @param string $title
     * @param int $cmid
     * @param array $filepaths
     * @param int|null $now
     * @return string
     */
    public static function build(string $title, int $cmid, array $filepaths, ?int $now = null): string {
        return self::render(self::build_data($title, $cmid, $filepaths, $now));
    }
}
