<?php
/**
 * Moves media in and out of a SCORM package.
 *
 * While editing, media live inside the deck JSON as data: URIs (or as Moodle
 * pluginfile URLs). A SCORM package must be self contained, so on export those
 * binaries are written to assets/media/ and the deck is rewritten to relative
 * paths; on import the reverse happens.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local\scorm;

defined('MOODLE_INTERNAL') || die();

class media_packer {

    /** Directory inside the package holding every extracted binary. */
    public const MEDIADIR = 'assets/media';

    /** Refuse to inline package files bigger than this (bytes). */
    public const MAXINLINEBYTES = 268435456; // 256 MB.

    /** MIME type => file extension for data: URIs. */
    private static $MIMETYPES = [
        'image/png'       => 'png',
        'image/jpeg'      => 'jpg',
        'image/jpg'       => 'jpg',
        'image/gif'       => 'gif',
        'image/webp'      => 'webp',
        'image/svg+xml'   => 'svg',
        'image/bmp'       => 'bmp',
        'image/avif'      => 'avif',
        'image/x-icon'    => 'ico',
        'video/mp4'       => 'mp4',
        'video/webm'      => 'webm',
        'video/ogg'       => 'ogv',
        'video/quicktime' => 'mov',
        'audio/mpeg'      => 'mp3',
        'audio/wav'       => 'wav',
        'audio/ogg'       => 'oga',
        'application/pdf' => 'pdf',
    ];

    /**
     * Extract every data: URI and every pluginfile owned by this context out
     * of the deck, writing the binaries under $workdir/assets/media and
     * rewriting the deck in place to package-relative paths.
     *
     * @param array $deck Deck as returned by deck::get_deck() (objects).
     * @param string $workdir Working directory of the package being built.
     * @param \context $context Module context, used to resolve pluginfiles.
     * @return int Number of media entries extracted.
     */
    public static function rewrite_deck(array &$deck, string $workdir, \context $context): int {
        $count = 0;

        foreach ($deck as $slide) {
            foreach (($slide->elements ?? []) as $i => $el) {
                if (!is_array($el) || empty($el['src'])) {
                    continue;
                }
                $new = self::resolve_source($el['src'], $workdir, $context);
                if ($new !== null && $new !== $el['src']) {
                    $slide->elements[$i]['src'] = $new;
                    $count++;
                }
            }

            if (!is_array($slide->background)) {
                continue;
            }
            if (!empty($slide->background['image'])) {
                $new = self::resolve_source($slide->background['image'], $workdir, $context);
                if ($new !== null && $new !== $slide->background['image']) {
                    $slide->background['image'] = $new;
                    $count++;
                }
            }
        }

        return $count;
    }

    /**
     * Reverse operation: turn package-relative media paths back into data: URIs
     * so the imported deck is self contained again.
     *
     * Slides are given in save format (arrays: title / elements / background
     * array or JSON string / transition) because that is what a decoded
     * deck.json contains.
     *
     * @param array $slides Slides in save format, modified in place.
     * @param string $packageroot Directory containing imsmanifest.xml.
     * @return int Number of media entries inlined.
     */
    public static function inline_media(array &$slides, string $packageroot): int {
        $count = 0;

        foreach ($slides as $i => $slide) {
            if (!is_array($slide)) {
                continue;
            }

            foreach (($slide['elements'] ?? []) as $j => $el) {
                if (!is_array($el) || empty($el['src'])) {
                    continue;
                }
                $new = self::inline_source($el['src'], $packageroot);
                if ($new !== null && $new !== $el['src']) {
                    $slides[$i]['elements'][$j]['src'] = $new;
                    $count++;
                }
            }

            $bg = $slide['background'] ?? [];
            if (is_string($bg)) {
                $bg = json_decode($bg, true) ?? [];
            }
            if (!is_array($bg) || empty($bg['image'])) {
                continue;
            }
            $new = self::inline_source($bg['image'], $packageroot);
            if ($new !== null && $new !== $bg['image']) {
                $bg['image'] = $new;
                $slides[$i]['background'] = $bg;
                $count++;
            }
        }

        return $count;
    }

    /**
     * Resolve a single source: data: URIs and pluginfiles become relative
     * paths, everything else (http, relative, empty) is left untouched.
     *
     * @param string $src
     * @param string $workdir
     * @param \context $context
     * @return string|null New source, or null when nothing could be done.
     */
    private static function resolve_source(string $src, string $workdir, \context $context): ?string {
        if (strpos($src, 'data:') === 0) {
            return self::store_data_uri($src, $workdir);
        }
        if (stripos($src, 'pluginfile.php') !== false) {
            return self::store_pluginfile($src, $workdir, $context);
        }
        if (stripos($src, '/mod/slides/pix/') !== false || stripos($src, 'mod/slides/pix/') === 0) {
            return self::store_pix_asset($src, $workdir);
        }
        return null;
    }

    /**
     * Copy a bundled plugin asset (mod/slides/pix/... — e.g. photo bank
     * images) into the package so it stays self contained offline.
     *
     * @param string $src
     * @param string $workdir
     * @return string|null Relative path or null.
     */
    private static function store_pix_asset(string $src, string $workdir): ?string {
        global $CFG;

        $src = strtok($src, '?#');
        $pos = stripos($src, 'mod/slides/pix/');
        if ($pos === false) {
            return null;
        }

        $rel = substr($src, $pos); // mod/slides/pix/<category>/<file>
        $parts = explode('/', str_replace('\\', '/', $rel));
        foreach ($parts as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                return null;
            }
        }

        $from = $CFG->dirroot . '/' . implode('/', $parts);
        if (!is_file($from)) {
            return null;
        }

        $sub = implode('/', array_slice($parts, 3)); // <category>/<file>
        $dir = $workdir . '/' . self::MEDIADIR;
        if (!is_dir($dir) && !mkdir($dir, 0777, true) && !is_dir($dir)) {
            return null;
        }

        $target = $dir . '/' . $sub;
        $targetdir = dirname($target);
        if (!is_dir($targetdir) && !mkdir($targetdir, 0777, true) && !is_dir($targetdir)) {
            return null;
        }
        if (!file_exists($target) && !copy($from, $target)) {
            return null;
        }

        return self::MEDIADIR . '/' . $sub;
    }

    /**
     * Decode a base64 data: URI and write it to $workdir/assets/media.
     *
     * @param string $src
     * @param string $workdir
     * @return string|null Relative path or null.
     */
    private static function store_data_uri(string $src, string $workdir): ?string {
        if (!preg_match('#^data:([\w.+\-]+/[\w.+\-]+);base64,(.+)$#s', $src, $m)) {
            // Not a base64 payload: cannot be stored as a file safely.
            return null;
        }

        $mime  = strtolower($m[1]);
        $bin   = base64_decode($m[2], true);
        if ($bin === false || $bin === '') {
            return null;
        }

        $ext = self::$MIMETYPES[$mime] ?? 'bin';
        $name = sha1($bin) . '.' . $ext;

        return self::write_media($workdir, $name, $bin);
    }

    /**
     * Copy a Moodle pluginfile referenced by this module into the package.
     *
     * @param string $src
     * @param string $workdir
     * @param \context $context
     * @return string|null Relative path or null.
     */
    private static function store_pluginfile(string $src, string $workdir, \context $context): ?string {
        $pos = strpos($src, 'pluginfile.php');
        if ($pos === false) {
            return null;
        }

        $path = substr($src, $pos + strlen('pluginfile.php'));
        $path = strtok($path, '?#'); // Drop query string / fragment.
        $parts = array_values(array_filter(explode('/', $path), 'strlen'));
        // Expected: contextid / component / filearea / itemid / ...filepath / filename.
        if (count($parts) < 5) {
            return null;
        }

        $contextid = (int) array_shift($parts);
        $component  = array_shift($parts);
        $filearea   = array_shift($parts);
        $itemid     = (int) array_shift($parts);
        $filename   = array_pop($parts);

        if ($contextid !== (int) $context->id || $component !== 'mod_slides' || $filename === null) {
            return null;
        }

        $filepath = $parts ? '/' . implode('/', $parts) . '/' : '/';

        $fs = get_file_storage();
        $file = $fs->get_file($contextid, $component, $filearea, $itemid, $filepath, clean_param($filename, PARAM_FILE));
        if (!$file || $file->is_directory()) {
            return null;
        }

        $name = substr(sha1($file->get_contenthash()), 0, 12) . '_' . self::safe_name($file->get_filename());

        return self::write_media($workdir, $name, $file->get_content());
    }

    /**
     * Write a binary blob to the media directory.
     *
     * @param string $workdir
     * @param string $name Safe file name.
     * @param string $bin Binary content.
     * @return string|null Package-relative path.
     */
    private static function write_media(string $workdir, string $name, string $bin): ?string {
        $dir = $workdir . '/' . self::MEDIADIR;
        if (!is_dir($dir) && !mkdir($dir, 0777, true) && !is_dir($dir)) {
            return null;
        }

        $target = $dir . '/' . $name;
        if (!file_exists($target) && file_put_contents($target, $bin) === false) {
            return null;
        }

        return self::MEDIADIR . '/' . $name;
    }

    /**
     * Public entry point used by the generic importer to inline a package
     * relative image path (or pass through remote URLs).
     *
     * @param string $src Path as found in the HTML page.
     * @param string $packageroot Directory containing imsmanifest.xml.
     * @return string|null data: URI or null when the source must be kept as is.
     */
    public static function inline_path(string $src, string $packageroot): ?string {
        return self::inline_source($src, $packageroot);
    }

    /**
     * Turn a package-relative path into a data: URI by reading the file back.
     *
     * @param string $src
     * @param string $packageroot
     * @return string|null data: URI, or null when the file cannot be inlined.
     */
    private static function inline_source(string $src, string $packageroot): ?string {
        if (strpos($src, 'data:') === 0 || strpos($src, '://') !== false) {
            return null;
        }

        $clean = ltrim(str_replace('\\', '/', $src), '/');
        if (strpos($clean, '..') !== false) {
            return null;
        }

        $full = $packageroot . '/' . $clean;
        if (!is_file($full) || filesize($full) > self::MAXINLINEBYTES) {
            return null;
        }

        $bin = file_get_contents($full);
        if ($bin === false) {
            return null;
        }

        $mime = self::mime_for_name($clean);

        return 'data:' . $mime . ';base64,' . base64_encode($bin);
    }

    /**
     * Guess a MIME type from a file name.
     *
     * @param string $name
     * @return string
     */
    public static function mime_for_name(string $name): string {
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $map = array_flip(self::$MIMETYPES);
        if (isset($map[$ext])) {
            return $map[$ext];
        }

        $extra = [
            'jpg' => 'image/jpeg', 'jpe' => 'image/jpeg', 'avif' => 'image/avif',
            'ico' => 'image/x-icon', 'bmp' => 'image/bmp', 'svg' => 'image/svg+xml',
            'webm' => 'video/webm', 'ogv' => 'video/ogg', 'mov' => 'video/quicktime',
            'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'oga' => 'audio/ogg',
            'woff2' => 'font/woff2', 'woff' => 'font/woff', 'ttf' => 'font/ttf',
            'pdf' => 'application/pdf', 'json' => 'application/json',
            'js' => 'text/javascript', 'css' => 'text/css', 'html' => 'text/html',
            'htm' => 'text/html', 'txt' => 'text/plain',
        ];

        return $extra[$ext] ?? 'application/octet-stream';
    }

    /**
     * Sanitise a file name for use inside the package.
     *
     * @param string $name
     * @return string
     */
    private static function safe_name(string $name): string {
        $name = preg_replace('/[^A-Za-z0-9._\-]/', '_', basename($name));
        if ($name === '' || $name === '.' || $name === '..') {
            $name = 'file.bin';
        }
        return substr($name, -100);
    }
}
