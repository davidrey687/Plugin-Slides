<?php
/**
 * Builds a SCORM 1.2 package out of a slides presentation.
 *
 * Everything is produced inside a plugin-owned temporary directory and packed
 * with Moodle's zip_packer; nothing outside mod_slides is touched.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local\scorm;

use mod_slides\local\deck;
use mod_slides\local\slide_renderer;

defined('MOODLE_INTERNAL') || die();

class exporter {

    /** Temp directory prefix (relative to $CFG->tempdir). */
    public const WORKPREFIX = 'mod_slides/scorm_export_';

    /**
     * Generate the .zip for a presentation.
     *
     * @param object $instance Row of the 'slides' table.
     * @param object $cm Course module.
     * @param \context|null $context Module context (defaults to $cm->id).
     * @return array{zip:string,filename:string,media:int,files:int}
     * @throws \moodle_exception When the deck is empty or the zip fails.
     */
    public static function run(object $instance, object $cm, ?\context $context = null): array {
        global $OUTPUT;

        $deck = deck::get_deck((int) $instance->id);
        if (empty($deck)) {
            throw new \moodle_exception('nothingtoexport', 'mod_slides');
        }

        $context = $context ?: \context_module::instance($cm->id);
        $workdir = make_temp_directory(self::WORKPREFIX . uniqid('', true));

        try {
            // 1. Pull media out of the deck so the package is self contained.
            $mediacount = media_packer::rewrite_deck($deck, $workdir, $context);

            // 2. Render the slides to static HTML using the very same
            //    template the Moodle page uses.
            [$canvasw, $canvash] = deck::canvas_dimensions($instance->aspectratio);
            $slidecount = count($deck);
            $deckjson = slide_renderer::viewer_json($deck);

            $viewerhtml = $OUTPUT->render_from_template('mod_slides/viewer', [
                'cmid'         => $cm->id,
                'slidecount'   => $slidecount,
                'aspectratio'  => $instance->aspectratio,
                'aspectwidth'  => $canvasw,
                'canvasheight' => $canvash,
                'initialslide' => 1,
                'iseditor'     => false,
                'empty'        => false,
                'seedurl'      => '',
                'sesskey'      => '',
                'slides'       => slide_renderer::template_slides($deck),
                'slidesjson'   => $deckjson,
                'pageheading'  => $instance->name,
                'intro'        => '',
                'progressbar'  => slide_renderer::progressbar($slidecount),
                'scorm'        => true,
            ]);

            $indexhtml = $OUTPUT->render_from_template('mod_slides/scorm_player', [
                'title'      => $instance->name,
                'lang'       => current_language(),
                'viewerhtml' => $viewerhtml,
            ]);

            // 3. Write the package tree.
            self::write_file($workdir, 'index.html', $indexhtml);
            self::write_file($workdir, 'assets/deck.json',
                json_encode(slide_renderer::viewer_slides($deck),
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

            self::copy_assets($workdir);

            // 4. Manifest listing every file in the package.
            $paths = self::relative_paths($workdir);
            $manifest = manifest_builder::build($instance->name, (int) $cm->id, $paths);
            self::write_file($workdir, 'imsmanifest.xml', $manifest);
            $paths = self::relative_paths($workdir);

            // 5. Zip it.
            $filename = self::package_filename($instance, $cm);
            $zippath  = make_temp_directory('mod_slides/scorm_zip') . '/' . uniqid('scorm_', true) . '_' . $filename;

            $files = [];
            foreach ($paths as $rel) {
                $files[$rel] = $workdir . '/' . $rel;
            }

            $packer = get_file_packer('application/zip');
            if (!$packer->archive_to_pathname($files, $zippath, false)) {
                throw new \moodle_exception('errorcreatingzip', 'mod_slides');
            }

            $result = [
                'zip'     => $zippath,
                'filename' => $filename,
                'media'   => $mediacount,
                'files'   => count($files),
            ];
        } finally {
            remove_dir($workdir);
        }

        return $result;
    }

    /**
     * Copy the plugin's player runtime, styles and fonts into the package.
     *
     * @param string $workdir
     * @return void
     */
    private static function copy_assets(string $workdir): void {
        global $CFG;

        $plugindir = $CFG->dirroot . '/mod/slides';

        $map = [
            'scorm/APIWrapper.js' => 'assets/APIWrapper.js',
            'scorm/player.js'     => 'assets/player.js',
            'scorm/player.css'    => 'assets/player.css',
            'styles.css'          => 'assets/styles.css',
        ];

        foreach ($map as $from => $to) {
            $src = $plugindir . '/' . $from;
            if (is_file($src)) {
                self::write_file($workdir, $to, (string) file_get_contents($src));
            }
        }

        // Fonts: fonts.css references the woff2 files by relative name, so they
        // must keep living side by side inside the package.
        $fonts = glob($plugindir . '/fonts/*');
        foreach (($fonts ?: []) as $src) {
            if (!is_file($src)) {
                continue;
            }
            self::write_file($workdir, 'fonts/' . basename($src), (string) file_get_contents($src));
        }

        // KaTeX: the package must be self contained, including the katex fonts
        // referenced relatively by katex.min.css.
        $katexdir = $plugindir . '/vendor/katex';
        $katexfiles = [
            $katexdir . '/katex.min.js'   => 'vendor/katex/katex.min.js',
            $katexdir . '/katex.min.css'  => 'vendor/katex/katex.min.css',
            $katexdir . '/LICENSE'        => 'vendor/katex/LICENSE',
        ];
        foreach ($katexfiles as $src => $to) {
            if (is_file($src)) {
                self::write_file($workdir, $to, (string) file_get_contents($src));
            }
        }
        foreach ((glob($katexdir . '/fonts/*') ?: []) as $src) {
            if (!is_file($src)) {
                continue;
            }
            self::write_file($workdir, 'vendor/katex/fonts/' . basename($src), (string) file_get_contents($src));
        }
    }

    /**
     * Write a file inside the working directory, creating parent folders.
     *
     * @param string $workdir
     * @param string $relpath Package-relative path.
     * @param string $content
     * @return void
     */
    private static function write_file(string $workdir, string $relpath, string $content): void {
        $target = $workdir . '/' . ltrim($relpath, '/');
        $dir = dirname($target);
        if (!is_dir($dir) && !mkdir($dir, 0777, true) && !is_dir($dir)) {
            throw new \moodle_exception('errorcreatingzip', 'mod_slides');
        }
        if (file_put_contents($target, $content) === false) {
            throw new \moodle_exception('errorcreatingzip', 'mod_slides');
        }
    }

    /**
     * List every file below $root as a package-relative path.
     *
     * @param string $root
     * @return array
     */
    private static function relative_paths(string $root): array {
        $paths = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }
            $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
            if (strpos($rel, '..') === false) {
                $paths[] = $rel;
            }
        }
        sort($paths);
        return $paths;
    }

    /**
     * Build a safe download file name for the package.
     *
     * @param object $instance
     * @param object $cm
     * @return string
     */
    public static function package_filename(object $instance, object $cm): string {
        $name = strtolower((string) ($instance->name ?? ''));
        $name = preg_replace('/[^a-z0-9\-_]+/', '-', $name);
        $name = trim($name, '-');
        $name = substr($name, 0, 40);

        return 'slides-' . ($name ?: 'package') . '-' . (int) $cm->id . '-' . date('Ymd-His') . '.zip';
    }
}
