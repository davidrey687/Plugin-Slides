<?php
/**
 * Reads a SCORM 1.2 package back into a slides deck.
 *
 * Two routes are supported:
 *   - native: the package was exported by mod_slides and carries assets/deck.json,
 *             so the original design is restored with full fidelity;
 *   - generic: any other SCORM package, whose imsmanifest items are converted
 *             into plain text/image slides (best effort).
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local\scorm;

use mod_slides\local\deck;
use mod_slides\local\deck_sanitizer;

defined('MOODLE_INTERNAL') || die();

class importer {

    /** Extensions accepted inside an uploaded package. */
    public const ALLOWED_EXTENSIONS = [
        'html', 'htm', 'js', 'css', 'json', 'xml', 'txt', 'md',
        'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico', 'bmp', 'avif',
        'mp4', 'webm', 'ogv', 'ogg', 'mp3', 'wav', 'oga', 'm4a',
        'woff', 'woff2', 'ttf', 'otf', 'eot', 'pdf',
    ];

    public const MAXFILES = 5000;
    public const MAXTOTALBYTES = 1073741824; // 1 GB uncompressed.
    public const MAXSLIDES = 300;

    /** Where our own exporter stores the deck inside the package. */
    private const DECKCANDIDATES = ['assets/deck.json', 'deck.json', 'content/deck.json'];

    /**
     * Import a package into a presentation, replacing its slides.
     *
     * @param \stored_file $file Uploaded .zip.
     * @param object $instance Row of the 'slides' table.
     * @return array{slides:int,format:string} Number of slides and route used.
     * @throws \moodle_exception On any validation or parsing failure.
     */
    public static function import(\stored_file $file, object $instance): array {
        $packer = get_file_packer('application/zip');
        $tmpdir = make_temp_directory('mod_slides/scorm_import_' . uniqid('', true));

        try {
            self::assert_archive_is_safe($file, $packer);

            if ($packer->extract_to_pathname($file, $tmpdir) === false) {
                throw new \moodle_exception('invalidpackage', 'mod_slides');
            }

            $manifestpath = self::find_manifest($tmpdir);
            if ($manifestpath === null) {
                throw new \moodle_exception('invalidmanifest', 'mod_slides');
            }

            $manifest = self::load_manifest($manifestpath);
            $root = dirname($manifestpath);

            $deckpath = self::find_deck_json($root);
            if ($deckpath !== null) {
                $slides = self::slides_from_deck($deckpath, $root);
                $format = 'native';
            } else {
                $slides = self::slides_from_manifest($manifest, $root);
                $format = 'generic';
            }

            if (empty($slides)) {
                throw new \moodle_exception('importempty', 'mod_slides');
            }

            $slides = array_slice($slides, 0, self::MAXSLIDES);
            media_packer::inline_media($slides, $root);

            deck::replace_deck((int) $instance->id, deck_sanitizer::sanitize_slides($slides));

            return ['slides' => count($slides), 'format' => $format];

        } finally {
            remove_dir($tmpdir);
        }
    }

    /* ------------------------------------------------------------------ *
     *  Archive validation / extraction
     * ------------------------------------------------------------------ */

    /**
     * Reject archives that are too big, hold too many files, carry dangerous
     * paths (zip slip) or unexpected file types.
     *
     * @param \stored_file $file
     * @param \file_packer $packer
     * @return void
     */
    private static function assert_archive_is_safe(\stored_file $file, \file_packer $packer): void {
        $entries = $file->list_files($packer);
        if (!is_array($entries) || empty($entries)) {
            throw new \moodle_exception('invalidpackage', 'mod_slides');
        }
        if (count($entries) > self::MAXFILES) {
            throw new \moodle_exception('packagetoolarge', 'mod_slides');
        }

        $total = 0;
        foreach ($entries as $entry) {
            $path = is_object($entry) ? (string) ($entry->pathname ?? '') : (string) $entry;
            $path = str_replace('\\', '/', $path);

            if ($path === '' || $path[0] === '/' || strpos($path, "\0") !== false
                    || strpos($path, '..') !== false || preg_match('#^[a-zA-Z]:#', $path)) {
                throw new \moodle_exception('unsafearchive', 'mod_slides');
            }

            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if ($ext !== '' && !in_array($ext, self::ALLOWED_EXTENSIONS, true)) {
                throw new \moodle_exception('forbiddenfiletype', 'mod_slides', '', $ext);
            }

            $total += is_object($entry) ? (int) ($entry->size ?? 0) : 0;
            if ($total > self::MAXTOTALBYTES) {
                throw new \moodle_exception('packagetoolarge', 'mod_slides');
            }
        }
    }

    /**
     * Locate imsmanifest.xml (root first, then the shallowest copy).
     *
     * @param string $dir
     * @return string|null Absolute path.
     */
    private static function find_manifest(string $dir): ?string {
        $found = null;
        $depth = PHP_INT_MAX;

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile() || strtolower($file->getFilename()) !== 'imsmanifest.xml') {
                continue;
            }
            $path = $file->getPathname();
            $d = substr_count(str_replace('\\', '/', substr($path, strlen($dir))), '/');
            if ($found === null || $d < $depth) {
                $found = $path;
                $depth = $d;
            }
        }

        return $found;
    }

    /**
     * Parse imsmanifest.xml defensively (no DTD, no network, no entities).
     *
     * @param string $path
     * @return \SimpleXMLElement
     */
    private static function load_manifest(string $path): \SimpleXMLElement {
        $content = @file_get_contents($path);
        if ($content === false || trim($content) === '') {
            throw new \moodle_exception('invalidmanifest', 'mod_slides');
        }
        if (stripos($content, '<!DOCTYPE') !== false || stripos($content, '<!ENTITY') !== false) {
            throw new \moodle_exception('invalidmanifest', 'mod_slides');
        }

        $previous = libxml_use_internal_errors(true);
        $xml = simplexml_load_string($content, '\SimpleXMLElement', LIBXML_NONET);
        $errors = libxml_get_errors();
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        if ($xml === false) {
            $detail = '';
            if (!empty($errors)) {
                $detail = trim($errors[0]->message);
            }
            throw new \moodle_exception('invalidmanifest', 'mod_slides', '', $detail);
        }

        return $xml;
    }

    /* ------------------------------------------------------------------ *
     *  Native route (packages generated by mod_slides)
     * ------------------------------------------------------------------ */

    /**
     * Find the embedded deck.json of our own exporter.
     *
     * @param string $root Package root (directory of the manifest).
     * @return string|null
     */
    private static function find_deck_json(string $root): ?string {
        foreach (self::DECKCANDIDATES as $rel) {
            $path = $root . '/' . $rel;
            if (is_file($path)) {
                return $path;
            }
        }
        return null;
    }

    /**
     * Decode deck.json into slides in save format.
     *
     * @param string $path
     * @param string $root
     * @return array
     */
    private static function slides_from_deck(string $path, string $root): array {
        $raw = @file_get_contents($path);
        $data = $raw === false ? null : json_decode($raw, true);
        if (!is_array($data)) {
            throw new \moodle_exception('importfailed', 'mod_slides');
        }

        $slides = [];
        foreach ($data as $slide) {
            if (!is_array($slide)) {
                continue;
            }
            $slides[] = [
                'title'      => (string) ($slide['title'] ?? ''),
                'sortorder'  => count($slides),
                'elements'   => is_array($slide['elements'] ?? null) ? $slide['elements'] : [],
                'background' => is_array($slide['background'] ?? null)
                    ? $slide['background'] : ['color' => '#ffffff'],
                'transition' => (string) ($slide['transition'] ?? 'none'),
            ];
        }

        return $slides;
    }

    /* ------------------------------------------------------------------ *
     *  Generic route (any SCORM package)
     * ------------------------------------------------------------------ */

    /**
     * Convert the manifest's organisations into text/image slides.
     *
     * @param \SimpleXMLElement $manifest
     * @param string $root
     * @return array
     */
    private static function slides_from_manifest(\SimpleXMLElement $manifest, string $root): array {
        $resources = [];
        if (isset($manifest->resources->resource)) {
            foreach ($manifest->resources->resource as $res) {
                $id = trim((string) $res['identifier']);
                if ($id !== '') {
                    $resources[$id] = trim((string) $res['href']);
                }
            }
        }

        $items = [];
        if (isset($manifest->organizations->organization)) {
            foreach ($manifest->organizations->organization as $org) {
                self::collect_items($org, $resources, $items);
            }
        }

        $slides = [];
        foreach ($items as $item) {
            $sub = self::item_to_slides($item['title'], $item['href'], $root);
            foreach ($sub as $slide) {
                $slides[] = $slide;
                if (count($slides) >= self::MAXSLIDES) {
                    return $slides;
                }
            }
        }

        return $slides;
    }

    /**
     * Walk an organisation (or nested item) collecting leaf activities.
     *
     * @param \SimpleXMLElement $node Organization or item element.
     * @param array $resources identifier => href.
     * @param array $items Collected items (by reference).
     * @return void
     */
    private static function collect_items(\SimpleXMLElement $node, array $resources, array &$items): void {
        if (!isset($node->item)) {
            return;
        }

        foreach ($node->item as $item) {
            $title = trim((string) $item->title);
            $ref = trim((string) ($item['identifierref'] ?? ''));
            $href = $resources[$ref] ?? ($ref !== '' && strpos($ref, '.') !== false ? $ref : '');

            if (isset($item->item)) {
                // Parent activity: keep it as a section marker only when it has
                // no launchable content of its own.
                if ($href === '') {
                    self::collect_items($item, $resources, $items);
                    continue;
                }
            }

            $items[] = ['title' => $title, 'href' => $href];
            if (isset($item->item)) {
                self::collect_items($item, $resources, $items);
            }
        }
    }

    /**
     * Turn one SCO (usually one HTML page) into one or more slides.
     *
     * @param string $itemtitle Title coming from the manifest.
     * @param string $href Resource href inside the package.
     * @param string $root Package root.
     * @return array Slides in save format.
     */
    private static function item_to_slides(string $itemtitle, string $href, string $root): array {
        $file = self::resolve_href($href, $root);

        if ($file === null) {
            // No readable content: keep a title-only slide so the structure
            // of the course is not lost.
            if ($itemtitle === '') {
                return [];
            }
            return [self::make_title_slide($itemtitle)];
        }

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($ext, ['html', 'htm'], true)) {
            if ($itemtitle === '') {
                return [];
            }
            return [self::make_title_slide($itemtitle)];
        }

        $sections = self::parse_html(file_get_contents($file), $root);
        if (empty($sections)) {
            return $itemtitle === '' ? [] : [self::make_title_slide($itemtitle)];
        }

        if ($sections[0]['title'] === '' && $itemtitle !== '') {
            $sections[0]['title'] = $itemtitle;
        }

        return self::layout_sections($sections, $itemtitle);
    }

    /**
     * Resolve a manifest href to an existing file inside the package.
     *
     * @param string $href
     * @param string $root
     * @return string|null Absolute path.
     */
    private static function resolve_href(string $href, string $root): ?string {
        $href = explode('#', $href)[0];
        $href = explode('?', $href)[0];
        $href = rawurldecode($href);
        $href = ltrim(str_replace('\\', '/', $href), '/');

        if ($href === '' || strpos($href, '..') !== false) {
            return null;
        }

        $path = $root . '/' . $href;
        return is_file($path) ? $path : null;
    }

    /**
     * Extract headings, paragraphs, list items and images from an HTML page.
     *
     * @param string $html
     * @param string $root Package root, used to inline local images.
     * @return array List of ['title' => string, 'blocks' => array].
     */
    private static function parse_html(string $html, string $root): array {
        if (trim($html) === '') {
            return [];
        }

        $previous = libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        $flags = LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING;
        // loadHTML needs a declared encoding to cope with UTF-8 pages.
        $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, $flags);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        $xpath = new \DOMXPath($dom);
        $nodes = $xpath->query('//body//h1|//body//h2|//body//h3|//body//h4|//body//h5|//body//h6'
            . '|//body//p|//body//li|//body//pre|//body//blockquote|//body//img');
        if ($nodes === false) {
            return [];
        }

        $sections = [];
        $current = ['title' => '', 'blocks' => []];

        foreach ($nodes as $node) {
            $tag = strtolower($node->nodeName);

            if ($tag === 'img') {
                $src = trim($node->getAttribute('src'));
                if ($src !== '') {
                    $inline = media_packer::inline_path($src, $root);
                    $current['blocks'][] = ['type' => 'image', 'src' => $inline ?? $src,
                        'alt' => trim($node->getAttribute('alt'))];
                }
                continue;
            }

            // Skip a block nested inside another selected block (e.g. <p> inside <li>).
            if (self::has_selected_ancestor($node)) {
                continue;
            }

            $text = self::clean_text($node->textContent);
            if ($tag === 'li') {
                $text = '• ' . $text;
            }
            if ($text === '') {
                continue;
            }

            if (strpos($tag, 'h') === 0) {
                if ($current['title'] !== '' || !empty($current['blocks'])) {
                    $sections[] = $current;
                }
                $current = ['title' => $text, 'blocks' => []];
            } else {
                $current['blocks'][] = ['type' => 'text', 'text' => $text];
            }
        }

        if ($current['title'] !== '' || !empty($current['blocks'])) {
            $sections[] = $current;
        }

        return $sections;
    }

    /**
     * @param \DOMNode $node
     * @return bool True when an ancestor is also a block we already selected.
     */
    private static function has_selected_ancestor(\DOMNode $node): bool {
        $tags = ['p' => true, 'li' => true, 'pre' => true, 'blockquote' => true];
        $parent = $node->parentNode;
        $guard = 0;
        while ($parent !== null && $guard++ < 25) {
            if ($parent->nodeName !== null && isset($tags[strtolower($parent->nodeName)])) {
                return true;
            }
            $parent = $parent->parentNode;
        }
        return false;
    }

    /**
     * Collapse whitespace of a text fragment.
     *
     * @param string $text
     * @return string
     */
    private static function clean_text(string $text): string {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim((string) $text);
    }

    /**
     * A slide holding only a title (used when a package has no readable page).
     *
     * @param string $title
     * @return array
     */
    private static function make_title_slide(string $title): array {
        return [
            'title'      => $title,
            'sortorder'  => 0,
            'elements'   => [[
                'type' => 'text', 'x' => 80, 'y' => 200, 'w' => 800, 'h' => 120,
                'text' => $title, 'fontSize' => 44, 'color' => '#1a1a2e',
                'align' => 'center', 'bold' => true,
            ]],
            'background' => ['color' => '#ffffff'],
            'transition' => 'none',
        ];
    }

    /**
     * Stack the extracted blocks onto 960x540 canvases, opening a new slide
     * whenever the current one would overflow.
     *
     * @param array $sections
     * @param string $packageTitle Fallback title.
     * @return array Slides in save format.
     */
    private static function layout_sections(array $sections, string $packageTitle): array {
        $slides = [];
        $state = self::open_slide($slides);

        foreach ($sections as $section) {
            $title = (string) $section['title'];

            if ($title !== '') {
                if ($state['y'] > 60 && $state['y'] + 80 > 500) {
                    $state = self::open_slide($slides);
                }
                if ($slides[$state['idx']]['title'] === '') {
                    $slides[$state['idx']]['title'] = $title;
                }
                $slides[$state['idx']]['elements'][] = [
                    'type' => 'text', 'x' => 60, 'y' => $state['y'], 'w' => 840, 'h' => 60,
                    'text' => $title, 'fontSize' => 34, 'color' => '#1a1a2e',
                    'align' => 'left', 'bold' => true,
                ];
                $state['y'] += 75;
            }

            foreach ($section['blocks'] as $block) {
                if ($block['type'] === 'image') {
                    if ($state['y'] + 200 > 510) {
                        $state = self::open_slide($slides);
                    }
                    $slides[$state['idx']]['elements'][] = [
                        'type' => 'image', 'x' => 60, 'y' => $state['y'], 'w' => 840, 'h' => 200,
                        'src' => $block['src'], 'alt' => $block['alt'] ?? '',
                        'opacity' => 100, 'borderRadius' => 4,
                    ];
                    $state['y'] += 216;
                    continue;
                }

                $text = (string) $block['text'];
                $lines = max(1, (int) ceil(strlen($text) / 95));
                $height = min(430, $lines * 32 + 10);

                if ($state['y'] + $height > 510) {
                    $state = self::open_slide($slides);
                }

                $slides[$state['idx']]['elements'][] = [
                    'type' => 'text', 'x' => 60, 'y' => $state['y'], 'w' => 840, 'h' => $height,
                    'text' => $text, 'fontSize' => 24, 'color' => '#333333',
                    'align' => 'left', 'bold' => false,
                ];
                $state['y'] += $height + 16;
            }

            $state['y'] += 24;
        }

        // Drop the leading placeholder when it collected nothing.
        if (count($slides) > 1 && empty($slides[0]['elements'])) {
            array_shift($slides);
        }
        if (empty($slides)) {
            $slides[] = self::make_title_slide($packageTitle !== '' ? $packageTitle
                : get_string('slide1', 'mod_slides'));
        }

        foreach ($slides as $i => $slide) {
            $slides[$i]['sortorder'] = $i;
            if ($slide['title'] === '') {
                $slides[$i]['title'] = get_string('slide1', 'mod_slides') . ' ' . ($i + 1);
            }
        }

        return $slides;
    }

    /**
     * Append an empty slide and return the cursor for it.
     *
     * @param array $slides Collected slides (by reference).
     * @return array{idx:int,y:int}
     */
    private static function open_slide(array &$slides): array {
        $slides[] = [
            'title'      => '',
            'sortorder'  => count($slides),
            'elements'   => [],
            'background' => ['color' => '#ffffff'],
            'transition' => 'none',
        ];

        return ['idx' => count($slides) - 1, 'y' => 60];
    }
}
