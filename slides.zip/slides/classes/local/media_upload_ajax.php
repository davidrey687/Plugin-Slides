<?php
/**
 * AJAX endpoint for uploading an audio/video recording from the editor.
 *
 * Expects a multipart/form-data POST built with FormData:
 *   cmid (int), sesskey (string), media (file).
 *
 * Always answers with a single clean JSON object — any incidental PHP
 * notice/warning is discarded from the output buffer before the payload.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// Buffer everything from the very start so stray notices never pollute
// the JSON response (flushed clean by slides_media_json()).
ob_start();

require_once(__DIR__ . '/../../../../config.php');
require_once($CFG->dirroot . '/mod/slides/classes/local/media_uploader.php');

use mod_slides\local\media_uploader;

header('Content-Type: application/json; charset=utf-8');

function slides_media_json(array $payload): void {
    if (ob_get_level() > 0) {
        ob_clean();
    }
    echo json_encode($payload);
    die;
}

$cmid = optional_param('cmid', 0, PARAM_INT);
$sesskey = optional_param('sesskey', '', PARAM_RAW);

if ($cmid <= 0 || $sesskey === '' || !confirm_sesskey($sesskey)) {
    slides_media_json(['error' => get_string('invalidsesskey', 'error')]);
}

if (empty($_FILES['media'])) {
    slides_media_json(['error' => get_string('mediainvalidtype', 'mod_slides')]);
}

try {
    $context = context_module::instance($cmid);
    if (!has_capability('mod/slides:edit', $context)) {
        slides_media_json(['error' => get_string('nopermissions', 'error')]);
    }

    // Auth done: release the session lock so heartbeats and other requests
    // from this user are not blocked while the file is being stored.
    session_write_close();

    $result = media_uploader::upload($cmid, $_FILES['media']);
    slides_media_json($result);
} catch (\moodle_exception $e) {
    slides_media_json(['error' => $e->getMessage()]);
} catch (\Throwable $e) {
    error_log('mod_slides media_upload_ajax: ' . $e->getMessage());
    slides_media_json(['error' => get_string('mediauploaderror', 'mod_slides')]);
}
