<?php
/**
 * Shape CSS helper for mod_slides.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Provides CSS clip-path recipes for shapes used in slide rendering.
 */
class shapes {

    /**
     * Allowed video URL patterns (whitelist).
     *
     * @var array Array of regex patterns for allowed video embed sources.
     */
    private static $VIDEO_WHITELIST = [
        '/^https?:\/\/(www\.)?youtube\.com\//',
        '/^https?:\/\/youtu\.be\//',
        '/^https?:\/\/(www\.)?vimeo\.com\//',
        '/^https?:\/\/(www\.)?dailymotion\.com\//',
        '/^https?:\/\/player\.dailymotion\.com\//',
        '/^https?:\/\/(www\.)?tiktok\.com\//',
        '/^https?:\/\/(www\.)?facebook\.com\/.*\/videos\//',
        '/^https?:\/\/(www\.)?facebook\.com\/.*\/reel\//',
        '/^https?:\/\/(www\.)?instagram\.com\/.*\/reel\//',
        '/^https?:\/\/(www\.)?instagram\.com\/.*\/p\//',
        '/^https?:\/\/(www\.)?twitter\.com\//',
        '/^https?:\/\/(www\.)?x\.com\//',
        '/^\//',
    ];

    /**
     * Validate whether a video URL is from an allowed source.
     *
     * @param string $url The video URL to validate.
     * @return bool True if the URL is allowed.
     */
    public static function is_video_url_allowed(string $url): bool {
        if (empty(trim($url))) {
            return false;
        }

        // Allow relative paths (Moodle files).
        foreach (self::$VIDEO_WHITELIST as $pattern) {
            if (preg_match($pattern, $url)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Sanitize a video URL, returning empty string if not allowed.
     *
     * @param string $url The video URL to sanitize.
     * @return string The sanitized URL or empty string.
     */
    public static function sanitize_video_url(string $url): string {
        $url = trim($url);

        if (empty($url)) {
            return '';
        }

        return self::is_video_url_allowed($url) ? $url : '';
    }

    /**
     * Generate CSS clip-path recipe for a given shape.
     *
     * @param string $shape Shape key.
     * @param int    $sw    Stroke width.
     * @param string $stroke Stroke color.
     * @param string $fill  Fill colour (used by dotted symbols such as ÷).
     * @return string CSS rules string.
     */
    public static function shape_clip(string $shape, int $sw, string $stroke, string $fill = '#0d6efd'): string {
        if ($shape === 'line') {
            $barh = max(2, $sw);
            return 'width:100%;height:' . $barh . 'px;position:absolute;top:calc(50% - ' . ($barh / 2) . 'px);' .
                   'background:' . $stroke . ';border-radius:' . ($barh / 2) . 'px;';
        }

        $recipes = [
            'rect'         => '',
            'roundedrect'  => 'border-radius:18px;',
            'circle'       => 'border-radius:50%;',
            'ellipse'      => 'border-radius:50%;',
            'triangle'     => 'clip-path:polygon(50% 0,100% 100%,0 100%);',
            'triangledown' => 'clip-path:polygon(50% 100%,100% 0,0 0);',
            'diamond'      => 'clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);',
            'pentagon'     => 'clip-path:polygon(50% 0,100% 38%,82% 100%,18% 100%,0 38%);',
            'hexagon'      => 'clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);',
            'octagon'      => 'clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);',
            'cross'        => 'clip-path:polygon(35% 0,65% 0,65% 35%,100% 35%,100% 65%,65% 65%,65% 100%,35% 100%,35% 65%,0 65%,0 35%,35% 35%);',
            'heart'        => 'clip-path:polygon(50% 92%,42% 78%,25% 62%,12% 48%,6% 34%,8% 20%,20% 9%,33% 8%,44% 15%,50% 25%,56% 15%,67% 8%,80% 9%,92% 20%,94% 34%,88% 48%,75% 62%,58% 78%);',
            'cloud'        => 'clip-path:polygon(22% 78%,12% 74%,5% 62%,6% 48%,14% 37%,26% 31%,33% 20%,46% 14%,58% 18%,67% 13%,78% 19%,87% 29%,94% 42%,93% 56%,88% 68%,78% 76%,60% 78%,40% 78%);',
            'parallelogram'=> 'clip-path:polygon(25% 0,100% 0,75% 100%,0 100%);',
            'trapezoid'    => 'clip-path:polygon(20% 0,80% 0,100% 100%,0 100%);',
            'speechbubble' => 'clip-path:polygon(0 0,100% 0,100% 70%,70% 70%,50% 100%,50% 70%,0 70%);',
            'star4'        => 'clip-path:polygon(50% 0,65% 35%,100% 35%,75% 57%,85% 91%,50% 72%,15% 91%,25% 57%,0 35%,35% 35%);',
            'star5'        => 'clip-path:polygon(50% 0,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%);',
            'star6'        => 'clip-path:polygon(50% 0,63% 25%,100% 25%,75% 50%,88% 81%,50% 63%,12% 81%,25% 50%,0 25%,37% 25%);',
            'star8'        => 'clip-path:polygon(50% 0,60% 20%,80% 5%,75% 28%,100% 25%,80% 42%,95% 60%,72% 58%,80% 80%,55% 65%,50% 90%,45% 65%,20% 80%,28% 58%,5% 60%,20% 42%,0% 25%,25% 28%,20% 5%,40% 20%);',
            'star12'       => 'clip-path:polygon(50% 0,61% 15%,78% 6%,79% 25%,98% 25%,88% 41%,100% 50%,88% 59%,98% 75%,79% 75%,78% 94%,61% 85%,50% 100%,39% 85%,22% 94%,21% 75%,2% 75%,12% 59%,0 50%,12% 41%,2% 25%,21% 25%,22% 6%,39% 15%);',
            'arrowright'   => 'clip-path:polygon(0 30%,60% 30%,60% 0,100% 50%,60% 100%,60% 70%,0 70%);',
            'arrowleft'    => 'clip-path:polygon(100% 30%,40% 30%,40% 0,0 50%,40% 100%,40% 70%,100% 70%);',
            'arrowup'      => 'clip-path:polygon(30% 100%,30% 40%,0 40%,50% 0,100% 40%,70% 40%,70% 100%);',
            'arrowdown'    => 'clip-path:polygon(30% 0,30% 60%,0 60%,50% 100%,100% 60%,70% 60%,70% 0);',
            'arrowrightwide'=> 'clip-path:polygon(0 20%,60% 20%,60% 0,100% 50%,60% 100%,60% 80%,0 80%);',
            // Equation silhouettes.
            'eqplus'       => 'clip-path:polygon(35% 0,65% 0,65% 35%,100% 35%,100% 65%,65% 65%,65% 100%,35% 100%,35% 65%,0 65%,0 35%,35% 35%);',
            'eqminus'      => 'clip-path:polygon(0 35%,100% 35%,100% 65%,0 65%);',
            'eqmultiply'   => 'clip-path:polygon(20% 0,50% 30%,80% 0,100% 20%,70% 50%,100% 80%,80% 100%,50% 70%,20% 100%,0 80%,30% 50%,0 20%);',
            'eqdivide'     => 'clip-path:polygon(0 0,100% 0,100% 100%,0 100%);',
            'eqequals'     => 'clip-path:polygon(0 20%,100% 20%,100% 40%,0 40%,0 60%,100% 60%,100% 80%,0 80%);',
            // Flowchart.
            'flowprocess'  => '',
            'flowdecision' => 'clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);',
            'flowterminator'=> 'border-radius:999px;',
            // Stars and extras.
            'bolt'         => 'clip-path:polygon(55% 0,18% 55%,44% 55%,40% 100%,82% 40%,52% 40%);',
            'shield'       => 'clip-path:polygon(50% 0,100% 16%,100% 55%,50% 100%,0 55%,0 16%);',
            'droplet'      => 'clip-path:polygon(50% 0,90% 42%,88% 70%,50% 100%,12% 70%,10% 42%);',
            'ribbon'       => 'clip-path:polygon(0 0,100% 0,100% 100%,50% 72%,0 100%);',
            'pennant'      => 'clip-path:polygon(0 0,100% 0,72% 50%,100% 100%,0 100%);',
            'hourglass'    => 'clip-path:polygon(0 0,100% 0,56% 50%,100% 100%,0 100%,44% 50%);',
            'flower'       => 'clip-path:polygon(50% 0,65% 20%,90% 12%,80% 38%,100% 50%,80% 62%,90% 88%,65% 80%,50% 100%,35% 80%,10% 88%,20% 62%,0 50%,20% 38%,10% 12%,35% 20%);',
        ];

        $css = $recipes[$shape] ?? '';
        if ($shape === 'eqdivide') {
            // ÷ drawn from background layers (bar + two dots) in the fill colour.
            $css .= 'background-color:transparent;' .
                'background-image:' .
                'radial-gradient(circle at 50% 14%,' . $fill . ' 0 7%,transparent 7.5%),' .
                'radial-gradient(circle at 50% 86%,' . $fill . ' 0 7%,transparent 7.5%),' .
                'linear-gradient(' . $fill . ',' . $fill . ');' .
                'background-size:100% 100%,100% 100%,100% 14%;' .
                'background-position:0 0,0 0,0 43%;' .
                'background-repeat:no-repeat;';
            return $css;
        }
        if (strpos($css, 'clip-path') === false && $sw > 0) {
            $css .= 'border:' . $sw . 'px solid ' . $stroke . ';';
        }
        return $css;
    }
}
