<?php
/**
 * Deck helper — load, format, and seed slide data.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local;

defined('MOODLE_INTERNAL') || die();

class deck {

    const CANVAS_W       = 960;
    const CANVAS_H_16_9  = 540;
    const CANVAS_H_4_3   = 720;

    /**
     * Return [width, height] for the given aspect ratio string.
     */
    public static function canvas_dimensions(string $ratio): array {
        return match ($ratio) {
            '4:3'   => [self::CANVAS_W, self::CANVAS_H_4_3],
            default => [self::CANVAS_W, self::CANVAS_H_16_9],
        };
    }

    /**
     * Sanitize a hex colour string, returning a safe fallback on failure.
     */
    public static function sanitize_color(string $value): string {
        $value = trim($value);
        if (preg_match('/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/', $value)) {
            return strtolower($value);
        }
        return '#ffffff';
    }

    /**
     * Load all slides for a presentation, decoding JSON fields.
     *
     * @return array  Indexed array (sortorder ASC), each entry is an
     *                object with ->elements (array) and ->background (array).
     */
    public static function get_deck(int $slidesid): array {
        global $DB;

        $records = $DB->get_records('slides_slides', ['slidesid' => $slidesid], 'sortorder ASC');

        return array_map(static function ($row) {
            $row->elements   = json_decode($row->elements, true) ?? [];
            $row->background = json_decode($row->background, true) ?? ['color' => '#ffffff'];
            return $row;
        }, array_values($records));
    }

    /**
     * Check whether a presentation has any slides.
     */
    public static function is_empty(int $slidesid): bool {
        global $DB;
        return !$DB->record_exists('slides_slides', ['slidesid' => $slidesid]);
    }

    /**
     * Replace every slide of a presentation inside a single transaction.
     *
     * Shared by the web service and the SCORM importer so both write the very
     * same way.
     *
     * @param int $slidesid Presentation instance id.
     * @param array $slides Slides in save format: title / elements / background
     *                       (JSON string, transition already folded in).
     * @return int Number of slides stored.
     */
    public static function replace_deck(int $slidesid, array $slides): int {
        global $DB;

        $transaction = $DB->start_delegated_transaction();

        try {
            $DB->delete_records('slides_slides', ['slidesid' => $slidesid]);

            $sort = 0;
            foreach ($slides as $s) {
                $row = new \stdClass();
                $row->slidesid   = $slidesid;
                $row->sortorder  = $sort++;
                $row->title      = $s['title'] ?? '';
                $row->elements   = json_encode($s['elements'] ?? [], JSON_UNESCAPED_UNICODE);
                $row->background = $s['background']
                    ?? json_encode(['color' => '#ffffff'], JSON_UNESCAPED_UNICODE);
                $DB->insert_record('slides_slides', $row);
            }

            $DB->commit_delegated_transaction($transaction);
        } catch (\Throwable $e) {
            $transaction->rollback($e);
            throw $e;
        }

        return $sort;
    }

    /* ------------------------------------------------------------------
     *  Demo / seed helpers (used by the "create demo" button in F1)
     * ----------------------------------------------------------------*/

    /**
     * Insert a demo deck (5 slides) for the given presentation instance.
     * Deletes any existing slides first.
     */
    public static function create_demo_deck(int $slidesid): void {
        global $DB;

        $DB->delete_records('slides_slides', ['slidesid' => $slidesid]);

        $deck = self::demo_slides();
        $sort = 0;

        foreach ($deck as $slide) {
            $row = new \stdClass();
            $row->slidesid   = $slidesid;
            $row->sortorder  = $sort++;
            $row->title      = $slide['title'];
            $row->elements   = json_encode($slide['elements'], JSON_UNESCAPED_UNICODE);
            $row->background = json_encode($slide['background'], JSON_UNESCAPED_UNICODE);
            $DB->insert_record('slides_slides', $row);
        }
    }

    /**
     * Return the demo slide definitions (readable structure).
     */
    private static function demo_slides(): array {
        return [
            // Slide 1 — Title
            [
                'title'      => 'Portada',
                'background' => ['color' => '#1a1a2e'],
                'elements'   => [
                    [
                        'type' => 'text', 'x' => 120, 'y' => 160, 'w' => 720, 'h' => 90,
                        'text' => 'Presentación de Ejemplo',
                        'fontSize' => 52, 'color' => '#ffffff', 'align' => 'center', 'bold' => true,
                    ],
                    [
                        'type' => 'text', 'x' => 120, 'y' => 290, 'w' => 720, 'h' => 50,
                        'text' => 'Creada con mod_slides para Moodle',
                        'fontSize' => 26, 'color' => '#cccccc', 'align' => 'center', 'bold' => false,
                    ],
                ],
            ],
            // Slide 2 — What is mod_slides?
            [
                'title'      => '¿Qué es mod_slides?',
                'background' => ['color' => '#ffffff'],
                'elements'   => [
                    [
                        'type' => 'text', 'x' => 80, 'y' => 60, 'w' => 800, 'h' => 70,
                        'text' => '¿Qué es mod_slides?',
                        'fontSize' => 40, 'color' => '#1a1a2e', 'align' => 'left', 'bold' => true,
                    ],
                    [
                        'type' => 'text', 'x' => 80, 'y' => 160, 'w' => 800, 'h' => 320,
                        'text' => "• Editor de diapositivas integrado en Moodle\n"
                                . "• Crear presentaciones directamente en el curso\n"
                                . "• Formato nativo HTML5 (sin PowerPoint)\n"
                                . "• Navegación con teclado y ratón\n"
                                . "• Exportable a PPTX (próximamente)",
                        'fontSize' => 28, 'color' => '#333333', 'align' => 'left', 'bold' => false,
                    ],
                ],
            ],
            // Slide 3 — Two columns layout
            [
                'title'      => 'Dos columnas',
                'background' => ['color' => '#f8f9fa'],
                'elements'   => [
                    [
                        'type' => 'text', 'x' => 80, 'y' => 60, 'w' => 800, 'h' => 70,
                        'text' => 'Formato flexible',
                        'fontSize' => 40, 'color' => '#1a1a2e', 'align' => 'left', 'bold' => true,
                    ],
                    [
                        'type' => 'text', 'x' => 80, 'y' => 160, 'w' => 380, 'h' => 300,
                        'text' => "Izquierda\n\n• Texto libre\n• Imágenes\n• Formas",
                        'fontSize' => 26, 'color' => '#333333', 'align' => 'left', 'bold' => false,
                    ],
                    [
                        'type' => 'text', 'x' => 500, 'y' => 160, 'w' => 380, 'h' => 300,
                        'text' => "Derecha\n\n• Colores\n• Tamaños\n• Alineación",
                        'fontSize' => 26, 'color' => '#333333', 'align' => 'left', 'bold' => false,
                    ],
                ],
            ],
            // Slide 4 — Visual focus
            [
                'title'      => 'Diseño visual',
                'background' => ['color' => '#e8f4f8'],
                'elements'   => [
                    [
                        'type' => 'text', 'x' => 160, 'y' => 100, 'w' => 640, 'h' => 80,
                        'text' => 'Diseño visual',
                        'fontSize' => 48, 'color' => '#0d6efd', 'align' => 'center', 'bold' => true,
                    ],
                    [
                        'type' => 'text', 'x' => 120, 'y' => 230, 'w' => 720, 'h' => 120,
                        'text' => "Cada diapositiva es un lienzo de 960×540 píxeles.\n"
                                . "Los elementos se posicionan de forma absoluta\n"
                                . "y el todo se escala proporcionalmente al pantalla.",
                        'fontSize' => 26, 'color' => '#444444', 'align' => 'center', 'bold' => false,
                    ],
                    [
                        'type' => 'text', 'x' => 160, 'y' => 400, 'w' => 640, 'h' => 60,
                        'text' => '← Navega con las flechas del teclado →',
                        'fontSize' => 22, 'color' => '#888888', 'align' => 'center', 'bold' => false,
                    ],
                ],
            ],
            // Slide 5 — Closing
            [
                'title'      => 'Cierre',
                'background' => ['color' => '#1a1a2e'],
                'elements'   => [
                    [
                        'type' => 'text', 'x' => 120, 'y' => 180, 'w' => 720, 'h' => 100,
                        'text' => '¡Gracias!',
                        'fontSize' => 64, 'color' => '#ffffff', 'align' => 'center', 'bold' => true,
                    ],
                    [
                        'type' => 'text', 'x' => 120, 'y' => 320, 'w' => 720, 'h' => 50,
                        'text' => 'Próximamente: editor, imágenes, exportación…',
                        'fontSize' => 24, 'color' => '#aaaaaa', 'align' => 'center', 'bold' => false,
                    ],
                ],
            ],
        ];
    }
}
