<?php
/**
 * Server-side slide renderer: turns a deck into template data and viewer JSON.
 *
 * Shared by view.php (Moodle page) and the SCORM exporter, so both produce
 * exactly the same markup.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local;

defined('MOODLE_INTERNAL') || die();

class slide_renderer {

    /**
     * Build the per-slide template data consumed by mod_slides/viewer.
     *
     * @param array $deck Deck as returned by deck::get_deck(): objects with
     *                    ->elements (array) and ->background (array).
     * @return array List of entries: number, title, bg, bgimage, elements, isfirst.
     */
    public static function template_slides(array $deck): array {
        $slidetpldata = [];
        $isfirst = true;

        foreach ($deck as $i => $s) {
            $slidetpldata[] = [
                'number'   => $i + 1,
                'title'    => $s->title ?? '',
                'bg'       => deck::sanitize_color($s->background['color'] ?? '#ffffff'),
                'bgimage'  => $s->background['image'] ?? '',
                'elements' => self::template_elements($s->elements ?? []),
                'isfirst'  => $isfirst,
            ];
            $isfirst = false;
        }

        return $slidetpldata;
    }

    /**
     * Normalise a list of raw elements into template entries.
     *
     * @param array $elements Raw elements (decoded JSON).
     * @return array
     */
    public static function template_elements(array $elements): array {
        $out = [];

        foreach ($elements as $el) {
            $type = $el['type'] ?? 'text';
            $isshape = ($type === 'shape');
            $isimage = ($type === 'image');
            $isvideo = ($type === 'video');
            $ispdf = ($type === 'pdf');
            $isequation = ($type === 'equation');
            $ishtml = ($type === 'html');
            $isaudio = ($type === 'audio');
            $isembedvideo = false;
            $isdirectvideo = false;
            $embedurl = '';

            // HTML / embed markup already passed deck_sanitizer on save: it is
            // printed verbatim by the template (triple braces) so the element
            // also works in the SCORM package, which has no viewer.js.
            $htmlcode = $ishtml ? (string) ($el['text'] ?? '') : '';

            // Recorded audio (slides_media file area) — served through
            // pluginfile.php by the template's audio player.
            $audiourl = $isaudio ? (string) ($el['src'] ?? '') : '';

            if ($isvideo) {
                $src = $el['src'] ?? '';
                if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&?#]+)/', $src, $m)) {
                    $isembedvideo = true;
                    $embedurl = 'https://www.youtube.com/embed/' . $m[1] . '?rel=0';
                } elseif (preg_match('/vimeo\.com\/(\d+)/', $src, $m)) {
                    $isembedvideo = true;
                    $embedurl = 'https://player.vimeo.com/video/' . $m[1];
                } elseif (preg_match('/\.(mp4|webm|ogg)(\?.*)?$/i', $src)) {
                    $isdirectvideo = true;
                } else {
                    $isembedvideo = true;
                    $embedurl = $src;
                }
            }

            $innerstyle = '';
            if ($isshape) {
                // Preserve an empty fill (transparent) instead of coercing it
                // to #ffffff through sanitize_color().
                $fillraw = $el['fill'] ?? '#0d6efd';
                $fillcss = ($fillraw === '') ? 'transparent' : deck::sanitize_color($fillraw);
                $innerstyle = 'width:100%;height:100%;box-sizing:border-box;background:' .
                    $fillcss . ';' .
                    shapes::shape_clip($el['shape'] ?? 'rect', (int) ($el['strokeWidth'] ?? 0),
                        deck::sanitize_color($el['stroke'] ?? '#1a1a2e'), $fillcss);
            }

            // Compute text-decoration.
            $textdecoration = '';
            $ul = !empty($el['underline']);
            $st = !empty($el['strikethrough']);
            if ($ul && $st) {
                $textdecoration = 'text-decoration:underline line-through;';
            } else if ($ul) {
                $textdecoration = 'text-decoration:underline;';
            } else if ($st) {
                $textdecoration = 'text-decoration:line-through;';
            }

            // List rendering.
            $haslist = false;
            $listtag = '';
            $listitems = [];
            if (!empty($el['listType']) && $el['listType'] !== 'none') {
                $haslist = true;
                $listtag = ($el['listType'] === 'bullet') ? 'ul' : 'ol';
                $listitems = explode("\n", $el['text'] ?? '');
            }

            // Image style: plain contain by default, source-crop geometry when cropped.
            $opacitypct  = (int) ($el['opacity'] ?? 100);
            $borderradpx = (int) ($el['borderRadius'] ?? 0);
            $imgstyle = 'width:100%;height:100%;object-fit:contain;opacity:' . $opacitypct .
                '%;border-radius:' . $borderradpx . 'px;display:block;';
            $iscropped = false;
            $crop = $el['crop'] ?? null;
            if ($isimage && is_array($crop)) {
                $cw = (float) ($crop['w'] ?? 0);
                $ch = (float) ($crop['h'] ?? 0);
                if ($cw > 0 && $cw <= 1 && $ch > 0 && $ch <= 1) {
                    $iscropped = true;
                    $cx = (float) ($crop['x'] ?? 0);
                    $cy = (float) ($crop['y'] ?? 0);
                    $imgstyle = 'position:absolute;max-width:none;width:' . round(100 / $cw, 4) .
                        '%;height:' . round(100 / $ch, 4) .
                        '%;left:' . round(-$cx / $cw * 100, 4) .
                        '%;top:' . round(-$cy / $ch * 100, 4) .
                        '%;object-fit:fill;opacity:' . $opacitypct . '%;display:block;';
                }
            }

            // Equation flex alignment (the LaTeX lives in `text` and is rendered
            // client-side with katex from the data-tex attribute).
            $eqjustify = 'center';
            if (($el['align'] ?? 'left') === 'left') {
                $eqjustify = 'flex-start';
            } else if (($el['align'] ?? 'left') === 'right') {
                $eqjustify = 'flex-end';
            }

            $out[] = [
                'type'           => $type,
                'x'              => (int) ($el['x'] ?? 0),
                'y'              => (int) ($el['y'] ?? 0),
                'w'              => (int) ($el['w'] ?? 200),
                'h'              => (int) ($el['h'] ?? 40),
                'text'           => $el['text'] ?? '',
                'fontfamily'     => $el['fontfamily'] ?? 'sans-serif',
                'fontSize'       => (int) ($el['fontSize'] ?? 24),
                'color'          => deck::sanitize_color($el['color'] ?? '#000000'),
                'align'          => $el['align'] ?? 'left',
                'bold'           => !empty($el['bold']),
                'italic'         => !empty($el['italic']),
                'textdecoration' => $textdecoration,
                'shape'          => $el['shape'] ?? '',
                'fill'           => deck::sanitize_color($el['fill'] ?? '#0d6efd'),
                'stroke'         => deck::sanitize_color($el['stroke'] ?? '#1a1a2e'),
                'strokeWidth'    => (int) ($el['strokeWidth'] ?? 0),
                'isshape'        => $isshape,
                'isimage'        => $isimage,
                'isvideo'        => $isvideo,
                'ispdf'          => $ispdf,
                'isequation'     => $isequation,
                'ishtml'         => $ishtml,
                'htmlcode'       => $htmlcode,
                'isaudio'        => $isaudio,
                'audiourl'       => $audiourl,
                'eqjustify'      => $eqjustify,
                'isembedvideo'   => $isembedvideo,
                'isdirectvideo'  => $isdirectvideo,
                'embedurl'       => $embedurl,
                'innerstyle'     => $innerstyle,
                'src'            => $el['src'] ?? '',
                'alt'            => $el['alt'] ?? '',
                'pdftitle'       => $el['pdftitle'] ?? '',
                'opacity'        => (int) ($el['opacity'] ?? 100),
                'borderRadius'   => (int) ($el['borderRadius'] ?? 0),
                'imgstyle'       => $imgstyle,
                'iscropped'      => $iscropped,
                'haslist'        => $haslist,
                'listtag'        => $listtag,
                'listitems'      => $listitems,
            ];
        }

        return $out;
    }

    /**
     * Deck in the shape expected by the viewer JSON payload: transition
     * extracted from the background object.
     *
     * @param array $deck Deck as returned by deck::get_deck().
     * @return array
     */
    public static function viewer_slides(array $deck): array {
        $out = [];

        foreach ($deck as $s) {
            $bgobj = is_array($s->background) ? $s->background : ['color' => '#ffffff'];
            $transition = $bgobj['transition'] ?? 'none';
            unset($bgobj['transition']);

            $out[] = [
                'title'      => $s->title ?? '',
                'background' => $bgobj,
                'transition' => $transition,
                'elements'   => $s->elements ?? [],
            ];
        }

        return $out;
    }

    /**
     * JSON payload embedded in the viewer page.
     *
     * @param array $deck Deck as returned by deck::get_deck().
     * @return string
     */
    public static function viewer_json(array $deck): string {
        return json_encode(self::viewer_slides($deck), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
    }

    /**
     * Percentage of the progress bar for a deck.
     *
     * @param int $slidecount
     * @return int
     */
    public static function progressbar(int $slidecount): int {
        return $slidecount > 0 ? round(100 / $slidecount) : 0;
    }
}
