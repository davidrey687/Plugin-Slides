<?php
/**
 * PDF Resource upload helper — stores the attached PDF in the plugin's
 * `slides_pdf` file area (Moodle File API) and returns its pluginfile.php URL.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local;

defined('MOODLE_INTERNAL') || die();

use moodle_url;
use context_module;

class pdf_uploader {

    /** File area used exclusively for PDF resources. */
    const FILEAREA = 'slides_pdf';

    /** Maximum file size in bytes (100 MB). */
    const MAX_FILESIZE = 104857600;

    /**
     * Upload a PDF ($_FILES entry) to the module's slides_pdf file area.
     *
     * @param int    $cmid Course module ID.
     * @param array  $file $_FILES entry: tmp_name, name, size, type, error.
     * @return array ['url' => string, 'filename' => string, 'filesize' => int]
     * @throws \moodle_exception
     */
    public static function upload(int $cmid, array $file): array {
        global $USER;

        if (empty($file['tmp_name'])) {
            throw new \moodle_exception('pdfinvalidtype', 'mod_slides');
        }
        if (!empty($file['error'])) {
            throw new \moodle_exception('pdfuploaderror', 'mod_slides', '', $file['error']);
        }

        // Validate real MIME type from content (never trust the client).
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if ($mime !== 'application/pdf') {
            throw new \moodle_exception('pdfinvalidtype', 'mod_slides');
        }

        // Validate size.
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > self::MAX_FILESIZE) {
            throw new \moodle_exception('pdffiletoolarge', 'mod_slides', '',
                self::format_size(self::MAX_FILESIZE));
        }

        // Capability check — only editors may attach PDFs.
        $context = context_module::instance($cmid);
        require_capability('mod/slides:edit', $context);

        // Safe filename: original basename + timestamp + random suffix.
        $original = (string) ($file['name'] ?? 'documento.pdf');
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            $ext = 'pdf';
        }
        $basename = clean_param(pathinfo($original, PATHINFO_FILENAME), PARAM_FILE);
        if ($basename === '') {
            $basename = 'pdf';
        }
        $filename = $basename . '_' . time() . '_' . random_string(8) . '.' . $ext;

        // Store in the Moodle File API (plugin file area).
        $fs = get_file_storage();
        $fileRecord = [
            'contextid'   => $context->id,
            'component'   => 'mod_slides',
            'filearea'    => self::FILEAREA,
            'itemid'      => 0,
            'filepath'    => '/',
            'filename'    => $filename,
            'userid'      => $USER->id,
            'author'      => $USER->username,
            'license'     => 'allrightsreserved',
            'timecreated' => time(),
            'timemodified' => time(),
        ];

        $storedFile = $fs->create_file_from_pathname($fileRecord, $file['tmp_name']);
        if (!$storedFile) {
            throw new \moodle_exception('pdfstorefailed', 'mod_slides');
        }

        $url = moodle_url::make_pluginfile_url(
            $context->id,
            'mod_slides',
            self::FILEAREA,
            0,
            '/',
            $filename
        )->out(false);

        return [
            'url'      => $url,
            'filename' => $storedFile->get_filename(),
            'filesize' => $storedFile->get_filesize(),
        ];
    }

    /**
     * Format bytes as human-readable string.
     */
    private static function format_size(int $bytes): string {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 1) . ' GB';
        }
        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 1) . ' MB';
        }
        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 1) . ' KB';
        }
        return $bytes . ' bytes';
    }
}
