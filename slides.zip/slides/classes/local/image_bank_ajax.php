<?php
/**
 * AJAX endpoint that returns the local photo bank catalogue.
 *
 * Scans mod/slides/pix/stock/<category>/ on disk so new photos dropped into
 * the folder become available without rebuilding any JavaScript.
 *
 * Answers with a single clean JSON object.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// Buffer everything from the very start so stray notices never pollute
// the JSON response.
ob_start();

require_once(__DIR__ . '/../../../../config.php');

header('Content-Type: application/json; charset=utf-8');

function slides_bank_json(array $payload): void {
    if (ob_get_level() > 0) {
        ob_clean();
    }
    echo json_encode($payload);
    die;
}

try {
    require_login();

    global $CFG;

    $root = $CFG->dirroot . '/mod/slides/pix/stock';
    $base = $CFG->wwwroot . '/mod/slides/pix/stock/';

    if (!is_dir($root)) {
        slides_bank_json(['categories' => []]);
    }

    // Preferred display order; unknown folders are appended alphabetically.
    $preferred = ['usc', 'educacion', 'naturaleza', 'tecnologia', 'abstractos'];
    $folders = [];
    foreach (scandir($root) as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        if (is_dir($root . '/' . $entry)) {
            $folders[] = $entry;
        }
    }
    $ordered = [];
    foreach ($preferred as $p) {
        if (in_array($p, $folders, true)) {
            $ordered[] = $p;
        }
    }
    sort($folders);
    foreach ($folders as $f) {
        if (!in_array($f, $ordered, true)) {
            $ordered[] = $f;
        }
    }

    $stringmanager = get_string_manager();
    $categories = [];

    foreach ($ordered as $folder) {
        $dir = $root . '/' . $folder;
        $images = [];
        foreach (scandir($dir) as $file) {
            if (!preg_match('/\.(jpe?g|png|webp|gif)$/i', $file)) {
                continue;
            }
            $full = $dir . '/' . $file;
            $info = @getimagesize($full);
            if ($info === false) {
                continue;
            }
            $stem = pathinfo($file, PATHINFO_FILENAME);
            $thumb = $dir . '/thumbs/' . $stem . '.jpg';
            $url = $base . rawurlencode($folder) . '/' . rawurlencode($file);
            $images[] = [
                'file'  => $folder . '/' . $file,
                'name'  => $stem,
                'w'     => (int) $info[0],
                'h'     => (int) $info[1],
                'url'   => $url,
                'thumb' => is_file($thumb) ? $base . rawurlencode($folder) . '/thumbs/' . rawurlencode($stem) . '.jpg' : $url,
            ];
        }
        if (!$images) {
            continue;
        }

        $stringid = 'bankcat-' . $folder;
        if ($stringmanager->string_exists($stringid, 'mod_slides')) {
            $label = get_string($stringid, 'mod_slides');
        } else {
            $label = ucwords(str_replace(['-', '_'], ' ', $folder));
        }

        $categories[] = [
            'id'     => $folder,
            'label'  => $label,
            'images' => $images,
        ];
    }

    slides_bank_json(['categories' => $categories]);
} catch (\moodle_exception $e) {
    slides_bank_json(['error' => $e->getMessage()]);
} catch (\Throwable $e) {
    error_log('mod_slides image_bank_ajax: ' . $e->getMessage());
    slides_bank_json(['error' => get_string('errorloading', 'mod_slides')]);
}
