<?php
/**
 * Sanitisation of slide elements and slide records.
 *
 * Extracted from mod_slides\external so that the web services, the SCORM
 * importer and any future caller share exactly one validation routine.
 *
 * @package   mod_slides
 * @copyright 2026
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace mod_slides\local;

defined('MOODLE_INTERNAL') || die();

class deck_sanitizer {

    /**
     * Validate a CSS font-family value without duplicating the font bank list:
     * accept any plain/quoted family chain, but reject anything that could break
     * out of the declaration (braces, semicolons, parens, angle brackets...).
     *
     * @param string $value
     * @return string
     */
    public static function sanitize_fontfamily(string $value): string {
        $clean = trim($value);
        if ($clean === '' || strlen($clean) > 255) {
            return 'sans-serif';
        }
        $quoted = '(?:"[^"\r\n]{1,100}"|\'[^\'\r\n]{1,100}\')';
        $ident  = '[\p{L}\p{N}][\p{L}\p{N} ._-]{0,99}';
        $token  = '(?:' . $quoted . '|' . $ident . ')';
        if (preg_match('/^' . $token . '(?:\s*,\s*' . $token . ')*$/u', $clean) === 1) {
            return $clean;
        }
        return 'sans-serif';
    }

    /**
     * Validate an optional image crop rect given as source-image fractions.
     *
     * @param mixed $crop Raw crop (array with x/y/w/h) or anything else.
     * @return array|null Clean crop or null when there is no valid crop.
     */
    public static function sanitize_crop($crop) {
        if (!is_array($crop)) {
            return null;
        }
        $w = (float) ($crop['w'] ?? 0);
        $h = (float) ($crop['h'] ?? 0);
        if ($w <= 0 || $h <= 0 || $w > 1 || $h > 1) {
            return null;
        }
        $x = (float) ($crop['x'] ?? 0);
        $y = (float) ($crop['y'] ?? 0);
        $x = max(0.0, min($x, 1.0 - $w));
        $y = max(0.0, min($y, 1.0 - $h));
        return [
            'x' => round($x, 4),
            'y' => round($y, 4),
            'w' => round($w, 4),
            'h' => round($h, 4),
        ];
    }

    /**
     * Validate the destination URL of an interactive link element.
     *
     * Only navigation schemes that cannot execute script are accepted:
     * http(s), protocol-relative, mailto, tel and in-site paths (anchors,
     * query strings, pluginfile URLs). Anything else — most importantly
     * javascript: and data: — collapses to an empty string, so a crafted
     * deck can never run code in a student's browser when they click an
     * image, shape or button. Bare hosts (example.com/page) get the same
     * https:// auto-prefix the editor applies while typing.
     *
     * @param string $value Raw URL from the editor.
     * @return string Clean URL ('' when nothing safe remains).
     */
    public static function sanitize_url(string $value): string {
        $value = trim($value);
        if ($value === '') {
            return '';
        }

        // Strip control characters first so "java\tscript:" cannot sneak by.
        $probe = strtolower((string) preg_replace('/[\x00-\x20]+/', '', $value));
        if (preg_match('#^(javascript|vbscript|data):#', $probe)) {
            return '';
        }

        if (preg_match('#^(https?:)?//#i', $value)
                || preg_match('#^(mailto|tel):#i', $value)) {
            return $value;
        }

        // In-site targets: /path, #anchor, ?query=…
        if ($value[0] === '/' || $value[0] === '#' || $value[0] === '?') {
            return $value;
        }

        // Bare hostname without spaces (example.com/page, localhost:8080/…).
        if (!preg_match('/\s/', $value)
                && preg_match('#^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}(:\d+)?(/.*)?$#i', $value)) {
            return 'https://' . $value;
        }

        return '';
    }

    /**
     * Sanitise raw HTML / embed markup pasted by a teacher.
     *
     * Goal: keep the useful 90% (YouTube/Vimeo iframes, images, video/audio,
     * forms, div/span/p/a markup with inline styles) while removing anything
     * that can run script or navigate the page away (script/style/base/meta/
     * link tags, inline event handlers, javascript: URLs).
     *
     * @param string $html Raw markup.
     * @return string Clean markup (empty string when nothing usable remains).
     */
    public static function sanitize_html_code(string $html): string {
        $html = trim($html);
        if ($html === '' || strlen($html) > 200000) {
            return '';
        }

        if (!class_exists('DOMDocument')) {
            // Degraded fallback: drop the riskiest constructs only.
            $html = preg_replace('#<\s*(script|style|base|meta|link)\b[^>]*>.*?<\s*/\s*\1\s*>#is', '', $html);
            $html = preg_replace('#<\s*(script|style|base|meta|link)\b[^>]*/?>#is', '', $html);
            $html = preg_replace('/\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/is', '', $html);
            $html = preg_replace('/\s(href|src)\s*=\s*(["\'])\s*javascript:[^"\']*\2/is', ' $1="#"', $html);
            return $html;
        }

        $prev = libxml_use_internal_errors(true);
        $doc = new \DOMDocument();
        // The XML declaration pins UTF-8: without it libxml assumes ISO-8859-1
        // and turns accented characters into numeric entities.
        $wrapped = '<?xml encoding="utf-8" ?><div id="mod-slides-sanitize-root">' . $html . '</div>';
        // LIBXML_NONET stops libxml from fetching remote DTDs/entities.
        $ok = $doc->loadHTML($wrapped, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        if (!$ok) {
            return '';
        }

        // Never drop the document structure (html/head/body): <html> is the
        // document element, so removing it detaches the whole tree and
        // getElementById() below would find nothing (returning '' and wiping
        // the stored markup). Those nodes are never serialised anyway — only
        // the children of the sentinel root are — and their on* attributes
        // are stripped by the same loop.
        $drop = ['script', 'style', 'base', 'meta', 'link', 'title', 'noscript'];
        $xpath = new \DOMXPath($doc);

        foreach ($xpath->query('//*[local-name()]') as $node) {
            $tag = strtolower($node->nodeName);

            if (in_array($tag, $drop, true)) {
                $node->parentNode->removeChild($node);
                continue;
            }

            // Strip inline event handlers and dangerous URL schemes.
            $attrs = [];
            for ($i = 0; $i < $node->attributes->length; $i++) {
                $attrs[] = $node->attributes->item($i);
            }
            foreach ($attrs as $attr) {
                $name = strtolower($attr->name);
                $value = trim((string) $attr->value);

                if (strpos($name, 'on') === 0) {
                    $node->removeAttribute($attr->name);
                    continue;
                }
                if (in_array($name, ['href', 'src', 'xlink:href', 'action', 'formaction', 'data', 'poster'], true)) {
                    $scheme = strtolower((string) preg_replace('/\s+/', '', $value));
                    $scheme = preg_replace('/^(javascript|vbscript|data):.*$/is', '$1:', $scheme);
                    if (strpos($scheme, 'javascript:') === 0 || strpos($scheme, 'vbscript:') === 0) {
                        $node->removeAttribute($attr->name);
                        continue;
                    }
                    // data: URIs stay limited to images (avatars, inline SVG...).
                    if (strpos($scheme, 'data:') === 0 && !preg_match('#^data:image/#i', $value)) {
                        $node->removeAttribute($attr->name);
                        continue;
                    }
                }
                if ($name === 'srcdoc' && $node->nodeName !== 'iframe') {
                    $node->removeAttribute($attr->name);
                }
            }
        }

        $clean = '';
        $root = $doc->getElementById('mod-slides-sanitize-root');
        if ($root) {
            foreach (iterator_to_array($root->childNodes) as $child) {
                $clean .= $doc->saveHTML($child);
            }
        } else {
            // Safety net: serialise <body> instead of wiping the markup,
            // skipping the sentinel wrapper when the parser kept it around.
            $body = $doc->getElementsByTagName('body')->item(0);
            if ($body) {
                foreach (iterator_to_array($body->childNodes) as $child) {
                    if ($child->nodeType === XML_ELEMENT_NODE
                            && strtolower($child->nodeName) === 'div'
                            && $child->getAttribute('id') === 'mod-slides-sanitize-root') {
                        foreach (iterator_to_array($child->childNodes) as $inner) {
                            $clean .= $doc->saveHTML($inner);
                        }
                        continue;
                    }
                    $clean .= $doc->saveHTML($child);
                }
            }
        }
        return trim($clean);
    }

    /**
     * Sanitise a single element array, filling every field the editor expects.
     *
     * @param array $el Raw element.
     * @return array Clean element with a fixed key set.
     */
    /**
     * Whitelist an interactive action behaviour object: fixed kind, typed
     * fields, scheme-whitelisted URLs (external link and pop-up image).
     *
     * @param mixed $behavior Raw behaviour from the editor payload.
     * @return array Clean behaviour (empty array when not usable).
     */
    public static function sanitize_behavior($behavior): array {
        if (!is_array($behavior)) {
            return [];
        }
        $kind = in_array($behavior['kind'] ?? '', ['slide', 'url', 'label'], true)
            ? $behavior['kind'] : 'label';
        $clean = ['kind' => $kind];
        if ($kind === 'slide') {
            $clean['slide'] = (int) ($behavior['slide'] ?? 0);
        } else if ($kind === 'url') {
            $clean['url'] = self::sanitize_url((string) ($behavior['url'] ?? ''));
        } else {
            $clean['text'] = (string) ($behavior['text'] ?? '');
            $clean['img'] = self::sanitize_url((string) ($behavior['img'] ?? ''));
            $clean['video'] = self::sanitize_url((string) ($behavior['video'] ?? ''));
        }
        return $clean;
    }

    public static function sanitize_element(array $el): array {
        $clean = [
            'type'          => $el['type'] ?? 'text',
            'x'             => (int) ($el['x'] ?? 0),
            'y'             => (int) ($el['y'] ?? 0),
            'w'             => (int) ($el['w'] ?? 200),
            'h'             => (int) ($el['h'] ?? 40),
            'text'          => $el['text'] ?? '',
            'fontfamily'    => self::sanitize_fontfamily($el['fontfamily'] ?? 'sans-serif'),
            'fontSize'      => (int) ($el['fontSize'] ?? 24),
            'color'         => deck::sanitize_color($el['color'] ?? '#000000'),
            // Preserve an empty highlight as-is: sanitize_color('') would
            // coerce it to #ffffff, painting a white box behind new text.
            'highlight'     => ($el['highlight'] ?? '') !== '' ? deck::sanitize_color($el['highlight']) : '',
            'align'         => $el['align'] ?? 'left',
            'bold'          => !empty($el['bold']),
            'italic'        => !empty($el['italic']),
            'underline'     => !empty($el['underline']),
            'strikethrough' => !empty($el['strikethrough']),
            'listType'      => $el['listType'] ?? 'none',
            'shape'         => $el['shape'] ?? '',
            // Preserve an empty fill as-is (transparent): sanitize_color('')
            // would coerce it to #ffffff and paint a white box.
            'fill'          => (($el['fill'] ?? '#0d6efd') !== '') ? deck::sanitize_color($el['fill'] ?? '#0d6efd') : '',
            'stroke'        => deck::sanitize_color($el['stroke'] ?? '#1a1a2e'),
            'strokeWidth'   => (int) ($el['strokeWidth'] ?? 0),
            'angle'         => (int) ($el['angle'] ?? 0),
            'src'           => $el['src'] ?? '',
            'alt'           => $el['alt'] ?? '',
            'crop'          => self::sanitize_crop($el['crop'] ?? null),
            // Interactive link: scheme-whitelisted URL + fixed target window.
            'url'           => self::sanitize_url((string) ($el['url'] ?? '')),
            'target'        => in_array($el['target'] ?? '', ['_blank', '_self'], true)
                ? $el['target'] : '_blank',
            // Interactive action buttons (Genially-style).
            'actionId'      => (string) ($el['actionId'] ?? ''),
            'slideIdx'      => (int) ($el['slideIdx'] ?? 0),
            'label'         => (string) ($el['label'] ?? ''),
            'bg'            => deck::sanitize_color((string) ($el['bg'] ?? '#0d6efd')),
            'behavior'      => self::sanitize_behavior($el['behavior'] ?? null),
            'opacity'       => (int) ($el['opacity'] ?? 100),
            'borderRadius'  => (int) ($el['borderRadius'] ?? 0),
            'points'        => $el['points'] ?? [],
            // Pencil fill used by imported vector shapes; empty = stroke only.
            // Kept separate from `fill` so legacy drawings (which never set
            // it) are not suddenly painted over after a save round-trip.
            'pathfill'      => (($el['pathfill'] ?? '') !== '') ? deck::sanitize_color($el['pathfill']) : '',
            'pdftitle'      => $el['pdftitle'] ?? '',
            'background'    => $el['background'] ?? '',
            'charttype'     => $el['charttype'] ?? 'bar',
            'title'         => $el['title'] ?? '',
            'labels'        => $el['labels'] ?? '',
            'values'        => $el['values'] ?? '',
            'titleColor'    => $el['titleColor'] ?? '#1a1a2e',
            'valueColor'    => $el['valueColor'] ?? '#333333',
            'bgColor'       => $el['bgColor'] ?? '#ffffff',
            'shadowEnabled' => !empty($el['shadowEnabled']),
            'shadowColor'   => $el['shadowColor'] ?? '#00000080',
            'shadowBlur'    => (int) ($el['shadowBlur'] ?? 0),
            'shadowX'       => (int) ($el['shadowX'] ?? 0),
            'shadowY'       => (int) ($el['shadowY'] ?? 0),
            // Click-to-reveal animation: order 0 = not animated; type is a
            // strict whitelist so nothing else ever reaches the viewer.
            'animOrder'     => max(0, (int) ($el['animOrder'] ?? 0)),
            'animType'      => in_array($el['animType'] ?? '', ['appear', 'fade', 'up'], true) ? $el['animType'] : '',
        ];

        // HTML / embed elements carry raw markup in `text`: scrub it server-side
        // so scripts and inline handlers never reach the viewer or the SCORM
        // package (which prints the markup verbatim).
        if (($clean['type'] ?? '') === 'html') {
            $clean['text'] = self::sanitize_html_code((string) $clean['text']);
        }

        // Omit the crop key entirely when there is no valid crop: the WS
        // return structure only accepts an object (or nothing) for it.
        if ($clean['crop'] === null) {
            unset($clean['crop']);
        }

        return $clean;
    }

    /**
     * Sanitise a whole deck given in save format:
     * [ ['title' =>, 'sortorder' =>, 'elements' => [], 'background' => string|array, 'transition' =>], ... ]
     *
     * The transition is folded back into the background JSON exactly like
     * external::save_deck() does, so the result can be stored as-is.
     *
     * @param array $slides Slides in save format.
     * @return array Clean slides in save format.
     */
    public static function sanitize_slides(array $slides): array {
        $out = [];

        foreach ($slides as $s) {
            if (!is_array($s)) {
                continue;
            }

            $elements = [];
            foreach (($s['elements'] ?? []) as $el) {
                if (is_array($el)) {
                    $elements[] = self::sanitize_element($el);
                }
            }

            $bg = $s['background'] ?? [];
            if (is_string($bg)) {
                $bg = json_decode($bg, true) ?? [];
            }
            if (!is_array($bg)) {
                $bg = [];
            }
            $bg['transition'] = $s['transition'] ?? ($bg['transition'] ?? 'none');
            if (!isset($bg['color']) || $bg['color'] === '') {
                $bg['color'] = '#ffffff';
            }

            $out[] = [
                'title'      => clean_param($s['title'] ?? '', PARAM_TEXT),
                'sortorder'  => (int) ($s['sortorder'] ?? 0),
                'elements'   => $elements,
                'background' => json_encode($bg, JSON_UNESCAPED_UNICODE),
                'transition' => $s['transition'] ?? 'none',
            ];
        }

        return $out;
    }
}
